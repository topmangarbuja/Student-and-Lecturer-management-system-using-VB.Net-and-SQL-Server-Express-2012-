﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormStudentModule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormStudentModule))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.StudentModuleAddNew1 = New ControlLibrary_IMS.StudentModuleAddNew()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.StudentModuleSearch1 = New ControlLibrary_IMS.StudentModuleSearch()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.ImageList = Me.ImageList1
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1191, 616)
        Me.TabControl1.TabIndex = 0
        Me.TabControl1.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.StudentModuleAddNew1)
        Me.TabPage1.ImageIndex = 3
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1183, 584)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Add new"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'StudentModuleAddNew1
        '
        Me.StudentModuleAddNew1.AutoScroll = True
        Me.StudentModuleAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.StudentModuleAddNew1.BackgroundImage = CType(resources.GetObject("StudentModuleAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.StudentModuleAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentModuleAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentModuleAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentModuleAddNew1.Location = New System.Drawing.Point(3, 3)
        Me.StudentModuleAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.StudentModuleAddNew1.Name = "StudentModuleAddNew1"
        Me.StudentModuleAddNew1.Size = New System.Drawing.Size(1175, 576)
        Me.StudentModuleAddNew1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.StudentModuleSearch1)
        Me.TabPage2.ImageIndex = 1
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1183, 589)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Search"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'StudentModuleSearch1
        '
        Me.StudentModuleSearch1.BackColor = System.Drawing.Color.Transparent
        Me.StudentModuleSearch1.BackgroundImage = CType(resources.GetObject("StudentModuleSearch1.BackgroundImage"), System.Drawing.Image)
        Me.StudentModuleSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentModuleSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentModuleSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentModuleSearch1.Location = New System.Drawing.Point(3, 3)
        Me.StudentModuleSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.StudentModuleSearch1.Name = "StudentModuleSearch1"
        Me.StudentModuleSearch1.Size = New System.Drawing.Size(1175, 581)
        Me.StudentModuleSearch1.TabIndex = 0
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "windows_view_icon [www.imagesplitter.net].png")
        Me.ImageList1.Images.SetKeyName(1, "1417093445_search-24.png")
        Me.ImageList1.Images.SetKeyName(2, "1431585835_Add-Male-User.png")
        Me.ImageList1.Images.SetKeyName(3, "1431586047_698913-icon-81-document-add-24.png")
        '
        'FormStudentModule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1191, 616)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormStudentModule"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Student Module"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents StudentModuleAddNew1 As ControlLibrary_IMS.StudentModuleAddNew
    Friend WithEvents StudentModuleSearch1 As ControlLibrary_IMS.StudentModuleSearch
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
End Class
