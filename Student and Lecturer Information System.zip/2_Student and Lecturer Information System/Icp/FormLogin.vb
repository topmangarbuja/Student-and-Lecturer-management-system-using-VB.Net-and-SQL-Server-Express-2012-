﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class FormLogin

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    'New instance of LoginAccess Class
    Private loginAccess As New LoginAccess

    'Error capturing variable
    Dim strExceptionGetUserInfoAndCheckForActive As String

    'CLICK EVENT TO LOGIN TO SYSTEM
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        'Check if textboxes are empty
        If txtUsername.Text.Trim.Length > 0 And txtPassword.Text.Trim.Length > 0 Then
            'Check if connection is established
            If loginAccess.HasConnection = True Then
                'Check if user is authenticated 
                If IsAuthenticated() = True Then
                    'Call a method to get info and check active state of the user
                    GetUserInfoAndCheckForActive()
                    'Check if error message is capture while calling above GetUserInfoAndCheckForActive Method
                    If strExceptionGetUserInfoAndCheckForActive <> "" Then
                        'Show error message
                        MsgBox(strExceptionGetUserInfoAndCheckForActive, MsgBoxStyle.Exclamation, "LOGIN FAILED")

                        'Set variable to nothing
                        strExceptionGetUserInfoAndCheckForActive = Nothing

                        'Call TextBoxClear method
                        ClearTextFields()

                        'Get out of this procedure
                        Exit Sub
                    End If
                    ChangeUserLastLoginDate()
                    Using objPrgForm As New FormProgressBar
                        objPrgForm.ShowDialog(Me)
                    End Using
                    'Using objFormManageUser As New FormManageUser
                    '    objFormManageUser.ShowDialog(Me)
                    'End Using
                End If
            End If
        Else
            'Display error message
            MessageBox.Show("Please enter required entry.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    'CLICK EVENT TO CLOSE THE APPLICATION
    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    'CHECK WHETHER THE USER IS AUTHENTICATED OR NOT
    Private Function IsAuthenticated() As Boolean
        'Clear existing records
        If loginAccess.objDataSetLogin IsNot Nothing Then
            loginAccess.objDataSetLogin.Clear()
        End If

        'Send username and password to check for login
        loginAccess.RunQueryToLogin(txtUsername.Text, txtPassword.Text)

        'Check for login errors or login pass or invalid user credentials
        If loginAccess.strExceptionRunQueryToLogin <> "" Then
            'Show error message
            MsgBox(loginAccess.strExceptionRunQueryToLogin, MsgBoxStyle.Critical, "LOGIN ERROR")

            'Set the variable to nothing
            loginAccess.strExceptionRunQueryToLogin = Nothing

            Return False
        ElseIf loginAccess.objDataSetLogin.Tables(0).Rows(0).Item("UserCount") = 1 Then
            Return True
        Else
            'Show invalid login message
            MsgBox("Invalid user credentials.", MsgBoxStyle.Critical, "LOGIN FAILED.")

            'Clear textboxes
            ClearTextFields()
            Return False
        End If
    End Function


    'CLEAR TEXTBOXES AND SET FOCUS ON USERNAME TEXTBOX
    Private Sub ClearTextFields()
        'Clear the textboxes and make focus in Username Textbox
        txtUsername.Text = String.Empty
        txtPassword.Text = String.Empty
        txtUsername.Focus()
    End Sub

    'GET THE BASIC INFORMATION ABOUT CURRENT LOGIN USER
    Private Sub GetUserInfoAndCheckForActive()
        'strUsername = txtUsername.Text
        GblAccessItem.gstrUsername = txtUsername.Text

        'Clear existing records
        If loginAccess.objDataSet IsNot Nothing Then
            loginAccess.objDataSet.Clear()
        End If

        'Call method of LoginAccess class to get user info as well as to check whether the account is active or not
        loginAccess.RunQueryAndFillDataSet("SELECT Type, [Last Login Date] " & _
        "FROM ADMIN " & _
        "WHERE Username='" & GblAccessItem.gstrUsername & "' " & _
        "AND Active=1")

        'Check for errors
        If loginAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(loginAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation, "LOGIN ERROR")

            'Set the variable to nothing
            loginAccess.strExceptionRunQueryAndFillDataSet = Nothing
        ElseIf loginAccess.objDataSet.Tables(0).Rows.Count = 1 Then
            For Each i As Object In loginAccess.objDataSet.Tables(0).Rows
                'strUsername = i.Item("Username")
                GblAccessItem.gstrType = i.item("Type")
                GblAccessItem.gdtmLastLoginDate = i.item("Last Login Date")
            Next
        ElseIf loginAccess.objDataSet.Tables(0).Rows.Count = 0 Then
            'Capture manual error message
            strExceptionGetUserInfoAndCheckForActive = "Your account is not active. Contact administrator to activate it."
        End If
    End Sub


    'UPDATE THE USER'S LAST LOGIN DATETIME WITH CURRENT DATETIME
    Private Sub ChangeUserLastLoginDate()
        'Create a sql query text
        Dim strCommand As String = "UPDATE ADMIN " & _
        "SET [Last Login Date]=GetDate() " & _
        "WHERE Username= @userName"

        'Create a new command
        Dim objCommand As New SqlCommand
        objCommand.CommandText = strCommand

        'Add a parameter
        objCommand.Parameters.AddWithValue("@userName", GblAccessItem.gstrUsername)

        'Call RunQuery method to set current date and time to LastLoginDate field
        loginAccess.RunQuery(objCommand)

        If loginAccess.strExceptionRunQuery <> "" Then
            'Show error message
            MsgBox(loginAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "ERROR OCCURED WHILE CHANGING LAST LOGIN DATE")

            'Set the variable to nothing
            loginAccess.strExceptionRunQuery = Nothing
        ElseIf loginAccess.intCountRecord = 1 Then
            'Do nothing
        End If
    End Sub

    'KEY PRESS EVENT OF USERNAME TEXTBOX
    Private Sub txtUsername_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUsername.KeyPress
        'Donot allow white spaces in textbox
        If Char.IsWhiteSpace(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    'KEY PRESS EVENT OF PASSWORD TEXTBOX
    Private Sub txtPassword_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPassword.KeyPress
        'Donot allow white spaces in textbox
        If Char.IsWhiteSpace(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
End Class
