﻿Imports ClassLibrary_IMS

Public Class FormAccount
    'New instance of LoginAccess Class
    Private loginAccess As New LoginAccess


    'FORMCLOSED EVENT TO CLOSE THE PREVIOUS LOGIN AND PROGESSBAR FORM-OCCURED AFTER FORMACCOUNT FORM IS CLOSED
    Private Sub FormAccount_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        '  Me.Close()
    End Sub

    'CHANGE THE ACCEPT BUTTON OF THE FORM BASED ON TAB PAGE SELECTED
    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedIndex = 1 Then
            Me.AcceptButton = btnApply

            'Set focus on the old password textbox
            txtOldPassword.Focus()
        Else
            Me.AcceptButton = Nothing
        End If
    End Sub










    'TAB PAGE 1:USER_PROFILE RELATED EVENTS AND SUBS
    Private Sub FormAccount_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Make the following new size to window size
        Me.Size = New Size(427, 186)

        'Retrieve the Username, Type and Lastlogindate from Shared variable
        txtUsername.Text = GblAccessItem.gstrUsername
        txtType.Text = GblAccessItem.gstrType
        txtLastLoginDate.Text = GblAccessItem.gdtmLastLoginDate.ToLongDateString & "  |  " & GblAccessItem.gdtmLastLoginDate.ToLongTimeString
    End Sub

    'ENTER EVENT OF USER PROFILE TAB PAGE
    Private Sub tabUserProfile_Enter(sender As Object, e As EventArgs) Handles tabUserProfile.Enter
        'Change the size of the window
        Me.Size = New Size(427, 186)
    End Sub






    'TAB PAGE 2:SETTINGS RELATED EVENT OR SUBS
    'ENTER EVENT OF SETTINGS TAB PAGE
    Private Sub tabSettings_Enter(sender As Object, e As EventArgs) Handles tabPassword.Enter
        'Change the size of the window
        Me.Size = New Size(430, 245)
    End Sub

    'SHOW OR HIDE THE PASSWORD TEXTBOX CHARACTER
    Private Sub chkShowPassword_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowPassword.CheckedChanged
        If chkShowPassword.Checked = True Then
            'Show password in the TextBox
            txtOldPassword.UseSystemPasswordChar = False
            txtNewPassword.UseSystemPasswordChar = False
            txtConfirmPassword.UseSystemPasswordChar = False
        Else
            'Hide password in the TextBox
            txtOldPassword.UseSystemPasswordChar = True
            txtNewPassword.UseSystemPasswordChar = True
            txtConfirmPassword.UseSystemPasswordChar = True
        End If

    End Sub

    'CLICK EVENT OF APPLY BUTTON
    Private Sub btnApply_Click(sender As Object, e As EventArgs) Handles btnApply.Click
        If txtOldPassword.Text.Trim.Length > 0 And txtNewPassword.Text.Trim.Length > 0 And txtConfirmPassword.Text.Length > 0 Then
            If txtNewPassword.Text.Equals(txtConfirmPassword.Text) Then
                If IsAuthenticated() = True Then
                    loginAccess.SetPassword(txtUsername.Text, txtNewPassword.Text)

                    'Check for error
                    If loginAccess.strExceptionSetPassword <> "" Then
                        'Show error message
                        MsgBox(loginAccess.strExceptionSetPassword, MsgBoxStyle.Critical)

                        'Set variable to nothing
                        loginAccess.strExceptionSetPassword = Nothing
                    ElseIf loginAccess.intCountRecord = 1 Then
                        'Show successfully set message
                        MsgBox("New password is successfully set up.", MsgBoxStyle.Information)

                        'Clear the textboxes and make focus in Old Password Textbox
                        txtOldPassword.Text = String.Empty
                        txtNewPassword.Text = String.Empty
                        txtConfirmPassword.Text = String.Empty
                        txtOldPassword.Focus()
                    End If
                End If
            Else
                'Show error message
                MsgBox("New passwords do not match.", MsgBoxStyle.Exclamation)

                'Clear the textboxes and make focus in New Password Textbox
                txtNewPassword.Text = String.Empty
                txtConfirmPassword.Text = String.Empty
                txtNewPassword.Focus()
            End If
            'If loginAccess.HasConnection = True Then

            'End If
        Else
            'Display error message
            MessageBox.Show("Please enter data.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    'METHOD-CHECK WHETHER USER IS AUTHENTICATED OR NOT
    Private Function IsAuthenticated() As Boolean
        'Clear existing records
        If loginAccess.objDataSetLogin IsNot Nothing Then
            loginAccess.objDataSetLogin.Clear()
        End If

        'Send username and typed text to check for login
        loginAccess.RunQueryToLogin(txtUsername.Text, txtOldPassword.Text)

        'Check for login errors or login pass or invalid user credentials
        If loginAccess.strExceptionRunQueryToLogin <> "" Then
            'Show error message
            MsgBox(loginAccess.strExceptionRunQueryToLogin, MsgBoxStyle.Critical, "Query Execution")

            'Set the variable to nothing
            loginAccess.strExceptionRunQueryToLogin = Nothing

            Return False
        ElseIf loginAccess.objDataSetLogin.Tables(0).Rows(0).Item("UserCount") = 1 Then
            Return True
        Else
            'Show invalid login message
            MsgBox("Old password is invalid.", MsgBoxStyle.Critical, "LOGIN FAILED.")

            'Clear the textboxes and make focus in Old Password Textbox
            txtOldPassword.Text = String.Empty
            txtOldPassword.Focus()
            Return False
        End If
    End Function

    'KEYPRESS EVENT OF TEXTBOXES
    Private Sub txtTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewPassword.KeyPress, txtOldPassword.KeyPress, txtConfirmPassword.KeyPress
        'Donot allow white spaces in the textboxes
        If Char.IsWhiteSpace(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub


    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear the textboxes and make focus in Old Password Textbox
        txtOldPassword.Text = String.Empty
        txtNewPassword.Text = String.Empty
        txtConfirmPassword.Text = String.Empty
        txtOldPassword.Focus()
    End Sub
End Class
