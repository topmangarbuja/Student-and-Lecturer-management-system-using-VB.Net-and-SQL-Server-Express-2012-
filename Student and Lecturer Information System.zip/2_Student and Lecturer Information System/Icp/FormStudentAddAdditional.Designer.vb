﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormStudentAddAdditional
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormStudentAddAdditional))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.StudentAddPhone1 = New ControlLibrary_IMS.StudentAddPhone()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.StudentAddEmail1 = New ControlLibrary_IMS.StudentAddEmail()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.StudentAdditionalView1 = New ControlLibrary_IMS.StudentAdditionalView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ImageList = Me.ImageList1
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1013, 623)
        Me.TabControl1.TabIndex = 0
        Me.TabControl1.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.StudentAddPhone1)
        Me.TabPage1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.ImageIndex = 1
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Size = New System.Drawing.Size(1005, 596)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Phone Number"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'StudentAddPhone1
        '
        Me.StudentAddPhone1.AutoScroll = True
        Me.StudentAddPhone1.BackColor = System.Drawing.Color.Transparent
        Me.StudentAddPhone1.BackgroundImage = CType(resources.GetObject("StudentAddPhone1.BackgroundImage"), System.Drawing.Image)
        Me.StudentAddPhone1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentAddPhone1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentAddPhone1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentAddPhone1.Location = New System.Drawing.Point(4, 4)
        Me.StudentAddPhone1.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.StudentAddPhone1.Name = "StudentAddPhone1"
        Me.StudentAddPhone1.Size = New System.Drawing.Size(995, 586)
        Me.StudentAddPhone1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.StudentAddEmail1)
        Me.TabPage2.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.ImageIndex = 2
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Size = New System.Drawing.Size(1005, 596)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Email Address"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'StudentAddEmail1
        '
        Me.StudentAddEmail1.AutoScroll = True
        Me.StudentAddEmail1.BackColor = System.Drawing.Color.Transparent
        Me.StudentAddEmail1.BackgroundImage = CType(resources.GetObject("StudentAddEmail1.BackgroundImage"), System.Drawing.Image)
        Me.StudentAddEmail1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentAddEmail1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentAddEmail1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentAddEmail1.Location = New System.Drawing.Point(4, 4)
        Me.StudentAddEmail1.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.StudentAddEmail1.Name = "StudentAddEmail1"
        Me.StudentAddEmail1.Size = New System.Drawing.Size(995, 586)
        Me.StudentAddEmail1.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.StudentAdditionalView1)
        Me.TabPage4.ImageIndex = 5
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1005, 596)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "View"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'StudentAdditionalView1
        '
        Me.StudentAdditionalView1.BackColor = System.Drawing.Color.Transparent
        Me.StudentAdditionalView1.BackgroundImage = CType(resources.GetObject("StudentAdditionalView1.BackgroundImage"), System.Drawing.Image)
        Me.StudentAdditionalView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentAdditionalView1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentAdditionalView1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentAdditionalView1.Location = New System.Drawing.Point(0, 0)
        Me.StudentAdditionalView1.Margin = New System.Windows.Forms.Padding(4)
        Me.StudentAdditionalView1.Name = "StudentAdditionalView1"
        Me.StudentAdditionalView1.Size = New System.Drawing.Size(1003, 594)
        Me.StudentAdditionalView1.TabIndex = 0
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "1431585835_Add-Male-User.png")
        Me.ImageList1.Images.SetKeyName(1, "1431591250_phone-24.png")
        Me.ImageList1.Images.SetKeyName(2, "1431591408_mail-icon-24.png")
        Me.ImageList1.Images.SetKeyName(3, "1431596915_mail-24.png")
        Me.ImageList1.Images.SetKeyName(4, "image [www.imagesplitter.net] (11).png")
        Me.ImageList1.Images.SetKeyName(5, "windows_view_icon [www.imagesplitter.net].png")
        Me.ImageList1.Images.SetKeyName(6, "1431597980_user_accounts [www.imagesplitter.net].png")
        '
        'FormStudentAddAdditional
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1013, 623)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "FormStudentAddAdditional"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Student Additional"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents StudentAddPhone1 As ControlLibrary_IMS.StudentAddPhone
    Friend WithEvents StudentAddEmail1 As ControlLibrary_IMS.StudentAddEmail
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents StudentAdditionalView1 As ControlLibrary_IMS.StudentAdditionalView
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
End Class
