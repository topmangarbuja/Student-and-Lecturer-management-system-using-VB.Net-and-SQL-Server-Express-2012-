﻿Imports ClassLibrary_IMS

Public Class FormMain
    Private WithEvents formStudentSearch As New FormStudentSearch
    Private WithEvents formLecturerSearch As New FormLecturerSearch
    Private WithEvents formModuleSearch As New FormModuleSearch
    Private WithEvents formGuardianSearch As New FormGuardianSearch
    Private WithEvents formBookSearch As New FormBookSearch
    Private WithEvents formBookIssueSearch As New FormBookIssueSearch
    'Dim color As New Color

    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        MenuStrip1.Renderer = New MyToolStripProfessionalRenderer()
    End Sub


    'FORMCLOSED EVENT TO CLOSE THE PREVIOUS LOGIN AND PROGESSBAR FORM-OCCURED AFTER MAIN FORM IS CLOSED
    Private Sub FormMain_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        'Close the Progressbar and Login Form
        FormProgressBar.Close()
        FormLogin.Close()

        'Make sure that the search window also get closed
        formStudentSearch.Close()
        formLecturerSearch.Close()
        formModuleSearch.Close()
        formGuardianSearch.Close()
        formBookSearch.Close()
        formBookIssueSearch.Close()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'Close the application
        Me.Close()
    End Sub

    Private Sub FormMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure that you want to close the application?", Me.Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) _
            = MsgBoxResult.Yes Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If
    End Sub

    'Private Sub FormMain_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
    '    If (e.Control AndAlso e.Alt AndAlso e.KeyCode = Keys.A) Then
    '        'Open the Student Admission form
    '        Using objStudentAdmission As New FormStudentAdmission
    '            objStudentAdmission.ShowDialog(Me)
    '        End Using
    '    ElseIf (e.Control AndAlso e.KeyCode = Keys.S AndAlso e.KeyCode = Keys.A) Then
    '        'Open the Student Additional form
    '        Using objStudentAddAdditional As New FormStudentAddAdditional
    '            objStudentAddAdditional.ShowDialog(Me)
    '        End Using
    '    ElseIf (e.Control AndAlso e.KeyCode = Keys.S AndAlso e.KeyCode = Keys.M) Then
    '        'Open the Student Module form
    '        Using objStudentModule As New FormStudentModule
    '            objStudentModule.ShowDialog(Me)
    '        End Using
    '    ElseIf (e.Control AndAlso (e.KeyCode = Keys.L + Keys.A)) Then
    '        'Open the Lecturer Additional form
    '        Using objLecturerAddAdditional As New FormLecturerAddAdditional
    '            objLecturerAddAdditional.ShowDialog(Me)
    '        End Using
    '        'AddLecturerAdditionalToolStripMenuItem_Click(Nothing, Nothing)
    '    ElseIf (e.Control AndAlso (e.KeyCode = Keys.L + Keys.M)) Then
    '        'Open the Lecturer Module form
    '        Using objLecturerModule As New FormLecturerModule
    '            objLecturerModule.ShowDialog(Me)
    '        End Using
    '        'AddLecturerCurrentModuleToolStripMenuItem_Click(Nothing, Nothing)
    '    End If

    'End Sub

    'Private Sub FormMain_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
    '    'If Keys.ControlKey AndAlso Keys.Alt AndAlso Keys.KeyCode = Keys.A Then
    '    '    'Open the Student Admission form
    '    '    Using objStudentAdmission As New FormStudentAdmission
    '    '        objStudentAdmission.ShowDialog(Me)
    '    '    End Using
    '    'ElseIf Keys.ControlKey AndAlso Keys.KeyCode = Keys.S AndAlso Keys.KeyCode = Keys.A Then
    '    '    'Open the Student Additional form
    '    '    Using objStudentAddAdditional As New FormStudentAddAdditional
    '    '        objStudentAddAdditional.ShowDialog(Me)
    '    '    End Using
    '    'ElseIf Keys.ControlKey AndAlso Keys.KeyCode = Keys.L AndAlso Keys.KeyCode = Keys.M Then
    '    '    ''Open the Student Module form
    '    '    'Using objStudentModule As New FormStudentModule
    '    '    '    objStudentModule.ShowDialog(Me)
    '    '    'End Using
    '    '    AddLecturerCurrentModuleToolStripMenuItem_Click(Nothing, Nothing)
    '    'End If

    '    'End If
    '    'If Keys.Control Then
    '    '    If Keys.Control + Keys.KeyCode = Keys.L Then
    '    '        If Keys.Control + Keys.KeyCode = Keys.L + Keys.KeyCode = Keys.M Then
    '    '            AddLecturerCurrentModuleToolStripMenuItem_Click(Nothing, Nothing)
    '    '        End If
    '    '    End If
    '    '    ''Open the Student Module form
    '    '    'Using objStudentModule As New FormStudentModule
    '    '    '    objStudentModule.ShowDialog(Me)
    '    '    'End Using

    '    'End If
    'End Sub

    'Private Sub FormMain_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
    '    'If Keys.Control AndAlso Keys.Alt AndAlso Keys.KeyCode = Keys.A Then
    '    '    'Open the Student Admission form
    '    '    Using objStudentAdmission As New FormStudentAdmission
    '    '        objStudentAdmission.ShowDialog(Me)
    '    '    End Using
    '    'ElseIf Keys.Control AndAlso Keys.KeyCode = Keys.S AndAlso Keys.KeyCode = Keys.A Then
    '    '    'Open the Student Additional form
    '    '    Using objStudentAddAdditional As New FormStudentAddAdditional
    '    '        objStudentAddAdditional.ShowDialog(Me)
    '    '    End Using
    '    'End If
    'End Sub

    'FORM LOAD EVENT
    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Change Label on the status bar
        ToolStripStatusLabel3.Text = "LOGIN: " & GblAccessItem.gstrUsername

        'Hide this menu 
        G0T0ToolStripMenuItem.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ToolStripStatusLabel2.Text = Now.ToLongDateString & " | " & Now.ToLongTimeString
    End Sub

    'DROPDOWNOPENED EVENT OF FILETOOL STRIPMENUITEM
    Private Sub FILEToolStripMenuItem_DropDownOpened(sender As Object, e As EventArgs) Handles FILEToolStripMenuItem.DropDownOpened
        If Not String.Compare(GblAccessItem.gstrType, "admin1", True) = 0 Then
            SettingsToolStripMenuItem.DropDownItems.Remove(ManageUserToolStripMenuItem)
            SettingsToolStripMenuItem.DropDownItems.Remove(BackupRestoreToolStripMenuItem)
        End If
        'If Not GblAccessItem.gstrType.ToLower = "admin2" Then
        '    SettingsToolStripMenuItem.DropDownItems.Remove(ManageUserToolStripMenuItem)
        'End If
    End Sub


    Private Sub ManageUserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageUserToolStripMenuItem.Click
        'Open the manager user form
        Using objFormManagerUser As New FormManageUser
            objFormManagerUser.ShowDialog()
        End Using
    End Sub

    Private Sub AddStudentAdditionalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddStudentAdditionalToolStripMenuItem.Click
        'Open the Student Additional form
        Using objFormStudentAddAdditional As New FormStudentAddAdditional
            objFormStudentAddAdditional.ShowDialog(Me)
        End Using
    End Sub

    Private Sub AddLecturerAdditionalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddLecturerAdditionalToolStripMenuItem.Click
        'Open the Form Additional form
        Using objFormLecturerAddAdditional As New FormLecturerAddAdditional
            objFormLecturerAddAdditional.ShowDialog(Me)
        End Using
    End Sub

    Private Sub AccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProfileToolStripMenuItem.Click
        'Open the Form Account form
        Using objFormAccount As New FormAccount
            objFormAccount.ShowDialog(Me)
        End Using
    End Sub




    'LIST OF MENUITEM CLICK EVENT TO OPEN AN SEPARATE SEARCH WINDOW

    'OPEN THE STUDENT SEARCH WINDOW
    Private Sub SearchStudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchStudentToolStripMenuItem.Click
        If SearchStudentToolStripMenuItem.Checked = False Then
            'Get new instance
            formStudentSearch = New FormStudentSearch

            'Open the form
            formStudentSearch.Show()

            'Check the corresponding menu item to true
            SearchStudentToolStripMenuItem.Checked = True
        End If

    End Sub


    'OPEN THE LECTURER SEARCH WINDOW
    Private Sub SearchLecturerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchLecturerToolStripMenuItem.Click
        If SearchLecturerToolStripMenuItem.Checked = False Then
            formLecturerSearch = New FormLecturerSearch

            'Open the form
            formLecturerSearch.Show()

            'Check the corresponding menu item to true
            SearchLecturerToolStripMenuItem.Checked = True
        End If
    End Sub


    'OPEN THE MODULE SEARCH WINDOW
    Private Sub SearchModuleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchModuleToolStripMenuItem.Click
        If SearchModuleToolStripMenuItem.Checked = False Then
            formModuleSearch = New FormModuleSearch

            'Open the form
            formModuleSearch.Show()

            'Check the corresponding menu item to true
            SearchModuleToolStripMenuItem.Checked = True
        End If
    End Sub


    'OPEN THE GUARDIAN SEARCH WINDOW
    Private Sub SearchGuardiansToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchGuardiansToolStripMenuItem.Click
        If SearchGuardiansToolStripMenuItem.Checked = False Then
            formGuardianSearch = New FormGuardianSearch

            'Open the form
            formGuardianSearch.Show()

            'Check the corresponding menu item to true
            SearchGuardiansToolStripMenuItem.Checked = True
        End If
    End Sub


    'OPEN THE BOOK SEARCH WINDOW
    Private Sub SearchBookToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchBookToolStripMenuItem.Click
        If SearchBookToolStripMenuItem.Checked = False Then
            formBookSearch = New FormBookSearch

            'Open the form
            formBookSearch.Show()

            'Check the corresponding menu item to true
            SearchBookToolStripMenuItem.Checked = True
        End If
    End Sub


    'OPEN THE BOOK ISSUESEARCH WINDOW
    Private Sub SearchBookIssueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchBookIssueToolStripMenuItem.Click
        If SearchBookIssueToolStripMenuItem.Checked = False Then
            formBookIssueSearch = New FormBookIssueSearch

            'Open the form
            formBookIssueSearch.Show()

            'Check the corresponding menu item to true
            SearchBookIssueToolStripMenuItem.Checked = True
        End If
    End Sub






    'LIST OF UNCHECKEDMENU ITEM EVENTS

    'UNCHECK THE CORRESPONDING MENU ITEM [EVEN RAISE WHEN CORRESPONDING FORM IS CLOSED]
    Private Sub formStudentSearch_UncheckMenuItem(sender As Object) Handles formStudentSearch.UncheckMenuItem
        SearchStudentToolStripMenuItem.Checked = False
    End Sub


    'UNCHECK THE CORRESPONDING MENU ITEM [EVEN RAISE WHEN CORRESPONDING FORM IS CLOSED]
    Private Sub formLecturerSearch_UncheckMenuItem(sender As Object) Handles formLecturerSearch.UncheckMenuItem
        SearchLecturerToolStripMenuItem.Checked = False
    End Sub

    'UNCHECK THE CORRESPONDING MENU ITEM [EVEN RAISE WHEN CORRESPONDING FORM IS CLOSED]
    Private Sub formModuleSearch_UncheckMenuItem(sender As Object) Handles formModuleSearch.UncheckMenuItem
        SearchModuleToolStripMenuItem.Checked = False
    End Sub

    'UNCHECK THE CORRESPONDING MENU ITEM [EVEN RAISE WHEN CORRESPONDING FORM IS CLOSED]
    Private Sub formGuardianSearch_UncheckMenuItem(sender As Object) Handles formGuardianSearch.UncheckMenuItem
        SearchGuardiansToolStripMenuItem.Checked = False
    End Sub

    'UNCHECK THE CORRESPONDING MENU ITEM [EVEN RAISE WHEN CORRESPONDING FORM IS CLOSED]
    Private Sub formBookSearch_UncheckMenuItem(sender As Object) Handles formBookSearch.UncheckMenuItem
        SearchBookToolStripMenuItem.Checked = false
    End Sub

    'UNCHECK THE CORRESPONDING MENU ITEM [EVEN RAISE WHEN CORRESPONDING FORM IS CLOSED]
    Private Sub formBookIssueSearch_UncheckMenuItem(sender As Object) Handles formBookIssueSearch.UncheckMenuItem
        SearchBookIssueToolStripMenuItem.Checked = False
    End Sub

    'CLICKEVENT OF ABOUTSLIS MENU ITEM
    Private Sub AboutSLISToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutSLISToolStripMenuItem.Click
        'Open the modal form of ABOUT SOFTWARE
        Using objAboutSoftware As New AboutSoftware
            objAboutSoftware.ShowDialog(Me)
        End Using
    End Sub

    'CLICK EVENT OF STUDENT ADMISSION MENU ITEM
    Private Sub AddAdmissionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddAdmissionToolStripMenuItem.Click
        'Open the modal form of STUDENT ADMISSION
        Using objFormStudentAdmission As New FormStudentAdmission
            objFormStudentAdmission.ShowDialog(Me)
        End Using
    End Sub

    'CLICK EVENT OF STUDENT CURRENT MODULE MENU ITEM
    Private Sub AddStudentCurrentModuleDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddStudentCurrentModuleDetailsToolStripMenuItem.Click
        'Open the modal form of STUDENT CURRENT MODULE
        Using objFormStudentModule As New FormStudentModule
            objFormStudentModule.ShowDialog(Me)
        End Using
    End Sub


    'CLICK EVENT OF LECTURER CURRENT MODULE MENU ITEM
    Private Sub AddLecturerCurrentModuleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddLecturerCurrentModuleToolStripMenuItem.Click
        'Open the modal form of STUDENT CURRENT MODULE
        Using objFormLecturerModule As New FormLecturerModule
            objFormLecturerModule.ShowDialog(Me)
        End Using
    End Sub


    'METHOD: UNCHECK MENU ITEMS UNDER GOTO MENU
    Private Sub UncheckMenuItems()
        Dim menu1 As New List(Of ToolStripMenuItem)
        Dim menu2 As New List(Of ToolStripMenuItem)
        For Each item1 As ToolStripItem In G0T0ToolStripMenuItem.DropDownItems
            menu1.Add(item1)
        Next

        'UNCHECKED THE FIRST DROPDOWN ITEMS GOTO MAIN MENU
        For Each item1 As ToolStripMenuItem In menu1
            item1.Checked = False
            For Each item2 As ToolStripItem In item1.DropDownItems
                menu2.Add(item2)
            Next
        Next

        'UNCHECKED THE SECOND DROPDOWN ITEMS GOTO MAIN MENU
        For Each item2 As ToolStripMenuItem In menu2
            item2.Checked = False
        Next
    End Sub

    Private Sub ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentAddNewToolStripMenuItem.Click, StudentSearchToolStripMenuItem.Click, StudentViewToolStripMenuItem.Click, _
        LecturerAddNewToolStripMenuItem.Click, LecturerSearchToolStripMenuItem.Click, LecturerViewToolStripMenuItem.Click, ModuleAddNewToolStripMenuItem.Click, ModuleSearchToolStripMenuItem.Click, _
        ModuleViewToolStripMenuItem.Click, GuardianAddNewToolStripMenuItem.Click, GuardianSearchViewToolStripMenuItem.Click, BookAddNewToolStripMenuItem.Click, BookSearchToolStripMenuItem.Click, _
        BookViewToolStripMenuItem.Click, IssueAddNewToolStripMenuItem.Click, BookReturnToolStripMenuItem.Click, IssueViewToolStripMenuItem.Click

        If Not TabControl1.Visible = False Then
            'Uncheck all menu items under GOTOTsoolStripItem
            UncheckMenuItems()


            'STUDENT PAGE 
            If sender Is StudentAddNewToolStripMenuItem Then
                StudentToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 0

                StudentAddNewToolStripMenuItem.Checked = True
                tabStudent.SelectedIndex = 0
            ElseIf sender Is StudentSearchToolStripMenuItem Then
                StudentToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 0

                StudentSearchToolStripMenuItem.Checked = True
                tabStudent.SelectedIndex = 1

            ElseIf sender Is StudentViewToolStripMenuItem Then
                StudentToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 0

                StudentViewToolStripMenuItem.Checked = True
                tabStudent.SelectedIndex = 2

                'LECTURER PAGE
            ElseIf sender Is LecturerAddNewToolStripMenuItem Then
                LecturerToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 1

                LecturerAddNewToolStripMenuItem.Checked = True
                tabLecturer.SelectedIndex = 0

            ElseIf sender Is LecturerSearchToolStripMenuItem Then
                LecturerToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 1

                LecturerSearchToolStripMenuItem.Checked = True
                tabLecturer.SelectedIndex = 1
            ElseIf sender Is LecturerViewToolStripMenuItem Then
                LecturerToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 1

                LecturerViewToolStripMenuItem.Checked = True
                tabLecturer.SelectedIndex = 2

                'MODULE PAGE
            ElseIf sender Is ModuleAddNewToolStripMenuItem Then
                ModuleToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 2

                ModuleAddNewToolStripMenuItem.Checked = True
                tabModule.SelectedIndex = 0

            ElseIf sender Is ModuleSearchToolStripMenuItem Then
                ModuleToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 2

                ModuleSearchToolStripMenuItem.Checked = True
                tabModule.SelectedIndex = 1
            ElseIf sender Is ModuleViewToolStripMenuItem Then
                ModuleToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 2

                ModuleViewToolStripMenuItem.Checked = True
                tabModule.SelectedIndex = 2

                'GUARDIAN PAGE
            ElseIf sender Is GuardianAddNewToolStripMenuItem Then
                GuardianToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 3

                GuardianAddNewToolStripMenuItem.Checked = True
                tabGuardian.SelectedIndex = 0
            ElseIf sender Is GuardianSearchViewToolStripMenuItem Then
                GuardianToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 3

                GuardianSearchViewToolStripMenuItem.Checked = True
                tabGuardian.SelectedIndex = 1

                'BOOK PAGE
            ElseIf sender Is BookAddNewToolStripMenuItem Then
                BookToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 4

                BookAddNewToolStripMenuItem.Checked = True
                tabBook.SelectedIndex = 0
            ElseIf sender Is BookSearchToolStripMenuItem Then
                BookToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 4

                BookSearchToolStripMenuItem.Checked = True
                tabBook.SelectedIndex = 1
            ElseIf sender Is BookViewToolStripMenuItem Then
                BookToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 4

                BookViewToolStripMenuItem.Checked = True
                tabBook.SelectedIndex = 2

                'ISSUE PAGE
            ElseIf sender Is IssueAddNewToolStripMenuItem Then
                IssueToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 5

                IssueAddNewToolStripMenuItem.Checked = True
                tabIssue.SelectedIndex = 0

            ElseIf sender Is BookReturnToolStripMenuItem Then
                IssueToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 5

                BookReturnToolStripMenuItem.Checked = True
                tabIssue.SelectedIndex = 1
            ElseIf sender Is IssueViewToolStripMenuItem Then
                IssueToolStripMenuItem.Checked = True
                TabControl1.SelectedIndex = 5

                IssueViewToolStripMenuItem.Checked = True
                tabIssue.SelectedIndex = 2
            End If
        End If
    End Sub

  
    Private Sub tabStudentMain_Enter(sender As Object, e As EventArgs) Handles tabStudentMain.Enter, tabStudentSearch.Enter, tabStudentView.Enter
        Dim intIndex As Integer = tabStudent.SelectedIndex
        If intIndex = 0 Then
            ToolStripMenuItem_Click(StudentAddNewToolStripMenuItem, Nothing)
        ElseIf intIndex = 1 Then
            ToolStripMenuItem_Click(StudentSearchToolStripMenuItem, Nothing)
        ElseIf intIndex = 2 Then
            ToolStripMenuItem_Click(StudentViewToolStripMenuItem, Nothing)
        End If
    End Sub

    
    
    Private Sub tabLecturerMain_Enter(sender As Object, e As EventArgs) Handles tabLecturerMain.Enter, tabLecturerSearch.Enter, tabLecturerView.Enter
        Dim intIndex As Integer = tabLecturer.SelectedIndex
        If intIndex = 0 Then
            ToolStripMenuItem_Click(LecturerAddNewToolStripMenuItem, Nothing)
        ElseIf intIndex = 1 Then
            ToolStripMenuItem_Click(LecturerSearchToolStripMenuItem, Nothing)
        ElseIf intIndex = 2 Then
            ToolStripMenuItem_Click(LecturerViewToolStripMenuItem, Nothing)
        End If
    End Sub

    Private Sub tabModuleMain_Enter(sender As Object, e As EventArgs) Handles tabModuleMain.Enter, tabModuleAddNew.Enter, tabModuleSearch.Enter, tabModuleView.Enter
        Dim intIndex As Integer = tabModule.SelectedIndex
        If intIndex = 0 Then
            ToolStripMenuItem_Click(ModuleAddNewToolStripMenuItem, Nothing)
        ElseIf intIndex = 1 Then
            ToolStripMenuItem_Click(ModuleSearchToolStripMenuItem, Nothing)
        ElseIf intIndex = 2 Then
            ToolStripMenuItem_Click(ModuleViewToolStripMenuItem, Nothing)
        End If
    End Sub

    Private Sub tabGuardianMain_Enter(sender As Object, e As EventArgs) Handles tabGuardianMain.Enter, tabGuardianAddNew.Enter, tabGuardianSearchView.Enter
        Dim intIndex As Integer = tabGuardian.SelectedIndex
        If intIndex = 0 Then
            ToolStripMenuItem_Click(GuardianAddNewToolStripMenuItem, Nothing)
        ElseIf intIndex = 1 Then
            ToolStripMenuItem_Click(GuardianSearchViewToolStripMenuItem, Nothing)
        End If
    End Sub

    Private Sub tabBookMain_Enter(sender As Object, e As EventArgs) Handles tabBookMain.Enter, tabBookAddNew.Enter, tabBookSearch.Enter, tabBookView.Enter
        Dim intIndex As Integer = tabBook.SelectedIndex
        If intIndex = 0 Then
            ToolStripMenuItem_Click(BookAddNewToolStripMenuItem, Nothing)
        ElseIf intIndex = 1 Then
            ToolStripMenuItem_Click(BookSearchToolStripMenuItem, Nothing)
        ElseIf intIndex = 2 Then
            ToolStripMenuItem_Click(BookViewToolStripMenuItem, Nothing)
        End If
    End Sub

    Private Sub tabIssueMain_Enter(sender As Object, e As EventArgs) Handles tabIssueMain.Enter, tabIssueAddNew.Enter, tabIssueBookReturn.Enter, tabIssueView.Enter
        Dim intIndex As Integer = tabIssue.SelectedIndex
        If intIndex = 0 Then
            ToolStripMenuItem_Click(IssueAddNewToolStripMenuItem, Nothing)
        ElseIf intIndex = 1 Then
            ToolStripMenuItem_Click(BookReturnToolStripMenuItem, Nothing)
        ElseIf intIndex = 2 Then
            ToolStripMenuItem_Click(IssueViewToolStripMenuItem, Nothing)
        End If
    End Sub

    Private Sub ViewHelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewHelpToolStripMenuItem.Click
        'Open the View Help Form
        Using objViewHelp As New ViewHelp
            objViewHelp.ShowDialog(Me)
        End Using
    End Sub


    Dim a As New Panel

    Private Sub OpenMainFormToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenMainFormToolStripMenuItem.Click
        If TabControl1.Visible = False Then
            TabControl1.Dock = DockStyle.Fill
            TabControl1.Visible = True
            'CloseMainFormToolStripMenuItem.Visible = True
            'color = Panel1.BackColor
            a.BackColor = Panel1.BackColor
            Panel1.BackColor = Color.WhiteSmoke
            'OpenMainFormToolStripMenuItem.Visible = False


            'Hide this menu 
            G0T0ToolStripMenuItem.Enabled = True
        End If
    End Sub

    Private Sub CloseMainFormToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseMainFormToolStripMenuItem.Click
        If TabControl1.Visible = True Then
            TabControl1.Visible = False
            'CloseMainFormToolStripMenuItem.Visible = False
            Panel1.BackColor = a.BackColor
            'OpenMainFormToolStripMenuItem.Visible = True
            'Hide this menu 
            G0T0ToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub BackupRestoreToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackupRestoreToolStripMenuItem.Click
        'Open the backuprestore form
        Using objBackupRestore As New FormBackupRestore
            objBackupRestore.ShowDialog(Me)
        End Using
    End Sub

    Private Sub AboutDeveloperToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutDeveloperToolStripMenuItem.Click
        'Open the aboutdeveloper form
        Using objAboutDeveloper As New About_Developer
            objAboutDeveloper.ShowDialog(Me)
        End Using
    End Sub
End Class