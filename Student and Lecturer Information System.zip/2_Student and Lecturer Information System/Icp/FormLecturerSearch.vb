﻿Public Class FormLecturerSearch
    Public Event UncheckMenuItem(sender As Object)


    Private Sub FormLecturerSearch_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        RaiseEvent UncheckMenuItem(sender)
    End Sub
End Class