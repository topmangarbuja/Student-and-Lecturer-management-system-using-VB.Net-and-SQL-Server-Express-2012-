﻿Imports ClassLibrary_IMS
Public Class FormProgressBar
    'Dim loginForm As New LoginForm
    Dim intLoad As Integer = 1

    'FORM CLOSING EVENT OF FOM
    Private Sub FormProgressBar_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'Donot close the form
        e.Cancel = True
    End Sub

    'FORM LOAD EVENT
    Private Sub ProgressBarForm_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtUsername.Text = GblAccessItem.gstrUsername
        txtType.Text = GblAccessItem.gstrType
        txtLastLoginDate.Text = GblAccessItem.gdtmLastLoginDate.ToLongDateString & "  |  " & GblAccessItem.gdtmLastLoginDate.ToLongTimeString
    End Sub

    'TICK EVENT OF TIMER1
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ToolStripProgressBar1.Increment(5)
        If ToolStripProgressBar1.Value = ToolStripProgressBar1.Maximum Then
            Timer1.Enabled = False

            'Hide this form as well as Login form
            Me.Hide()
            FormLogin.Hide()

            'FormAccount.Show()

            'Open the main form
            FormMain.Show()
        End If

        'Change the text of status on the ToolStrip control
        If intLoad = 1 Then
            ToolStripStatusLabel1.Text = "Loading."
            intLoad += 1
            Exit Sub
        ElseIf intLoad = 2 Then
            ToolStripStatusLabel1.Text = "Loading.."
            intLoad += 1
            Exit Sub
        ElseIf intLoad = 3 Then
            ToolStripStatusLabel1.Text = "Loading..."
            intLoad = 1
            Exit Sub
        End If
    End Sub
End Class