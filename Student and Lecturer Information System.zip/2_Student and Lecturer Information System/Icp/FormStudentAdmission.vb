﻿Public Class FormStudentAdmission

    Private Sub FormStudentAdmission_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Set the size of the form
        Me.Size = New Size(562, 577)
    End Sub


    Private Sub TabPage1_Enter(sender As Object, e As EventArgs) Handles TabPage1.Enter
        'Set the size of the form
        Me.Size = New Size(562, 577)
    End Sub


    Private Sub TabPage2_Enter(sender As Object, e As EventArgs) Handles TabPage2.Enter
        'Set the size of the form
        Me.Size = New Size(1043, 625)
    End Sub
End Class