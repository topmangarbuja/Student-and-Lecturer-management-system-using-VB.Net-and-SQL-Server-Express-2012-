﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FILEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenMainFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseMainFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupRestoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.G0T0ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentAddNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerAddNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModuleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModuleAddNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModuleSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModuleViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardianAddNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardianSearchViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookAddNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IssueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IssueAddNewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BookReturnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IssueViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WINDOWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddAdmissionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddStudentAdditionalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddStudentCurrentModuleDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddLecturerAdditionalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddLecturerCurrentModuleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchStudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchGuardiansToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SearchLecturerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.SearchModuleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.SearchBookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchBookIssueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutSLISToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutDeveloperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabStudentMain = New System.Windows.Forms.TabPage()
        Me.tabStudent = New System.Windows.Forms.TabControl()
        Me.tabStudentAddNew = New System.Windows.Forms.TabPage()
        Me.StudentAddNew1 = New ControlLibrary_IMS.StudentAddNew()
        Me.tabStudentSearch = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.StudentSearch1 = New ControlLibrary_IMS.StudentSearch()
        Me.tabStudentView = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.StudentView1 = New ControlLibrary_IMS.StudentView()
        Me.tabLecturerMain = New System.Windows.Forms.TabPage()
        Me.tabLecturer = New System.Windows.Forms.TabControl()
        Me.tabLecturerAddNew = New System.Windows.Forms.TabPage()
        Me.LecturerAddNew1 = New ControlLibrary_IMS.LecturerAddNew()
        Me.tabLecturerSearch = New System.Windows.Forms.TabPage()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.LecturerSearch1 = New ControlLibrary_IMS.LecturerSearch()
        Me.tabLecturerView = New System.Windows.Forms.TabPage()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.LecturerView1 = New ControlLibrary_IMS.LecturerView()
        Me.tabModuleMain = New System.Windows.Forms.TabPage()
        Me.tabModule = New System.Windows.Forms.TabControl()
        Me.tabModuleAddNew = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.ModuleAddNew1 = New ControlLibrary_IMS.ModuleAddNew()
        Me.tabModuleSearch = New System.Windows.Forms.TabPage()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.ModuleSearch1 = New ControlLibrary_IMS.ModuleSearch()
        Me.tabModuleView = New System.Windows.Forms.TabPage()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.ModuleView1 = New ControlLibrary_IMS.ModuleView()
        Me.tabGuardianMain = New System.Windows.Forms.TabPage()
        Me.tabGuardian = New System.Windows.Forms.TabControl()
        Me.tabGuardianAddNew = New System.Windows.Forms.TabPage()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.GuardianAddNew1 = New ControlLibrary_IMS.GuardianAddNew()
        Me.tabGuardianSearchView = New System.Windows.Forms.TabPage()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.GuardianSearch1 = New ControlLibrary_IMS.GuardianSearch()
        Me.tabBookMain = New System.Windows.Forms.TabPage()
        Me.tabBook = New System.Windows.Forms.TabControl()
        Me.tabBookAddNew = New System.Windows.Forms.TabPage()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.BookAddNew1 = New ControlLibrary_IMS.BookAddNew()
        Me.tabBookSearch = New System.Windows.Forms.TabPage()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.BookSearch1 = New ControlLibrary_IMS.BookSearch()
        Me.tabBookView = New System.Windows.Forms.TabPage()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.BookView1 = New ControlLibrary_IMS.BookView()
        Me.tabIssueMain = New System.Windows.Forms.TabPage()
        Me.tabIssue = New System.Windows.Forms.TabControl()
        Me.tabIssueAddNew = New System.Windows.Forms.TabPage()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.IssueAddNew1 = New ControlLibrary_IMS.IssueAddNew()
        Me.tabIssueBookReturn = New System.Windows.Forms.TabPage()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.IssueSearch1 = New ControlLibrary_IMS.IssueSearch()
        Me.tabIssueView = New System.Windows.Forms.TabPage()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.IssueView1 = New ControlLibrary_IMS.IssueView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tabStudentMain.SuspendLayout()
        Me.tabStudent.SuspendLayout()
        Me.tabStudentAddNew.SuspendLayout()
        Me.tabStudentSearch.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.tabStudentView.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.tabLecturerMain.SuspendLayout()
        Me.tabLecturer.SuspendLayout()
        Me.tabLecturerAddNew.SuspendLayout()
        Me.tabLecturerSearch.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.tabLecturerView.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.tabModuleMain.SuspendLayout()
        Me.tabModule.SuspendLayout()
        Me.tabModuleAddNew.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.tabModuleSearch.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.tabModuleView.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.tabGuardianMain.SuspendLayout()
        Me.tabGuardian.SuspendLayout()
        Me.tabGuardianAddNew.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.tabGuardianSearchView.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.tabBookMain.SuspendLayout()
        Me.tabBook.SuspendLayout()
        Me.tabBookAddNew.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.tabBookSearch.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.tabBookView.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.tabIssueMain.SuspendLayout()
        Me.tabIssue.SuspendLayout()
        Me.tabIssueAddNew.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.tabIssueBookReturn.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.tabIssueView.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FILEToolStripMenuItem, Me.G0T0ToolStripMenuItem, Me.WINDOWToolStripMenuItem, Me.SEARCHToolStripMenuItem, Me.HELPToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(784, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FILEToolStripMenuItem
        '
        Me.FILEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenMainFormToolStripMenuItem, Me.CloseMainFormToolStripMenuItem, Me.ToolStripSeparator7, Me.SettingsToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FILEToolStripMenuItem.Name = "FILEToolStripMenuItem"
        Me.FILEToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FILEToolStripMenuItem.Text = "&FILE"
        '
        'OpenMainFormToolStripMenuItem
        '
        Me.OpenMainFormToolStripMenuItem.Name = "OpenMainFormToolStripMenuItem"
        Me.OpenMainFormToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+O"
        Me.OpenMainFormToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.OpenMainFormToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.OpenMainFormToolStripMenuItem.Text = "Open Tabs"
        '
        'CloseMainFormToolStripMenuItem
        '
        Me.CloseMainFormToolStripMenuItem.Name = "CloseMainFormToolStripMenuItem"
        Me.CloseMainFormToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+E"
        Me.CloseMainFormToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.CloseMainFormToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.CloseMainFormToolStripMenuItem.Text = "Close Tabs"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(198, 6)
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileToolStripMenuItem, Me.ManageUserToolStripMenuItem, Me.BackupRestoreToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Image = CType(resources.GetObject("SettingsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'ProfileToolStripMenuItem
        '
        Me.ProfileToolStripMenuItem.Image = CType(resources.GetObject("ProfileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ProfileToolStripMenuItem.Name = "ProfileToolStripMenuItem"
        Me.ProfileToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.ProfileToolStripMenuItem.Text = "Profile"
        '
        'ManageUserToolStripMenuItem
        '
        Me.ManageUserToolStripMenuItem.Image = CType(resources.GetObject("ManageUserToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ManageUserToolStripMenuItem.Name = "ManageUserToolStripMenuItem"
        Me.ManageUserToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.ManageUserToolStripMenuItem.Text = "Manage User Account"
        '
        'BackupRestoreToolStripMenuItem
        '
        Me.BackupRestoreToolStripMenuItem.Image = CType(resources.GetObject("BackupRestoreToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BackupRestoreToolStripMenuItem.Name = "BackupRestoreToolStripMenuItem"
        Me.BackupRestoreToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.BackupRestoreToolStripMenuItem.Text = "Backup | Restore"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(198, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Image = CType(resources.GetObject("ExitToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.ShortcutKeyDisplayString = "Alt+F4"
        Me.ExitToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.ExitToolStripMenuItem.Text = "Exit Application "
        '
        'G0T0ToolStripMenuItem
        '
        Me.G0T0ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentToolStripMenuItem, Me.LecturerToolStripMenuItem, Me.ModuleToolStripMenuItem, Me.GuardianToolStripMenuItem, Me.BookToolStripMenuItem, Me.IssueToolStripMenuItem})
        Me.G0T0ToolStripMenuItem.Name = "G0T0ToolStripMenuItem"
        Me.G0T0ToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
        Me.G0T0ToolStripMenuItem.Text = "&GO TO"
        '
        'StudentToolStripMenuItem
        '
        Me.StudentToolStripMenuItem.Checked = True
        Me.StudentToolStripMenuItem.CheckOnClick = True
        Me.StudentToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.StudentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentAddNewToolStripMenuItem, Me.StudentSearchToolStripMenuItem, Me.StudentViewToolStripMenuItem})
        Me.StudentToolStripMenuItem.Name = "StudentToolStripMenuItem"
        Me.StudentToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.StudentToolStripMenuItem.Text = "Student"
        '
        'StudentAddNewToolStripMenuItem
        '
        Me.StudentAddNewToolStripMenuItem.Checked = True
        Me.StudentAddNewToolStripMenuItem.CheckOnClick = True
        Me.StudentAddNewToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.StudentAddNewToolStripMenuItem.Name = "StudentAddNewToolStripMenuItem"
        Me.StudentAddNewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.StudentAddNewToolStripMenuItem.Text = "Add new"
        '
        'StudentSearchToolStripMenuItem
        '
        Me.StudentSearchToolStripMenuItem.CheckOnClick = True
        Me.StudentSearchToolStripMenuItem.Name = "StudentSearchToolStripMenuItem"
        Me.StudentSearchToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.StudentSearchToolStripMenuItem.Text = "Search"
        '
        'StudentViewToolStripMenuItem
        '
        Me.StudentViewToolStripMenuItem.CheckOnClick = True
        Me.StudentViewToolStripMenuItem.Name = "StudentViewToolStripMenuItem"
        Me.StudentViewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.StudentViewToolStripMenuItem.Text = "View"
        '
        'LecturerToolStripMenuItem
        '
        Me.LecturerToolStripMenuItem.CheckOnClick = True
        Me.LecturerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LecturerAddNewToolStripMenuItem, Me.LecturerSearchToolStripMenuItem, Me.LecturerViewToolStripMenuItem})
        Me.LecturerToolStripMenuItem.Name = "LecturerToolStripMenuItem"
        Me.LecturerToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.LecturerToolStripMenuItem.Text = "Lecturer"
        '
        'LecturerAddNewToolStripMenuItem
        '
        Me.LecturerAddNewToolStripMenuItem.CheckOnClick = True
        Me.LecturerAddNewToolStripMenuItem.Name = "LecturerAddNewToolStripMenuItem"
        Me.LecturerAddNewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.LecturerAddNewToolStripMenuItem.Text = "Add new"
        '
        'LecturerSearchToolStripMenuItem
        '
        Me.LecturerSearchToolStripMenuItem.CheckOnClick = True
        Me.LecturerSearchToolStripMenuItem.Name = "LecturerSearchToolStripMenuItem"
        Me.LecturerSearchToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.LecturerSearchToolStripMenuItem.Text = "Search"
        '
        'LecturerViewToolStripMenuItem
        '
        Me.LecturerViewToolStripMenuItem.CheckOnClick = True
        Me.LecturerViewToolStripMenuItem.Name = "LecturerViewToolStripMenuItem"
        Me.LecturerViewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.LecturerViewToolStripMenuItem.Text = "View"
        '
        'ModuleToolStripMenuItem
        '
        Me.ModuleToolStripMenuItem.CheckOnClick = True
        Me.ModuleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ModuleAddNewToolStripMenuItem, Me.ModuleSearchToolStripMenuItem, Me.ModuleViewToolStripMenuItem})
        Me.ModuleToolStripMenuItem.Name = "ModuleToolStripMenuItem"
        Me.ModuleToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.ModuleToolStripMenuItem.Text = "Module"
        '
        'ModuleAddNewToolStripMenuItem
        '
        Me.ModuleAddNewToolStripMenuItem.CheckOnClick = True
        Me.ModuleAddNewToolStripMenuItem.Name = "ModuleAddNewToolStripMenuItem"
        Me.ModuleAddNewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.ModuleAddNewToolStripMenuItem.Text = "Add new"
        '
        'ModuleSearchToolStripMenuItem
        '
        Me.ModuleSearchToolStripMenuItem.CheckOnClick = True
        Me.ModuleSearchToolStripMenuItem.Name = "ModuleSearchToolStripMenuItem"
        Me.ModuleSearchToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.ModuleSearchToolStripMenuItem.Text = "Search"
        '
        'ModuleViewToolStripMenuItem
        '
        Me.ModuleViewToolStripMenuItem.CheckOnClick = True
        Me.ModuleViewToolStripMenuItem.Name = "ModuleViewToolStripMenuItem"
        Me.ModuleViewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.ModuleViewToolStripMenuItem.Text = "View"
        '
        'GuardianToolStripMenuItem
        '
        Me.GuardianToolStripMenuItem.CheckOnClick = True
        Me.GuardianToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GuardianAddNewToolStripMenuItem, Me.GuardianSearchViewToolStripMenuItem})
        Me.GuardianToolStripMenuItem.Name = "GuardianToolStripMenuItem"
        Me.GuardianToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.GuardianToolStripMenuItem.Text = "Guardian"
        '
        'GuardianAddNewToolStripMenuItem
        '
        Me.GuardianAddNewToolStripMenuItem.CheckOnClick = True
        Me.GuardianAddNewToolStripMenuItem.Name = "GuardianAddNewToolStripMenuItem"
        Me.GuardianAddNewToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.GuardianAddNewToolStripMenuItem.Text = "Add new"
        '
        'GuardianSearchViewToolStripMenuItem
        '
        Me.GuardianSearchViewToolStripMenuItem.CheckOnClick = True
        Me.GuardianSearchViewToolStripMenuItem.Name = "GuardianSearchViewToolStripMenuItem"
        Me.GuardianSearchViewToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.GuardianSearchViewToolStripMenuItem.Text = "Search && View"
        '
        'BookToolStripMenuItem
        '
        Me.BookToolStripMenuItem.CheckOnClick = True
        Me.BookToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BookAddNewToolStripMenuItem, Me.BookSearchToolStripMenuItem, Me.BookViewToolStripMenuItem})
        Me.BookToolStripMenuItem.Name = "BookToolStripMenuItem"
        Me.BookToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.BookToolStripMenuItem.Text = "Book"
        '
        'BookAddNewToolStripMenuItem
        '
        Me.BookAddNewToolStripMenuItem.CheckOnClick = True
        Me.BookAddNewToolStripMenuItem.Name = "BookAddNewToolStripMenuItem"
        Me.BookAddNewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.BookAddNewToolStripMenuItem.Text = "Add new"
        '
        'BookSearchToolStripMenuItem
        '
        Me.BookSearchToolStripMenuItem.CheckOnClick = True
        Me.BookSearchToolStripMenuItem.Name = "BookSearchToolStripMenuItem"
        Me.BookSearchToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.BookSearchToolStripMenuItem.Text = "Search"
        '
        'BookViewToolStripMenuItem
        '
        Me.BookViewToolStripMenuItem.CheckOnClick = True
        Me.BookViewToolStripMenuItem.Name = "BookViewToolStripMenuItem"
        Me.BookViewToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.BookViewToolStripMenuItem.Text = "View"
        '
        'IssueToolStripMenuItem
        '
        Me.IssueToolStripMenuItem.CheckOnClick = True
        Me.IssueToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IssueAddNewToolStripMenuItem, Me.BookReturnToolStripMenuItem, Me.IssueViewToolStripMenuItem})
        Me.IssueToolStripMenuItem.Name = "IssueToolStripMenuItem"
        Me.IssueToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.IssueToolStripMenuItem.Text = "Book-Issue"
        '
        'IssueAddNewToolStripMenuItem
        '
        Me.IssueAddNewToolStripMenuItem.CheckOnClick = True
        Me.IssueAddNewToolStripMenuItem.Name = "IssueAddNewToolStripMenuItem"
        Me.IssueAddNewToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.IssueAddNewToolStripMenuItem.Text = "Add new"
        '
        'BookReturnToolStripMenuItem
        '
        Me.BookReturnToolStripMenuItem.CheckOnClick = True
        Me.BookReturnToolStripMenuItem.Name = "BookReturnToolStripMenuItem"
        Me.BookReturnToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.BookReturnToolStripMenuItem.Text = "Book return"
        '
        'IssueViewToolStripMenuItem
        '
        Me.IssueViewToolStripMenuItem.CheckOnClick = True
        Me.IssueViewToolStripMenuItem.Name = "IssueViewToolStripMenuItem"
        Me.IssueViewToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.IssueViewToolStripMenuItem.Text = "View"
        '
        'WINDOWToolStripMenuItem
        '
        Me.WINDOWToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentToolStripMenuItem1, Me.LecturerToolStripMenuItem1})
        Me.WINDOWToolStripMenuItem.Name = "WINDOWToolStripMenuItem"
        Me.WINDOWToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.WINDOWToolStripMenuItem.Text = "&WINDOW"
        '
        'StudentToolStripMenuItem1
        '
        Me.StudentToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddAdmissionToolStripMenuItem, Me.AddStudentAdditionalToolStripMenuItem, Me.AddStudentCurrentModuleDetailsToolStripMenuItem})
        Me.StudentToolStripMenuItem1.Image = CType(resources.GetObject("StudentToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.StudentToolStripMenuItem1.Name = "StudentToolStripMenuItem1"
        Me.StudentToolStripMenuItem1.Size = New System.Drawing.Size(117, 22)
        Me.StudentToolStripMenuItem1.Text = "Student"
        '
        'AddAdmissionToolStripMenuItem
        '
        Me.AddAdmissionToolStripMenuItem.Name = "AddAdmissionToolStripMenuItem"
        Me.AddAdmissionToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.AddAdmissionToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AddAdmissionToolStripMenuItem.Text = "Add admission"
        '
        'AddStudentAdditionalToolStripMenuItem
        '
        Me.AddStudentAdditionalToolStripMenuItem.Name = "AddStudentAdditionalToolStripMenuItem"
        Me.AddStudentAdditionalToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.AddStudentAdditionalToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AddStudentAdditionalToolStripMenuItem.Text = "Add additional"
        '
        'AddStudentCurrentModuleDetailsToolStripMenuItem
        '
        Me.AddStudentCurrentModuleDetailsToolStripMenuItem.Name = "AddStudentCurrentModuleDetailsToolStripMenuItem"
        Me.AddStudentCurrentModuleDetailsToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.AddStudentCurrentModuleDetailsToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AddStudentCurrentModuleDetailsToolStripMenuItem.Text = "Add current module"
        '
        'LecturerToolStripMenuItem1
        '
        Me.LecturerToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddLecturerAdditionalToolStripMenuItem, Me.AddLecturerCurrentModuleToolStripMenuItem})
        Me.LecturerToolStripMenuItem1.Image = CType(resources.GetObject("LecturerToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.LecturerToolStripMenuItem1.Name = "LecturerToolStripMenuItem1"
        Me.LecturerToolStripMenuItem1.Size = New System.Drawing.Size(117, 22)
        Me.LecturerToolStripMenuItem1.Text = "Lecturer"
        '
        'AddLecturerAdditionalToolStripMenuItem
        '
        Me.AddLecturerAdditionalToolStripMenuItem.Name = "AddLecturerAdditionalToolStripMenuItem"
        Me.AddLecturerAdditionalToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.AddLecturerAdditionalToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AddLecturerAdditionalToolStripMenuItem.Text = "Add additional"
        '
        'AddLecturerCurrentModuleToolStripMenuItem
        '
        Me.AddLecturerCurrentModuleToolStripMenuItem.Name = "AddLecturerCurrentModuleToolStripMenuItem"
        Me.AddLecturerCurrentModuleToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.AddLecturerCurrentModuleToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AddLecturerCurrentModuleToolStripMenuItem.Text = "Add current module"
        '
        'SEARCHToolStripMenuItem
        '
        Me.SEARCHToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SearchStudentToolStripMenuItem, Me.SearchGuardiansToolStripMenuItem, Me.ToolStripSeparator4, Me.SearchLecturerToolStripMenuItem, Me.ToolStripSeparator5, Me.SearchModuleToolStripMenuItem, Me.ToolStripSeparator6, Me.SearchBookToolStripMenuItem, Me.SearchBookIssueToolStripMenuItem})
        Me.SEARCHToolStripMenuItem.Name = "SEARCHToolStripMenuItem"
        Me.SEARCHToolStripMenuItem.Size = New System.Drawing.Size(63, 20)
        Me.SEARCHToolStripMenuItem.Text = "&SEARCH"
        '
        'SearchStudentToolStripMenuItem
        '
        Me.SearchStudentToolStripMenuItem.AutoSize = False
        Me.SearchStudentToolStripMenuItem.Name = "SearchStudentToolStripMenuItem"
        Me.SearchStudentToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SearchStudentToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+S"
        Me.SearchStudentToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SearchStudentToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
        Me.SearchStudentToolStripMenuItem.Text = "Search Student"
        Me.SearchStudentToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SearchGuardiansToolStripMenuItem
        '
        Me.SearchGuardiansToolStripMenuItem.AutoSize = False
        Me.SearchGuardiansToolStripMenuItem.Name = "SearchGuardiansToolStripMenuItem"
        Me.SearchGuardiansToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+G"
        Me.SearchGuardiansToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.SearchGuardiansToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
        Me.SearchGuardiansToolStripMenuItem.Text = "Search Guardian"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.AutoSize = False
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(236, 6)
        '
        'SearchLecturerToolStripMenuItem
        '
        Me.SearchLecturerToolStripMenuItem.AutoSize = False
        Me.SearchLecturerToolStripMenuItem.Name = "SearchLecturerToolStripMenuItem"
        Me.SearchLecturerToolStripMenuItem.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.SearchLecturerToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SearchLecturerToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+L"
        Me.SearchLecturerToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.SearchLecturerToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
        Me.SearchLecturerToolStripMenuItem.Text = "Search Lecturer"
        Me.SearchLecturerToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.AutoSize = False
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(236, 6)
        '
        'SearchModuleToolStripMenuItem
        '
        Me.SearchModuleToolStripMenuItem.AutoSize = False
        Me.SearchModuleToolStripMenuItem.Name = "SearchModuleToolStripMenuItem"
        Me.SearchModuleToolStripMenuItem.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always
        Me.SearchModuleToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SearchModuleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+M"
        Me.SearchModuleToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.SearchModuleToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
        Me.SearchModuleToolStripMenuItem.Text = "Search Module"
        Me.SearchModuleToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.AutoSize = False
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(236, 6)
        '
        'SearchBookToolStripMenuItem
        '
        Me.SearchBookToolStripMenuItem.AutoSize = False
        Me.SearchBookToolStripMenuItem.Name = "SearchBookToolStripMenuItem"
        Me.SearchBookToolStripMenuItem.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.SearchBookToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SearchBookToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+B"
        Me.SearchBookToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.SearchBookToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
        Me.SearchBookToolStripMenuItem.Text = "Search Book"
        Me.SearchBookToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SearchBookIssueToolStripMenuItem
        '
        Me.SearchBookIssueToolStripMenuItem.AutoSize = False
        Me.SearchBookIssueToolStripMenuItem.Name = "SearchBookIssueToolStripMenuItem"
        Me.SearchBookIssueToolStripMenuItem.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.SearchBookIssueToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SearchBookIssueToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+I"
        Me.SearchBookIssueToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.SearchBookIssueToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
        Me.SearchBookIssueToolStripMenuItem.Text = "Search Book-Issue"
        Me.SearchBookIssueToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'HELPToolStripMenuItem
        '
        Me.HELPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewHelpToolStripMenuItem, Me.ToolStripSeparator8, Me.AboutSLISToolStripMenuItem, Me.ToolStripSeparator3, Me.AboutDeveloperToolStripMenuItem})
        Me.HELPToolStripMenuItem.Name = "HELPToolStripMenuItem"
        Me.HELPToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.HELPToolStripMenuItem.Text = "&HELP"
        '
        'ViewHelpToolStripMenuItem
        '
        Me.ViewHelpToolStripMenuItem.Image = CType(resources.GetObject("ViewHelpToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewHelpToolStripMenuItem.Name = "ViewHelpToolStripMenuItem"
        Me.ViewHelpToolStripMenuItem.ShortcutKeyDisplayString = "Shift+F1"
        Me.ViewHelpToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.ViewHelpToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ViewHelpToolStripMenuItem.Text = "View Help"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(211, 6)
        '
        'AboutSLISToolStripMenuItem
        '
        Me.AboutSLISToolStripMenuItem.Image = CType(resources.GetObject("AboutSLISToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutSLISToolStripMenuItem.Name = "AboutSLISToolStripMenuItem"
        Me.AboutSLISToolStripMenuItem.ShortcutKeyDisplayString = "Shift+F2"
        Me.AboutSLISToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.F2), System.Windows.Forms.Keys)
        Me.AboutSLISToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.AboutSLISToolStripMenuItem.Text = "About Software"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(211, 6)
        '
        'AboutDeveloperToolStripMenuItem
        '
        Me.AboutDeveloperToolStripMenuItem.Image = CType(resources.GetObject("AboutDeveloperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutDeveloperToolStripMenuItem.Name = "AboutDeveloperToolStripMenuItem"
        Me.AboutDeveloperToolStripMenuItem.ShortcutKeyDisplayString = "Shift+F3"
        Me.AboutDeveloperToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.F3), System.Windows.Forms.Keys)
        Me.AboutDeveloperToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.AboutDeveloperToolStripMenuItem.Text = "About Developer"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.StatusStrip1.Font = New System.Drawing.Font("Stencil", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 433)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(784, 28)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(256, 23)
        Me.ToolStripStatusLabel1.Spring = True
        Me.ToolStripStatusLabel1.Text = "INFORMATICS COLLEGE POKHARA |"
        Me.ToolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ToolStripStatusLabel2.Margin = New System.Windows.Forms.Padding(0)
        Me.ToolStripStatusLabel2.MergeAction = System.Windows.Forms.MergeAction.Replace
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(256, 28)
        Me.ToolStripStatusLabel2.Spring = True
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Cambria", 9.75!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ToolStripStatusLabel3.Margin = New System.Windows.Forms.Padding(0)
        Me.ToolStripStatusLabel3.MergeAction = System.Windows.Forms.MergeAction.Replace
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(256, 28)
        Me.ToolStripStatusLabel3.Spring = True
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolStripStatusLabel3.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "windows_view_icon [www.imagesplitter.net].png")
        Me.ImageList1.Images.SetKeyName(1, "1417093445_search-24.png")
        Me.ImageList1.Images.SetKeyName(2, "1431585835_Add-Male-User.png")
        Me.ImageList1.Images.SetKeyName(3, "1431586047_698913-icon-81-document-add-24.png")
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 500
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel1.BackgroundImage = Global.Icp.My.Resources.Resources.background
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.TabControl1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(784, 409)
        Me.Panel1.TabIndex = 5
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabStudentMain)
        Me.TabControl1.Controls.Add(Me.tabLecturerMain)
        Me.TabControl1.Controls.Add(Me.tabModuleMain)
        Me.TabControl1.Controls.Add(Me.tabGuardianMain)
        Me.TabControl1.Controls.Add(Me.tabBookMain)
        Me.TabControl1.Controls.Add(Me.tabIssueMain)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(782, 407)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 4
        Me.TabControl1.TabStop = False
        Me.TabControl1.Visible = False
        '
        'tabStudentMain
        '
        Me.tabStudentMain.AutoScroll = True
        Me.tabStudentMain.BackColor = System.Drawing.Color.Transparent
        Me.tabStudentMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabStudentMain.Controls.Add(Me.tabStudent)
        Me.tabStudentMain.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabStudentMain.Location = New System.Drawing.Point(4, 26)
        Me.tabStudentMain.Name = "tabStudentMain"
        Me.tabStudentMain.Size = New System.Drawing.Size(774, 377)
        Me.tabStudentMain.TabIndex = 5
        Me.tabStudentMain.Text = "STUDENT"
        '
        'tabStudent
        '
        Me.tabStudent.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabStudent.Controls.Add(Me.tabStudentAddNew)
        Me.tabStudent.Controls.Add(Me.tabStudentSearch)
        Me.tabStudent.Controls.Add(Me.tabStudentView)
        Me.tabStudent.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabStudent.Font = New System.Drawing.Font("Cambria", 10.25!)
        Me.tabStudent.ImageList = Me.ImageList1
        Me.tabStudent.Location = New System.Drawing.Point(0, 0)
        Me.tabStudent.Name = "tabStudent"
        Me.tabStudent.SelectedIndex = 0
        Me.tabStudent.Size = New System.Drawing.Size(772, 375)
        Me.tabStudent.TabIndex = 1
        Me.tabStudent.TabStop = False
        '
        'tabStudentAddNew
        '
        Me.tabStudentAddNew.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabStudentAddNew.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabStudentAddNew.Controls.Add(Me.StudentAddNew1)
        Me.tabStudentAddNew.ImageIndex = 3
        Me.tabStudentAddNew.Location = New System.Drawing.Point(4, 28)
        Me.tabStudentAddNew.Name = "tabStudentAddNew"
        Me.tabStudentAddNew.Size = New System.Drawing.Size(764, 343)
        Me.tabStudentAddNew.TabIndex = 4
        Me.tabStudentAddNew.Text = "Add new"
        '
        'StudentAddNew1
        '
        Me.StudentAddNew1.AutoScroll = True
        Me.StudentAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.StudentAddNew1.BackgroundImage = CType(resources.GetObject("StudentAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.StudentAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.StudentAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentAddNew1.Location = New System.Drawing.Point(0, 0)
        Me.StudentAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.StudentAddNew1.Name = "StudentAddNew1"
        Me.StudentAddNew1.Size = New System.Drawing.Size(762, 341)
        Me.StudentAddNew1.TabIndex = 0
        '
        'tabStudentSearch
        '
        Me.tabStudentSearch.BackColor = System.Drawing.Color.White
        Me.tabStudentSearch.Controls.Add(Me.Panel3)
        Me.tabStudentSearch.ImageIndex = 1
        Me.tabStudentSearch.Location = New System.Drawing.Point(4, 28)
        Me.tabStudentSearch.Name = "tabStudentSearch"
        Me.tabStudentSearch.Size = New System.Drawing.Size(764, 343)
        Me.tabStudentSearch.TabIndex = 2
        Me.tabStudentSearch.Text = "Search"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Control
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.StudentSearch1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(764, 343)
        Me.Panel3.TabIndex = 0
        '
        'StudentSearch1
        '
        Me.StudentSearch1.AutoScroll = True
        Me.StudentSearch1.BackColor = System.Drawing.Color.Transparent
        Me.StudentSearch1.BackgroundImage = CType(resources.GetObject("StudentSearch1.BackgroundImage"), System.Drawing.Image)
        Me.StudentSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentSearch1.Location = New System.Drawing.Point(0, 0)
        Me.StudentSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.StudentSearch1.Name = "StudentSearch1"
        Me.StudentSearch1.Size = New System.Drawing.Size(762, 341)
        Me.StudentSearch1.TabIndex = 0
        '
        'tabStudentView
        '
        Me.tabStudentView.BackColor = System.Drawing.Color.White
        Me.tabStudentView.Controls.Add(Me.Panel4)
        Me.tabStudentView.ImageIndex = 0
        Me.tabStudentView.Location = New System.Drawing.Point(4, 28)
        Me.tabStudentView.Name = "tabStudentView"
        Me.tabStudentView.Size = New System.Drawing.Size(764, 343)
        Me.tabStudentView.TabIndex = 3
        Me.tabStudentView.Text = "View"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.Control
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.StudentView1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(764, 343)
        Me.Panel4.TabIndex = 0
        '
        'StudentView1
        '
        Me.StudentView1.AutoScroll = True
        Me.StudentView1.BackColor = System.Drawing.Color.Transparent
        Me.StudentView1.BackgroundImage = CType(resources.GetObject("StudentView1.BackgroundImage"), System.Drawing.Image)
        Me.StudentView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StudentView1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentView1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.StudentView1.Location = New System.Drawing.Point(0, 0)
        Me.StudentView1.Margin = New System.Windows.Forms.Padding(4)
        Me.StudentView1.Name = "StudentView1"
        Me.StudentView1.Size = New System.Drawing.Size(762, 341)
        Me.StudentView1.TabIndex = 0
        '
        'tabLecturerMain
        '
        Me.tabLecturerMain.AutoScroll = True
        Me.tabLecturerMain.BackColor = System.Drawing.Color.Transparent
        Me.tabLecturerMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabLecturerMain.Controls.Add(Me.tabLecturer)
        Me.tabLecturerMain.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabLecturerMain.Location = New System.Drawing.Point(4, 26)
        Me.tabLecturerMain.Name = "tabLecturerMain"
        Me.tabLecturerMain.Padding = New System.Windows.Forms.Padding(3)
        Me.tabLecturerMain.Size = New System.Drawing.Size(774, 377)
        Me.tabLecturerMain.TabIndex = 1
        Me.tabLecturerMain.Text = "LECTURER"
        '
        'tabLecturer
        '
        Me.tabLecturer.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabLecturer.Controls.Add(Me.tabLecturerAddNew)
        Me.tabLecturer.Controls.Add(Me.tabLecturerSearch)
        Me.tabLecturer.Controls.Add(Me.tabLecturerView)
        Me.tabLecturer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabLecturer.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabLecturer.ImageList = Me.ImageList1
        Me.tabLecturer.Location = New System.Drawing.Point(3, 3)
        Me.tabLecturer.Name = "tabLecturer"
        Me.tabLecturer.SelectedIndex = 0
        Me.tabLecturer.Size = New System.Drawing.Size(766, 369)
        Me.tabLecturer.TabIndex = 2
        Me.tabLecturer.TabStop = False
        '
        'tabLecturerAddNew
        '
        Me.tabLecturerAddNew.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabLecturerAddNew.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabLecturerAddNew.Controls.Add(Me.LecturerAddNew1)
        Me.tabLecturerAddNew.ImageIndex = 3
        Me.tabLecturerAddNew.Location = New System.Drawing.Point(4, 28)
        Me.tabLecturerAddNew.Name = "tabLecturerAddNew"
        Me.tabLecturerAddNew.Size = New System.Drawing.Size(758, 337)
        Me.tabLecturerAddNew.TabIndex = 4
        Me.tabLecturerAddNew.Text = "Add new"
        '
        'LecturerAddNew1
        '
        Me.LecturerAddNew1.AutoScroll = True
        Me.LecturerAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.LecturerAddNew1.BackgroundImage = CType(resources.GetObject("LecturerAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.LecturerAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LecturerAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LecturerAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.LecturerAddNew1.Location = New System.Drawing.Point(0, 0)
        Me.LecturerAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.LecturerAddNew1.Name = "LecturerAddNew1"
        Me.LecturerAddNew1.Size = New System.Drawing.Size(756, 335)
        Me.LecturerAddNew1.TabIndex = 0
        '
        'tabLecturerSearch
        '
        Me.tabLecturerSearch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabLecturerSearch.Controls.Add(Me.Panel6)
        Me.tabLecturerSearch.ImageIndex = 1
        Me.tabLecturerSearch.Location = New System.Drawing.Point(4, 28)
        Me.tabLecturerSearch.Name = "tabLecturerSearch"
        Me.tabLecturerSearch.Size = New System.Drawing.Size(758, 337)
        Me.tabLecturerSearch.TabIndex = 2
        Me.tabLecturerSearch.Text = "Search"
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.LecturerSearch1)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(758, 337)
        Me.Panel6.TabIndex = 0
        '
        'LecturerSearch1
        '
        Me.LecturerSearch1.AutoScroll = True
        Me.LecturerSearch1.BackColor = System.Drawing.Color.Transparent
        Me.LecturerSearch1.BackgroundImage = CType(resources.GetObject("LecturerSearch1.BackgroundImage"), System.Drawing.Image)
        Me.LecturerSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LecturerSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LecturerSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.LecturerSearch1.Location = New System.Drawing.Point(0, 0)
        Me.LecturerSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.LecturerSearch1.Name = "LecturerSearch1"
        Me.LecturerSearch1.Size = New System.Drawing.Size(756, 335)
        Me.LecturerSearch1.TabIndex = 0
        '
        'tabLecturerView
        '
        Me.tabLecturerView.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabLecturerView.Controls.Add(Me.Panel7)
        Me.tabLecturerView.ImageIndex = 0
        Me.tabLecturerView.Location = New System.Drawing.Point(4, 28)
        Me.tabLecturerView.Name = "tabLecturerView"
        Me.tabLecturerView.Size = New System.Drawing.Size(758, 337)
        Me.tabLecturerView.TabIndex = 3
        Me.tabLecturerView.Text = "View"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.LecturerView1)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(758, 337)
        Me.Panel7.TabIndex = 0
        '
        'LecturerView1
        '
        Me.LecturerView1.AutoScroll = True
        Me.LecturerView1.BackColor = System.Drawing.Color.Transparent
        Me.LecturerView1.BackgroundImage = CType(resources.GetObject("LecturerView1.BackgroundImage"), System.Drawing.Image)
        Me.LecturerView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LecturerView1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LecturerView1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.LecturerView1.Location = New System.Drawing.Point(0, 0)
        Me.LecturerView1.Margin = New System.Windows.Forms.Padding(4)
        Me.LecturerView1.Name = "LecturerView1"
        Me.LecturerView1.Size = New System.Drawing.Size(756, 335)
        Me.LecturerView1.TabIndex = 0
        '
        'tabModuleMain
        '
        Me.tabModuleMain.BackColor = System.Drawing.Color.Transparent
        Me.tabModuleMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabModuleMain.Controls.Add(Me.tabModule)
        Me.tabModuleMain.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabModuleMain.Location = New System.Drawing.Point(4, 26)
        Me.tabModuleMain.Name = "tabModuleMain"
        Me.tabModuleMain.Size = New System.Drawing.Size(774, 377)
        Me.tabModuleMain.TabIndex = 2
        Me.tabModuleMain.Text = "MODULE"
        '
        'tabModule
        '
        Me.tabModule.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabModule.Controls.Add(Me.tabModuleAddNew)
        Me.tabModule.Controls.Add(Me.tabModuleSearch)
        Me.tabModule.Controls.Add(Me.tabModuleView)
        Me.tabModule.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabModule.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabModule.ImageList = Me.ImageList1
        Me.tabModule.Location = New System.Drawing.Point(0, 0)
        Me.tabModule.Name = "tabModule"
        Me.tabModule.SelectedIndex = 0
        Me.tabModule.Size = New System.Drawing.Size(772, 375)
        Me.tabModule.TabIndex = 0
        Me.tabModule.TabStop = False
        '
        'tabModuleAddNew
        '
        Me.tabModuleAddNew.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabModuleAddNew.Controls.Add(Me.Panel8)
        Me.tabModuleAddNew.ImageIndex = 3
        Me.tabModuleAddNew.Location = New System.Drawing.Point(4, 28)
        Me.tabModuleAddNew.Name = "tabModuleAddNew"
        Me.tabModuleAddNew.Size = New System.Drawing.Size(764, 343)
        Me.tabModuleAddNew.TabIndex = 4
        Me.tabModuleAddNew.Text = "Add new"
        '
        'Panel8
        '
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.ModuleAddNew1)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(0, 0)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(764, 343)
        Me.Panel8.TabIndex = 0
        '
        'ModuleAddNew1
        '
        Me.ModuleAddNew1.AutoScroll = True
        Me.ModuleAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.ModuleAddNew1.BackgroundImage = CType(resources.GetObject("ModuleAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.ModuleAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ModuleAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModuleAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ModuleAddNew1.Location = New System.Drawing.Point(0, 0)
        Me.ModuleAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.ModuleAddNew1.Name = "ModuleAddNew1"
        Me.ModuleAddNew1.Size = New System.Drawing.Size(762, 341)
        Me.ModuleAddNew1.TabIndex = 0
        '
        'tabModuleSearch
        '
        Me.tabModuleSearch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabModuleSearch.Controls.Add(Me.Panel9)
        Me.tabModuleSearch.ImageIndex = 1
        Me.tabModuleSearch.Location = New System.Drawing.Point(4, 28)
        Me.tabModuleSearch.Name = "tabModuleSearch"
        Me.tabModuleSearch.Padding = New System.Windows.Forms.Padding(3)
        Me.tabModuleSearch.Size = New System.Drawing.Size(764, 343)
        Me.tabModuleSearch.TabIndex = 0
        Me.tabModuleSearch.Text = "Search"
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.ModuleSearch1)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel9.Location = New System.Drawing.Point(3, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(758, 337)
        Me.Panel9.TabIndex = 0
        '
        'ModuleSearch1
        '
        Me.ModuleSearch1.AutoScroll = True
        Me.ModuleSearch1.BackColor = System.Drawing.Color.Transparent
        Me.ModuleSearch1.BackgroundImage = CType(resources.GetObject("ModuleSearch1.BackgroundImage"), System.Drawing.Image)
        Me.ModuleSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ModuleSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModuleSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ModuleSearch1.Location = New System.Drawing.Point(0, 0)
        Me.ModuleSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.ModuleSearch1.Name = "ModuleSearch1"
        Me.ModuleSearch1.Size = New System.Drawing.Size(756, 335)
        Me.ModuleSearch1.TabIndex = 0
        '
        'tabModuleView
        '
        Me.tabModuleView.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabModuleView.Controls.Add(Me.Panel10)
        Me.tabModuleView.ImageIndex = 0
        Me.tabModuleView.Location = New System.Drawing.Point(4, 28)
        Me.tabModuleView.Name = "tabModuleView"
        Me.tabModuleView.Size = New System.Drawing.Size(764, 343)
        Me.tabModuleView.TabIndex = 5
        Me.tabModuleView.Text = "View"
        '
        'Panel10
        '
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.ModuleView1)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(0, 0)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(764, 343)
        Me.Panel10.TabIndex = 0
        '
        'ModuleView1
        '
        Me.ModuleView1.AutoScroll = True
        Me.ModuleView1.BackColor = System.Drawing.Color.Transparent
        Me.ModuleView1.BackgroundImage = CType(resources.GetObject("ModuleView1.BackgroundImage"), System.Drawing.Image)
        Me.ModuleView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ModuleView1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModuleView1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ModuleView1.Location = New System.Drawing.Point(0, 0)
        Me.ModuleView1.Margin = New System.Windows.Forms.Padding(4)
        Me.ModuleView1.Name = "ModuleView1"
        Me.ModuleView1.Size = New System.Drawing.Size(762, 341)
        Me.ModuleView1.TabIndex = 0
        '
        'tabGuardianMain
        '
        Me.tabGuardianMain.BackColor = System.Drawing.Color.Transparent
        Me.tabGuardianMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabGuardianMain.Controls.Add(Me.tabGuardian)
        Me.tabGuardianMain.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabGuardianMain.Location = New System.Drawing.Point(4, 26)
        Me.tabGuardianMain.Name = "tabGuardianMain"
        Me.tabGuardianMain.Size = New System.Drawing.Size(774, 377)
        Me.tabGuardianMain.TabIndex = 3
        Me.tabGuardianMain.Text = "GUARDIAN"
        '
        'tabGuardian
        '
        Me.tabGuardian.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabGuardian.Controls.Add(Me.tabGuardianAddNew)
        Me.tabGuardian.Controls.Add(Me.tabGuardianSearchView)
        Me.tabGuardian.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabGuardian.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabGuardian.ImageList = Me.ImageList1
        Me.tabGuardian.Location = New System.Drawing.Point(0, 0)
        Me.tabGuardian.Name = "tabGuardian"
        Me.tabGuardian.SelectedIndex = 0
        Me.tabGuardian.Size = New System.Drawing.Size(772, 375)
        Me.tabGuardian.TabIndex = 1
        Me.tabGuardian.TabStop = False
        '
        'tabGuardianAddNew
        '
        Me.tabGuardianAddNew.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabGuardianAddNew.Controls.Add(Me.Panel17)
        Me.tabGuardianAddNew.ImageIndex = 3
        Me.tabGuardianAddNew.Location = New System.Drawing.Point(4, 28)
        Me.tabGuardianAddNew.Name = "tabGuardianAddNew"
        Me.tabGuardianAddNew.Size = New System.Drawing.Size(764, 343)
        Me.tabGuardianAddNew.TabIndex = 4
        Me.tabGuardianAddNew.Text = "Add new"
        '
        'Panel17
        '
        Me.Panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel17.Controls.Add(Me.GuardianAddNew1)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel17.Location = New System.Drawing.Point(0, 0)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(764, 343)
        Me.Panel17.TabIndex = 0
        '
        'GuardianAddNew1
        '
        Me.GuardianAddNew1.AutoScroll = True
        Me.GuardianAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.GuardianAddNew1.BackgroundImage = CType(resources.GetObject("GuardianAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.GuardianAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GuardianAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GuardianAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.GuardianAddNew1.Location = New System.Drawing.Point(0, 0)
        Me.GuardianAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.GuardianAddNew1.Name = "GuardianAddNew1"
        Me.GuardianAddNew1.Size = New System.Drawing.Size(762, 341)
        Me.GuardianAddNew1.TabIndex = 0
        '
        'tabGuardianSearchView
        '
        Me.tabGuardianSearchView.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabGuardianSearchView.Controls.Add(Me.Panel11)
        Me.tabGuardianSearchView.ImageIndex = 1
        Me.tabGuardianSearchView.Location = New System.Drawing.Point(4, 28)
        Me.tabGuardianSearchView.Name = "tabGuardianSearchView"
        Me.tabGuardianSearchView.Size = New System.Drawing.Size(764, 343)
        Me.tabGuardianSearchView.TabIndex = 5
        Me.tabGuardianSearchView.Text = "Search & View"
        '
        'Panel11
        '
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel11.Controls.Add(Me.GuardianSearch1)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(0, 0)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(764, 343)
        Me.Panel11.TabIndex = 0
        '
        'GuardianSearch1
        '
        Me.GuardianSearch1.AutoScroll = True
        Me.GuardianSearch1.BackColor = System.Drawing.Color.Transparent
        Me.GuardianSearch1.BackgroundImage = CType(resources.GetObject("GuardianSearch1.BackgroundImage"), System.Drawing.Image)
        Me.GuardianSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GuardianSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GuardianSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.GuardianSearch1.Location = New System.Drawing.Point(0, 0)
        Me.GuardianSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.GuardianSearch1.Name = "GuardianSearch1"
        Me.GuardianSearch1.Size = New System.Drawing.Size(762, 341)
        Me.GuardianSearch1.TabIndex = 0
        '
        'tabBookMain
        '
        Me.tabBookMain.BackColor = System.Drawing.Color.Transparent
        Me.tabBookMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabBookMain.Controls.Add(Me.tabBook)
        Me.tabBookMain.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabBookMain.Location = New System.Drawing.Point(4, 26)
        Me.tabBookMain.Name = "tabBookMain"
        Me.tabBookMain.Size = New System.Drawing.Size(774, 377)
        Me.tabBookMain.TabIndex = 4
        Me.tabBookMain.Text = "BOOK"
        '
        'tabBook
        '
        Me.tabBook.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabBook.Controls.Add(Me.tabBookAddNew)
        Me.tabBook.Controls.Add(Me.tabBookSearch)
        Me.tabBook.Controls.Add(Me.tabBookView)
        Me.tabBook.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabBook.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabBook.ImageList = Me.ImageList1
        Me.tabBook.Location = New System.Drawing.Point(0, 0)
        Me.tabBook.Name = "tabBook"
        Me.tabBook.SelectedIndex = 0
        Me.tabBook.Size = New System.Drawing.Size(772, 375)
        Me.tabBook.TabIndex = 0
        Me.tabBook.TabStop = False
        '
        'tabBookAddNew
        '
        Me.tabBookAddNew.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabBookAddNew.Controls.Add(Me.Panel14)
        Me.tabBookAddNew.ImageIndex = 3
        Me.tabBookAddNew.Location = New System.Drawing.Point(4, 28)
        Me.tabBookAddNew.Name = "tabBookAddNew"
        Me.tabBookAddNew.Padding = New System.Windows.Forms.Padding(3)
        Me.tabBookAddNew.Size = New System.Drawing.Size(764, 343)
        Me.tabBookAddNew.TabIndex = 0
        Me.tabBookAddNew.Text = "Add new"
        '
        'Panel14
        '
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.BookAddNew1)
        Me.Panel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel14.Location = New System.Drawing.Point(3, 3)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(758, 337)
        Me.Panel14.TabIndex = 0
        '
        'BookAddNew1
        '
        Me.BookAddNew1.AutoScroll = True
        Me.BookAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.BookAddNew1.BackgroundImage = CType(resources.GetObject("BookAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.BookAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BookAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BookAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BookAddNew1.Location = New System.Drawing.Point(0, 0)
        Me.BookAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.BookAddNew1.Name = "BookAddNew1"
        Me.BookAddNew1.Size = New System.Drawing.Size(756, 335)
        Me.BookAddNew1.TabIndex = 0
        '
        'tabBookSearch
        '
        Me.tabBookSearch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabBookSearch.Controls.Add(Me.Panel12)
        Me.tabBookSearch.ImageIndex = 1
        Me.tabBookSearch.Location = New System.Drawing.Point(4, 28)
        Me.tabBookSearch.Name = "tabBookSearch"
        Me.tabBookSearch.Size = New System.Drawing.Size(764, 343)
        Me.tabBookSearch.TabIndex = 3
        Me.tabBookSearch.Text = "Search"
        '
        'Panel12
        '
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.BookSearch1)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(0, 0)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(764, 343)
        Me.Panel12.TabIndex = 0
        '
        'BookSearch1
        '
        Me.BookSearch1.AutoScroll = True
        Me.BookSearch1.BackColor = System.Drawing.Color.Transparent
        Me.BookSearch1.BackgroundImage = CType(resources.GetObject("BookSearch1.BackgroundImage"), System.Drawing.Image)
        Me.BookSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BookSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BookSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BookSearch1.Location = New System.Drawing.Point(0, 0)
        Me.BookSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.BookSearch1.Name = "BookSearch1"
        Me.BookSearch1.Size = New System.Drawing.Size(762, 341)
        Me.BookSearch1.TabIndex = 0
        '
        'tabBookView
        '
        Me.tabBookView.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabBookView.Controls.Add(Me.Panel13)
        Me.tabBookView.ImageIndex = 0
        Me.tabBookView.Location = New System.Drawing.Point(4, 28)
        Me.tabBookView.Name = "tabBookView"
        Me.tabBookView.Padding = New System.Windows.Forms.Padding(3)
        Me.tabBookView.Size = New System.Drawing.Size(764, 343)
        Me.tabBookView.TabIndex = 1
        Me.tabBookView.Text = "View"
        '
        'Panel13
        '
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.BookView1)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel13.Location = New System.Drawing.Point(3, 3)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(758, 337)
        Me.Panel13.TabIndex = 0
        '
        'BookView1
        '
        Me.BookView1.AutoScroll = True
        Me.BookView1.BackColor = System.Drawing.Color.Transparent
        Me.BookView1.BackgroundImage = CType(resources.GetObject("BookView1.BackgroundImage"), System.Drawing.Image)
        Me.BookView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BookView1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BookView1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BookView1.Location = New System.Drawing.Point(0, 0)
        Me.BookView1.Margin = New System.Windows.Forms.Padding(4)
        Me.BookView1.Name = "BookView1"
        Me.BookView1.Size = New System.Drawing.Size(756, 335)
        Me.BookView1.TabIndex = 0
        '
        'tabIssueMain
        '
        Me.tabIssueMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabIssueMain.Controls.Add(Me.tabIssue)
        Me.tabIssueMain.Font = New System.Drawing.Font("Cambria", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabIssueMain.Location = New System.Drawing.Point(4, 26)
        Me.tabIssueMain.Name = "tabIssueMain"
        Me.tabIssueMain.Size = New System.Drawing.Size(774, 377)
        Me.tabIssueMain.TabIndex = 6
        Me.tabIssueMain.Text = "BOOK-ISSUE"
        Me.tabIssueMain.UseVisualStyleBackColor = True
        '
        'tabIssue
        '
        Me.tabIssue.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabIssue.Controls.Add(Me.tabIssueAddNew)
        Me.tabIssue.Controls.Add(Me.tabIssueBookReturn)
        Me.tabIssue.Controls.Add(Me.tabIssueView)
        Me.tabIssue.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabIssue.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabIssue.ImageList = Me.ImageList1
        Me.tabIssue.Location = New System.Drawing.Point(0, 0)
        Me.tabIssue.Name = "tabIssue"
        Me.tabIssue.SelectedIndex = 0
        Me.tabIssue.Size = New System.Drawing.Size(772, 375)
        Me.tabIssue.TabIndex = 1
        Me.tabIssue.TabStop = False
        '
        'tabIssueAddNew
        '
        Me.tabIssueAddNew.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabIssueAddNew.Controls.Add(Me.Panel15)
        Me.tabIssueAddNew.ImageIndex = 3
        Me.tabIssueAddNew.Location = New System.Drawing.Point(4, 28)
        Me.tabIssueAddNew.Name = "tabIssueAddNew"
        Me.tabIssueAddNew.Size = New System.Drawing.Size(764, 343)
        Me.tabIssueAddNew.TabIndex = 3
        Me.tabIssueAddNew.Text = "Add new"
        '
        'Panel15
        '
        Me.Panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel15.Controls.Add(Me.IssueAddNew1)
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel15.Location = New System.Drawing.Point(0, 0)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(764, 343)
        Me.Panel15.TabIndex = 0
        '
        'IssueAddNew1
        '
        Me.IssueAddNew1.AutoScroll = True
        Me.IssueAddNew1.BackColor = System.Drawing.Color.Transparent
        Me.IssueAddNew1.BackgroundImage = CType(resources.GetObject("IssueAddNew1.BackgroundImage"), System.Drawing.Image)
        Me.IssueAddNew1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.IssueAddNew1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IssueAddNew1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.IssueAddNew1.Location = New System.Drawing.Point(0, 0)
        Me.IssueAddNew1.Margin = New System.Windows.Forms.Padding(4)
        Me.IssueAddNew1.Name = "IssueAddNew1"
        Me.IssueAddNew1.Size = New System.Drawing.Size(762, 341)
        Me.IssueAddNew1.TabIndex = 0
        '
        'tabIssueBookReturn
        '
        Me.tabIssueBookReturn.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabIssueBookReturn.Controls.Add(Me.Panel16)
        Me.tabIssueBookReturn.ImageIndex = 1
        Me.tabIssueBookReturn.Location = New System.Drawing.Point(4, 28)
        Me.tabIssueBookReturn.Name = "tabIssueBookReturn"
        Me.tabIssueBookReturn.Size = New System.Drawing.Size(764, 343)
        Me.tabIssueBookReturn.TabIndex = 4
        Me.tabIssueBookReturn.Text = "Book return"
        '
        'Panel16
        '
        Me.Panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel16.Controls.Add(Me.IssueSearch1)
        Me.Panel16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel16.Location = New System.Drawing.Point(0, 0)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(764, 343)
        Me.Panel16.TabIndex = 0
        '
        'IssueSearch1
        '
        Me.IssueSearch1.AutoScroll = True
        Me.IssueSearch1.BackColor = System.Drawing.Color.Transparent
        Me.IssueSearch1.BackgroundImage = CType(resources.GetObject("IssueSearch1.BackgroundImage"), System.Drawing.Image)
        Me.IssueSearch1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.IssueSearch1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IssueSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.IssueSearch1.Location = New System.Drawing.Point(0, 0)
        Me.IssueSearch1.Margin = New System.Windows.Forms.Padding(4)
        Me.IssueSearch1.Name = "IssueSearch1"
        Me.IssueSearch1.Size = New System.Drawing.Size(762, 341)
        Me.IssueSearch1.TabIndex = 0
        '
        'tabIssueView
        '
        Me.tabIssueView.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabIssueView.Controls.Add(Me.Panel18)
        Me.tabIssueView.ImageIndex = 0
        Me.tabIssueView.Location = New System.Drawing.Point(4, 28)
        Me.tabIssueView.Name = "tabIssueView"
        Me.tabIssueView.Size = New System.Drawing.Size(764, 343)
        Me.tabIssueView.TabIndex = 5
        Me.tabIssueView.Text = "View"
        '
        'Panel18
        '
        Me.Panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel18.Controls.Add(Me.IssueView1)
        Me.Panel18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel18.Location = New System.Drawing.Point(0, 0)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(764, 343)
        Me.Panel18.TabIndex = 0
        '
        'IssueView1
        '
        Me.IssueView1.AutoScroll = True
        Me.IssueView1.BackColor = System.Drawing.Color.Transparent
        Me.IssueView1.BackgroundImage = CType(resources.GetObject("IssueView1.BackgroundImage"), System.Drawing.Image)
        Me.IssueView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.IssueView1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IssueView1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.IssueView1.Location = New System.Drawing.Point(0, 0)
        Me.IssueView1.Margin = New System.Windows.Forms.Padding(4)
        Me.IssueView1.Name = "IssueView1"
        Me.IssueView1.Size = New System.Drawing.Size(762, 341)
        Me.IssueView1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel2.Location = New System.Drawing.Point(95, 132)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(628, 126)
        Me.Panel2.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Font = New System.Drawing.Font("Cambria", 20.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(104, 63)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(514, 3)
        Me.Label3.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Cambria", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(181, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(360, 32)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Informatics College Pokhara"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Cambria", 18.5!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(131, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(480, 30)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Student and Lecturer Information System"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = Global.Icp.My.Resources.Resources.MainLogo
        Me.PictureBox2.Location = New System.Drawing.Point(4, 13)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(95, 105)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(784, 409)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(784, 461)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(800, 500)
        Me.Name = "FormMain"
        Me.Text = "Student and Lecturer Information System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tabStudentMain.ResumeLayout(False)
        Me.tabStudent.ResumeLayout(False)
        Me.tabStudentAddNew.ResumeLayout(False)
        Me.tabStudentSearch.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.tabStudentView.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.tabLecturerMain.ResumeLayout(False)
        Me.tabLecturer.ResumeLayout(False)
        Me.tabLecturerAddNew.ResumeLayout(False)
        Me.tabLecturerSearch.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.tabLecturerView.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.tabModuleMain.ResumeLayout(False)
        Me.tabModule.ResumeLayout(False)
        Me.tabModuleAddNew.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.tabModuleSearch.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.tabModuleView.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.tabGuardianMain.ResumeLayout(False)
        Me.tabGuardian.ResumeLayout(False)
        Me.tabGuardianAddNew.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.tabGuardianSearchView.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.tabBookMain.ResumeLayout(False)
        Me.tabBook.ResumeLayout(False)
        Me.tabBookAddNew.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.tabBookSearch.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.tabBookView.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.tabIssueMain.ResumeLayout(False)
        Me.tabIssue.ResumeLayout(False)
        Me.tabIssueAddNew.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.tabIssueBookReturn.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.tabIssueView.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FILEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WINDOWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutSLISToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutDeveloperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StudentToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddAdmissionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LecturerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ManageUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabLecturerMain As System.Windows.Forms.TabPage
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents tabModuleMain As System.Windows.Forms.TabPage
    Friend WithEvents tabGuardianMain As System.Windows.Forms.TabPage
    Friend WithEvents tabBookMain As System.Windows.Forms.TabPage
    Friend WithEvents tabBook As System.Windows.Forms.TabControl
    Friend WithEvents tabBookAddNew As System.Windows.Forms.TabPage
    Friend WithEvents tabBookView As System.Windows.Forms.TabPage
    Friend WithEvents tabModule As System.Windows.Forms.TabControl
    Friend WithEvents tabModuleSearch As System.Windows.Forms.TabPage
    Friend WithEvents tabStudentMain As System.Windows.Forms.TabPage
    Friend WithEvents tabStudent As System.Windows.Forms.TabControl
    Friend WithEvents tabStudentSearch As System.Windows.Forms.TabPage
    Friend WithEvents tabStudentView As System.Windows.Forms.TabPage
    Friend WithEvents tabLecturer As System.Windows.Forms.TabControl
    Friend WithEvents tabLecturerSearch As System.Windows.Forms.TabPage
    Friend WithEvents tabLecturerView As System.Windows.Forms.TabPage
    Friend WithEvents tabModuleAddNew As System.Windows.Forms.TabPage
    Friend WithEvents tabBookSearch As System.Windows.Forms.TabPage
    Friend WithEvents tabGuardian As System.Windows.Forms.TabControl
    Friend WithEvents tabGuardianAddNew As System.Windows.Forms.TabPage
    Friend WithEvents SEARCHToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchStudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchLecturerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddStudentAdditionalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents StudentView1 As ControlLibrary_IMS.StudentView
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents LecturerSearch1 As ControlLibrary_IMS.LecturerSearch
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents LecturerView1 As ControlLibrary_IMS.LecturerView
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents ModuleAddNew1 As ControlLibrary_IMS.ModuleAddNew
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents ModuleSearch1 As ControlLibrary_IMS.ModuleSearch
    Friend WithEvents tabModuleView As System.Windows.Forms.TabPage
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents ModuleView1 As ControlLibrary_IMS.ModuleView
    Friend WithEvents AddLecturerAdditionalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tabGuardianSearchView As System.Windows.Forms.TabPage
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents GuardianSearch1 As ControlLibrary_IMS.GuardianSearch
    Friend WithEvents tabIssueMain As System.Windows.Forms.TabPage
    Friend WithEvents tabIssue As System.Windows.Forms.TabControl
    Friend WithEvents tabIssueAddNew As System.Windows.Forms.TabPage
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents BookSearch1 As ControlLibrary_IMS.BookSearch
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents BookView1 As ControlLibrary_IMS.BookView
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents BookAddNew1 As ControlLibrary_IMS.BookAddNew
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents IssueAddNew1 As ControlLibrary_IMS.IssueAddNew
    Friend WithEvents tabIssueBookReturn As System.Windows.Forms.TabPage
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents IssueSearch1 As ControlLibrary_IMS.IssueSearch
    Friend WithEvents SearchModuleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchBookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchBookIssueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents GuardianAddNew1 As ControlLibrary_IMS.GuardianAddNew
    Friend WithEvents tabIssueView As System.Windows.Forms.TabPage
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents IssueView1 As ControlLibrary_IMS.IssueView
    Friend WithEvents AddStudentCurrentModuleDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddLecturerCurrentModuleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents G0T0ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentAddNewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentSearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LecturerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LecturerAddNewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LecturerSearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LecturerViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModuleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModuleAddNewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModuleSearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModuleViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GuardianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GuardianAddNewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GuardianSearchViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookAddNewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookSearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IssueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IssueAddNewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookReturnToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IssueViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tabLecturerAddNew As System.Windows.Forms.TabPage
    Friend WithEvents LecturerAddNew1 As ControlLibrary_IMS.LecturerAddNew
    Friend WithEvents tabStudentAddNew As System.Windows.Forms.TabPage
    Friend WithEvents StudentAddNew1 As ControlLibrary_IMS.StudentAddNew
    Friend WithEvents SearchGuardiansToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents OpenMainFormToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CloseMainFormToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentSearch1 As ControlLibrary_IMS.StudentSearch
    Friend WithEvents BackupRestoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
End Class
