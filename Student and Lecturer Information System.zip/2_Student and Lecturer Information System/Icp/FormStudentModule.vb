﻿Public Class FormStudentModule

    'FORM LOAD EVENT
    Private Sub FormStudentModule_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Set the size of the form
        Me.Size = New Size(1102, 669)
    End Sub

    'ENTER EVENT OF TAB PAGE 1
    Private Sub TabPage1_Enter(sender As Object, e As EventArgs) Handles TabPage1.Enter
        'Set the size of the form
        Me.Size = New Size(1102, 669)
    End Sub

    'ENTER EVENT OF TAB PAGE 2
    Private Sub TabPage2_Enter(sender As Object, e As EventArgs) Handles TabPage2.Enter
        'Set the size of the form
        Me.Size = New Size(1207, 655)
    End Sub
End Class