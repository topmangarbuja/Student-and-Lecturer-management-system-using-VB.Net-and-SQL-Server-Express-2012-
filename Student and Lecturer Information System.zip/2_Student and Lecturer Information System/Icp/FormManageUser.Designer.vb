﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormManageUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormManageUser))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabCreateUser = New System.Windows.Forms.TabPage()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.chkNewUserShowPassword = New System.Windows.Forms.CheckBox()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtNewUserConfirmPassword = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtNewUserUsername = New System.Windows.Forms.TextBox()
        Me.txtNewUserPassword = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.rdbNewUserNo = New System.Windows.Forms.RadioButton()
        Me.rdbNewUserYes = New System.Windows.Forms.RadioButton()
        Me.tabModifyUser = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnViewAll = New System.Windows.Forms.Button()
        Me.grdUserDetails = New System.Windows.Forms.DataGridView()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtExistUserUsername = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtExistUserPassword = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtExistUserType = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtExistUserLastLoginDate = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdbExistUserNo = New System.Windows.Forms.RadioButton()
        Me.rdbExistUserYes = New System.Windows.Forms.RadioButton()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.tabCreateUser.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.tabModifyUser.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.grdUserDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabCreateUser)
        Me.TabControl1.Controls.Add(Me.tabModifyUser)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.ImageList = Me.ImageList1
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(473, 520)
        Me.TabControl1.TabIndex = 1
        Me.TabControl1.TabStop = False
        '
        'tabCreateUser
        '
        Me.tabCreateUser.AutoScroll = True
        Me.tabCreateUser.BackColor = System.Drawing.Color.White
        Me.tabCreateUser.BackgroundImage = Global.Icp.My.Resources.Resources.background
        Me.tabCreateUser.Controls.Add(Me.btnClear)
        Me.tabCreateUser.Controls.Add(Me.chkNewUserShowPassword)
        Me.tabCreateUser.Controls.Add(Me.btnCreate)
        Me.tabCreateUser.Controls.Add(Me.GroupBox2)
        Me.tabCreateUser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.tabCreateUser.ImageIndex = 0
        Me.tabCreateUser.Location = New System.Drawing.Point(4, 23)
        Me.tabCreateUser.Name = "tabCreateUser"
        Me.tabCreateUser.Padding = New System.Windows.Forms.Padding(3)
        Me.tabCreateUser.Size = New System.Drawing.Size(465, 493)
        Me.tabCreateUser.TabIndex = 0
        Me.tabCreateUser.Text = "Create User"
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(268, 160)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(117, 32)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'chkNewUserShowPassword
        '
        Me.chkNewUserShowPassword.AutoSize = True
        Me.chkNewUserShowPassword.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.chkNewUserShowPassword.Location = New System.Drawing.Point(14, 167)
        Me.chkNewUserShowPassword.Name = "chkNewUserShowPassword"
        Me.chkNewUserShowPassword.Size = New System.Drawing.Size(127, 21)
        Me.chkNewUserShowPassword.TabIndex = 0
        Me.chkNewUserShowPassword.TabStop = False
        Me.chkNewUserShowPassword.Text = "Show Password"
        Me.ToolTip1.SetToolTip(Me.chkNewUserShowPassword, "Show Password")
        Me.chkNewUserShowPassword.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCreate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnCreate.Location = New System.Drawing.Point(147, 160)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(117, 32)
        Me.btnCreate.TabIndex = 1
        Me.btnCreate.Text = "Create"
        Me.ToolTip1.SetToolTip(Me.btnCreate, "Click to add new user account.")
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.GroupBox2.Font = New System.Drawing.Font("Stencil", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(3, 4)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(396, 153)
        Me.GroupBox2.TabIndex = 12
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "new user"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtNewUserConfirmPassword, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtNewUserUsername, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtNewUserPassword, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 1, 3)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(7, 17)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(382, 131)
        Me.TableLayoutPanel1.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Label10.Location = New System.Drawing.Point(3, 104)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 17)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Active:"
        '
        'txtNewUserConfirmPassword
        '
        Me.txtNewUserConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewUserConfirmPassword.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewUserConfirmPassword.Location = New System.Drawing.Point(137, 67)
        Me.txtNewUserConfirmPassword.MaxLength = 15
        Me.txtNewUserConfirmPassword.Name = "txtNewUserConfirmPassword"
        Me.txtNewUserConfirmPassword.Size = New System.Drawing.Size(238, 25)
        Me.txtNewUserConfirmPassword.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtNewUserConfirmPassword, "Confirm Password")
        Me.txtNewUserConfirmPassword.UseSystemPasswordChar = True
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Username:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Password:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 71)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Confirm Password:"
        '
        'txtNewUserUsername
        '
        Me.txtNewUserUsername.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtNewUserUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewUserUsername.Font = New System.Drawing.Font("Cambria", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewUserUsername.Location = New System.Drawing.Point(137, 4)
        Me.txtNewUserUsername.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtNewUserUsername.MaxLength = 15
        Me.txtNewUserUsername.Name = "txtNewUserUsername"
        Me.txtNewUserUsername.Size = New System.Drawing.Size(238, 25)
        Me.txtNewUserUsername.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtNewUserUsername, "Username")
        '
        'txtNewUserPassword
        '
        Me.txtNewUserPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewUserPassword.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewUserPassword.Location = New System.Drawing.Point(137, 36)
        Me.txtNewUserPassword.MaxLength = 15
        Me.txtNewUserPassword.Name = "txtNewUserPassword"
        Me.txtNewUserPassword.Size = New System.Drawing.Size(238, 25)
        Me.txtNewUserPassword.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtNewUserPassword, "Password")
        Me.txtNewUserPassword.UseSystemPasswordChar = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.rdbNewUserNo)
        Me.Panel2.Controls.Add(Me.rdbNewUserYes)
        Me.Panel2.Location = New System.Drawing.Point(137, 98)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(238, 26)
        Me.Panel2.TabIndex = 20
        '
        'rdbNewUserNo
        '
        Me.rdbNewUserNo.AutoSize = True
        Me.rdbNewUserNo.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbNewUserNo.Location = New System.Drawing.Point(60, 3)
        Me.rdbNewUserNo.Name = "rdbNewUserNo"
        Me.rdbNewUserNo.Size = New System.Drawing.Size(44, 21)
        Me.rdbNewUserNo.TabIndex = 1
        Me.rdbNewUserNo.TabStop = True
        Me.rdbNewUserNo.Text = "No"
        Me.ToolTip1.SetToolTip(Me.rdbNewUserNo, "No")
        Me.rdbNewUserNo.UseVisualStyleBackColor = True
        '
        'rdbNewUserYes
        '
        Me.rdbNewUserYes.AutoSize = True
        Me.rdbNewUserYes.Checked = True
        Me.rdbNewUserYes.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbNewUserYes.Location = New System.Drawing.Point(7, 3)
        Me.rdbNewUserYes.Name = "rdbNewUserYes"
        Me.rdbNewUserYes.Size = New System.Drawing.Size(47, 21)
        Me.rdbNewUserYes.TabIndex = 0
        Me.rdbNewUserYes.TabStop = True
        Me.rdbNewUserYes.Text = "Yes"
        Me.ToolTip1.SetToolTip(Me.rdbNewUserYes, "Yes")
        Me.rdbNewUserYes.UseVisualStyleBackColor = True
        '
        'tabModifyUser
        '
        Me.tabModifyUser.BackColor = System.Drawing.Color.White
        Me.tabModifyUser.Controls.Add(Me.GroupBox3)
        Me.tabModifyUser.Controls.Add(Me.GroupBox1)
        Me.tabModifyUser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.tabModifyUser.ImageIndex = 2
        Me.tabModifyUser.Location = New System.Drawing.Point(4, 23)
        Me.tabModifyUser.Name = "tabModifyUser"
        Me.tabModifyUser.Padding = New System.Windows.Forms.Padding(3)
        Me.tabModifyUser.Size = New System.Drawing.Size(465, 493)
        Me.tabModifyUser.TabIndex = 1
        Me.tabModifyUser.Text = "Modify User"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GroupBox3.Controls.Add(Me.TableLayoutPanel3)
        Me.GroupBox3.Font = New System.Drawing.Font("Stencil", 9.75!)
        Me.GroupBox3.Location = New System.Drawing.Point(525, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(434, 139)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Modify User Details"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 5
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.Controls.Add(Me.Button9, 4, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Button8, 3, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Button6, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Button4, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox5, 2, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(6, 47)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(246, 30)
        Me.TableLayoutPanel3.TabIndex = 11
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Button9.Location = New System.Drawing.Point(210, 3)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(33, 24)
        Me.Button9.TabIndex = 16
        Me.Button9.Text = ">|"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Button8.Location = New System.Drawing.Point(171, 3)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(33, 24)
        Me.Button8.TabIndex = 15
        Me.Button8.Text = ">"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Button6.Location = New System.Drawing.Point(42, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(33, 24)
        Me.Button6.TabIndex = 13
        Me.Button6.Text = "<"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Button4.Location = New System.Drawing.Point(3, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(33, 24)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "|<"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TextBox5
        '
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox5.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.TextBox5.Location = New System.Drawing.Point(81, 3)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(84, 25)
        Me.TextBox5.TabIndex = 15
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.BackgroundImage = Global.Icp.My.Resources.Resources.background
        Me.GroupBox1.Controls.Add(Me.btnViewAll)
        Me.GroupBox1.Controls.Add(Me.grdUserDetails)
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel2)
        Me.GroupBox1.Controls.Add(Me.btnUpdate)
        Me.GroupBox1.Controls.Add(Me.btnDelete)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 9.75!)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(447, 481)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "View and Modify User Details"
        '
        'btnViewAll
        '
        Me.btnViewAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAll.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAll.Location = New System.Drawing.Point(6, 14)
        Me.btnViewAll.Name = "btnViewAll"
        Me.btnViewAll.Size = New System.Drawing.Size(117, 32)
        Me.btnViewAll.TabIndex = 8
        Me.btnViewAll.Text = "View all"
        Me.ToolTip1.SetToolTip(Me.btnViewAll, "View all of the Admin2 user account details.")
        Me.btnViewAll.UseVisualStyleBackColor = True
        '
        'grdUserDetails
        '
        Me.grdUserDetails.AllowUserToAddRows = False
        Me.grdUserDetails.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdUserDetails.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdUserDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.grdUserDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdUserDetails.Location = New System.Drawing.Point(6, 50)
        Me.grdUserDetails.MultiSelect = False
        Me.grdUserDetails.Name = "grdUserDetails"
        Me.grdUserDetails.ReadOnly = True
        Me.grdUserDetails.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Cambria Math", 10.25!)
        Me.grdUserDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdUserDetails.Size = New System.Drawing.Size(434, 212)
        Me.grdUserDetails.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.grdUserDetails, "Select a record and get the data in the below section.")
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.txtExistUserUsername, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtExistUserPassword, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtExistUserType, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.txtExistUserLastLoginDate, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel1, 1, 4)
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 8.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(6, 280)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 5
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(381, 156)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'txtExistUserUsername
        '
        Me.txtExistUserUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExistUserUsername.Enabled = False
        Me.txtExistUserUsername.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtExistUserUsername.Location = New System.Drawing.Point(117, 3)
        Me.txtExistUserUsername.MaxLength = 15
        Me.txtExistUserUsername.Name = "txtExistUserUsername"
        Me.txtExistUserUsername.Size = New System.Drawing.Size(258, 25)
        Me.txtExistUserUsername.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.txtExistUserUsername, "Username")
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Label7.Location = New System.Drawing.Point(3, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 17)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Username:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Label8.Location = New System.Drawing.Point(3, 38)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 17)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Password:"
        '
        'txtExistUserPassword
        '
        Me.txtExistUserPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExistUserPassword.Enabled = False
        Me.txtExistUserPassword.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExistUserPassword.Location = New System.Drawing.Point(117, 34)
        Me.txtExistUserPassword.MaxLength = 15
        Me.txtExistUserPassword.Name = "txtExistUserPassword"
        Me.txtExistUserPassword.Size = New System.Drawing.Size(258, 25)
        Me.txtExistUserPassword.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.txtExistUserPassword, "Password")
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Label5.Location = New System.Drawing.Point(3, 131)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 17)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Active:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Label6.Location = New System.Drawing.Point(3, 69)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Type:"
        '
        'txtExistUserType
        '
        Me.txtExistUserType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExistUserType.Enabled = False
        Me.txtExistUserType.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExistUserType.Location = New System.Drawing.Point(117, 65)
        Me.txtExistUserType.Name = "txtExistUserType"
        Me.txtExistUserType.ReadOnly = True
        Me.txtExistUserType.Size = New System.Drawing.Size(258, 25)
        Me.txtExistUserType.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.txtExistUserType, "Type")
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.Label4.Location = New System.Drawing.Point(3, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 17)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Last Login Date:"
        '
        'txtExistUserLastLoginDate
        '
        Me.txtExistUserLastLoginDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExistUserLastLoginDate.Enabled = False
        Me.txtExistUserLastLoginDate.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtExistUserLastLoginDate.Location = New System.Drawing.Point(117, 96)
        Me.txtExistUserLastLoginDate.Name = "txtExistUserLastLoginDate"
        Me.txtExistUserLastLoginDate.ReadOnly = True
        Me.txtExistUserLastLoginDate.Size = New System.Drawing.Size(258, 25)
        Me.txtExistUserLastLoginDate.TabIndex = 14
        Me.ToolTip1.SetToolTip(Me.txtExistUserLastLoginDate, "Last Login Date")
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rdbExistUserNo)
        Me.Panel1.Controls.Add(Me.rdbExistUserYes)
        Me.Panel1.Location = New System.Drawing.Point(117, 127)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(238, 26)
        Me.Panel1.TabIndex = 17
        '
        'rdbExistUserNo
        '
        Me.rdbExistUserNo.AutoSize = True
        Me.rdbExistUserNo.Enabled = False
        Me.rdbExistUserNo.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbExistUserNo.Location = New System.Drawing.Point(65, 3)
        Me.rdbExistUserNo.Name = "rdbExistUserNo"
        Me.rdbExistUserNo.Size = New System.Drawing.Size(44, 21)
        Me.rdbExistUserNo.TabIndex = 18
        Me.rdbExistUserNo.TabStop = True
        Me.rdbExistUserNo.Text = "No"
        Me.ToolTip1.SetToolTip(Me.rdbExistUserNo, "No")
        Me.rdbExistUserNo.UseVisualStyleBackColor = True
        '
        'rdbExistUserYes
        '
        Me.rdbExistUserYes.AutoSize = True
        Me.rdbExistUserYes.Enabled = False
        Me.rdbExistUserYes.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbExistUserYes.Location = New System.Drawing.Point(12, 2)
        Me.rdbExistUserYes.Name = "rdbExistUserYes"
        Me.rdbExistUserYes.Size = New System.Drawing.Size(47, 21)
        Me.rdbExistUserYes.TabIndex = 17
        Me.rdbExistUserYes.TabStop = True
        Me.rdbExistUserYes.Text = "Yes"
        Me.ToolTip1.SetToolTip(Me.rdbExistUserYes, "Yes")
        Me.rdbExistUserYes.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Enabled = False
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(123, 442)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(117, 32)
        Me.btnUpdate.TabIndex = 6
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Enabled = False
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(246, 442)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(117, 32)
        Me.btnDelete.TabIndex = 7
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected user account.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "1431585835_Add-Male-User.png")
        Me.ImageList1.Images.SetKeyName(1, "1431596546_sign-up.png")
        Me.ImageList1.Images.SetKeyName(2, "1431596800_Edit-Male-User.png")
        '
        'FormManageUser
        '
        Me.AcceptButton = Me.btnCreate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(473, 520)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormManageUser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage User"
        Me.TabControl1.ResumeLayout(False)
        Me.tabCreateUser.ResumeLayout(False)
        Me.tabCreateUser.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.tabModifyUser.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.grdUserDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabCreateUser As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtNewUserUsername As System.Windows.Forms.TextBox
    Friend WithEvents tabModifyUser As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtExistUserPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtExistUserType As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents chkNewUserShowPassword As System.Windows.Forms.CheckBox
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtNewUserPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtExistUserUsername As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtExistUserLastLoginDate As System.Windows.Forms.TextBox
    Friend WithEvents txtNewUserConfirmPassword As System.Windows.Forms.TextBox
    Friend WithEvents btnViewAll As System.Windows.Forms.Button
    Friend WithEvents grdUserDetails As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbExistUserYes As System.Windows.Forms.RadioButton
    Friend WithEvents rdbExistUserNo As System.Windows.Forms.RadioButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents rdbNewUserNo As System.Windows.Forms.RadioButton
    Friend WithEvents rdbNewUserYes As System.Windows.Forms.RadioButton
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
