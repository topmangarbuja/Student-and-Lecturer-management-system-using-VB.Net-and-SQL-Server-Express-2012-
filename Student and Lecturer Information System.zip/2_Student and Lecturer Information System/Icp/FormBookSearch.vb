﻿Public Class FormBookSearch
    Public Event UncheckMenuItem(sender As Object)


    Private Sub FormBookSearch_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        RaiseEvent UncheckMenuItem(sender)
    End Sub
End Class