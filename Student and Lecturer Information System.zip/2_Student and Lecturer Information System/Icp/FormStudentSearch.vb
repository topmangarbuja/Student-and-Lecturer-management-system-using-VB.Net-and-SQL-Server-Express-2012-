﻿Public Class FormStudentSearch
    Public Event UncheckMenuItem(sender As System.Object)

    Private Sub FormStudentSearch_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        RaiseEvent UncheckMenuItem(sender)
    End Sub

    Private Sub FormStudentSearch_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class