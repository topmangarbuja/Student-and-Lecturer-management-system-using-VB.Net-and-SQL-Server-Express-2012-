﻿Imports ClassLibrary_IMS
Imports System.Configuration


Public Class FormBackupRestore
    Dim objBackupRestore As New BackupRestore
    Private strBackupDatabase As String
    Private strBackupPath As String = ConfigurationSettings.AppSettings("BackupPath")
    Private strRestorePath As String = ConfigurationSettings.AppSettings("RestorePath")

    Private Sub FormBackupRestore_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Backup() = False Then
            btnApplyBackup.Enabled = False
        Else
            btnApplyBackup.Enabled = True
        End If

        If Restore() = False Then
            btnApplyRestore.Enabled = False
        Else
            btnApplyRestore.Enabled = True
        End If
    End Sub

    Private Sub btnResetBackup_Click(sender As Object, e As EventArgs) Handles btnResetBackup.Click
        txtBackupPath.ForeColor = Color.Gray
        txtBackupPath.BackColor = Color.White
        txtBackupPath.Text = "You get it through configuration settings"

        cboDatabaseBackup.Items.Clear()
        cboDatabaseBackup.Items.Add("IcpAdmin")
        cboDatabaseBackup.Items.Add("IcpInfo")

        If Backup() = False Then
            btnApplyBackup.Enabled = False
        Else
            btnApplyBackup.Enabled = True
        End If
    End Sub


    Private Sub btnApplyBackup_Click(sender As Object, e As EventArgs) Handles btnApplyBackup.Click
        strBackupDatabase = cboDatabaseBackup.Text
        If cboDatabaseBackup.SelectedItem.ToString.Contains("IcpAdmin") Then
            objBackupRestore.RunQuery("BACKUP DATABASE " & strBackupDatabase & " TO disk= '" & strBackupPath & "\IcpAdmin.bak' WITH INIT;")
        Else
            objBackupRestore.RunQuery("BACKUP DATABASE " & strBackupDatabase & " TO disk= '" & strBackupPath & "\IcpInfo.bak' WITH INIT;")
        End If

        If objBackupRestore.strExceptionRunQuery <> "" Then
            'Show error message
            MessageBox.Show(objBackupRestore.strExceptionRunQuery, "Failed | Backup database", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            objBackupRestore.strExceptionRunQuery = Nothing
        Else
            'Show succeed message
            MessageBox.Show("You have successfully backup the selected database.", "Succeed | Backup database", MessageBoxButtons.OK, MessageBoxIcon.Information)

            btnResetBackup_Click(Nothing, Nothing)
        End If
    End Sub

    Private Function Backup() As Boolean
        If cboDatabaseBackup.SelectedIndex > -1 Then
            Return True
        Else
            Return False
        End If
    End Function


    Private Sub cboDatabaseBackup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDatabaseBackup.SelectedIndexChanged
        If Backup() = False Then
            btnApplyBackup.Enabled = False
        Else
            btnApplyBackup.Enabled = True
            txtBackupPath.Text = strBackupPath
            txtBackupPath.ForeColor = Color.Black
            txtBackupPath.BackColor = Color.WhiteSmoke
        End If
    End Sub












    Private Sub btnResetRestore_Click(sender As Object, e As EventArgs) Handles btnResetRestore.Click
        txtRestorePath.Text = "You get it through configuration settings"
        txtRestorePath.ForeColor = Color.Gray
        txtRestorePath.BackColor = Color.White

        cboDatabaseRestore.Items.Clear()
        cboDatabaseRestore.Items.Add("IcpAdmin")
        cboDatabaseRestore.Items.Add("IcpInfo")


        If Restore() = False Then
            btnApplyRestore.Enabled = False
        Else
            btnApplyRestore.Enabled = True
        End If
    End Sub

    Private Sub btnApplyRestore_Click(sender As Object, e As EventArgs) Handles btnApplyRestore.Click
        If cboDatabaseRestore.SelectedIndex = 0 Then
            objBackupRestore.RunQuery("ALTER DATABASE IcpAdmin " & _
                "SET SINGLE_USER " & _
                "WITH ROLLBACK IMMEDIATE; " & _
                "RESTORE DATABASE  IcpAdmin  FROM DISK='" & strBackupPath & "\IcpAdmin.bak' " & _
                "WITH FILE=1, " & _
                "Move N'IcpAdmin' TO '" & strRestorePath & "\IcpAdmin.mdf'," & _
                "Move N'IcpAdmin_Log'  TO '" & strRestorePath & "\IcpAdmin_Log.mdf'; " & _
                "ALTER DATABASE IcpAdmin SET MULTI_USER;")
        ElseIf cboDatabaseRestore.SelectedIndex = 1 Then
            objBackupRestore.RunQuery("ALTER DATABASE IcpInfo " & _
                "SET SINGLE_USER " & _
                "WITH ROLLBACK IMMEDIATE; " & _
                "RESTORE DATABASE  IcpInfo  FROM DISK='" & strBackupPath & "\IcpInfo.bak' " & _
                "WITH FILE=1, " & _
                "Move N'IcpInfo' TO '" & strRestorePath & "\IcpInfo.mdf'," & _
                "Move N'IcpInfo_Log'  TO '" & strRestorePath & "\IcpInfo_Log.mdf'; " & _
                "ALTER DATABASE IcpInfo SET MULTI_USER;")
        End If

        If objBackupRestore.strExceptionRunQuery <> "" Then
            'Show error message
            MessageBox.Show(objBackupRestore.strExceptionRunQuery, "Failed | Restore database", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            objBackupRestore.strExceptionRunQuery = Nothing
        Else
            'Show succeed message
            MessageBox.Show("You have successfully restore the selected database.", "Succeed | Restore database", MessageBoxButtons.OK, MessageBoxIcon.Information)

            btnResetRestore_Click(Nothing, Nothing)
        End If
    End Sub


    Private Function Restore() As Boolean
        If cboDatabaseRestore.SelectedIndex > -1 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub cboDatabaseRestore_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDatabaseRestore.SelectedIndexChanged
        If Restore() = False Then
            btnApplyRestore.Enabled = False
        Else
            btnApplyRestore.Enabled = True
            txtRestorePath.Text = strRestorePath
            txtRestorePath.ForeColor = Color.Black
            txtRestorePath.BackColor = Color.WhiteSmoke
        End If
    End Sub
End Class