﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class FormManageUser
    'New instance of LoginAccess Class
    Private loginAccess As New LoginAccess

    'Form-level variables
    Private intActive As Integer
    Private objDataTableUserDetails As DataTable
    Dim strUsername As String

    'FORM LOAD EVENT
    Private Sub FormManageUser_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Change the size of the form
        Me.Size = New Size(426, 260)
    End Sub

    'CHANGE THE ACCEPT BUTTON AND SIZE OF THE FORM BASED ON TAB PAGE SELECTED
    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedIndex = 0 Then
            'Set CreateButton as an Accept Button of the form
            Me.AcceptButton = btnCreate

            'Change the size of the form
            Me.Size = New Size(426, 260)

            'Set focus to Username TextBox
            txtNewUserUsername.Focus()
        Else
            'Set to nothing
            Me.AcceptButton = Nothing

            'Change the size of the form
            Me.Size = New Size(480, 555)
        End If
    End Sub











    'TAB PAGE 1: CREATE USER RELATED EVENTS AND SUBS

    'CLICK EVENT OF BUTTON CREATE
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        If txtNewUserUsername.Text.Trim.Length > 1 And txtNewUserPassword.Text.Trim.Length > 1 And txtNewUserConfirmPassword.Text.Trim.Length > 1 Then
            If txtNewUserPassword.Text.Equals(txtNewUserConfirmPassword.Text) Then
                If loginAccess.HasConnection = True Then
                    'Raise a YesNo question
                    If MessageBox.Show("Do you want to create new user: |" & txtNewUserUsername.Text & "| account?", "User Account", _
                                       MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                        CheckActive()
                        CreateUser()
                    End If
                End If
            Else
                'Show error message
                MsgBox("New passwords do not match.", MsgBoxStyle.Exclamation, "User Account")

                'Clear the password textbox fields
                txtNewUserPassword.Clear()
                txtNewUserConfirmPassword.Clear()
                'Set focus to Username TextBox
                txtNewUserPassword.Focus()
            End If
        Else
            'Display error message
            MessageBox.Show("Please enter data.", "User Account", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    'METHOD-CREATE NEW USER
    Private Sub CreateUser()
        'Create a sql query text
        Dim strCommand As String = "INSERT INTO ADMIN(Username, Password, Type, [Last Login Date], Active) " & _
            "VALUES(@userName, @passWord,@type ,GetDate(),@active) "

        'Create new sql command
        Dim objCommand As New SqlCommand(strCommand)

        'Add parameters
        objCommand.Parameters.AddWithValue("@userName", txtNewUserUsername.Text)
        objCommand.Parameters.AddWithValue("@passWord", txtNewUserPassword.Text)
        objCommand.Parameters.AddWithValue("@type", "Admin2")
        '        objCommand.Parameters.AddWithValue("@lastLoginDate", GetDate())
        objCommand.Parameters.AddWithValue("@active", intActive)

        'Call CreateUser method of LoginAccess class
        loginAccess.CreateUser(objCommand)

        'Check for errors
        If loginAccess.strExceptionCreateUser <> "" Then
            'Show error message
            MsgBox(loginAccess.strExceptionCreateUser, MsgBoxStyle.Exclamation, "User Account")

            'Set the variable to nothing
            loginAccess.strExceptionCreateUser = Nothing
        ElseIf loginAccess.intCountRecord = 1 Then
            'Show successful message
            MsgBox("New user: " & txtNewUserUsername.Text & " has been successfully created.", MsgBoxStyle.Information, "User Account")

            'Clear the textboxes and set default value to other control
            txtNewUserUsername.Clear()
            txtNewUserPassword.Clear()
            txtNewUserConfirmPassword.Clear()
            rdbNewUserYes.Checked = True
            chkNewUserShowPassword.Checked = False
            txtNewUserUsername.Focus()
        ElseIf loginAccess.intCountRecord = 0 Then
            'Show successful message
            MsgBox("Something gone wrong! Please try again.", MsgBoxStyle.Information, "User Account")
        End If
    End Sub

    'METHOD-GET VALUE FOR ACTIVE STATE
    Private Sub CheckActive()
        'Check whether user is active or not
        If rdbNewUserYes.Checked = True Then
            intActive = 1
        ElseIf rdbNewUserNo.Checked = True Then
            intActive = 0
        End If
    End Sub

    'SHOW OR HIDE THE PASSWORD TEXTBOX CHARACTER
    Private Sub chkNewUserShowPassword_CheckedChanged(sender As Object, e As EventArgs) Handles chkNewUserShowPassword.CheckedChanged
        If chkNewUserShowPassword.Checked = True Then
            'Show password in the TextBox
            txtNewUserPassword.UseSystemPasswordChar = False
            txtNewUserConfirmPassword.UseSystemPasswordChar = False
        Else
            'Hide password in the TextBox
            txtNewUserPassword.UseSystemPasswordChar = True
            txtNewUserConfirmPassword.UseSystemPasswordChar = True
        End If
    End Sub

    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear the textbox and set the radiobutton to default
        txtNewUserUsername.Clear()
        txtNewUserPassword.Clear()
        txtNewUserConfirmPassword.Clear()
        rdbNewUserYes.Checked = True

        'Set focus to Username TextBox
        txtNewUserUsername.Focus()
    End Sub






    'TAB PAGE 2: MODIFY USER RELATED EVENTS AND SUBS

    'CLICK EVENT OF BUTTON VIEWALL
    Private Sub btnViewAll_Click(sender As Object, e As EventArgs) Handles btnViewAll.Click
        'Clear existing records from the dataset
        If loginAccess.objDataSet IsNot Nothing Then
            loginAccess.objDataSet.Clear()
        End If

        'Call RunQuery method of LoginAccess class
        loginAccess.RunQueryAndFillDataSet("SELECT Username, Password, Type, [Last Login Date], Active FROM ADMIN " & _
                             "WHERE NOT Type='Admin1'")

        'Check for errors
        If loginAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(loginAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            loginAccess.strExceptionRunQueryAndFillDataSet = Nothing
        ElseIf loginAccess.objDataSet.Tables(0).Rows.Count > 0 Then
            'Get the table
            objDataTableUserDetails = AutoNumberedTable(loginAccess.objDataSet.Tables(0))

            'Call FillDataGridView method
            FillDataGridView()

            btnViewAll.Focus()

            'Call ClearFields method to clear the text
            ClearFields()

            'Uncheck the radiobuttons
            rdbExistUserYes.Checked = False
            rdbExistUserNo.Checked = False

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub


    Public Function AutoNumberedTable(ByVal sourceTable As DataTable)
        Dim resultTable As DataTable = New DataTable

        Dim autoNumberColumn As New DataColumn
        autoNumberColumn.DataType = GetType(Integer)
        autoNumberColumn.AutoIncrement = True
        autoNumberColumn.AutoIncrementSeed = 1
        autoNumberColumn.AutoIncrementStep = 1
        resultTable.Columns.Add(autoNumberColumn)
        resultTable.Merge(sourceTable)
        Return resultTable
    End Function

    'METHOD-FILL THE DATAGRIDVIEW WITH USER DETAILS
    Private Sub FillDataGridView()
        grdUserDetails.DataSource = objDataTableUserDetails
        grdUserDetails.RowHeadersVisible = False
        With grdUserDetails
            .Columns(0).HeaderText = "Sn"
            .Columns(1).HeaderText = "Username"
            .Columns(2).HeaderText = "Password"
            .Columns(3).HeaderText = "Type"
            .Columns(4).HeaderText = "Last Login Date"
            .Columns(5).HeaderText = "Active"
        End With

        'Donot allow columns to upto 1st column to move
        grdUserDetails.Columns(1).Frozen = True
    End Sub

    'CELL CLICK EVENT OF DATAGRIDVIEW CONTROL 
    Private Sub grdUserDetails_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdUserDetails.CellClick
        Try
            'Enable the controls
            EnableControls()

            'Get the textboxes value from selected row of DataGridView
            strUsername = grdUserDetails.Item(1, e.RowIndex).Value
            txtExistUserUsername.Text = grdUserDetails.Item(1, e.RowIndex).Value
            txtExistUserPassword.Text = grdUserDetails.Item(2, e.RowIndex).Value
            txtExistUserType.Text = grdUserDetails.Item(3, e.RowIndex).Value
            txtExistUserLastLoginDate.Text = grdUserDetails.Item(4, e.RowIndex).Value
            If grdUserDetails.Item(5, e.RowIndex).Value = True Then
                rdbExistUserYes.Checked = True
            Else
                rdbExistUserNo.Checked = True
            End If

            'Make sure that the Update button is disabled
            btnUpdate.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    'CLICK EVENT OF BUTTON DELETE
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete user: |" & strUsername & "| account?", "USER ACCOUNT", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM ADMIN " & _
                                 "WHERE Username= @userName"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@userName", strUsername)

            'Call RunQuery Method to delete the selected user
            loginAccess.RunQuery(objCommand)

            'Check for errors
            If loginAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(loginAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                loginAccess.strExceptionRunQuery = Nothing
            ElseIf loginAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("User: |" & strUsername & "| account has been successfully deleted.", MsgBoxStyle.Information, "User Account")

                'Call btnViewAll_Click procedure
                btnViewAll_Click(Nothing, Nothing)
            ElseIf loginAccess.intCountRecord = 0 Then
                'Show successfully deleted message
                MsgBox("There's no any user account: |" & strUsername & "|.", MsgBoxStyle.Exclamation, "User Account")

                'Call btnViewAll_Click procedure
                MsgBox("Click ViewAll button to refresh the Result box.", MsgBoxStyle.Information, "User Account")
            End If
        End If
    End Sub

    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtExistUserUsername.Enabled = True
        txtExistUserPassword.Enabled = True
        txtExistUserType.Enabled = True
        txtExistUserLastLoginDate.Enabled = True
        rdbExistUserYes.Enabled = True
        rdbExistUserNo.Enabled = True
        'btnUpdate.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtExistUserUsername.Enabled = False
        txtExistUserPassword.Enabled = False
        txtExistUserType.Enabled = False
        txtExistUserLastLoginDate.Enabled = False
        rdbExistUserYes.Enabled = False
        rdbExistUserNo.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    'CLEAR TEXT FIELDSSET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtExistUserUsername.Clear()
        txtExistUserPassword.Clear()
        txtExistUserLastLoginDate.Clear()
        txtExistUserType.Clear()
    End Sub

    'CLICK EVENT OF BUTTON UPDATE
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Check whether data is entered or not
        If CheckUserNameAndPassword() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update user: |" & strUsername & "| account?", "User Account", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                'Check whether user is active or not
                Dim intActiveTabSecond As Integer
                If rdbExistUserYes.Checked = True Then
                    intActiveTabSecond = 1
                ElseIf rdbExistUserNo.Checked = True Then
                    intActiveTabSecond = 0
                End If

                'Create a sql query text
                Dim strCommand As String = "UPDATE ADMIN " & _
                                     "SET Username=@userNameTextBox, " & _
                                     "Password= @passWord, " & _
                                     "Type=@type, " & _
                                     "[Last Login Date]= @lastLoginDate, " & _
                                     "Active= @intActive " & _
                                     "WHERE Username=@userName"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@userNameTextBox", txtExistUserUsername.Text)
                objCommand.Parameters.AddWithValue("@passWord", txtExistUserPassword.Text)
                objCommand.Parameters.AddWithValue("@type", "ADMIN2")
                objCommand.Parameters.AddWithValue("@lastLoginDate", txtExistUserLastLoginDate.Text)
                objCommand.Parameters.AddWithValue("@intActive", intActiveTabSecond)
                objCommand.Parameters.AddWithValue("@userName", strUsername)


                'Call RunQuery Method to update the selected user
                loginAccess.RunQuery(objCommand)

                'loginAccess.RunQuery("UPDATE ADMIN " & _
                '                     "SET Username='" & txtExistUserUsername.Text & "', " & _
                '                     "Password='" & txtExistUserPassword.Text & "', " & _
                '                     "Type='ADMIN2'" & ", " & _
                '                     "[Last Login Date]='" & txtExistUserLastLoginDate.Text & "', " & _
                '                     "Active=" & intActiveTabSecond & " " & _
                '                     "WHERE Username='" & strUsername & "'")

                'Check for errors
                If loginAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(loginAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    loginAccess.strExceptionRunQuery = Nothing
                ElseIf loginAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("User: |" & strUsername & "| account has been successfully updated.", MsgBoxStyle.Information, "User Account")

                    'Call btnViewAll_Click procedure
                    btnViewAll_Click(Nothing, Nothing)
                ElseIf loginAccess.intCountRecord = 0 Then
                    'Show successfully deleted message
                    MsgBox("There's no any user account: |" & strUsername & "|.", MsgBoxStyle.Exclamation, "User Account")

                    'Call btnViewAll_Click procedure
                    MsgBox("Click ViewAll button to refresh the Result box.", MsgBoxStyle.Information, "User Account")
                End If
            End If
        End If
    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN USERNAME AND PASSWORD
    Private Function CheckUserNameAndPassword()
        If txtExistUserUsername.Text.Trim.Length > 0 And txtExistUserPassword.Text.Trim.Length > 0 Then
            Return True
        ElseIf txtExistUserUsername.Text.Trim.Length <= 0 And txtExistUserPassword.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter username and password.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtExistUserUsername.Text.Trim.Length <= 0 And txtExistUserPassword.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter username.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            MessageBox.Show("You have to enter password.", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtExistUserUsername.TextChanged, txtExistUserPassword.TextChanged, rdbExistUserYes.CheckedChanged, rdbExistUserNo.CheckedChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    'KEYPRESS EVENT OF USERNAME AND PASSWORD TEXTBOXES
    Private Sub txtUser_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewUserUsername.KeyPress, txtNewUserPassword.KeyPress, txtNewUserConfirmPassword.KeyPress, txtExistUserUsername.KeyPress, txtExistUserPassword.KeyPress
        'Donot allow white spaces
        If Char.IsWhiteSpace(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
End Class