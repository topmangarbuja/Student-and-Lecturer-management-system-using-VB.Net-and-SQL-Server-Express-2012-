﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormBackupRestore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormBackupRestore))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnResetBackup = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboDatabaseBackup = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtBackupPath = New System.Windows.Forms.TextBox()
        Me.btnApplyBackup = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtRestorePath = New System.Windows.Forms.TextBox()
        Me.cboDatabaseRestore = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnResetRestore = New System.Windows.Forms.Button()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnApplyRestore = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.btnResetBackup)
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Controls.Add(Me.btnApplyBackup)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(477, 145)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Backup"
        '
        'btnResetBackup
        '
        Me.btnResetBackup.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnResetBackup.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnResetBackup.Location = New System.Drawing.Point(329, 107)
        Me.btnResetBackup.Name = "btnResetBackup"
        Me.btnResetBackup.Size = New System.Drawing.Size(128, 32)
        Me.btnResetBackup.TabIndex = 2
        Me.btnResetBackup.Text = "Reset"
        Me.ToolTip1.SetToolTip(Me.btnResetBackup, "Reset")
        Me.btnResetBackup.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.cboDatabaseBackup, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtBackupPath, 1, 1)
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 19)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(463, 82)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(172, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select database to backup:"
        '
        'cboDatabaseBackup
        '
        Me.cboDatabaseBackup.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cboDatabaseBackup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDatabaseBackup.FormattingEnabled = True
        Me.cboDatabaseBackup.Items.AddRange(New Object() {"IcpAdmin", "IcpInfo"})
        Me.cboDatabaseBackup.Location = New System.Drawing.Point(187, 10)
        Me.cboDatabaseBackup.Name = "cboDatabaseBackup"
        Me.cboDatabaseBackup.Size = New System.Drawing.Size(267, 25)
        Me.cboDatabaseBackup.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboDatabaseBackup, "Select a database")
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(155, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "This is the backup path:"
        '
        'txtBackupPath
        '
        Me.txtBackupPath.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtBackupPath.BackColor = System.Drawing.Color.White
        Me.txtBackupPath.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBackupPath.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBackupPath.ForeColor = System.Drawing.Color.Gray
        Me.txtBackupPath.Location = New System.Drawing.Point(187, 48)
        Me.txtBackupPath.Name = "txtBackupPath"
        Me.txtBackupPath.ReadOnly = True
        Me.txtBackupPath.Size = New System.Drawing.Size(267, 25)
        Me.txtBackupPath.TabIndex = 1
        Me.txtBackupPath.Text = "You get it through configuration settings"
        Me.ToolTip1.SetToolTip(Me.txtBackupPath, "You get it through configuration settings")
        '
        'btnApplyBackup
        '
        Me.btnApplyBackup.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnApplyBackup.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnApplyBackup.Location = New System.Drawing.Point(190, 107)
        Me.btnApplyBackup.Name = "btnApplyBackup"
        Me.btnApplyBackup.Size = New System.Drawing.Size(128, 32)
        Me.btnApplyBackup.TabIndex = 1
        Me.btnApplyBackup.Text = "Apply"
        Me.ToolTip1.SetToolTip(Me.btnApplyBackup, "Apply")
        Me.btnApplyBackup.UseVisualStyleBackColor = True
        '
        'txtRestorePath
        '
        Me.txtRestorePath.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtRestorePath.BackColor = System.Drawing.Color.White
        Me.txtRestorePath.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRestorePath.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRestorePath.ForeColor = System.Drawing.Color.Gray
        Me.txtRestorePath.Location = New System.Drawing.Point(187, 48)
        Me.txtRestorePath.Name = "txtRestorePath"
        Me.txtRestorePath.ReadOnly = True
        Me.txtRestorePath.Size = New System.Drawing.Size(267, 25)
        Me.txtRestorePath.TabIndex = 1
        Me.txtRestorePath.Text = "You get it through configuration settings"
        Me.ToolTip1.SetToolTip(Me.txtRestorePath, "You get it through configuration settings")
        '
        'cboDatabaseRestore
        '
        Me.cboDatabaseRestore.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cboDatabaseRestore.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDatabaseRestore.FormattingEnabled = True
        Me.cboDatabaseRestore.Items.AddRange(New Object() {"IcpAdmin", "IcpInfo"})
        Me.cboDatabaseRestore.Location = New System.Drawing.Point(187, 10)
        Me.cboDatabaseRestore.Name = "cboDatabaseRestore"
        Me.cboDatabaseRestore.Size = New System.Drawing.Size(267, 25)
        Me.cboDatabaseRestore.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboDatabaseRestore, "Select a database")
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btnResetRestore)
        Me.GroupBox2.Controls.Add(Me.TableLayoutPanel2)
        Me.GroupBox2.Controls.Add(Me.btnApplyRestore)
        Me.GroupBox2.Font = New System.Drawing.Font("Stencil", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(8, 159)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(477, 145)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Restore"
        '
        'btnResetRestore
        '
        Me.btnResetRestore.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnResetRestore.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnResetRestore.Location = New System.Drawing.Point(329, 107)
        Me.btnResetRestore.Name = "btnResetRestore"
        Me.btnResetRestore.Size = New System.Drawing.Size(128, 32)
        Me.btnResetRestore.TabIndex = 1
        Me.btnResetRestore.Text = "Reset"
        Me.ToolTip1.SetToolTip(Me.btnResetRestore, "Reset")
        Me.btnResetRestore.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.cboDatabaseRestore, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtRestorePath, 1, 1)
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 19)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 3
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(463, 82)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(171, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Select database to restore:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 52)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(154, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "This is the restore path:"
        '
        'btnApplyRestore
        '
        Me.btnApplyRestore.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnApplyRestore.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnApplyRestore.Location = New System.Drawing.Point(190, 107)
        Me.btnApplyRestore.Name = "btnApplyRestore"
        Me.btnApplyRestore.Size = New System.Drawing.Size(128, 32)
        Me.btnApplyRestore.TabIndex = 0
        Me.btnApplyRestore.Text = "Apply"
        Me.ToolTip1.SetToolTip(Me.btnApplyRestore, "Apply")
        Me.btnApplyRestore.UseVisualStyleBackColor = True
        '
        'FormBackupRestore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.Icp.My.Resources.Resources.background
        Me.ClientSize = New System.Drawing.Size(495, 315)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormBackupRestore"
        Me.Text = "Backup & Restore"
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboDatabaseBackup As System.Windows.Forms.ComboBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents btnApplyBackup As System.Windows.Forms.Button
    Friend WithEvents txtBackupPath As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtRestorePath As System.Windows.Forms.TextBox
    Friend WithEvents btnApplyRestore As System.Windows.Forms.Button
    Friend WithEvents btnResetBackup As System.Windows.Forms.Button
    Friend WithEvents btnResetRestore As System.Windows.Forms.Button
    Friend WithEvents cboDatabaseRestore As System.Windows.Forms.ComboBox
End Class
