﻿Public Class FormLecturerAddAdditional
    Private Sub FormLecturerAddAdditional_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Set the size of the window
        Me.Size = New Size(449, 484)
    End Sub

    Private Sub TabPage3_Enter(sender As Object, e As EventArgs) Handles TabPage3.Enter
        'Set the size of the window
        Me.Size = New Size(1016, 660)
    End Sub

    Private Sub TabPage2_Enter(sender As Object, e As EventArgs) Handles TabPage2.Enter
        'Set the size of the window
        Me.Size = New Size(449, 484)
    End Sub

    Private Sub TabPage1_Enter(sender As Object, e As EventArgs) Handles TabPage1.Enter
        'Set the size of the window
        Me.Size = New Size(449, 484)
    End Sub
End Class