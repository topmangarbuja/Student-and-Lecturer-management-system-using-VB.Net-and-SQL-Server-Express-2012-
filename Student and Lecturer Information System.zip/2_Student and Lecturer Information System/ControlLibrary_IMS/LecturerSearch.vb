﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class LecturerSearch
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtLecturerList As New DataTable

    Dim dtCountryUpdate As New DataTable
    Dim strLecturerId As String
    Dim strLecturerName As String
    Dim rowNumber As Int16

    'FORM LOAD EVENT
    Private Sub LecturerSearch_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Call method to clear searching fields
        ClearTextFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()

    End Sub

    'METHOD: GET LECTURER DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetLecturerList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT * " & _
            "FROM Lecturer;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'METHOD: FILL THE DATAGRIDVIEW
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdLecturer.DataSource = Nothing

            'Get the table data
            dtLecturerList = dataAccess.objDataSet.Tables(0)
            GblAccessItem.DataTableLecturerSearch = dataAccess.AutoNumberedTable(dtLecturerList)

            'Get the datasource for datagridview
            grdLecturer.DataSource = dtLecturerList

            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand

            If grdLecturer.RowCount > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = grdLecturer.RowCount


            grdLecturer.Columns(0).Frozen = True
        End If
    End Sub

    'CLEAR TEXTBOXES AND COMBOBOX ITEMS
    Private Sub ClearTextFields()
        txtLecturerId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        cboGender.Items.Clear()
        txtPlace.Clear()
        txtDistrict.Clear()
        txtCitizenshipNo.Clear()
        txtPassportNo.Clear()
        cboStatus.Items.Clear()
    End Sub


    'ENTER EVENT OF SEARCHING FIELDS
    Private Sub txtStudent_Enter(sender As Object, e As EventArgs) Handles txtLecturerId.Enter, txtFirstName.Enter, txtLastName.Enter, cboGender.Enter, txtDistrict.Enter, txtPlace.Enter, txtCitizenshipNo.Enter, txtPassportNo.Enter, cboStatus.Enter
        'Call method to clear searching fields
        ClearTextFields()

        'Clear the datasource of the datagridview
        grdLecturer.DataSource = Nothing

        If grdLecturer.RowCount > 0 Then
            'Enable the GetReport button
            btnGetReport.Enabled = True
        Else
            'Disable the GetReport button
            btnGetReport.Enabled = False
        End If

        'List the number of rows in the result
        lblResult.Text = grdLecturer.RowCount
    End Sub

    'TEXT CHANGED EVENT OF LECTURERID TEXTBOX
    Private Sub txtLecturerId_TextChanged(sender As Object, e As EventArgs) Handles txtLecturerId.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE LecturerId LIKE '%" & txtLecturerId.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF FIRSTNAME TEXTBOX
    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE FirstName LIKE '%" & txtFirstName.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF LASTNAME TEXTBOX
    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE LastName LIKE '%" & txtLastName.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF CITIZENSHIPNO TEXTBOX
    Private Sub txtCitizenshipNo_TextChanged(sender As Object, e As EventArgs) Handles txtCitizenshipNo.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE CitizenshipNo LIKE '%" & txtCitizenshipNo.Text & "%' " & _
            "ORDER BY FirstName;")
        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF PASSPORTNO TEXTBOX
    Private Sub txtPassportNo_TextChanged(sender As Object, e As EventArgs) Handles txtPassportNo.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE PassportNo LIKE '%" & txtPassportNo.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF DISTRICT TEXTBOX
    Private Sub txtDistrict_TextChanged(sender As Object, e As EventArgs) Handles txtDistrict.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE District LIKE '%" & txtDistrict.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF PLACE TEXTBOX
    Private Sub txtPlace_TextChanged(sender As Object, e As EventArgs) Handles txtPlace.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE Place LIKE '%" & txtPlace.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'CLICK EVENT OF GENDER COMBOBOX
    Private Sub cboGender_Click(sender As Object, e As EventArgs) Handles cboGender.Click
        'First clear the existing items
        cboGender.Items.Clear()

        'Add items in the list
        cboGender.Items.Add("Male")
        cboGender.Items.Add("Female")
        cboGender.Items.Add("Other")
    End Sub

    'TEXTCHANGED EVENT OF GENDER COMBOBOX
    Private Sub cboGender_TextChanged(sender As Object, e As EventArgs) Handles cboGender.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE Gender LIKE '" & cboGender.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'CLICK EVENT OF VIEWALL LecturerS BUTTON
    Private Sub btnViewAllLecturers_Click(sender As Object, e As EventArgs) Handles btnViewAllLecturers.Click
        'Get list of Lecturers
        GetLecturerList()
    End Sub

    'CLICK EVENT OF STATUS COMBOBOX
    Private Sub cboStatus_Click(sender As Object, e As EventArgs) Handles cboStatus.Click
        'First clear the existing items
        cboStatus.Items.Clear()

        'Add items in the combobox
        cboStatus.Items.Add("Active")
        cboStatus.Items.Add("Inactive")
    End Sub

    'TEXTCHANGED EVENT OF STATUS COMBOBOX
    Private Sub cboStatus_TextChanged(sender As Object, e As EventArgs) Handles cboStatus.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
            "FROM Lecturer " & _
            "WHERE Status LIKE '" & cboStatus.Text & "%' " & _
            "ORDER BY FirstName;")

        'Fill the datagridview
        FillDataGridView()
    End Sub




    'EDIT SECTONS

    'CLEAR TEXT FIELD and SET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtEditLecturerId.Clear()
        txtEditFirstName.Clear()
        txtEditLastName.Clear()
        dtpEditDateOfBirth.Value = Now
        cboEditGender.Text = ""
        txtEditDistrict.Clear()
        txtEditWardNo.Clear()
        txtEditPlace.Clear()
        cboEditCountry.Text = ""
        txtEditCitizenshipNo.Clear()
        txtEditPassportNo.Clear()
        cboEditStatus.Text = ""
    End Sub

    'FORM LOAD EVENT
    Private Sub LecturerView_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'CELL CLICK EVENT OF DATAGRIDVIEW CONTROL 
    Private Sub grdLecturer_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdLecturer.CellClick
        If grpEdit.Visible = True Then
            rowNumber = grdLecturer.CurrentCell.RowIndex

            'First clear the text fields
            ClearFields()

            'Enable the controls of the datagridview sections
            EnableControls()


            'Get list of country
            GetCountryUpdate()


            For i As Integer = 0 To grdLecturer.ColumnCount - 1
                Try
                    Select Case i

                        Case 0

                            'Get id and name
                            strLecturerId = grdLecturer.Item(0, e.RowIndex).Value
                            'Get values for the textboxes and combobox
                            txtEditLecturerId.Text = grdLecturer.Item(0, e.RowIndex).Value

                        Case 1
                            strLecturerName = grdLecturer.Item(1, e.RowIndex).Value & " " & grdLecturer.Item(2, e.RowIndex).Value
                            txtEditFirstName.Text = grdLecturer.Item(1, e.RowIndex).Value

                        Case 2
                            txtEditLastName.Text = grdLecturer.Item(2, e.RowIndex).Value

                        Case 3
                            dtpEditDateOfBirth.Value = grdLecturer.Item(3, e.RowIndex).Value

                        Case 4
                            If grdLecturer.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("female") Then
                                cboEditGender.SelectedIndex = 1
                            ElseIf grdLecturer.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("male") Then
                                cboEditGender.SelectedIndex = 0
                            ElseIf grdLecturer.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("other") Then
                                cboEditGender.SelectedIndex = 2
                            End If

                        Case 5
                            txtEditDistrict.Text = grdLecturer.Item(5, e.RowIndex).Value

                        Case 6
                            txtEditWardNo.Text = grdLecturer.Item(6, e.RowIndex).Value

                        Case 7
                            txtEditPlace.Text = grdLecturer.Item(7, e.RowIndex).Value

                        Case 8
                            cboEditCountry.Text = grdLecturer.Item(8, e.RowIndex).Value

                        Case 9
                            txtEditCitizenshipNo.Text = grdLecturer.Item(9, e.RowIndex).Value

                        Case 10
                            txtEditPassportNo.Text = grdLecturer.Item(10, e.RowIndex).Value
                        Case 11
                            If grdLecturer.Item(11, e.RowIndex).Value.ToString.ToLower.StartsWith("active") Then
                                cboEditStatus.SelectedIndex = 0
                            ElseIf grdLecturer.Item(11, e.RowIndex).Value.ToString.ToLower.StartsWith("inactive") Then
                                cboEditStatus.SelectedIndex = 1
                            End If
                    End Select
                Catch ex As Exception

                End Try
            Next

            'Make sure that the Update button is disabled
            btnUpdate.Enabled = False
        End If
    End Sub

    'CLICK EVENT OF UDPATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Call procedure to check whether there is data or not
        If CheckFirstNameLastName() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details?", "Lecturer Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE LECTURER " & _
                                     "SET LecturerId=@lecturerId, " & _
                                     "FirstName= @firstName, " & _
                                     "LastName=@lastName, " & _
                                     "DateOfBirth=@dob, " & _
                                     "Gender=@gender, " & _
                                     "District=@district, " & _
                                     "WardNo=@wardNo, " & _
                                     "Place=@place, " & _
                                     "Country=@country, " & _
                                     "CitizenshipNo=@citizenshipNo, " & _
                                     "PassportNo=@passportNo, " & _
                                     "Status=@status " & _
                                     "WHERE LecturerId=@originalLecturerId;"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@lecturerId", txtEditLecturerId.Text)
                objCommand.Parameters.AddWithValue("@firstName", txtEditFirstName.Text)
                objCommand.Parameters.AddWithValue("@lastName", txtEditLastName.Text)
                objCommand.Parameters.AddWithValue("@dob", dtpEditDateOfBirth.Value.Date)
                objCommand.Parameters.AddWithValue("@gender", cboEditGender.Text)
                objCommand.Parameters.AddWithValue("@district", txtEditDistrict.Text)
                objCommand.Parameters.AddWithValue("@wardNo", txtEditWardNo.Text)
                objCommand.Parameters.AddWithValue("@place", txtEditPlace.Text)
                objCommand.Parameters.AddWithValue("@country", cboEditCountry.Text)
                objCommand.Parameters.AddWithValue("@citizenshipNo", txtEditCitizenshipNo.Text)
                objCommand.Parameters.AddWithValue("@passportNo", txtEditPassportNo.Text)
                objCommand.Parameters.AddWithValue("@status", cboEditStatus.Text)
                objCommand.Parameters.AddWithValue("@originalLecturerId", strLecturerId)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Lecturer Details")

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing

                    'Call ClearFields method to clear the text
                    ClearFields()

                    'Call DisableControl method to disable controls
                    DisabledControls()
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details has been successfully updated.", MsgBoxStyle.Information, "Lecturer Details")

                    'Call btnView_Click procedure
                    'btnViewAll_Click(Nothing, Nothing)

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    'Get list of name and id and phone
                    dataAccess.RunQueryAndFillDataSet("SELECT * " & _
                        "FROM Lecturer " & _
                        "WHERE LecturerId='" & txtEditLecturerId.Text & "';")

                    'Fill the datagridview
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no lecturer with details: |" & strLecturerId & "| (" & strLecturerName & ").", MsgBoxStyle.Exclamation, "Lecturer Details")

                End If


                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            End If
        End If
    End Sub

    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete Lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details?", "Lecturer Details", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM LECTURER " & _
                                 "WHERE LecturerId= @lecturerId"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@lecturerId", strLecturerId)

            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Lecturer Details")

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("Lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details has been successfully deleted.", MsgBoxStyle.Information, "Lecturer Details")

                'Remove a row from the GridView
                grdLecturer.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdLecturer.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no lecturer with details: |" & strLecturerId & "| (" & strLecturerName & ").", MsgBoxStyle.Exclamation, "Lecturer Details")
            End If


            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub

    Private Sub EnableControls()
        txtEditLecturerId.Enabled = True
        txtEditFirstName.Enabled = True
        txtEditLastName.Enabled = True
        dtpEditDateOfBirth.Enabled = True
        cboEditGender.Enabled = True
        txtEditDistrict.Enabled = True
        txtEditWardNo.Enabled = True
        txtEditPlace.Enabled = True
        cboEditCountry.Enabled = True
        txtEditCitizenshipNo.Enabled = True
        txtEditPassportNo.Enabled = True
        cboEditStatus.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtEditLecturerId.Enabled = False
        txtEditFirstName.Enabled = False
        txtEditLastName.Enabled = False
        dtpEditDateOfBirth.Enabled = False
        cboEditGender.Enabled = False
        txtEditDistrict.Enabled = False
        txtEditWardNo.Enabled = False
        txtEditPlace.Enabled = False
        cboEditCountry.Enabled = False
        txtEditCitizenshipNo.Enabled = False
        txtEditPassportNo.Enabled = False
        cboEditStatus.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "LecturerSearch"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub


    Private Sub btnShowEditSection_Click(sender As Object, e As EventArgs) Handles btnShowEditSection.Click
        'Dim s As Point = pnlListOfStudent.Location
        If btnShowEditSection.Text = "Show Edit section" Then
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X - 220
            pnlListOfStudent.Location = p

            grpResult.Size = New Size(592, 491)

            Dim g As Point = grpResult.Location
            g.X = grpResult.Width + 20
            grpEdit.Location = g

            grpEdit.Visible = True
            lblDetails.Visible = True

            btnShowEditSection.Text = "Hide Edit section"
        Else
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X + 220
            pnlListOfStudent.Location = p


            grpResult.Size = New Size(1104, 491)


            grpEdit.Visible = False
            lblDetails.Visible = False

            btnShowEditSection.Text = "Show Edit section"

            'Disable the controls of the textboxes and buttons
            DisabledControls()
        End If

        'First clear the text fields
        ClearFields()
    End Sub


    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtEditLecturerId.TextChanged, txtEditFirstName.TextChanged, txtEditLastName.TextChanged, dtpEditDateOfBirth.ValueChanged, cboEditGender.SelectedIndexChanged, _
        txtEditDistrict.TextChanged, txtEditWardNo.TextChanged, txtEditPlace.TextChanged, cboEditCountry.TextChanged, cboEditCountry.SelectedIndexChanged, txtEditCitizenshipNo.TextChanged, txtEditPassportNo.TextChanged, cboEditStatus.SelectedIndexChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckFirstNameLastName() As Boolean
        If txtEditFirstName.Text.Trim.Length > 0 And txtEditLastName.Text.Trim.Length > 0 And txtEditLecturerId.Text.Trim.Length = 12 Then
            Return True
        ElseIf txtEditFirstName.Text.Trim.Length <= 0 And txtEditLastName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter first name and last name.", "Lecturer Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtEditFirstName.Text.Trim.Length <= 0 And txtEditLastName.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter first name.", "Lecturer Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtEditFirstName.Text.Trim.Length > 0 And txtEditLastName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter last name.", "Lecturer Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtLecturerId.Text.Trim.Length < 12 Then
            MessageBox.Show("You have to enter 12 digit id.", "Lecturer Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function



    Private Sub GetCountryUpdate()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Country FROM Lecturer; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Country List | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtCountryUpdate = dataAccess.dtListForComboBox
            cboEditCountry.DataSource = dtCountryUpdate
            cboEditCountry.DisplayMember = "Country"

            'If cboEditCategory.Text = "" Then

            'End If
        End If
    End Sub
End Class
