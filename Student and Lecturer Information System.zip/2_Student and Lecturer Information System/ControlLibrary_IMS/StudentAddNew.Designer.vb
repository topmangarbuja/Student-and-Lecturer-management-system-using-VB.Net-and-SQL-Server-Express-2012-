﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl1 overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StudentAddNew))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.txtEmailAddress = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.txtStudentId = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtPhoneNumber = New ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDistrict = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtWardNo = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtPlace = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtCitizenshipNo = New ControlLibrary_IMS.TextBoxNumericPunctuation()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.cboCountry = New System.Windows.Forms.ComboBox()
        Me.txtPassportNo = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.btnViewStudents = New System.Windows.Forms.Button()
        Me.grdStudent = New System.Windows.Forms.DataGridView()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grdStudent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(792, 476)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Main Details"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.cboGender, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.txtEmailAddress, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.dtpDateOfBirth, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtStudentId, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtFirstName, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtLastName, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtPhoneNumber, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.txtDistrict, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.txtWardNo, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.txtPlace, 1, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtCitizenshipNo, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.cboStatus, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.cboCountry, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtPassportNo, 3, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 10
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(784, 453)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'cboGender
        '
        Me.cboGender.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGender.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboGender, "Select gender from the list")
        Me.cboGender.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.cboGender.Location = New System.Drawing.Point(115, 190)
        Me.cboGender.Name = "cboGender"
        Me.HelpProvider1.SetShowHelp(Me.cboGender, True)
        Me.cboGender.Size = New System.Drawing.Size(262, 25)
        Me.cboGender.TabIndex = 12
        Me.ToolTip1.SetToolTip(Me.cboGender, "Gender")
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Location = New System.Drawing.Point(507, 184)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(269, 37)
        Me.Panel1.TabIndex = 0
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(135, 0)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(0, 1)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'txtEmailAddress
        '
        Me.txtEmailAddress.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEmailAddress.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtEmailAddress, resources.GetString("txtEmailAddress.HelpString"))
        Me.txtEmailAddress.Location = New System.Drawing.Point(116, 280)
        Me.txtEmailAddress.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEmailAddress.MaxLength = 225
        Me.txtEmailAddress.Name = "txtEmailAddress"
        Me.HelpProvider1.SetShowHelp(Me.txtEmailAddress, True)
        Me.txtEmailAddress.Size = New System.Drawing.Size(261, 25)
        Me.txtEmailAddress.TabIndex = 14
        Me.ToolTip1.SetToolTip(Me.txtEmailAddress, "Email address")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 14)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Id:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 149)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Date of birth:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 59)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "First Name:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 104)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Last Name:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 194)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 17)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Gender:"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(4, 239)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(104, 17)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Phone number:"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(4, 284)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(99, 17)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Email address:"
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.dtpDateOfBirth, "Click on the calendar icon then browse and select the date.")
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(115, 145)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.HelpProvider1.SetShowHelp(Me.dtpDateOfBirth, True)
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(262, 25)
        Me.dtpDateOfBirth.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.dtpDateOfBirth, "Date of birth")
        '
        'txtStudentId
        '
        Me.txtStudentId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStudentId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.HelpProvider1.SetHelpString(Me.txtStudentId, "Type student id. eg: 1808T112001")
        Me.txtStudentId.Location = New System.Drawing.Point(115, 10)
        Me.txtStudentId.MaxLength = 12
        Me.txtStudentId.Name = "txtStudentId"
        Me.HelpProvider1.SetShowHelp(Me.txtStudentId, True)
        Me.txtStudentId.Size = New System.Drawing.Size(261, 25)
        Me.txtStudentId.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtStudentId, "Student Id")
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtFirstName, "Type firstname ( and middle name if exists). eg: Aakash Bahadur")
        Me.txtFirstName.Location = New System.Drawing.Point(115, 55)
        Me.txtFirstName.MaxLength = 70
        Me.txtFirstName.Name = "txtFirstName"
        Me.HelpProvider1.SetShowHelp(Me.txtFirstName, True)
        Me.txtFirstName.Size = New System.Drawing.Size(261, 25)
        Me.txtFirstName.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.txtFirstName, "First Name")
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtLastName, "Type last name. eg: Magar")
        Me.txtLastName.Location = New System.Drawing.Point(115, 100)
        Me.txtLastName.MaxLength = 35
        Me.txtLastName.Name = "txtLastName"
        Me.HelpProvider1.SetShowHelp(Me.txtLastName, True)
        Me.txtLastName.Size = New System.Drawing.Size(261, 25)
        Me.txtLastName.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.txtLastName, "Last Name")
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPhoneNumber, resources.GetString("txtPhoneNumber.HelpString"))
        Me.txtPhoneNumber.Location = New System.Drawing.Point(115, 235)
        Me.txtPhoneNumber.MaxLength = 25
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.HelpProvider1.SetShowHelp(Me.txtPhoneNumber, True)
        Me.txtPhoneNumber.Size = New System.Drawing.Size(261, 25)
        Me.txtPhoneNumber.TabIndex = 13
        Me.ToolTip1.SetToolTip(Me.txtPhoneNumber, "Phone number")
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 329)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 17)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "District:"
        '
        'txtDistrict
        '
        Me.txtDistrict.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtDistrict, "Type a district name of the permanent address. eg: Myagdi")
        Me.txtDistrict.Location = New System.Drawing.Point(115, 325)
        Me.txtDistrict.MaxLength = 20
        Me.txtDistrict.Name = "txtDistrict"
        Me.HelpProvider1.SetShowHelp(Me.txtDistrict, True)
        Me.txtDistrict.Size = New System.Drawing.Size(261, 25)
        Me.txtDistrict.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.txtDistrict, "District")
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 374)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 17)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Ward no.:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 420)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 17)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Place:"
        '
        'txtWardNo
        '
        Me.txtWardNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtWardNo, "Type a ward no. eg: 9")
        Me.txtWardNo.Location = New System.Drawing.Point(115, 370)
        Me.txtWardNo.MaxLength = 3
        Me.txtWardNo.Name = "txtWardNo"
        Me.HelpProvider1.SetShowHelp(Me.txtWardNo, True)
        Me.txtWardNo.Size = New System.Drawing.Size(261, 25)
        Me.txtWardNo.TabIndex = 16
        Me.ToolTip1.SetToolTip(Me.txtWardNo, "Ward no.")
        '
        'txtPlace
        '
        Me.txtPlace.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPlace, "Type place name of the permanent address. eg: Tiplyang")
        Me.txtPlace.Location = New System.Drawing.Point(115, 416)
        Me.txtPlace.MaxLength = 20
        Me.txtPlace.Name = "txtPlace"
        Me.HelpProvider1.SetShowHelp(Me.txtPlace, True)
        Me.txtPlace.Size = New System.Drawing.Size(261, 25)
        Me.txtPlace.TabIndex = 17
        Me.ToolTip1.SetToolTip(Me.txtPlace, "Place")
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(396, 14)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 17)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Country:"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(396, 59)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(103, 17)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "Citizenship no.:"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(396, 104)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 17)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Passport no.:"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(396, 149)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(50, 17)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Status:"
        '
        'txtCitizenshipNo
        '
        Me.txtCitizenshipNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtCitizenshipNo, "If exists, type a valid citizenship no. eg: 119293-38383")
        Me.txtCitizenshipNo.Location = New System.Drawing.Point(506, 55)
        Me.txtCitizenshipNo.MaxLength = 15
        Me.txtCitizenshipNo.Name = "txtCitizenshipNo"
        Me.HelpProvider1.SetShowHelp(Me.txtCitizenshipNo, True)
        Me.txtCitizenshipNo.Size = New System.Drawing.Size(261, 25)
        Me.txtCitizenshipNo.TabIndex = 19
        Me.ToolTip1.SetToolTip(Me.txtCitizenshipNo, "Citizenship no")
        '
        'cboStatus
        '
        Me.cboStatus.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboStatus, "Select 'active' if he is currently on the college otherwise select 'Inactive'")
        Me.cboStatus.Items.AddRange(New Object() {"Active", "Inactive"})
        Me.cboStatus.Location = New System.Drawing.Point(506, 145)
        Me.cboStatus.Name = "cboStatus"
        Me.HelpProvider1.SetShowHelp(Me.cboStatus, True)
        Me.cboStatus.Size = New System.Drawing.Size(262, 25)
        Me.cboStatus.TabIndex = 21
        Me.ToolTip1.SetToolTip(Me.cboStatus, "Status")
        '
        'cboCountry
        '
        Me.cboCountry.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboCountry.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboCountry, "Select country from the list if exists, otherwise type eg: India.")
        Me.cboCountry.Location = New System.Drawing.Point(506, 10)
        Me.cboCountry.Name = "cboCountry"
        Me.HelpProvider1.SetShowHelp(Me.cboCountry, True)
        Me.cboCountry.Size = New System.Drawing.Size(261, 25)
        Me.cboCountry.TabIndex = 18
        Me.ToolTip1.SetToolTip(Me.cboCountry, "Country")
        '
        'txtPassportNo
        '
        Me.txtPassportNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPassportNo, "If exists, type a valid passport no. eg: 04449380")
        Me.txtPassportNo.Location = New System.Drawing.Point(506, 100)
        Me.txtPassportNo.MaxLength = 9
        Me.txtPassportNo.Name = "txtPassportNo"
        Me.HelpProvider1.SetShowHelp(Me.txtPassportNo, True)
        Me.txtPassportNo.Size = New System.Drawing.Size(261, 25)
        Me.txtPassportNo.TabIndex = 20
        Me.ToolTip1.SetToolTip(Me.txtPassportNo, "Citizenship no")
        '
        'btnViewStudents
        '
        Me.btnViewStudents.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewStudents.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewStudents.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.btnViewStudents.Location = New System.Drawing.Point(805, 14)
        Me.btnViewStudents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewStudents.Name = "btnViewStudents"
        Me.btnViewStudents.Size = New System.Drawing.Size(125, 35)
        Me.btnViewStudents.TabIndex = 1
        Me.btnViewStudents.TabStop = False
        Me.btnViewStudents.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewStudents, "View all of students in the college.")
        Me.btnViewStudents.UseVisualStyleBackColor = True
        '
        'grdStudent
        '
        Me.grdStudent.AllowUserToAddRows = False
        Me.grdStudent.AllowUserToDeleteRows = False
        Me.grdStudent.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdStudent.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdStudent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdStudent.Location = New System.Drawing.Point(807, 56)
        Me.grdStudent.MultiSelect = False
        Me.grdStudent.Name = "grdStudent"
        Me.grdStudent.ReadOnly = True
        Me.grdStudent.RowHeadersVisible = False
        Me.grdStudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdStudent.ShowCellToolTips = False
        Me.grdStudent.Size = New System.Drawing.Size(316, 428)
        Me.grdStudent.TabIndex = 0
        Me.grdStudent.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdStudent, "Click header to sort the list of students.")
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'StudentAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grdStudent)
        Me.Controls.Add(Me.btnViewStudents)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "StudentAddNew"
        Me.Size = New System.Drawing.Size(1138, 496)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.grdStudent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtEmailAddress As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnViewStudents As System.Windows.Forms.Button
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents txtWardNo As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtStudentId As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents txtFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtDistrict As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtPlace As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtCitizenshipNo As ControlLibrary_IMS.TextBoxNumericPunctuation
    Friend WithEvents txtPhoneNumber As ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon
    Friend WithEvents grdStudent As System.Windows.Forms.DataGridView
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents cboCountry As System.Windows.Forms.ComboBox
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents txtPassportNo As ControlLibrary_IMS.TextBoxNumericCharacters

End Class
