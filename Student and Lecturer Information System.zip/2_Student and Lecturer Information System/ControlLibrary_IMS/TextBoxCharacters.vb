﻿Public Class TextBoxCharacters
    Inherits TextBox

    Protected Overrides Sub OnKeyPress(e As KeyPressEventArgs)
        MyBase.OnKeyPress(e)

        If Not Char.IsLetter(e.KeyChar) And Not Char.IsWhiteSpace(e.KeyChar) And Not Asc(e.KeyChar) = 8 Then
            e.Handled = True
        Else
            e.Handled = False
        End If
        'If Keys.Space Then
        '    e.Handled = False
        'End If
    End Sub
End Class
