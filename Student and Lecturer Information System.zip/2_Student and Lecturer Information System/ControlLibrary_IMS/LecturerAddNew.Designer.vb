﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LecturerAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LecturerAddNew))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtPassportNo = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.txtCitizenshipNo = New ControlLibrary_IMS.TextBoxNumericPunctuation()
        Me.cboCountry = New System.Windows.Forms.ComboBox()
        Me.txtPlace = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtWardNo = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtDistrict = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtEmailAddress = New System.Windows.Forms.TextBox()
        Me.txtPhoneNumber = New ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.txtLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtLecturerId = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.btnViewLecturer = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grdLecturer = New System.Windows.Forms.DataGridView()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.GroupBox5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grdLecturer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox5.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(792, 477)
        Me.GroupBox5.TabIndex = 10
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Lecturer Main Details"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 4
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.Controls.Add(Me.txtPassportNo, 3, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.cboStatus, 3, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.txtCitizenshipNo, 3, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.cboCountry, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.txtPlace, 1, 9)
        Me.TableLayoutPanel4.Controls.Add(Me.txtWardNo, 1, 8)
        Me.TableLayoutPanel4.Controls.Add(Me.txtDistrict, 1, 7)
        Me.TableLayoutPanel4.Controls.Add(Me.txtEmailAddress, 1, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.txtPhoneNumber, 1, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.dtpDateOfBirth, 1, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.txtLastName, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.txtFirstName, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.txtLecturerId, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.cboGender, 1, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel1, 3, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.Label22, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label23, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label24, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label25, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label26, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.Label34, 0, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label35, 0, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.Label33, 0, 7)
        Me.TableLayoutPanel4.Controls.Add(Me.Label32, 0, 8)
        Me.TableLayoutPanel4.Controls.Add(Me.Label31, 0, 9)
        Me.TableLayoutPanel4.Controls.Add(Me.Label30, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label29, 2, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label28, 2, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label27, 2, 3)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 10
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(784, 454)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'txtPassportNo
        '
        Me.txtPassportNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPassportNo, "If exists, type a valid passport no. eg: 04449380")
        Me.txtPassportNo.Location = New System.Drawing.Point(506, 100)
        Me.txtPassportNo.MaxLength = 9
        Me.txtPassportNo.Name = "txtPassportNo"
        Me.HelpProvider1.SetShowHelp(Me.txtPassportNo, True)
        Me.txtPassportNo.Size = New System.Drawing.Size(261, 25)
        Me.txtPassportNo.TabIndex = 12
        Me.ToolTip1.SetToolTip(Me.txtPassportNo, "Citizenship no")
        '
        'cboStatus
        '
        Me.cboStatus.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboStatus, "Select 'active' if he is currently on the college otherwise select 'Inactive'")
        Me.cboStatus.Items.AddRange(New Object() {"Active", "Inactive"})
        Me.cboStatus.Location = New System.Drawing.Point(506, 145)
        Me.cboStatus.Name = "cboStatus"
        Me.HelpProvider1.SetShowHelp(Me.cboStatus, True)
        Me.cboStatus.Size = New System.Drawing.Size(262, 25)
        Me.cboStatus.TabIndex = 13
        Me.ToolTip1.SetToolTip(Me.cboStatus, "Status")
        '
        'txtCitizenshipNo
        '
        Me.txtCitizenshipNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtCitizenshipNo, "If exists, type a valid citizenship no. eg: 119293-38383")
        Me.txtCitizenshipNo.Location = New System.Drawing.Point(506, 55)
        Me.txtCitizenshipNo.MaxLength = 15
        Me.txtCitizenshipNo.Name = "txtCitizenshipNo"
        Me.HelpProvider1.SetShowHelp(Me.txtCitizenshipNo, True)
        Me.txtCitizenshipNo.Size = New System.Drawing.Size(261, 25)
        Me.txtCitizenshipNo.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.txtCitizenshipNo, "Citizenship no")
        '
        'cboCountry
        '
        Me.cboCountry.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboCountry.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboCountry, "Select country from the list if exists, otherwise type eg: India.")
        Me.cboCountry.Location = New System.Drawing.Point(506, 10)
        Me.cboCountry.Name = "cboCountry"
        Me.HelpProvider1.SetShowHelp(Me.cboCountry, True)
        Me.cboCountry.Size = New System.Drawing.Size(261, 25)
        Me.cboCountry.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.cboCountry, "Country")
        '
        'txtPlace
        '
        Me.txtPlace.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPlace, "Type place name of the permanent address. eg: Tiplyang")
        Me.txtPlace.Location = New System.Drawing.Point(115, 417)
        Me.txtPlace.MaxLength = 20
        Me.txtPlace.Name = "txtPlace"
        Me.HelpProvider1.SetShowHelp(Me.txtPlace, True)
        Me.txtPlace.Size = New System.Drawing.Size(261, 25)
        Me.txtPlace.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.txtPlace, "Place")
        '
        'txtWardNo
        '
        Me.txtWardNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtWardNo, "Type a ward no. eg: 9")
        Me.txtWardNo.Location = New System.Drawing.Point(115, 370)
        Me.txtWardNo.MaxLength = 3
        Me.txtWardNo.Name = "txtWardNo"
        Me.HelpProvider1.SetShowHelp(Me.txtWardNo, True)
        Me.txtWardNo.Size = New System.Drawing.Size(261, 25)
        Me.txtWardNo.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtWardNo, "Ward no")
        '
        'txtDistrict
        '
        Me.txtDistrict.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtDistrict, "Type a district name of the permanent address. eg: Myagdi")
        Me.txtDistrict.Location = New System.Drawing.Point(115, 325)
        Me.txtDistrict.MaxLength = 20
        Me.txtDistrict.Name = "txtDistrict"
        Me.HelpProvider1.SetShowHelp(Me.txtDistrict, True)
        Me.txtDistrict.Size = New System.Drawing.Size(261, 25)
        Me.txtDistrict.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtDistrict, "District")
        '
        'txtEmailAddress
        '
        Me.txtEmailAddress.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEmailAddress.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtEmailAddress, resources.GetString("txtEmailAddress.HelpString"))
        Me.txtEmailAddress.Location = New System.Drawing.Point(116, 280)
        Me.txtEmailAddress.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEmailAddress.MaxLength = 225
        Me.txtEmailAddress.Name = "txtEmailAddress"
        Me.HelpProvider1.SetShowHelp(Me.txtEmailAddress, True)
        Me.txtEmailAddress.Size = New System.Drawing.Size(261, 25)
        Me.txtEmailAddress.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtEmailAddress, "Email address")
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPhoneNumber, resources.GetString("txtPhoneNumber.HelpString"))
        Me.txtPhoneNumber.Location = New System.Drawing.Point(115, 235)
        Me.txtPhoneNumber.MaxLength = 25
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.HelpProvider1.SetShowHelp(Me.txtPhoneNumber, True)
        Me.txtPhoneNumber.Size = New System.Drawing.Size(261, 25)
        Me.txtPhoneNumber.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtPhoneNumber, "Phone number")
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.dtpDateOfBirth, "Click on the calendar icon then browse and select the date.")
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(115, 145)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.HelpProvider1.SetShowHelp(Me.dtpDateOfBirth, True)
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(262, 25)
        Me.dtpDateOfBirth.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dtpDateOfBirth, "Date of birth")
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtLastName, "Type last name. eg: Gurung")
        Me.txtLastName.Location = New System.Drawing.Point(115, 100)
        Me.txtLastName.MaxLength = 35
        Me.txtLastName.Name = "txtLastName"
        Me.HelpProvider1.SetShowHelp(Me.txtLastName, True)
        Me.txtLastName.Size = New System.Drawing.Size(261, 25)
        Me.txtLastName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtLastName, "Last Name")
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtFirstName, "Type firstname ( and middle name if exists). eg: Anita Kumari")
        Me.txtFirstName.Location = New System.Drawing.Point(115, 55)
        Me.txtFirstName.MaxLength = 70
        Me.txtFirstName.Name = "txtFirstName"
        Me.HelpProvider1.SetShowHelp(Me.txtFirstName, True)
        Me.txtFirstName.Size = New System.Drawing.Size(261, 25)
        Me.txtFirstName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtFirstName, "First Name")
        '
        'txtLecturerId
        '
        Me.txtLecturerId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLecturerId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.HelpProvider1.SetHelpString(Me.txtLecturerId, "Type lecturer id. eg: LECTT1120001")
        Me.txtLecturerId.Location = New System.Drawing.Point(115, 10)
        Me.txtLecturerId.MaxLength = 12
        Me.txtLecturerId.Name = "txtLecturerId"
        Me.HelpProvider1.SetShowHelp(Me.txtLecturerId, True)
        Me.txtLecturerId.Size = New System.Drawing.Size(261, 25)
        Me.txtLecturerId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtLecturerId, "Lecturer Id")
        '
        'cboGender
        '
        Me.cboGender.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGender.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboGender, "Select gender from the list")
        Me.cboGender.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.cboGender.Location = New System.Drawing.Point(115, 190)
        Me.cboGender.Name = "cboGender"
        Me.HelpProvider1.SetShowHelp(Me.cboGender, True)
        Me.cboGender.Size = New System.Drawing.Size(262, 25)
        Me.cboGender.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboGender, "Gender")
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Location = New System.Drawing.Point(507, 184)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(265, 37)
        Me.Panel1.TabIndex = 14
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(135, 2)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 16
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(0, 1)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 15
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 14)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(82, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Lecturer Id:"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(4, 149)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(91, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Date of birth:"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(4, 59)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(80, 17)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "First Name:"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(4, 104)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(77, 17)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Last Name:"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(4, 194)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(57, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Gender:"
        '
        'Label34
        '
        Me.Label34.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(4, 239)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(104, 17)
        Me.Label34.TabIndex = 10
        Me.Label34.Text = "Phone number:"
        '
        'Label35
        '
        Me.Label35.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(4, 284)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(99, 17)
        Me.Label35.TabIndex = 11
        Me.Label35.Text = "Email address:"
        '
        'Label33
        '
        Me.Label33.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(4, 329)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(59, 17)
        Me.Label33.TabIndex = 3
        Me.Label33.Text = "District:"
        '
        'Label32
        '
        Me.Label32.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(4, 374)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(68, 17)
        Me.Label32.TabIndex = 4
        Me.Label32.Text = "Ward no.:"
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(4, 421)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(46, 17)
        Me.Label31.TabIndex = 5
        Me.Label31.Text = "Place:"
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(396, 14)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(63, 17)
        Me.Label30.TabIndex = 6
        Me.Label30.Text = "Country:"
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(396, 59)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(103, 17)
        Me.Label29.TabIndex = 7
        Me.Label29.Text = "Citizenship no.:"
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(396, 104)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(89, 17)
        Me.Label28.TabIndex = 8
        Me.Label28.Text = "Passport no.:"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(396, 149)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(50, 17)
        Me.Label27.TabIndex = 9
        Me.Label27.Text = "Status:"
        '
        'btnViewLecturer
        '
        Me.btnViewLecturer.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewLecturer.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewLecturer.Location = New System.Drawing.Point(804, 14)
        Me.btnViewLecturer.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewLecturer.Name = "btnViewLecturer"
        Me.btnViewLecturer.Size = New System.Drawing.Size(125, 35)
        Me.btnViewLecturer.TabIndex = 21
        Me.btnViewLecturer.TabStop = False
        Me.btnViewLecturer.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewLecturer, "View all of lecturers in the college.")
        Me.btnViewLecturer.UseVisualStyleBackColor = True
        '
        'grdLecturer
        '
        Me.grdLecturer.AllowUserToAddRows = False
        Me.grdLecturer.AllowUserToDeleteRows = False
        Me.grdLecturer.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdLecturer.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdLecturer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdLecturer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdLecturer.Location = New System.Drawing.Point(806, 53)
        Me.grdLecturer.MultiSelect = False
        Me.grdLecturer.Name = "grdLecturer"
        Me.grdLecturer.ReadOnly = True
        Me.grdLecturer.RowHeadersVisible = False
        Me.grdLecturer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdLecturer.ShowCellToolTips = False
        Me.grdLecturer.Size = New System.Drawing.Size(316, 428)
        Me.grdLecturer.TabIndex = 0
        Me.grdLecturer.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdLecturer, "Click header to sort the list of students.")
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'LecturerAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grdLecturer)
        Me.Controls.Add(Me.btnViewLecturer)
        Me.Controls.Add(Me.GroupBox5)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "LecturerAddNew"
        Me.Size = New System.Drawing.Size(1137, 498)
        Me.GroupBox5.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.grdLecturer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnViewLecturer As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents txtLecturerId As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents grdLecturer As System.Windows.Forms.DataGridView
    Friend WithEvents txtFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents txtLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtPhoneNumber As ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon
    Friend WithEvents txtEmailAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtDistrict As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtWardNo As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtPlace As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents cboCountry As System.Windows.Forms.ComboBox
    Friend WithEvents txtCitizenshipNo As ControlLibrary_IMS.TextBoxNumericPunctuation
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents txtPassportNo As ControlLibrary_IMS.TextBoxNumericCharacters

End Class
