﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GuardianSearch
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grpResult = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnShowEditSection = New System.Windows.Forms.Button()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.btnViewAllGuardians = New System.Windows.Forms.Button()
        Me.grdGuardian = New System.Windows.Forms.DataGridView()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtRelationship = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtStudentLastName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtStudentFirstName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtStudentId = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.txtGuardianLastName = New System.Windows.Forms.TextBox()
        Me.txtGuardianFirstName = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.cboRelationship = New System.Windows.Forms.ComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.txtViewPhoneNumber = New ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon()
        Me.txtViewGuardianLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtViewGuardianFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtViewStudentId = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtViewStudentName = New System.Windows.Forms.TextBox()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pnlListOfStudent = New System.Windows.Forms.Panel()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.grpResult.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grdGuardian, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.grpEdit.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.pnlListOfStudent.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpResult
        '
        Me.grpResult.BackColor = System.Drawing.Color.Transparent
        Me.grpResult.Controls.Add(Me.Panel1)
        Me.grpResult.Controls.Add(Me.grdGuardian)
        Me.grpResult.Location = New System.Drawing.Point(8, 177)
        Me.grpResult.Name = "grpResult"
        Me.grpResult.Padding = New System.Windows.Forms.Padding(0)
        Me.grpResult.Size = New System.Drawing.Size(1140, 341)
        Me.grpResult.TabIndex = 0
        Me.grpResult.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnShowEditSection)
        Me.Panel1.Controls.Add(Me.btnGetReport)
        Me.Panel1.Controls.Add(Me.btnViewAllGuardians)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 298)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1140, 43)
        Me.Panel1.TabIndex = 21
        '
        'btnShowEditSection
        '
        Me.btnShowEditSection.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnShowEditSection.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShowEditSection.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnShowEditSection.Location = New System.Drawing.Point(535, 4)
        Me.btnShowEditSection.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShowEditSection.Name = "btnShowEditSection"
        Me.btnShowEditSection.Size = New System.Drawing.Size(132, 35)
        Me.btnShowEditSection.TabIndex = 74
        Me.btnShowEditSection.TabStop = False
        Me.btnShowEditSection.Text = "Show Edit section"
        Me.ToolTip1.SetToolTip(Me.btnShowEditSection, "Refresh the view list.")
        Me.btnShowEditSection.UseVisualStyleBackColor = True
        '
        'btnGetReport
        '
        Me.btnGetReport.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(675, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 73
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'btnViewAllGuardians
        '
        Me.btnViewAllGuardians.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnViewAllGuardians.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllGuardians.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllGuardians.Location = New System.Drawing.Point(385, 4)
        Me.btnViewAllGuardians.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllGuardians.Name = "btnViewAllGuardians"
        Me.btnViewAllGuardians.Size = New System.Drawing.Size(142, 35)
        Me.btnViewAllGuardians.TabIndex = 50
        Me.btnViewAllGuardians.TabStop = False
        Me.btnViewAllGuardians.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllGuardians, "View all of the guardian details of the corresponding student.")
        Me.btnViewAllGuardians.UseVisualStyleBackColor = True
        '
        'grdGuardian
        '
        Me.grdGuardian.AllowUserToAddRows = False
        Me.grdGuardian.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdGuardian.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdGuardian.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdGuardian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdGuardian.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdGuardian.Location = New System.Drawing.Point(0, 18)
        Me.grdGuardian.MultiSelect = False
        Me.grdGuardian.Name = "grdGuardian"
        Me.grdGuardian.ReadOnly = True
        Me.grdGuardian.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdGuardian.ShowCellToolTips = False
        Me.grdGuardian.Size = New System.Drawing.Size(1140, 273)
        Me.grdGuardian.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdGuardian, "Click 'Show Enable section' button to view the Edit section and select a record a" & _
        "nd get the data in the Details section.")
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 3)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(127, 17)
        Me.Label10.TabIndex = 51
        Me.Label10.Text = "List of guardians:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Location = New System.Drawing.Point(57, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1067, 137)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search By:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 7
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.txtRelationship, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtStudentLastName, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtStudentFirstName, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtStudentId, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtPhoneNumber, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtGuardianLastName, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtGuardianFirstName, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 5, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1061, 113)
        Me.TableLayoutPanel1.TabIndex = 45
        '
        'txtRelationship
        '
        Me.txtRelationship.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtRelationship.Location = New System.Drawing.Point(186, 83)
        Me.txtRelationship.MaxLength = 20
        Me.txtRelationship.Name = "txtRelationship"
        Me.txtRelationship.Size = New System.Drawing.Size(213, 25)
        Me.txtRelationship.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtRelationship, "Relationship")
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(88, 87)
        Me.Label15.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(90, 17)
        Me.Label15.TabIndex = 72
        Me.Label15.Text = "Relationship:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(4, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 17)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Student"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold)
        Me.Label3.Location = New System.Drawing.Point(5, 50)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 17)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Guardian"
        '
        'txtStudentLastName
        '
        Me.txtStudentLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStudentLastName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtStudentLastName.Location = New System.Drawing.Point(838, 7)
        Me.txtStudentLastName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtStudentLastName.Name = "txtStudentLastName"
        Me.txtStudentLastName.Size = New System.Drawing.Size(213, 25)
        Me.txtStudentLastName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtStudentLastName, "Student Last Name")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(724, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 17)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Last Name:"
        '
        'txtStudentFirstName
        '
        Me.txtStudentFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStudentFirstName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtStudentFirstName.Location = New System.Drawing.Point(501, 7)
        Me.txtStudentFirstName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtStudentFirstName.Name = "txtStudentFirstName"
        Me.txtStudentFirstName.Size = New System.Drawing.Size(213, 25)
        Me.txtStudentFirstName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtStudentFirstName, "Student First Name")
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(411, 11)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "First Name:"
        '
        'txtStudentId
        '
        Me.txtStudentId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStudentId.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtStudentId.Location = New System.Drawing.Point(188, 7)
        Me.txtStudentId.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtStudentId.Name = "txtStudentId"
        Me.txtStudentId.Size = New System.Drawing.Size(213, 25)
        Me.txtStudentId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtStudentId, "Student Id")
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(87, 11)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(25, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Id:"
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPhoneNumber.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtPhoneNumber.Location = New System.Drawing.Point(838, 46)
        Me.txtPhoneNumber.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(213, 25)
        Me.txtPhoneNumber.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtPhoneNumber, "Guardian Phone number")
        '
        'txtGuardianLastName
        '
        Me.txtGuardianLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtGuardianLastName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtGuardianLastName.Location = New System.Drawing.Point(501, 46)
        Me.txtGuardianLastName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtGuardianLastName.Name = "txtGuardianLastName"
        Me.txtGuardianLastName.Size = New System.Drawing.Size(213, 25)
        Me.txtGuardianLastName.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtGuardianLastName, "Guardian Last Name")
        '
        'txtGuardianFirstName
        '
        Me.txtGuardianFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtGuardianFirstName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtGuardianFirstName.Location = New System.Drawing.Point(188, 46)
        Me.txtGuardianFirstName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtGuardianFirstName.Name = "txtGuardianFirstName"
        Me.txtGuardianFirstName.Size = New System.Drawing.Size(213, 25)
        Me.txtGuardianFirstName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtGuardianFirstName, "Guardian First Name")
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(88, 50)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(80, 17)
        Me.Label11.TabIndex = 54
        Me.Label11.Text = "First Name:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(411, 50)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 17)
        Me.Label7.TabIndex = 54
        Me.Label7.Text = "Last Name:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(724, 50)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 17)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Phone number:"
        '
        'grpEdit
        '
        Me.grpEdit.Controls.Add(Me.TableLayoutPanel2)
        Me.grpEdit.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpEdit.Location = New System.Drawing.Point(758, 177)
        Me.grpEdit.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.grpEdit.Size = New System.Drawing.Size(390, 341)
        Me.grpEdit.TabIndex = 71
        Me.grpEdit.TabStop = False
        Me.grpEdit.Visible = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.cboRelationship, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewPhoneNumber, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewGuardianLastName, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewGuardianFirstName, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label20, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewStudentId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewStudentName, 1, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 7
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(380, 314)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'cboRelationship
        '
        Me.cboRelationship.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboRelationship.FormattingEnabled = True
        Me.cboRelationship.Location = New System.Drawing.Point(117, 237)
        Me.cboRelationship.Name = "cboRelationship"
        Me.cboRelationship.Size = New System.Drawing.Size(261, 25)
        Me.cboRelationship.Sorted = True
        Me.cboRelationship.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboRelationship, "Relationship")
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnDelete)
        Me.Panel3.Controls.Add(Me.btnUpdate)
        Me.Panel3.Location = New System.Drawing.Point(117, 273)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(261, 38)
        Me.Panel3.TabIndex = 73
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(132, 3)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(2, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'txtViewPhoneNumber
        '
        Me.txtViewPhoneNumber.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewPhoneNumber.Location = New System.Drawing.Point(117, 190)
        Me.txtViewPhoneNumber.MaxLength = 20
        Me.txtViewPhoneNumber.Name = "txtViewPhoneNumber"
        Me.txtViewPhoneNumber.Size = New System.Drawing.Size(257, 25)
        Me.txtViewPhoneNumber.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtViewPhoneNumber, "Guardian Phone number")
        '
        'txtViewGuardianLastName
        '
        Me.txtViewGuardianLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewGuardianLastName.Location = New System.Drawing.Point(117, 145)
        Me.txtViewGuardianLastName.MaxLength = 35
        Me.txtViewGuardianLastName.Name = "txtViewGuardianLastName"
        Me.txtViewGuardianLastName.Size = New System.Drawing.Size(257, 25)
        Me.txtViewGuardianLastName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtViewGuardianLastName, "Guardian Last Name")
        '
        'txtViewGuardianFirstName
        '
        Me.txtViewGuardianFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewGuardianFirstName.Location = New System.Drawing.Point(117, 100)
        Me.txtViewGuardianFirstName.MaxLength = 70
        Me.txtViewGuardianFirstName.Name = "txtViewGuardianFirstName"
        Me.txtViewGuardianFirstName.Size = New System.Drawing.Size(257, 25)
        Me.txtViewGuardianFirstName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtViewGuardianFirstName, "Guardian First Name")
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 194)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Phone number:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 104)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 17)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "First Name:"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 149)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 17)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Last Name:"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(5, 239)
        Me.Label20.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(90, 17)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Relationship:"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(5, 14)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 17)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Student Id:"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(5, 59)
        Me.Label13.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 17)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Name:"
        '
        'txtViewStudentId
        '
        Me.txtViewStudentId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewStudentId.Location = New System.Drawing.Point(117, 10)
        Me.txtViewStudentId.Name = "txtViewStudentId"
        Me.txtViewStudentId.ReadOnly = True
        Me.txtViewStudentId.Size = New System.Drawing.Size(257, 25)
        Me.txtViewStudentId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtViewStudentId, "Student Id")
        '
        'txtViewStudentName
        '
        Me.txtViewStudentName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewStudentName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewStudentName.Location = New System.Drawing.Point(117, 55)
        Me.txtViewStudentName.Name = "txtViewStudentName"
        Me.txtViewStudentName.ReadOnly = True
        Me.txtViewStudentName.Size = New System.Drawing.Size(257, 25)
        Me.txtViewStudentName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtViewStudentName, "Student Name")
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(919, 159)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(61, 17)
        Me.lblDetails.TabIndex = 72
        Me.lblDetails.Text = "Details:"
        Me.lblDetails.Visible = False
        '
        'pnlListOfStudent
        '
        Me.pnlListOfStudent.BackColor = System.Drawing.Color.Transparent
        Me.pnlListOfStudent.Controls.Add(Me.lblResult)
        Me.pnlListOfStudent.Controls.Add(Me.Label10)
        Me.pnlListOfStudent.Location = New System.Drawing.Point(553, 159)
        Me.pnlListOfStudent.Name = "pnlListOfStudent"
        Me.pnlListOfStudent.Size = New System.Drawing.Size(155, 20)
        Me.pnlListOfStudent.TabIndex = 73
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(127, 3)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 50
        Me.lblResult.Text = "0"
        '
        'GuardianSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.pnlListOfStudent)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpResult)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "GuardianSearch"
        Me.Size = New System.Drawing.Size(1160, 528)
        Me.grpResult.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.grdGuardian, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.grpEdit.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.pnlListOfStudent.ResumeLayout(False)
        Me.pnlListOfStudent.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grpResult As System.Windows.Forms.GroupBox
    Friend WithEvents grdGuardian As System.Windows.Forms.DataGridView
    Friend WithEvents btnViewAllGuardians As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtGuardianLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtPhoneNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtGuardianFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtStudentLastName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtStudentFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtStudentId As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtRelationship As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents grpEdit As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtViewPhoneNumber As ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon
    Friend WithEvents txtViewGuardianLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtViewGuardianFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtViewStudentName As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents txtViewStudentId As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents cboRelationship As System.Windows.Forms.ComboBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents btnShowEditSection As System.Windows.Forms.Button
    Friend WithEvents pnlListOfStudent As System.Windows.Forms.Panel
    Friend WithEvents lblResult As System.Windows.Forms.Label

End Class
