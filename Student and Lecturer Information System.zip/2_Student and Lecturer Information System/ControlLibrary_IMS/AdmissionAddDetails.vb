﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class AdmissionAddDetails
    'New instances
        Private dataAccess As New DataAccess
        Dim objCommand As SqlCommand
    Dim dtStudentList As New DataTable
    Dim dtFacultyList As New DataTable
    Dim dtAdmission As New DataTable
    Dim objDataView As New DataView
    Dim strExceptionId As String = "errStudentId"

        'METHOD: GET STUDENT ID AND NAME BASED ON COMBOBOX SELECTION
        Private Sub GetStudentIdAndName()
            Dim intYear As Integer
            'Get year value for YEAR combobox
            Select Case cboYear.SelectedIndex
                Case 0
                    intYear = 0
                Case 1
                    intYear = 1
                Case 2
                    intYear = 2
                Case 3
                    intYear = 3
            End Select

            objCommand = New SqlCommand
        objCommand.CommandText = "SELECT StudentId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Student; "

        'Call GetStudentName method to get list of name and id
            dataAccess.GetListForComboBox(objCommand)

        'Check for errors
            If dataAccess.strExceptionGetListForComboBox <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtStudentList = dataAccess.dtListForComboBox
            'objDataView = New DataView(dtStudentList)
            cboId.DataSource = dtStudentList
            cboId.DisplayMember = "StudentId"

            If cboId.Text = "" Then
                txtName.Clear()

                strExceptionId = "Select or enter 12 character student Id."
                ErrorProvider1.SetError(cboId, strExceptionId)
            Else
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)
            End If


            'Check whether to enable save button or not
            EnabledSaveButton()
        End If
        End Sub

    Private Sub EnabledSaveButton()
        If strExceptionId = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub


    Private Sub GetFacultyList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Stream;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Get the table data
            dtFacultyList = dataAccess.objDataSet.Tables(0)

            'Clear previous DataGridView DataSource
            cboFaculty.DataSource = Nothing

            'Get the datasource for datagridview
            cboFaculty.DataSource = dtFacultyList
        End If
    End Sub

        'FORM LOAD EVENT 
        Private Sub StudentAddPhone_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0

        'Call GetStudentName to get list in the combobox
        GetStudentIdAndName()

        'Call this procedure to get list in the GridView
        GetStudentIdAndNameAndAdmission()

        'Make sure that the datagridview readonly property is true
        grdAdmission.ReadOnly = True

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

        'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
        Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If

        ''Get student id for combobox
        'GetStudentIdAndName()

            'Fill datagridview
        'GetStudentIdAndNameAndEmail()


        End Sub


    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
        Private Sub cboId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
            'Clear any previous bindings..
            txtName.DataBindings.Clear()

            'Binding process
            txtName.DataBindings.Add("Text", dtStudentList, "Name")

        'Refresh datagridview
        GetStudentIdAndNameAndAdmission()
        End Sub

    Private Sub cboId_Validating(sender As Object, e As EventArgs) Handles cboId.Validating
        'Check if the student already exists
        If cboId.Text.Trim.Length = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSetStudentCheck IsNot Nothing Then
                dataAccess.objDataSetStudentCheck.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSetIdCheck("SELECT *  " & _
                "FROM Student " & _
                "WHERE StudentId LIKE '%" & cboId.Text & "%';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSetIdCheck <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSetIdCheck, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSetIdCheck = Nothing
            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 1 Then
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 0 Then
                strExceptionId = "This student does not exist."
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtName.Clear()
            End If
        Else
            strExceptionId = "Select or enter 12 character student Id."
            ErrorProvider1.SetError(cboId, strExceptionId)

            'Clear the name textbox
            txtName.Clear()
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If cboFaculty.Text.Trim.Length > 1 Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you want to add the following admission information?")
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
            objStringBuilder.AppendLine("Admission-Date: " & dtpAdmissionDate.Text)
            objStringBuilder.AppendLine("Year and Faculty: " & cboYear.Text)

            'Show message box
            If MessageBox.Show(objStringBuilder.ToString, "Add New Admission Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                'Call
                AddAdmissionDetails()
            End If
        Else
            'Show error message
            MsgBox("Please select faculty from the list.", MsgBoxStyle.Exclamation, "Admission details")

        End If
        
    End Sub

    Private Sub AddAdmissionDetails()
        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        '
        objCommand = New SqlCommand
        objCommand.CommandText = "INSERT INTO StudentAdmission " & _
            "VALUES(@studentId,@admissionDate, @year, @faculty); "
        '& _
        '            "IF EXISTS (SELECT * FROM StudentCurrentYear WHERE StudentId=@studentId AND Faculty=@faculty) " & _
        '                "UPDATE StudentCurrentYear SET CurrentYear=@year WHERE StudentId=@studentId " & _
        '            "ELSE " & _
        '                "INSERT INTO StudentCurrentYear VALUES (@studentId, @year, @faculty);"

        'Add parameters for the placeholder in the SQL CommandText property..
        objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
        objCommand.Parameters.AddWithValue("@admissionDate", dtpAdmissionDate.Value.Date)
        objCommand.Parameters.AddWithValue("@year", intYear)
        objCommand.Parameters.AddWithValue("@faculty", cboFaculty.Text)

        'Call AddDetails method to add admission details
        dataAccess.AddDetails(objCommand)

        'Check for errors
        If dataAccess.strExceptionAddDetails <> "" Then
            If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                'Show error message
                MessageBox.Show("The student have already been registered for the faculty at the same date.", "Admission Details | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                'Show error message
                MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Admission Details | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            'Set the variable to nothing
            dataAccess.strExceptionAddDetails = Nothing

            'Select and focus on phone number textbox
            cboId.SelectAll()
            cboId.Focus()
        Else
            'If there is no error, show succeed message
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("The following admission information has been successfully added.")
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
            objStringBuilder.AppendLine("Admission-Date: " & dtpAdmissionDate.Text)
            objStringBuilder.AppendLine("Year and Faculty: " & cboYear.Text)

            'Show message box
            MessageBox.Show(objStringBuilder.ToString, "Add Admission Details | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ''Refresh datagridview
            GetStudentIdAndNameAndAdmission()
        End If
    End Sub





    'LIST OF METHOD FOR THE DATAGRIDVIEW SECTION
    'METHOD: GET STUDENT ID AND NAME AND ADMISSION DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetStudentIdAndNameAndAdmission()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name, AdmissionDate As [Admission Date], Year, Faculty " & _
            "FROM Student " & _
            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
            "WHERE Student.StudentId= '" & cboId.Text & "' " & _
            "ORDER BY Year;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdAdmission.DataSource = Nothing

            'Get the table data
            dtAdmission = dataAccess.objDataSet.Tables(0)

            'Get the datasource for datagridview
            grdAdmission.DataSource = dtAdmission

            GblAccessItem.DataTableAdmissionAdd = dataAccess.AutoNumberedTable(dtAdmission)

            'Make sure the following changes
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Make DataGridView ReadOnly property to true
            grdAdmission.ReadOnly = True

            If grdAdmission.RowCount > 0 Then
                'Enable the btnGetReport button
                btnGetReport.Enabled = True

                'Enable the enable edit button
                btnEnableEdit.Enabled = True
            Else
                'Disable the btnGetReport button
                btnGetReport.Enabled = False

                'Disable the enable edit button
                btnEnableEdit.Enabled = False
            End If

            grdAdmission.Columns(1).Frozen = True
        End If
    End Sub

    'METHOD: GET STUDENT ID AND ADMISSION DETAILS FROM A SINGLE TABLE
    Private Sub GetStudentIdAndAdmission()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT StudentId As [Student Id], AdmissionDate As [Admission Date], Year, Faculty " & _
                                          "FROM StudentAdmission " & _
                                          "WHERE StudentId='" & cboId.Text & "' " & _
            "ORDER BY Year;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdAdmission.DataSource = Nothing

            'Get the datasource for datagridview
            grdAdmission.DataSource = dataAccess.objDataSet.Tables(0)

            'Get update command
            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand
        End If
    End Sub


   
    Private Sub grdAdmission_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles grdAdmission.CellValueChanged
        'Enable save button
        btnGrdSave.Enabled = True
    End Sub


    Private Sub grdAdmission_UserDeletedRow(sender As Object, e As DataGridViewRowEventArgs) Handles grdAdmission.UserDeletedRow
        'Enable save button
        btnGrdSave.Enabled = True
    End Sub

    Private Sub btnEnableEdit_Click(sender As Object, e As EventArgs) Handles btnEnableEdit.Click
        If btnEnableEdit.Text = "Enable Edit" Then
            'Change the text
            btnEnableEdit.Text = "Disable Edit"

            'Fill datagridview from a single admission table
            GetStudentIdAndAdmission()

            'Make DataGridView ReadOnly property to false
            grdAdmission.ReadOnly = False

            'Allow user to delete rows
            grdAdmission.AllowUserToDeleteRows = True

            'Make sure that the 1st column is not able to change
            grdAdmission.Columns(0).ReadOnly = True
        Else
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Refresh datagridview
            GetStudentIdAndNameAndAdmission()

            'Make DataGridView ReadOnly property to true
            grdAdmission.ReadOnly = True

            'Donot allow user to delete rows
            grdAdmission.AllowUserToDeleteRows = False
        End If
    End Sub

    Private Sub grdAdmission_UserDeletingRow(sender As Object, e As DataGridViewRowCancelEventArgs) Handles grdAdmission.UserDeletingRow
        If grdAdmission.ReadOnly = False Then
        
        Else
            'Cancel the delete process
            e.Cancel = True
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        'Refresh datagridview
        GetStudentIdAndNameAndAdmission()
    End Sub

    Private Sub btnGrdSave_Click(sender As Object, e As EventArgs) Handles btnGrdSave.Click
        'Show question box
        If MessageBox.Show("Do you want to save the modification that you have made?", "Admission Modification", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                'Save updates to the datbase
                dataAccess.objDataAdapter.Update(dataAccess.objDataSet)

                'Fill datagridview from a single phone number table
                GetStudentIdAndAdmission()

                'Show message box
                MessageBox.Show("The modification that you have made is successfully saved.", "Admission Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

            'Disable save button
            btnGrdSave.Enabled = False
        End If
        
    End Sub

    Private Sub cboId_TextChanged(sender As Object, e As EventArgs) Handles cboId.TextChanged
        ''GetStudentIdAndName()
        'objDataView.Find(cboId.Text)
        ''objDataView.Sort()
        'cboId.DataSource = objDataView
        'cboId.DisplayMember = "StudentId"
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "AdmissionAdd"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        dtpAdmissionDate.Value = Now()
        cboYear.SelectedIndex = 0
        cboId.SelectAll()
    End Sub
End Class


