﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient


Public Class IssueView
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtIssueList As New DataTable
    Dim intBookId As Integer
    Dim strId As String
    Dim issueDate As Date
    Dim blnIsStudent As Boolean
    Dim strRemarksValue As String

    Dim rowNumber As Int16

    'FORM LOAD EVENT
    Private Sub IssueView_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Select first item in the Remarks combobox
        cboRemarks.SelectedIndex = 0

        'Call procedure:make sure that the View sections control are disabled
        DisabledControls()
    End Sub


    'METHOD: GET BOOK-ISSUE DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetBookIssuedList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'If Student radiobutton is checked and 'Borrowed' is selected in the combobox
        If rdbStudent.Checked = True And cboRemarks.Text.ToLower.Contains("borrowed") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Borrowed' " & _
                                              "ORDER BY Name;")


            'Change boolean variable
            blnIsStudent = True

            'If Lecturer radiobutton is checked and 'Borrowed' is selected in the combobox
        ElseIf rdbLecturer.Checked = True And cboRemarks.Text.ToLower.Contains("borrowed") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Borrowed' " & _
                                              "ORDER BY Name;")


            'Change boolean variable
            blnIsStudent = False

            'If Both radiobutton is checked and 'Borrowed' is selected in the combobox
        ElseIf rdbBoth.Checked = True And cboRemarks.Text.ToLower.Contains("borrowed") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Borrowed' " & _
                                              "UNION " & _
                                              "SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Borrowed' " & _
                                              "ORDER BY Name;")


            'Change boolean variable
            blnIsStudent = True

            'If Student radiobutton is checked and 'Returned' is selected in the combobox
        ElseIf rdbStudent.Checked = True And cboRemarks.Text.ToLower.Contains("returned") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Returned' " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True

            'If Lecturer radiobutton is checked and 'Returned' is selected in the combobox
        ElseIf rdbLecturer.Checked = True And cboRemarks.Text.ToLower.Contains("returned") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Returned' " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = False

            'If Both radiobutton is checked and 'Returned' is selected in the combobox
        ElseIf rdbBoth.Checked = True And cboRemarks.Text.ToLower.Contains("returned") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Returned' " & _
                                              "UNION " & _
                                              "SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Returned' " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True


            'If Student radiobutton is checked and 'Other' is selected in the combobox
        ElseIf rdbStudent.Checked = True And cboRemarks.Text.ToLower.Contains("lost") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Lost' " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True

            'If Lecturer radiobutton is checked and 'Other' is selected in the combobox
        ElseIf rdbLecturer.Checked = True And cboRemarks.Text.ToLower.Contains("lost") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Lost' " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = False

            'If Both radiobutton is checked and 'Other' is selected in the combobox
        ElseIf rdbBoth.Checked = True And cboRemarks.Text.ToLower.Contains("lost") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                               "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                               "join Student on studentbookissue.studentid = student.studentid " & _
                                               "WHERE Remarks='Lost' " & _
                                               "UNION " & _
                                               "SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE Remarks='Lost' " & _
                                              "ORDER BY Name;")


            'Change boolean variable
            blnIsStudent = True

            'If Student radiobutton is checked and 'All' is selected in the combobox
        ElseIf rdbStudent.Checked = True And cboRemarks.Text.ToLower.Contains("all") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True

            'If Lecturer radiobutton is checked and 'All' is selected in the combobox
        ElseIf rdbLecturer.Checked = True And cboRemarks.Text.ToLower.Contains("all") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = False

            'If Both radiobutton is checked and 'All' is selected in the combobox
        ElseIf rdbBoth.Checked = True And cboRemarks.Text.ToLower.Contains("all") Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "UNION " & _
                                              "SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "ORDER BY Name;")


            'Change boolean variable
            blnIsStudent = True


        End If



        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub


    'METHOD:FILL DATAGRIDVIEW CONTROL
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdBookIssue.DataSource = Nothing

            'Get the table data
            dtIssueList = dataAccess.objDataSet.Tables(0)

            'Get the datasource for datagridview
            grdBookIssue.DataSource = dtIssueList

            GblAccessItem.DataTableIssueView = dataAccess.AutoNumberedTable(dtIssueList)

            'Do not show the first column
            grdBookIssue.Columns(0).Visible = False

            If rdbBoth.Checked = True Then
                'Set the name of the second column
                grdBookIssue.Columns(1).HeaderText = "Id"
            End If

            If grdBookIssue.Rows.Count > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            'Display the number of records 
            lblResult.Text = grdBookIssue.RowCount


        End If


        'Call ClearFields method to clear the text of the View sections
        ClearFields()

        'Call procedure:make sure that the View sections control are disabled
        DisabledControls()

        grdBookIssue.Columns(1).Frozen = True
    End Sub

    'CLICK EVENT OF VIEW BUTTON
    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        GetBookIssuedList()
    End Sub

    Private Sub grdBookIssue_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdBookIssue.CellClick
        rowNumber = grdBookIssue.CurrentCell.RowIndex

        'Clear the text in the view sections
        ClearFields()

        'Enable the controls of view sections
        EnableControls()

        For i As Integer = 0 To grdBookIssue.ColumnCount - 1
            Try
                Select Case i
                    Case 0
                        intBookId = grdBookIssue.Item(0, e.RowIndex).Value
                    Case 1
                        strId = grdBookIssue.Item(1, e.RowIndex).Value
                        If strId.ToLower.StartsWith("1808") Then
                            blnIsStudent = True
                        Else
                            blnIsStudent = False
                        End If

                        txtViewId.Text = strId
                    Case 2
                        txtViewName.Text = grdBookIssue.Item(2, e.RowIndex).Value
                    Case 3
                        txtViewIsbn.Text = grdBookIssue.Item(3, e.RowIndex).Value
                    Case 4
                        txtViewTitle.Text = grdBookIssue.Item(4, e.RowIndex).Value
                    Case 5
                        txtViewAuthor.Text = grdBookIssue.Item(5, e.RowIndex).Value
                    Case 6
                        issueDate = grdBookIssue.Item(6, e.RowIndex).Value
                        dtpViewIssueDate.Value = grdBookIssue.Item(6, e.RowIndex).Value
                    Case 7
                        dtpViewIssueTime.Value = grdBookIssue.Item(6, e.RowIndex).Value + grdBookIssue.Item(7, e.RowIndex).Value
                    Case 8
                        dtpViewReturnDate.Value = grdBookIssue.Item(8, e.RowIndex).Value
                    Case 9
                        dtpViewReturnTime.Value = grdBookIssue.Item(8, e.RowIndex).Value + grdBookIssue.Item(9, e.RowIndex).Value
                    Case 10
                        Dim strRemarks As String
                        strRemarks = grdBookIssue.Item(10, e.RowIndex).Value.ToString.ToLower
                        If strRemarks.Contains("borrowed") Then
                            cboViewRemarks.SelectedIndex = 0
                        ElseIf strRemarks.Contains("returned") Then
                            cboViewRemarks.SelectedIndex = 1
                        ElseIf strRemarks.Contains("lost") Then
                            cboViewRemarks.SelectedIndex = 2
                            'Else
                            '    cboViewRemarks.Text = ""
                            '    cboViewRemarks.Text = strRemarks
                        End If
                        strRemarksValue = strRemarks
                End Select

            Catch ex As Exception

            End Try


        Next

        'Make sure that the Update button is disabled
        btnUpdate.Enabled = False

        'Try
        '    'Enable the controls of view sections
        '    EnableControls()

        '    intBookId = grdBookIssue.Item(0, e.RowIndex).Value
        '    strId = grdBookIssue.Item(1, e.RowIndex).Value
        '    If strId.ToLower.StartsWith("1808") Then
        '        blnIsStudent = True
        '    Else
        '        blnIsStudent = False
        '    End If

        '    txtViewId.Text = strId
        '    txtViewName.Text = grdBookIssue.Item(2, e.RowIndex).Value
        '    txtViewIsbn.Text = grdBookIssue.Item(3, e.RowIndex).Value
        '    txtViewTitle.Text = grdBookIssue.Item(4, e.RowIndex).Value
        '    'txtViewAuthor.Text = grdBookIssue.Item(5, e.RowIndex).Value
        '    issueDate = grdBookIssue.Item(6, e.RowIndex).Value
        '    dtpViewIssueDate.Value = grdBookIssue.Item(6, e.RowIndex).Value
        '    dtpViewIssueTime.Value = grdBookIssue.Item(6, e.RowIndex).Value + grdBookIssue.Item(7, e.RowIndex).Value
        '    'dtpViewReturnDate.Value = grdBookIssue.Item(8, e.RowIndex).Value
        '    ' dtpViewReturnTime.Value = grdBookIssue.Item(8, e.RowIndex).Value + grdBookIssue.Item(9, e.RowIndex).Value

        '    Dim strRemarks As String
        '    strRemarks = grdBookIssue.Item(10, e.RowIndex).Value.ToString.ToLower
        '    If strRemarks.Contains("borrowed") Then
        '        cboViewRemarks.SelectedIndex = 0
        '    ElseIf strRemarks.Contains("returned") Then
        '        cboViewRemarks.SelectedIndex = 1
        '    ElseIf strRemarks.Contains("lost") Then
        '        cboViewRemarks.SelectedIndex = 2
        '        'Else
        '        '    cboViewRemarks.Text = ""
        '        '    cboViewRemarks.Text = strRemarks
        '    End If
        '    strRemarksValue = strRemarks



        '    'Make sure that the Update button is disabled
        '    btnUpdate.Enabled = False
        'Catch ex As Exception

        'End Try
    End Sub


    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles cboViewRemarks.TextChanged, cboViewRemarks.SelectedIndexChanged, dtpViewIssueDate.ValueChanged, dtpViewIssueTime.ValueChanged, dtpViewReturnDate.ValueChanged, dtpViewReturnTime.ValueChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    'CLICK EVENT OF UPDATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Check whether the issue date is smaller than return date
        If CheckIssueAndReturnDate() = True Then
            If blnIsStudent = True Then
                'Call procedure to update the book-issue details
                UpdateStudentBookReturn()
            Else
                'Call procedure to update the book-issue details
                UpdateLecturerBookReturn()
            End If
        End If


        'Refresh the datagridview
        'GetBookIssuedList()

        'Call ClearFields method to clear the text of the View sections
        ClearFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'UPDATE THE STUDENT BOOK-ISSUE DETAILS
    Private Sub UpdateStudentBookReturn()
        Dim strRemarksFromDb As String
        Dim strRemarksFromCbo As String = cboViewRemarks.Text.ToLower

        dataAccess.RunQueryAndFillDataSet("SELECT Remarks FROM StudentBookIssue " & _
                                     "WHERE BookId=" & intBookId & _
                             "AND StudentId='" & strId & "' " & _
                            "AND IssueDate='" & issueDate & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation, "ERROR")

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
            For Each i As Object In dataAccess.objDataSet.Tables(0).Rows
                strRemarksFromDb = i.item("Remarks").ToString.ToLower
            Next
        ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
            'Capture manual error message
            MsgBox("There's no such book issue details", MsgBoxStyle.Exclamation)
        End If


        Try
            'If remarks from db contains 'Returned' and remarks from cbo does not contain
            If strRemarksFromDb.Contains("returned") And Not strRemarksFromCbo.Contains("returned") Then
                'cboViewRemarks.Text.ToLower.Contains("borrowed") Or cboViewRemarks.Text.ToLower.Contains("lost") Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you really want to update book issue details with date and time :" & dtpViewIssueDate.Value.ToShortDateString & " | " & dtpViewIssueTime.Value.ToLongTimeString.ToString & _
                                         " of book: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") ?")
                objStringBuilder.AppendLine(String.Empty)
                'objStringBuilder.AppendLine("Do you really want to update book issue: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text--Update as well as Subtract book from available quantity
                    Dim strCommand As String = "UPDATE StudentBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "ReturnDate=Null, " & _
                                         "ReturnTime=Null, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND StudentId=@studentId " & _
                                        "AND IssueDate=@issueDateOriginal; " & _
                                         "UPDATE BOOK " & _
                                         "SET AvailableQuantity= (AvailableQuantity-1) " & _
                                         "WHERE BookId = @bookId; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    'objCommand.Parameters.AddWithValue("@bookId", txt)
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@studentId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 2 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If


                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                          "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                                          "join Student on studentbookissue.studentid = student.studentid " & _
                                                          "WHERE Student.StudentId = '" & strId & "' " & _
                                                          "AND Book.BookId= " & intBookId & " " & _
                                                          "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")

                        'Change boolean variable
                        blnIsStudent = True


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If

                'If db  remarks is not 'Returned' and combo remarks is 'Returned'
            ElseIf Not strRemarksFromDb.Contains("returned") And strRemarksFromCbo.Contains("returned") Then
                'cboViewRemarks.Text.ToLower.Contains("returned") Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                objStringBuilder.AppendLine(String.Empty)

                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text-- Update as well as Add Book to the available quantity
                    Dim strCommand As String = "UPDATE StudentBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "ReturnDate=@returnDate, " & _
                                         "ReturnTime=@returnTime, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND StudentId=@studentId " & _
                                         "AND IssueDate=@issueDateOriginal; " & _
                                         "UPDATE BOOK " & _
                                         "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                         "WHERE BookId = @bookId; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@returnDate", dtpViewReturnDate.Value)
                    objCommand.Parameters.AddWithValue("@returnTime", dtpViewReturnTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@studentId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 2 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                                              "WHERE Student.StudentId = '" & strId & "' " & _
                                                            "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")

                        'Change boolean variable
                        blnIsStudent = True


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If

                'If both db and combo remarks are 'Returned'
            ElseIf strRemarksFromDb.Contains("returned") And strRemarksFromCbo.Contains("returned") Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                objStringBuilder.AppendLine(String.Empty)

                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text
                    Dim strCommand As String = "UPDATE StudentBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "ReturnDate=@returnDate, " & _
                                         "ReturnTime=@returnTime, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND StudentId=@studentId " & _
                                        "AND IssueDate=@issueDateOriginal; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@returnDate", dtpViewReturnDate.Value)
                    objCommand.Parameters.AddWithValue("@returnTime", dtpViewReturnTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@studentId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 1 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                                              "WHERE Student.StudentId = '" & strId & "' " & _
                                                            "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")

                        'Change boolean variable
                        blnIsStudent = True


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If
                'If both Remarks from db and combobox are not 'Returned'
            ElseIf Not strRemarksFromDb.Contains("returned") And Not strRemarksFromCbo.Contains("returned") Then
                'cboViewRemarks.Text.ToLower.Contains("borrowed") Or cboViewRemarks.Text.ToLower.Contains("lost") Then
                Dim objStringBuilder4 As New System.Text.StringBuilder
                objStringBuilder4.AppendLine("Do you really want to update book issue details with date and time :" & dtpViewIssueDate.Value.ToShortDateString & " | " & dtpViewIssueTime.Value.ToLongTimeString.ToString & _
                                         " of book: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") ?")
                objStringBuilder4.AppendLine(String.Empty)
                'objStringBuilder.AppendLine("Do you really want to update book issue: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder4.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text
                    Dim strCommand As String = "UPDATE StudentBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND StudentId=@studentId " & _
                                        "AND IssueDate=@issueDateOriginal; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    'objCommand.Parameters.AddWithValue("@bookId", txt)
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@studentId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 1 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                                              "WHERE Student.StudentId = '" & strId & "' " & _
                                                            "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")

                        'Change boolean variable
                        blnIsStudent = True


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    'UPDATE THE LECTURER BOOK-ISSUE DETAILS
    Private Sub UpdateLecturerBookReturn()
        Dim strRemarksFromDb As String
        Dim strRemarksFromCbo As String = cboViewRemarks.Text.ToLower

        dataAccess.RunQueryAndFillDataSet("SELECT Remarks FROM LecturerBookIssue " & _
                                     "WHERE BookId=" & intBookId & _
                             "AND LecturerId='" & strId & "' " & _
                            "AND IssueDate='" & issueDate & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation, "ERROR")

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
            For Each i As Object In dataAccess.objDataSet.Tables(0).Rows
                strRemarksFromDb = i.item("Remarks").ToString.ToLower
            Next
        ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
            'Capture manual error message
            MsgBox("There's no such book issue details", MsgBoxStyle.Exclamation)
        End If


        Try
            'If remarks from db contains 'Returned' and remarks from cbo does not contain
            If strRemarksFromDb.Contains("returned") And Not strRemarksFromCbo.Contains("returned") Then
                'cboViewRemarks.Text.ToLower.Contains("borrowed") Or cboViewRemarks.Text.ToLower.Contains("lost") Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you really want to update book issue details with date and time :" & dtpViewIssueDate.Value.ToShortDateString & " | " & dtpViewIssueTime.Value.ToLongTimeString.ToString & _
                                         " of book: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") ?")
                objStringBuilder.AppendLine(String.Empty)
                'objStringBuilder.AppendLine("Do you really want to update book issue: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'Raise a YesNo questionLecturerId
                If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text
                    Dim strCommand As String = "UPDATE LecturerBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "ReturnDate=Null, " & _
                                         "ReturnTime=Null, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND LecturerId=@lecturerId " & _
                                        "AND IssueDate=@issueDateOriginal; " & _
                                         "UPDATE BOOK " & _
                                         "SET AvailableQuantity= (AvailableQuantity-1) " & _
                                         "WHERE BookId = @bookId; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    'objCommand.Parameters.AddWithValue("@bookId", txt)
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@lecturerId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 2 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                                              "WHERE Lecturer.LecturerId = '" & strId & "' " & _
                                                         "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")
                        'Change boolean variable
                        blnIsStudent = False


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If

                'If db  remarks is not 'Returned' and combo remarks is 'Returned'
            ElseIf Not strRemarksFromDb.Contains("returned") And strRemarksFromCbo.Contains("returned") Then
                'cboViewRemarks.Text.ToLower.Contains("returned") Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                objStringBuilder.AppendLine(String.Empty)

                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text
                    Dim strCommand As String = "UPDATE LecturerBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "ReturnDate=@returnDate, " & _
                                         "ReturnTime=@returnTime, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND LecturerId=@lecturerId " & _
                                         "AND IssueDate=@issueDateOriginal; " & _
                                         "UPDATE BOOK " & _
                                         "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                         "WHERE BookId = @bookId; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@returnDate", dtpViewReturnDate.Value)
                    objCommand.Parameters.AddWithValue("@returnTime", dtpViewReturnTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@lecturerId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 2 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                                              "WHERE Lecturer.LecturerId = '" & strId & "' " & _
                                                         "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")
                        'Change boolean variable
                        blnIsStudent = False


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If

                'If both db and combo remarks are 'Returned'
            ElseIf strRemarksFromDb.Contains("returned") And strRemarksFromCbo.Contains("returned") Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                objStringBuilder.AppendLine(String.Empty)

                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text
                    Dim strCommand As String = "UPDATE LecturerBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "ReturnDate=@returnDate, " & _
                                         "ReturnTime=@returnTime, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND LecturerId=@lecturerId " & _
                                        "AND IssueDate=@issueDateOriginal; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@returnDate", dtpViewReturnDate.Value)
                    objCommand.Parameters.AddWithValue("@returnTime", dtpViewReturnTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@lecturerId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 1 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                                              "WHERE Lecturer.LecturerId = '" & strId & "' " & _
                                                         "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")
                        'Change boolean variable
                        blnIsStudent = False


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If
                'If both Remarks from db and combobox are not 'Returned'
            ElseIf Not strRemarksFromDb.Contains("returned") And Not strRemarksFromCbo.Contains("returned") Then
                'cboViewRemarks.Text.ToLower.Contains("borrowed") Or cboViewRemarks.Text.ToLower.Contains("lost") Then
                Dim objStringBuilder4 As New System.Text.StringBuilder
                objStringBuilder4.AppendLine("Do you really want to update book issue details with date and time :" & dtpViewIssueDate.Value.ToShortDateString & " | " & dtpViewIssueTime.Value.ToLongTimeString.ToString & _
                                         " of book: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") ?")
                objStringBuilder4.AppendLine(String.Empty)
                'objStringBuilder.AppendLine("Do you really want to update book issue: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
                'Raise a YesNo question
                If MessageBox.Show(objStringBuilder4.ToString, "Book-Issue Details", _
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                    'Create a sql query text
                    Dim strCommand As String = "UPDATE LecturerBookIssue " & _
                                         "SET IssueDate= @issueDate, " & _
                                         "IssueTime=@issueTime, " & _
                                         "Remarks=@remarks " & _
                                         "WHERE BookId=@bookId " & _
                                         "AND LecturerId=@lecturerId " & _
                                        "AND IssueDate=@issueDateOriginal; "

                    'Create a new sql command
                    Dim objCommand As New SqlCommand
                    objCommand.CommandText = strCommand

                    'Add parameters
                    'objCommand.Parameters.AddWithValue("@bookId", txt)
                    objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                    objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                    objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                    objCommand.Parameters.AddWithValue("@bookId", intBookId)
                    objCommand.Parameters.AddWithValue("@lecturerId", strId)
                    objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 1 Then
                        'Show successfully update message
                        MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                        'Clear existing records from the dataset
                        If dataAccess.objDataSet IsNot Nothing Then
                            dataAccess.objDataSet.Clear()
                        End If

                        dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                                              "WHERE Lecturer.LecturerId = '" & strId & "' " & _
                                                         "AND Book.BookId= " & intBookId & " " & _
                                                              "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")
                        'Change boolean variable
                        blnIsStudent = False


                        'Call procedure FillDataGridView to fill
                        FillDataGridView()
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtViewId.Enabled = True
        txtViewName.Enabled = True
        txtViewIsbn.Enabled = True
        txtViewTitle.Enabled = True
        txtViewAuthor.Enabled = True
        dtpViewIssueDate.Enabled = True
        dtpViewIssueTime.Enabled = True
        dtpViewReturnDate.Enabled = True
        dtpViewReturnTime.Enabled = True
        cboViewRemarks.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtViewId.Enabled = False
        txtViewName.Enabled = False
        txtViewIsbn.Enabled = False
        txtViewTitle.Enabled = False
        txtViewAuthor.Enabled = False
        dtpViewIssueDate.Enabled = False
        dtpViewIssueTime.Enabled = False
        dtpViewReturnDate.Enabled = False
        dtpViewReturnTime.Enabled = False
        cboViewRemarks.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub


    'CLEAR TEXT FIELD AND SET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtViewId.Clear()
        txtViewName.Clear()
        txtViewIsbn.Clear()
        txtViewTitle.Clear()
        txtViewAuthor.Clear()
        dtpViewIssueDate.Value = Now
        dtpViewIssueTime.Value = Now
        dtpViewReturnDate.Value = Now
        dtpViewReturnTime.Value = Now
        cboViewRemarks.Text = ""
    End Sub


    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If blnIsStudent = True Then
            'Call procedure to delete student issue details
            DeleteStudentBookIssue()
        Else
            'Call procedure to delete lecturer issue details
            DeleteLecturerBookIssue()
        End If

        'List the number of rows in the result
        lblResult.Text = grdBookIssue.RowCount
    End Sub

    'DELETE STUDENT BOOK ISSUE DETAILS
    Private Sub DeleteStudentBookIssue()
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you really want to delete following book issue details? ")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Student id :" & strId)
        objStringBuilder.AppendLine("Name :" & txtViewName.Text)
        objStringBuilder.AppendLine("Book: " & txtViewTitle.Text & " |" & txtViewIsbn.Text & "|")
        objStringBuilder.AppendLine("Issue-Date: " & issueDate)
        If MessageBox.Show(objStringBuilder.ToString, "Book-issue details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                       = DialogResult.Yes Then

            'Create a sql query text
            Dim strCommand As String = "DELETE FROM StudentBookIssue " & _
                                 "WHERE BookId=@bookId " & _
                                 "AND StudentId=@studentId " & _
                                "AND IssueDate=@issueDateOriginal; "

            'Create a new sql command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add parameters
            objCommand.Parameters.AddWithValue("@bookId", intBookId)
            objCommand.Parameters.AddWithValue("@studentId", strId)
            objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


            'Call RunQuery Method to update the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                If Not strRemarksValue.Contains("returned") Then
                    'Create a sql query text
                    Dim strCommandText As String = "UPDATE BOOK " & _
                                         "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                         "WHERE BookId = @bookId; "

                    'Create a new sql command
                    Dim objNewCommand As New SqlCommand
                    objNewCommand.CommandText = strCommandText

                    'Add parameters
                    objNewCommand.Parameters.AddWithValue("@bookId", intBookId)

                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objNewCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 1 Then
                        'Show successfully update message
                        MsgBox("Book-Issue details of student id :" & strId & " details has been successfully deleted.", MsgBoxStyle.Information, "Book-Issue Details")

                        'Remove the record from the gridview
                        grdBookIssue.Rows.RemoveAt(rowNumber)

                        'Disable the GetReport button
                        btnGetReport.Enabled = False
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with student id :" & strId & " having details Book: " & txtViewTitle.Text & _
                                   "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")
                    End If
                Else
                    'Show successfully update message
                    MsgBox("Book-Issue details of student id :" & strId & " details has been successfully deleted.", MsgBoxStyle.Information, "Book-Issue Details")

                    'Remove the record from the gridview
                    grdBookIssue.Rows.RemoveAt(rowNumber)
                End If
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show error message
                MsgBox("There's no book with student id :" & strId & " having details Book: " & txtViewTitle.Text & _
                           "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")

                'Refresh the datagridview
                GetBookIssuedList()
            End If


        End If
    End Sub

    'DELETE LECTURER BOOK ISSUE DETAILS
    Private Sub DeleteLecturerBookIssue()
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you really want to delete following book issue details? ")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Lecturer id :" & strId)
        objStringBuilder.AppendLine("Name :" & txtViewName.Text)
        objStringBuilder.AppendLine("Book: " & txtViewTitle.Text & " |" & txtViewIsbn.Text & "|")
        objStringBuilder.AppendLine("Issue-Date: " & issueDate)
        If MessageBox.Show(objStringBuilder.ToString, "Book-issue details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                       = DialogResult.Yes Then

            'Create a sql query text
            Dim strCommand As String = "DELETE FROM LecturerBookIssue " & _
                                 "WHERE BookId=@bookId " & _
                                 "AND LecturerId = @lecturerId " & _
                                "AND IssueDate=@issueDateOriginal; "

            'Create a new sql command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add parameters
            objCommand.Parameters.AddWithValue("@bookId", intBookId)
            objCommand.Parameters.AddWithValue("@lecturerId", strId)
            objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


            'Call RunQuery Method to update the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                If Not strRemarksValue.Contains("returned") Then
                    'Create a sql query text
                    Dim strCommandText As String = "UPDATE BOOK " & _
                                         "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                         "WHERE BookId = @bookId; "

                    'Create a new sql command
                    Dim objNewCommand As New SqlCommand
                    objNewCommand.CommandText = strCommandText

                    'Add parameters
                    objNewCommand.Parameters.AddWithValue("@bookId", intBookId)

                    'Call RunQuery Method to update the selected user
                    dataAccess.RunQuery(objNewCommand)

                    'Check for errors
                    If dataAccess.strExceptionRunQuery <> "" Then
                        'Show error message
                        MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                        'Set the variable to nothing
                        dataAccess.strExceptionRunQuery = Nothing
                    ElseIf dataAccess.intCountRecord = 1 Then
                        'Show successfully update message
                        MsgBox("Book-Issue details of lecturer id :" & strId & " details has been successfully deleted.", MsgBoxStyle.Information, "Book-Issue Details")

                        'Remove the record from the gridview
                        grdBookIssue.Rows.RemoveAt(rowNumber)

                        'Disable the GetReport button
                        btnGetReport.Enabled = False
                    ElseIf dataAccess.intCountRecord = 0 Then
                        'Show error message
                        MsgBox("There's no book with student id :" & strId & " having details Book: " & txtViewTitle.Text & _
                                   "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")
                    End If
                Else
                    'Show successfully update message
                    MsgBox("Book-Issue details of lecturer id :" & strId & " details has been successfully deleted.", MsgBoxStyle.Information, "Book-Issue Details")

                    'Remove the record from the gridview
                    grdBookIssue.Rows.RemoveAt(rowNumber)
                End If

            ElseIf dataAccess.intCountRecord = 0 Then
                'Show error message
                MsgBox("There's no book with lecturer id :" & strId & " having details Book: " & txtViewTitle.Text & _
                           "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")

                'Refresh the datagridview
                GetBookIssuedList()
            End If

            'Refresh the datagridview
            'GetBookIssuedList()
        End If
    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckIssueAndReturnDate() As Boolean
        If dtpViewIssueDate.Value <= dtpViewReturnDate.Value Then
            Return True
        Else
            MessageBox.Show("The issue date must be smaller than return date.", "Book-Issue Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "IssueView"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub
End Class
