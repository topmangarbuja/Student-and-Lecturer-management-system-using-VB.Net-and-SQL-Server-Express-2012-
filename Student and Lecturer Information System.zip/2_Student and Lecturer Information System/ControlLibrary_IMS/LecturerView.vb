﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class LecturerView
    'Form-level variables
    Private dataAccess As New DataAccess
    Dim strLecturerId As String
    Dim strLecturerName As String
    Dim dtLecturerList As DataTable
    Dim rowNumber As Int16

    Dim objCommand As SqlCommand
    Dim dtCountryUpdate As New DataTable

    'CLEAR TEXT FIELDSSET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtLecturerId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        dtpDateOfBirth.Value = Now
        cboGender.Text = ""
        txtDistrict.Clear()
        txtWardNo.Clear()
        txtPlace.Clear()
        cboEditCountry.Text = ""
        txtCitizenshipNo.Clear()
        txtEditPassportNo.Clear()
        cboStatus.Text = ""

    End Sub

    'FORM LOAD EVENT
    Private Sub LecturerView_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'CELL CLICK EVENT OF DATAGRIDVIEW CONTROL 
    Private Sub grdLecturer_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdLecturer.CellClick
        rowNumber = grdLecturer.CurrentCell.RowIndex


        'First clear the text fields
        ClearFields()

        'Enable the controls of the datagridview sections
        EnableControls()

        'Get list of country
        GetCountryUpdate()

        For i As Integer = 0 To grdLecturer.ColumnCount - 1
            Try
                Select Case i

                    Case 0

                        'Get id and name
                        strLecturerId = grdLecturer.Item(0, e.RowIndex).Value
                        'Get values for the textboxes and combobox
                        txtLecturerId.Text = grdLecturer.Item(0, e.RowIndex).Value

                    Case 1
                        strLecturerName = grdLecturer.Item(1, e.RowIndex).Value & " " & grdLecturer.Item(2, e.RowIndex).Value
                        txtFirstName.Text = grdLecturer.Item(1, e.RowIndex).Value

                    Case 2
                        txtLastName.Text = grdLecturer.Item(2, e.RowIndex).Value

                    Case 3
                        dtpDateOfBirth.Value = grdLecturer.Item(3, e.RowIndex).Value

                    Case 4
                        If grdLecturer.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("female") Then
                            cboGender.SelectedIndex = 1
                        ElseIf grdLecturer.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("male") Then
                            cboGender.SelectedIndex = 0
                        ElseIf grdLecturer.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("other") Then
                            cboGender.SelectedIndex = 2
                        End If

                    Case 5
                        txtDistrict.Text = grdLecturer.Item(5, e.RowIndex).Value

                    Case 6
                        txtWardNo.Text = grdLecturer.Item(6, e.RowIndex).Value

                    Case 7
                        txtPlace.Text = grdLecturer.Item(7, e.RowIndex).Value

                    Case 8
                        cboEditCountry.Text = grdLecturer.Item(8, e.RowIndex).Value

                    Case 9
                        txtCitizenshipNo.Text = grdLecturer.Item(9, e.RowIndex).Value

                    Case 10
                        txtEditPassportNo.Text = grdLecturer.Item(10, e.RowIndex).Value
                    Case 11
                        If grdLecturer.Item(11, e.RowIndex).Value.ToString.ToLower.StartsWith("active") Then
                            cboStatus.SelectedIndex = 0
                        ElseIf grdLecturer.Item(11, e.RowIndex).Value.ToString.ToLower.StartsWith("inactive") Then
                            cboStatus.SelectedIndex = 1
                        End If
                End Select
            Catch ex As Exception

            End Try
        Next

        'Make sure that the Update button is disabled
        btnUpdate.Enabled = False
    End Sub

    'CLICK EVENT OF UDPATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Call procedure to check whether there is data or not
        If CheckFirstNameLastName() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details?", "Lecturer Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE LECTURER " & _
                                     "SET LecturerId=@lecturerId, " & _
                                     "FirstName= @firstName, " & _
                                     "LastName=@lastName, " & _
                                     "DateOfBirth=@dob, " & _
                                     "Gender=@gender, " & _
                                     "District=@district, " & _
                                     "WardNo=@wardNo, " & _
                                     "Place=@place, " & _
                                     "Country=@country, " & _
                                     "CitizenshipNo=@citizenshipNo, " & _
                                     "PassportNo=@passportNo, " & _
                                     "Status=@status " & _
                                     "WHERE LecturerId=@originalLecturerId;"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@lecturerId", txtLecturerId.Text)
                objCommand.Parameters.AddWithValue("@firstName", txtFirstName.Text)
                objCommand.Parameters.AddWithValue("@lastName", txtLastName.Text)
                objCommand.Parameters.AddWithValue("@dob", dtpDateOfBirth.Value.Date)
                objCommand.Parameters.AddWithValue("@gender", cboGender.Text)
                objCommand.Parameters.AddWithValue("@district", txtDistrict.Text)
                objCommand.Parameters.AddWithValue("@wardNo", txtWardNo.Text)
                objCommand.Parameters.AddWithValue("@place", txtPlace.Text)
                objCommand.Parameters.AddWithValue("@country", cboEditCountry.Text)
                objCommand.Parameters.AddWithValue("@citizenshipNo", txtCitizenshipNo.Text)
                objCommand.Parameters.AddWithValue("@passportNo", txtEditPassportNo.Text)
                objCommand.Parameters.AddWithValue("@status", cboStatus.Text)
                objCommand.Parameters.AddWithValue("@originalLecturerId", strLecturerId)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Lecturer Details")

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing

                    'Call ClearFields method to clear the text
                    ClearFields()

                    'Call DisableControl method to disable controls
                    DisabledControls()
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details has been successfully updated.", MsgBoxStyle.Information, "Lecturer Details")

                    'Call btnView_Click procedure
                    'btnViewAll_Click(Nothing, Nothing)

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    'Get list of name and id and phone
                    dataAccess.RunQueryAndFillDataSet("SELECT * " & _
                        "FROM Lecturer " & _
                        "WHERE LecturerId='" & txtLecturerId.Text & "';")

                    'Fill the datagridview
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no lecturer with details: |" & strLecturerId & "| (" & strLecturerName & ").", MsgBoxStyle.Exclamation, "Lecturer Details")

                    'Call btnView_Click procedure
                    btnViewAll_Click(Nothing, Nothing)
                End If


                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            End If
        End If
    End Sub

    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete Lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details?", "Lecturer Details", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM LECTURER " & _
                                 "WHERE LecturerId= @lecturerId"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@lecturerId", strLecturerId)

            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Lecturer Details")

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("Lecturer: |" & strLecturerId & "| (" & strLecturerName & ") details has been successfully deleted.", MsgBoxStyle.Information, "Lecturer Details")

                'Call btnFilterView_Click procedure
                'btnViewAll_Click(Nothing, Nothing)

                'Remove a row from the GridView
                grdLecturer.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdLecturer.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no lecturer with details: |" & strLecturerId & "| (" & strLecturerName & ").", MsgBoxStyle.Exclamation, "Lecturer Details")

                'Call btnView_Click procedure
                btnViewAll_Click(Nothing, Nothing)
            End If


            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub

    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtLecturerId.Enabled = True
        txtFirstName.Enabled = True
        txtLastName.Enabled = True
        dtpDateOfBirth.Enabled = True
        cboGender.Enabled = True
        txtDistrict.Enabled = True
        txtWardNo.Enabled = True
        txtPlace.Enabled = True
        cboEditCountry.Enabled = True
        txtCitizenshipNo.Enabled = True
        txtEditPassportNo.Enabled = True
        cboStatus.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtLecturerId.Enabled = False
        txtFirstName.Enabled = False
        txtLastName.Enabled = False
        dtpDateOfBirth.Enabled = False
        cboGender.Enabled = False
        txtDistrict.Enabled = False
        txtWardNo.Enabled = False
        txtPlace.Enabled = False
        cboEditCountry.Enabled = False
        txtCitizenshipNo.Enabled = False
        txtEditPassportNo.Enabled = False
        cboStatus.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtLecturerId.TextChanged, txtFirstName.TextChanged, txtLastName.TextChanged, dtpDateOfBirth.ValueChanged, cboGender.SelectedIndexChanged, _
        txtDistrict.TextChanged, txtWardNo.TextChanged, txtPlace.TextChanged, cboEditCountry.TextChanged, cboEditCountry.SelectedIndexChanged, txtCitizenshipNo.TextChanged, cboStatus.SelectedIndexChanged, txtEditPassportNo.TextChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    'METHOD: GET ALL THE LecturerS LIST
    Private Sub GetAllLecturerList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If


        'Get list of active or inactive or both Lecturers
        If rdbActive.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM LECTURER " & _
                                              "WHERE Status='Active' " & _
                                              "ORDER BY FirstName;")
        ElseIf rdbInactive.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM LECTURER " & _
                                              "WHERE Status='Inactive' " & _
                                              "ORDER BY FirstName;")
        ElseIf rdbBoth.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM LECTURER " & _
                                              "ORDER BY FirstName;")
        End If

        FillDataGridView()
    End Sub
    Private Sub FillDataGridView()

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdLecturer.DataSource = Nothing

            'Get the table data
            dtLecturerList = dataAccess.objDataSet.Tables(0)
            GblAccessItem.DataTableLecturerView = dataAccess.AutoNumberedTable(dtLecturerList)

            'Get the datasource for datagridview
            grdLecturer.DataSource = dtLecturerList

            'Make DataGridView ReadOnly property to true
            grdLecturer.ReadOnly = True

            If grdLecturer.RowCount > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = dtLecturerList.Rows.Count


            grdLecturer.Columns(0).Frozen = True
        End If
    End Sub

    'CLICK EVENT OF VIEWALL BUTTON
    Private Sub btnViewAll_Click(sender As Object, e As EventArgs) Handles btnViewAll.Click
        'Call procedure to get all Lecturers
        GetAllLecturerList()

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckFirstNameLastName() As Boolean
        If txtFirstName.Text.Trim.Length > 0 And txtLastName.Text.Trim.Length > 0 Then
            Return True
        ElseIf txtFirstName.Text.Trim.Length <= 0 And txtLastName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter first name and last name.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtFirstName.Text.Trim.Length <= 0 And txtLastName.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter first name.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False

        Else
            MessageBox.Show("You have to enter last name.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim form As New FormReport
        form.strReport = "LecturerView"
        form.WindowState = FormWindowState.Maximized
        form.ShowDialog()
    End Sub


    Private Sub GetCountryUpdate()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Country FROM Lecturer; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Country List | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtCountryUpdate = dataAccess.dtListForComboBox
            cboEditCountry.DataSource = dtCountryUpdate
            cboEditCountry.DisplayMember = "Country"

            'If cboEditCategory.Text = "" Then

            'End If
        End If
    End Sub
End Class