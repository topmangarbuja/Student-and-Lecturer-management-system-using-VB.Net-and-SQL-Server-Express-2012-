﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class LecturerModuleSearch
    Private dataAccess As New DataAccess
    Dim intYear As Integer
    Dim intViewYear As Integer
    Dim dtLecturerModuleList As DataTable

    'Variable used for the datagridview section
    Dim strLecturerId As String
    Dim strModuleCode As String
    Dim dtStartDate As Date
    Dim dtModuleList As DataTable
    Dim blnLoadCboData As Boolean

    Private objCommand As SqlCommand
    Private objDataAdapter As SqlDataAdapter
    Private objDataSet As DataSet
    Public strExceptionRunQueryAndFillDataSet As String

    Dim rowNumber As Int16


    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If
    End Sub

    'SELECTEDINDEXCHANGED EVENT OF FACULTY COMBOBOX
    Private Sub cboFaculty_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFaculty.SelectedIndexChanged

    End Sub

    'FORM LOAD EVENT
    Private Sub LecturerModuleSearch_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Select the first item in the Year combobox
        cboYear.SelectedIndex = 0
        cboSelectViewYear.SelectedIndex = 0

        'Select the last item in the Semester combobox
        cboSemester.SelectedIndex = 4
        cboSelectViewSemester.SelectedIndex = 4

        'Clear fields of the View sections
        ClearFields()

        'Disable the controls of the View sections
        DisabledControls()
    End Sub

    Private Sub GetYear()
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select
    End Sub

    'METHOD:FILL DATAGRIDVIEW CONTROL
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            'grdLecturerModule.DataSource = Nothing

            'Get the datasource for datagridview
            dtLecturerModuleList = dataAccess.objDataSet.Tables(0)
            GblAccessItem.DataTableLecturerModule = dataAccess.AutoNumberedTable(dtLecturerModuleList)

            grdLecturerModule.DataSource = dtLecturerModuleList

            If grdLecturerModule.RowCount > 0 Then
                'Enable the Get Report button
                btnGetReport.Enabled = True
            Else
                'Disable the Get Report button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = grdLecturerModule.RowCount

            grdLecturerModule.Columns(0).Frozen = True
        End If

        'Call procedure:make sure that the View sections control are disabled
        DisabledControls()
    End Sub

    'METHOD: CLEAR THE SEARCHING FIELDS
    Private Sub ClearSearchingFields()
        'Clear other textboxes
        txtLecturerId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtModuleCode.Clear()
        txtModuleName.Clear()
    End Sub

    Private Sub txtLecturerId_Enter(sender As Object, e As EventArgs) Handles txtLecturerId.Enter, txtFirstName.Enter, txtLastName.Enter, txtModuleCode.Enter, txtModuleName.Enter
        'Clear the searching fields
        ClearSearchingFields()

        If grdLecturerModule.RowCount > 0 Then
            'Enable the Get Report button
            btnGetReport.Enabled = True
        Else
            'Disable the Get Report button
            btnGetReport.Enabled = False
        End If
    End Sub

    Private Sub txtLecturerId_TextChanged(sender As Object, e As EventArgs) Handles txtLecturerId.TextChanged
        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to know year value
        GetYear()

        If cboSemester.SelectedIndex <> 4 Then
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty,Year " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                "WHERE Lecturer.LecturerId LIKE '%" & txtLecturerId.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "' " & _
               "AND Semester=" & cboSemester.Text & "; ")
        Else
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                "WHERE Lecturer.LecturerId LIKE '%" & txtLecturerId.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "'; ")

        End If



        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub

    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged
        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to know year value
        GetYear()

        If cboSemester.SelectedIndex <> 4 Then
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
               "WHERE FirstName LIKE '%" & txtFirstName.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "' " & _
               "AND Semester=" & cboSemester.Text & ";")
        Else
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                "WHERE FirstName LIKE '%" & txtFirstName.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "';")
        End If



        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub

    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged
        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to know year value
        GetYear()

        If cboSemester.SelectedIndex <> 4 Then
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
               "WHERE LastName LIKE '%" & txtLastName.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "' " & _
               "AND Semester=" & cboSemester.Text & ";")
        Else
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                "WHERE LastName LIKE '%" & txtLastName.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "';")
        End If



        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub

    Private Sub txtModuleCode_TextChanged(sender As Object, e As EventArgs) Handles txtModuleCode.TextChanged
        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to know year value
        GetYear()

        If cboSemester.SelectedIndex <> 4 Then
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
               "WHERE Module.ModuleCode LIKE '%" & txtModuleCode.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "' " & _
               "AND Semester=" & cboSemester.Text & ";")
        Else
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
              "WHERE Module.ModuleCode LIKE '%" & txtModuleCode.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "';")
        End If



        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub

    Private Sub txtModuleName_TextChanged(sender As Object, e As EventArgs) Handles txtModuleName.TextChanged
        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to know year value
        GetYear()

        If cboSemester.SelectedIndex <> 4 Then
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
               "WHERE Name LIKE '%" & txtModuleName.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "' " & _
               "AND Semester=" & cboSemester.Text & ";")
        Else
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
              "WHERE Name LIKE '%" & txtModuleName.Text & "%' " & _
                "AND Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "';")
        End If



        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub

    Private Sub grdLecturerModule_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdLecturerModule.CellClick
        If grpEdit.Visible = True Then
            rowNumber = grdLecturerModule.CurrentCell.RowIndex

            'Clear the fields of the Edit sections
            ClearFields()

            'Enable the controls of the view sections
            EnableControls()

            Dim faculty As String
            For i As Integer = 0 To grdLecturerModule.ColumnCount - 1
                Try
                    Select Case i
                        Case 0
                            strLecturerId = grdLecturerModule.Item(0, e.RowIndex).Value
                            txtViewLecturerId.Text = strLecturerId
                        Case 1
                            txtViewName.Text = grdLecturerModule.Item(1, e.RowIndex).Value
                        Case 2
                            Dim intSemester As Integer = grdLecturerModule.Item(2, e.RowIndex).Value

                            If intSemester = 1 Then
                                cboViewSemester.SelectedIndex = 0
                            ElseIf intSemester = 2 Then
                                cboViewSemester.SelectedIndex = 1
                            ElseIf intSemester = 3 Then
                                cboViewSemester.SelectedIndex = 2
                            ElseIf intSemester = 4 Then
                                cboViewSemester.SelectedIndex = 3
                            End If
                        Case 3
                            strModuleCode = grdLecturerModule.Item(3, e.RowIndex).Value
                            cboViewModuleCode.Text = strModuleCode

                        Case 4
                            txtViewModuleName.Text = grdLecturerModule.Item(4, e.RowIndex).Value

                        Case 5
                            dtStartDate = grdLecturerModule.Item(5, e.RowIndex).Value
                            dtpViewStartDate.Value = dtStartDate
                        Case 6
                            faculty = grdLecturerModule.Item(6, e.RowIndex).Value.ToString
                            GetModuleCodeAndName(faculty)
                            cboViewModuleCode.Text = strModuleCode
                        Case 7
                            intViewYear = grdLecturerModule.Item(7, e.RowIndex).Value
                            txtViewYear.Text = faculty + " -- " + intViewYear.ToString

                    End Select
                Catch ex As Exception

                End Try
            Next

            'Make sure that the update button is disabled
            btnUpdate.Enabled = False
        End If
    End Sub


    'METHOD: GET MODULE CODE AND NAME
    Private Sub GetModuleCodeAndName(faculty As String)
        'Clear existing dataset records
        If objDataSet IsNot Nothing Then
            objDataSet.Clear()
        End If

        'Call method to get list of name and code
        RunQueryAndFillDataSet("SELECT ModuleCode, Name " & _
            "FROM Module " & _
            "WHERE Year=" & intViewYear & _
            " AND Faculty='" & faculty & "';")

        'Check for errors
        If strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MessageBox.Show(strExceptionRunQueryAndFillDataSet, "Retrieving Module code and name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Get the table data
            dtModuleList = objDataSet.Tables(0)

            cboViewModuleCode.DataSource = dtModuleList
            cboViewModuleCode.DisplayMember = "ModuleCode"
        End If
    End Sub

    Private Sub RunQueryAndFillDataSet(query As String)
        Dim objConnection As New SqlConnection
        objConnection = dataAccess.objConnection

        Try
            'Open the connection
            objConnection.Open()

            'Create a command
            objCommand = New SqlCommand(query, objConnection)

            'Fill dataset
            objDataAdapter = New SqlDataAdapter(objCommand)
            objDataSet = New DataSet
            objDataAdapter.Fill(objDataSet)

            'Execute the query
            'objCommand.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionRunQueryAndFillDataSet = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    Private Sub cboViewModuleCode_Click(sender As Object, e As EventArgs) Handles cboViewModuleCode.Click
        'If blnLoadCboData = False Then
        '    'GetModuleCodeAndName()

        '    cboViewModuleCode.Text = strModuleCode

        '    blnLoadCboData = True
        'Else
        '    'blnloadc()
        'End If

    End Sub

    'SELECTEDINDEXCHANGED EVENT OF MODULECODE COMBOBOX
    Private Sub cboViewModuleCode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboViewModuleCode.SelectedIndexChanged
        'Clear any previous bindings..
        txtViewModuleName.DataBindings.Clear()

        'Binding process
        txtViewModuleName.DataBindings.Add("Text", dtModuleList, "Name")
    End Sub


    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtViewLecturerId.Enabled = True
        txtViewName.Enabled = True
        txtViewYear.Enabled = True
        cboViewSemester.Enabled = True
        dtpViewStartDate.Enabled = True
        cboViewModuleCode.Enabled = True
        txtViewModuleName.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtViewLecturerId.Enabled = False
        txtViewName.Enabled = False
        txtViewYear.Enabled = False
        cboViewSemester.Enabled = False
        dtpViewStartDate.Enabled = False
        cboViewModuleCode.Enabled = False
        txtViewModuleName.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub


    'CLEAR TEXT FIELD AND SET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtViewLecturerId.Clear()
        txtViewName.Clear()
        txtViewYear.Clear()
        cboViewSemester.SelectedIndex = 0
        dtpViewStartDate.Value = Now
        cboViewModuleCode.Text = ""
        txtViewModuleName.Clear()
    End Sub

    Private Sub SelectedIndexAndValueChanged(sender As Object, e As EventArgs) Handles cboViewSemester.SelectedIndexChanged, dtpViewStartDate.ValueChanged, cboViewModuleCode.SelectedIndexChanged
        If sender Is cboViewModuleCode Then
            If cboViewModuleCode.Text <> strModuleCode Then
                'Enable the button
                btnUpdate.Enabled = True
            End If
        Else
            'Enable the button
            btnUpdate.Enabled = True
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If cboViewModuleCode.Text.Trim.Length > 0 Then

            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you really want to update module details of the following lecturer?")
            objStringBuilder.AppendLine("Lecturer-Info: " & txtViewLecturerId.Text & " | " & txtViewName.Text)
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Module-Info: " & cboViewModuleCode.Text & " | " & txtViewModuleName.Text)
            objStringBuilder.AppendLine("Start-Date: " & dtpViewStartDate.Value.ToLongDateString)
            objStringBuilder.AppendLine("Semester: " & cboViewSemester.Text)

            'Raise a YesNo question
            If MessageBox.Show(objStringBuilder.ToString, "Lecturer Module Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then



                objCommand = New SqlCommand
                objCommand.CommandText = "UPDATE LecturerModule " & _
                    "SET ModuleCode=@moduleCode, " & _
                    "StartDate=@startDate, " & _
                    "Semester=@semester " & _
                    "WHERE LecturerId=@previousLecturerId " & _
                    "AND ModuleCode=@previousModuleCode " & _
                    "AND StartDate=@previousStartDate;"

                'Add parameters for the placeholder in the SQL CommandText property..
                objCommand.Parameters.AddWithValue("@semester", cboViewSemester.Text)
                objCommand.Parameters.AddWithValue("@moduleCode", cboViewModuleCode.Text)
                objCommand.Parameters.AddWithValue("@startDate", dtpViewStartDate.Value.Date)
                objCommand.Parameters.AddWithValue("@previousLecturerId", strLecturerId)
                objCommand.Parameters.AddWithValue("@previousModuleCode", strModuleCode)
                objCommand.Parameters.AddWithValue("@previousStartDate", dtStartDate)

                'Call RunQuery method to add selected module for the Lecturer
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    If dataAccess.strExceptionRunQuery = "This data already exists!" Then
                        'Show error message
                        MessageBox.Show("The lecturer has already take this module at the same date.", "Update Student Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    ElseIf dataAccess.strExceptionRunQuery = "This data doesnot exist!" Then
                        'Show error message
                        MessageBox.Show("There's no such module. Please select from the list.", "Update Lecturer Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Else
                        'Show error message
                        MessageBox.Show(dataAccess.strExceptionRunQuery, "Update Lecturer Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If


                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing

                    'Refresh datagridview
                    'GetLecturerIdAndModuleCode()
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show message box
                    MessageBox.Show("The modification that you have made is successfully saved.", "Lecturer Module Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    'Clear existing dataset records
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    'Get list of name and id and module
                    dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty,Year " & _
                        "FROM Lecturer " & _
                        "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                        "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                    "WHERE Lecturer.LecturerId = '" & strLecturerId & "' " & _
                    "AND Module.ModuleCode='" & cboViewModuleCode.Text & "' " & _
                   "AND StartDate='" & dtpViewStartDate.Value.Date & "' ")

                    'Call procedure FillDataGridView to fill
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error add message
                    MsgBox("There's no lecturer with details: |" & strLecturerId & "| (" & txtViewName.Text & ") and their corresponding module details.", MsgBoxStyle.Exclamation, "Lecturer Module Details")
                End If
            End If

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        Else
            'Clear modulename text
            txtViewModuleName.Clear()

            'Show error message
            MsgBox("Please select a module", MsgBoxStyle.Exclamation, "Update Lecturer Module")
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you really want to delete module details of the following Lecturer?")
        objStringBuilder.AppendLine("Lecturer-Info: " & txtViewLecturerId.Text & " | " & txtViewName.Text)
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Module-Info: " & cboViewModuleCode.Text & " | " & txtViewModuleName.Text)
        objStringBuilder.AppendLine("Start-Date: " & dtpViewStartDate.Value.ToLongDateString)
        objStringBuilder.AppendLine("Semester: " & cboViewSemester.Text)

        'Raise a YesNo question
        If MessageBox.Show(objStringBuilder.ToString, "Lecturer Module Details", _
                          MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then



            objCommand = New SqlCommand
            objCommand.CommandText = "DELETE FROM LecturerModule " & _
                "WHERE LecturerId=@lecturerId " & _
                "AND ModuleCode=@moduleCode " & _
                "AND StartDate=@startDate"

            'Add parameters for the placeholder in the SQL CommandText property..
            objCommand.Parameters.AddWithValue("@lecturerId", strLecturerId)
            objCommand.Parameters.AddWithValue("@moduleCode", strModuleCode)
            objCommand.Parameters.AddWithValue("@startDate", dtStartDate)


            'Call RunQuery method to add selected module for the Lecturer
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionRunQuery, "Delete Lecturer Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show message box
                MessageBox.Show("The modification that you have made is successfully saved.", "Lecturer Module Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Remove a row from the gridview
                grdLecturerModule.Rows.RemoveAt(rowNumber)

                'Get the result 
                lblResult.Text = grdLecturerModule.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show error add message
                MsgBox("There's no lecturer with details: |" & strLecturerId & "| (" & txtViewName.Text & ") and their corresponding module details.", MsgBoxStyle.Exclamation, "Lecturer Module Details")
            End If
        End If

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "LecturerModule"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog(Me)
    End Sub

    Private Sub btnShowEditSection_Click(sender As Object, e As EventArgs) Handles btnShowEditSection.Click
        'Dim s As Point = pnlListOfStudent.Location
        If btnShowEditSection.Text = "Show Edit section" Then
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X - 235
            pnlListOfStudent.Location = p

            grpResult.Size = New Size(743, 342)


            Dim g As Point = grpResult.Location
            g.X = grpResult.Width + 20
            grpEdit.Location = g



            grpEdit.Visible = True
            lblDetails.Visible = True

            btnShowEditSection.Text = "Hide Edit section"
        Else
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X + 235
            pnlListOfStudent.Location = p


            grpResult.Size = New Size(1124, 342)


            grpEdit.Visible = False
            lblDetails.Visible = False

            btnShowEditSection.Text = "Show Edit section"

            'Disable the controls of the textboxes and buttons
            DisabledControls()
        End If

        'First clear the text fields
        ClearFields()
    End Sub

    Private Sub btnViewAllStudents_Click(sender As Object, e As EventArgs) Handles btnViewAllStudents.Click
        'Clear searching fields
        ClearSearchingFields()

        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to know year value
        GetYear()

        'Get list of name and id and module
        dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty, Year  " & _
            "FROM Lecturer " & _
            "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
            "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
            "ORDER BY Faculty, Name,Semester, [Module Name];")

        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub


    Private Sub btnFilterView_Click(sender As Object, e As EventArgs) Handles btnFilterView.Click
        'Clear existing dataset records
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If
        'Get year value for YEAR combobox
        Select Case cboSelectViewYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select


        If cboSelectViewSemester.SelectedIndex <> 4 Then
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty,Year " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                "WHERE Year = " & intYear & " " & _
                "AND Faculty='" & cboSelectFaculty.Text & "' " & _
                "AND Semester=" & cboSelectViewSemester.Text & " " & _
               "AND StartDate='" & dtpSelectViewStartDate.Value.Date & "';")
        Else
            'Get list of name and id and module
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date],Faculty,Year " & _
                "FROM Lecturer " & _
                "JOIN LecturerModule ON Lecturer.LecturerId=LecturerModule.LecturerId " & _
                "JOIN Module ON LecturerModule.ModuleCode=Module.ModuleCode " & _
                "WHERE Year = " & intYear & " " & _
                "AND Faculty='" & cboSelectFaculty.Text & "' " & _
                "AND StartDate='" & dtpSelectViewStartDate.Value.Date & "';")
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub

    Private Sub cboSelectViewYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSelectViewYear.SelectedIndexChanged
        If cboSelectViewYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboSelectFaculty.Items.Contains("FCHE") Then
                cboSelectFaculty.Items.Add("FCHE")
            End If
            cboSelectFaculty.SelectedIndex = cboSelectFaculty.Items.Count - 1
            cboSelectFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboSelectFaculty.Enabled = True
            cboSelectFaculty.Items.Remove("FCHE")
        End If
    End Sub
End Class