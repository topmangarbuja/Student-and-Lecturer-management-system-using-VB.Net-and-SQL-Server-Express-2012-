﻿Public Class TextBoxNumeric
    Inherits System.Windows.Forms.TextBox

    Protected Overrides Sub OnKeyPress(e As KeyPressEventArgs)
        MyBase.OnKeyPress(e)
        If Not Char.IsNumber(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) And Not e.KeyChar = Chr(Keys.Back) Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub
End Class