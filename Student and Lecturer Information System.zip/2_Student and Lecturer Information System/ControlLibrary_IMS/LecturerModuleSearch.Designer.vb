﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LecturerModuleSearch
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grdLecturerModule = New System.Windows.Forms.DataGridView()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.dtpViewStartDate = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtViewYear = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtViewLecturerId = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtViewName = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cboViewSemester = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtViewModuleName = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.cboViewModuleCode = New System.Windows.Forms.ComboBox()
        Me.grpResult = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnShowEditSection = New System.Windows.Forms.Button()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.btnViewAllStudents = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboFaculty = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtModuleCode = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtModuleName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtLecturerId = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboSemester = New System.Windows.Forms.ComboBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.dtpSelectViewStartDate = New System.Windows.Forms.DateTimePicker()
        Me.cboSelectViewYear = New System.Windows.Forms.ComboBox()
        Me.cboSelectFaculty = New System.Windows.Forms.ComboBox()
        Me.cboSelectViewSemester = New System.Windows.Forms.ComboBox()
        Me.btnFilterView = New System.Windows.Forms.Button()
        Me.pnlListOfStudent = New System.Windows.Forms.Panel()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        CType(Me.grdLecturerModule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpEdit.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.grpResult.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.pnlListOfStudent.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'grdLecturerModule
        '
        Me.grdLecturerModule.AllowUserToAddRows = False
        Me.grdLecturerModule.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdLecturerModule.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdLecturerModule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdLecturerModule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdLecturerModule.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdLecturerModule.Location = New System.Drawing.Point(0, 18)
        Me.grdLecturerModule.MultiSelect = False
        Me.grdLecturerModule.Name = "grdLecturerModule"
        Me.grdLecturerModule.ReadOnly = True
        Me.grdLecturerModule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdLecturerModule.Size = New System.Drawing.Size(1124, 278)
        Me.grdLecturerModule.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdLecturerModule, "Click 'Show Enable section' button to view the Edit section and select a record a" & _
        "nd get the data in the Details section.")
        '
        'grpEdit
        '
        Me.grpEdit.Controls.Add(Me.TableLayoutPanel2)
        Me.grpEdit.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpEdit.Location = New System.Drawing.Point(759, 231)
        Me.grpEdit.Margin = New System.Windows.Forms.Padding(4)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Padding = New System.Windows.Forms.Padding(4)
        Me.grpEdit.Size = New System.Drawing.Size(374, 339)
        Me.grpEdit.TabIndex = 63
        Me.grpEdit.TabStop = False
        Me.grpEdit.Visible = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.Panel1, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewStartDate, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label11, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewYear, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewLecturerId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label14, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewName, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label15, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.cboViewSemester, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label17, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewModuleName, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.cboViewModuleCode, 1, 5)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 8
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(366, 316)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnDelete)
        Me.Panel1.Controls.Add(Me.btnUpdate)
        Me.Panel1.Location = New System.Drawing.Point(107, 276)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(261, 35)
        Me.Panel1.TabIndex = 61
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(128, 4)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(2, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'dtpViewStartDate
        '
        Me.dtpViewStartDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewStartDate.Location = New System.Drawing.Point(107, 163)
        Me.dtpViewStartDate.Name = "dtpViewStartDate"
        Me.dtpViewStartDate.Size = New System.Drawing.Size(253, 25)
        Me.dtpViewStartDate.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.dtpViewStartDate, "Start date")
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(4, 167)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 17)
        Me.Label11.TabIndex = 61
        Me.Label11.Text = "Start date:"
        '
        'txtViewYear
        '
        Me.txtViewYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewYear.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewYear.Location = New System.Drawing.Point(108, 85)
        Me.txtViewYear.Margin = New System.Windows.Forms.Padding(4)
        Me.txtViewYear.Name = "txtViewYear"
        Me.txtViewYear.ReadOnly = True
        Me.txtViewYear.Size = New System.Drawing.Size(252, 25)
        Me.txtViewYear.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtViewYear, "Year")
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(4, 89)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(40, 17)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Year:"
        '
        'txtViewLecturerId
        '
        Me.txtViewLecturerId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewLecturerId.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewLecturerId.Location = New System.Drawing.Point(108, 7)
        Me.txtViewLecturerId.Margin = New System.Windows.Forms.Padding(4)
        Me.txtViewLecturerId.Name = "txtViewLecturerId"
        Me.txtViewLecturerId.ReadOnly = True
        Me.txtViewLecturerId.Size = New System.Drawing.Size(252, 25)
        Me.txtViewLecturerId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtViewLecturerId, "Lecturer Id")
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 11)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(82, 17)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Lecturer Id:"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 50)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(48, 17)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = "Name:"
        '
        'txtViewName
        '
        Me.txtViewName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewName.Location = New System.Drawing.Point(108, 46)
        Me.txtViewName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtViewName.Name = "txtViewName"
        Me.txtViewName.ReadOnly = True
        Me.txtViewName.Size = New System.Drawing.Size(252, 25)
        Me.txtViewName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtViewName, "Name")
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(4, 128)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 17)
        Me.Label15.TabIndex = 60
        Me.Label15.Text = "Semester:"
        '
        'cboViewSemester
        '
        Me.cboViewSemester.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboViewSemester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboViewSemester.FormattingEnabled = True
        Me.cboViewSemester.Items.AddRange(New Object() {"1", "2", "3", "4"})
        Me.cboViewSemester.Location = New System.Drawing.Point(107, 126)
        Me.cboViewSemester.Name = "cboViewSemester"
        Me.cboViewSemester.Size = New System.Drawing.Size(253, 25)
        Me.cboViewSemester.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.cboViewSemester, "Semester")
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 245)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(96, 17)
        Me.Label17.TabIndex = 62
        Me.Label17.Text = "Module name:"
        '
        'txtViewModuleName
        '
        Me.txtViewModuleName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewModuleName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewModuleName.Location = New System.Drawing.Point(108, 241)
        Me.txtViewModuleName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtViewModuleName.Name = "txtViewModuleName"
        Me.txtViewModuleName.ReadOnly = True
        Me.txtViewModuleName.Size = New System.Drawing.Size(252, 25)
        Me.txtViewModuleName.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtViewModuleName, "Module name")
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(4, 206)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(92, 17)
        Me.Label16.TabIndex = 60
        Me.Label16.Text = "Module code:"
        '
        'cboViewModuleCode
        '
        Me.cboViewModuleCode.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboViewModuleCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboViewModuleCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboViewModuleCode.FormattingEnabled = True
        Me.cboViewModuleCode.Location = New System.Drawing.Point(107, 204)
        Me.cboViewModuleCode.Name = "cboViewModuleCode"
        Me.cboViewModuleCode.Size = New System.Drawing.Size(253, 25)
        Me.cboViewModuleCode.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboViewModuleCode, "Module code")
        '
        'grpResult
        '
        Me.grpResult.BackColor = System.Drawing.Color.Transparent
        Me.grpResult.Controls.Add(Me.Panel2)
        Me.grpResult.Controls.Add(Me.grdLecturerModule)
        Me.grpResult.Location = New System.Drawing.Point(9, 228)
        Me.grpResult.Name = "grpResult"
        Me.grpResult.Padding = New System.Windows.Forms.Padding(0)
        Me.grpResult.Size = New System.Drawing.Size(1124, 342)
        Me.grpResult.TabIndex = 0
        Me.grpResult.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnShowEditSection)
        Me.Panel2.Controls.Add(Me.btnGetReport)
        Me.Panel2.Controls.Add(Me.btnViewAllStudents)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 299)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1124, 43)
        Me.Panel2.TabIndex = 22
        '
        'btnShowEditSection
        '
        Me.btnShowEditSection.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnShowEditSection.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShowEditSection.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnShowEditSection.Location = New System.Drawing.Point(504, 4)
        Me.btnShowEditSection.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShowEditSection.Name = "btnShowEditSection"
        Me.btnShowEditSection.Size = New System.Drawing.Size(132, 35)
        Me.btnShowEditSection.TabIndex = 20
        Me.btnShowEditSection.TabStop = False
        Me.btnShowEditSection.Text = "Show Edit section"
        Me.ToolTip1.SetToolTip(Me.btnShowEditSection, "Refresh the view list.")
        Me.btnShowEditSection.UseVisualStyleBackColor = True
        '
        'btnGetReport
        '
        Me.btnGetReport.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(644, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 64
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'btnViewAllStudents
        '
        Me.btnViewAllStudents.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnViewAllStudents.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllStudents.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllStudents.Location = New System.Drawing.Point(364, 4)
        Me.btnViewAllStudents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllStudents.Name = "btnViewAllStudents"
        Me.btnViewAllStudents.Size = New System.Drawing.Size(134, 35)
        Me.btnViewAllStudents.TabIndex = 1
        Me.btnViewAllStudents.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllStudents, "View all of lecturers current or past modules in the college.")
        Me.btnViewAllStudents.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(9, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(619, 195)
        Me.GroupBox1.TabIndex = 60
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select and search records:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.cboYear, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.cboFaculty, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtModuleCode, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtModuleName, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtFirstName, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtLastName, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtLecturerId, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.cboSemester, 1, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 22)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(611, 169)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'cboYear
        '
        Me.cboYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYear.FormattingEnabled = True
        Me.cboYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboYear.Location = New System.Drawing.Point(103, 9)
        Me.cboYear.Name = "cboYear"
        Me.cboYear.Size = New System.Drawing.Size(195, 25)
        Me.cboYear.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboYear, "Year")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 17)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Year:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(306, 11)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Faculty:"
        '
        'cboFaculty
        '
        Me.cboFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFaculty.FormattingEnabled = True
        Me.cboFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboFaculty.Location = New System.Drawing.Point(409, 9)
        Me.cboFaculty.Name = "cboFaculty"
        Me.cboFaculty.Size = New System.Drawing.Size(192, 25)
        Me.cboFaculty.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cboFaculty, "Faculty")
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 134)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 17)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Module code:"
        '
        'txtModuleCode
        '
        Me.txtModuleCode.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtModuleCode.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtModuleCode.Location = New System.Drawing.Point(104, 130)
        Me.txtModuleCode.Margin = New System.Windows.Forms.Padding(4)
        Me.txtModuleCode.Name = "txtModuleCode"
        Me.txtModuleCode.Size = New System.Drawing.Size(194, 25)
        Me.txtModuleCode.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtModuleCode, "Module code")
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(306, 134)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 17)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "Module name:"
        '
        'txtModuleName
        '
        Me.txtModuleName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtModuleName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtModuleName.Location = New System.Drawing.Point(410, 130)
        Me.txtModuleName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtModuleName.Name = "txtModuleName"
        Me.txtModuleName.Size = New System.Drawing.Size(194, 25)
        Me.txtModuleName.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtModuleName, "Module name")
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtFirstName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtFirstName.Location = New System.Drawing.Point(104, 85)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(194, 25)
        Me.txtFirstName.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtFirstName, "First Name")
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 89)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "First Name:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(306, 89)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 17)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Last Name:"
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLastName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtLastName.Location = New System.Drawing.Point(410, 85)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(194, 25)
        Me.txtLastName.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtLastName, "Last Name")
        '
        'txtLecturerId
        '
        Me.txtLecturerId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLecturerId.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtLecturerId.Location = New System.Drawing.Point(410, 46)
        Me.txtLecturerId.Margin = New System.Windows.Forms.Padding(4)
        Me.txtLecturerId.Name = "txtLecturerId"
        Me.txtLecturerId.Size = New System.Drawing.Size(194, 25)
        Me.txtLecturerId.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtLecturerId, "Lecturer Id")
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(306, 50)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Lecturer Id:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 50)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 17)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Semester:"
        '
        'cboSemester
        '
        Me.cboSemester.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboSemester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSemester.FormattingEnabled = True
        Me.cboSemester.Items.AddRange(New Object() {"1", "2", "3", "4", "All"})
        Me.cboSemester.Location = New System.Drawing.Point(103, 48)
        Me.cboSemester.Name = "cboSemester"
        Me.cboSemester.Size = New System.Drawing.Size(195, 25)
        Me.cboSemester.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.cboSemester, "Semester")
        '
        'dtpSelectViewStartDate
        '
        Me.dtpSelectViewStartDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpSelectViewStartDate.Location = New System.Drawing.Point(83, 130)
        Me.dtpSelectViewStartDate.Name = "dtpSelectViewStartDate"
        Me.dtpSelectViewStartDate.Size = New System.Drawing.Size(238, 25)
        Me.dtpSelectViewStartDate.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dtpSelectViewStartDate, "Start date")
        '
        'cboSelectViewYear
        '
        Me.cboSelectViewYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboSelectViewYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSelectViewYear.FormattingEnabled = True
        Me.cboSelectViewYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboSelectViewYear.Location = New System.Drawing.Point(83, 7)
        Me.cboSelectViewYear.Name = "cboSelectViewYear"
        Me.cboSelectViewYear.Size = New System.Drawing.Size(241, 25)
        Me.cboSelectViewYear.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboSelectViewYear, "Year")
        '
        'cboSelectFaculty
        '
        Me.cboSelectFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboSelectFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSelectFaculty.FormattingEnabled = True
        Me.cboSelectFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboSelectFaculty.Location = New System.Drawing.Point(83, 46)
        Me.cboSelectFaculty.Name = "cboSelectFaculty"
        Me.cboSelectFaculty.Size = New System.Drawing.Size(238, 25)
        Me.cboSelectFaculty.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cboSelectFaculty, "Faculty")
        '
        'cboSelectViewSemester
        '
        Me.cboSelectViewSemester.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboSelectViewSemester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSelectViewSemester.FormattingEnabled = True
        Me.cboSelectViewSemester.Items.AddRange(New Object() {"1", "2", "3", "4", "All"})
        Me.cboSelectViewSemester.Location = New System.Drawing.Point(83, 85)
        Me.cboSelectViewSemester.Name = "cboSelectViewSemester"
        Me.cboSelectViewSemester.Size = New System.Drawing.Size(241, 25)
        Me.cboSelectViewSemester.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.cboSelectViewSemester, "Semester")
        '
        'btnFilterView
        '
        Me.btnFilterView.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnFilterView.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFilterView.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnFilterView.Location = New System.Drawing.Point(331, 4)
        Me.btnFilterView.Margin = New System.Windows.Forms.Padding(4)
        Me.btnFilterView.Name = "btnFilterView"
        Me.btnFilterView.Size = New System.Drawing.Size(134, 31)
        Me.btnFilterView.TabIndex = 4
        Me.btnFilterView.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnFilterView, "View all of students current or past modules based on the selection.")
        Me.btnFilterView.UseVisualStyleBackColor = True
        '
        'pnlListOfStudent
        '
        Me.pnlListOfStudent.BackColor = System.Drawing.Color.Transparent
        Me.pnlListOfStudent.Controls.Add(Me.lblResult)
        Me.pnlListOfStudent.Controls.Add(Me.Label9)
        Me.pnlListOfStudent.Location = New System.Drawing.Point(438, 209)
        Me.pnlListOfStudent.Name = "pnlListOfStudent"
        Me.pnlListOfStudent.Size = New System.Drawing.Size(346, 20)
        Me.pnlListOfStudent.TabIndex = 64
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(320, 3)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 50
        Me.lblResult.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(4, 3)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(309, 17)
        Me.Label9.TabIndex = 57
        Me.Label9.Text = "List of current or past modules by lecturers:"
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(922, 212)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(61, 17)
        Me.lblDetails.TabIndex = 65
        Me.lblDetails.Text = "Details:"
        Me.lblDetails.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TableLayoutPanel3)
        Me.GroupBox2.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(636, 8)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(478, 194)
        Me.GroupBox2.TabIndex = 66
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select and view records:"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 4
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.Controls.Add(Me.dtpSelectViewStartDate, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.cboSelectViewYear, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label20, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Label10, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.cboSelectFaculty, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label18, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label24, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.cboSelectViewSemester, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.btnFilterView, 3, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(4, 22)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 4
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(470, 168)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(4, 134)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(72, 17)
        Me.Label20.TabIndex = 64
        Me.Label20.Text = "Start date:"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(4, 11)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 17)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Year:"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(4, 50)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(58, 17)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "Faculty:"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(4, 89)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(69, 17)
        Me.Label24.TabIndex = 25
        Me.Label24.Text = "Semester:"
        '
        'LecturerModuleSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.pnlListOfStudent)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.grpResult)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "LecturerModuleSearch"
        Me.Size = New System.Drawing.Size(1144, 576)
        CType(Me.grdLecturerModule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpEdit.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.grpResult.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.pnlListOfStudent.ResumeLayout(False)
        Me.pnlListOfStudent.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grdLecturerModule As System.Windows.Forms.DataGridView
    Friend WithEvents grpEdit As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents dtpViewStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtViewYear As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtViewLecturerId As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtViewName As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents cboViewSemester As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtViewModuleName As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents cboViewModuleCode As System.Windows.Forms.ComboBox
    Friend WithEvents grpResult As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cboYear As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents cboSemester As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtLecturerId As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtModuleCode As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtModuleName As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnShowEditSection As System.Windows.Forms.Button
    Friend WithEvents btnViewAllStudents As System.Windows.Forms.Button
    Friend WithEvents pnlListOfStudent As System.Windows.Forms.Panel
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents dtpSelectViewStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents cboSelectViewYear As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cboSelectFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents cboSelectViewSemester As System.Windows.Forms.ComboBox
    Friend WithEvents btnFilterView As System.Windows.Forms.Button

End Class
