﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BookView
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.grdBook = New System.Windows.Forms.DataGridView()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnViewAll = New System.Windows.Forms.Button()
        Me.btnFilterView = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtPublisher = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.txtAuthor = New ControlLibrary_IMS.TextBoxAuthorName()
        Me.txtIsbn = New ControlLibrary_IMS.TextBoxNumericAndHyphon()
        Me.txtAvailableQuantity = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtTotalQuantity = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.cboUpdateCategory = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpPublishDate = New System.Windows.Forms.DateTimePicker()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdBook, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(871, 129)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 17)
        Me.Label18.TabIndex = 64
        Me.Label18.Text = "Details:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnDelete)
        Me.Panel1.Controls.Add(Me.btnUpdate)
        Me.Panel1.Location = New System.Drawing.Point(124, 348)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(261, 38)
        Me.Panel1.TabIndex = 60
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(132, 3)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(2, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(277, 129)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 17)
        Me.Label10.TabIndex = 61
        Me.Label10.Text = "List of books:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btnGetReport)
        Me.GroupBox2.Controls.Add(Me.grdBook)
        Me.GroupBox2.Location = New System.Drawing.Point(13, 149)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(0)
        Me.GroupBox2.Size = New System.Drawing.Size(685, 429)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        '
        'btnGetReport
        '
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(248, 388)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 67
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'grdBook
        '
        Me.grdBook.AllowUserToAddRows = False
        Me.grdBook.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdBook.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdBook.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdBook.Location = New System.Drawing.Point(0, 18)
        Me.grdBook.MultiSelect = False
        Me.grdBook.Name = "grdBook"
        Me.grdBook.ReadOnly = True
        Me.grdBook.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdBook.Size = New System.Drawing.Size(685, 364)
        Me.grdBook.TabIndex = 0
        Me.grdBook.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdBook, "Select a record and get the data in the Details section.")
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox5.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(11, 7)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(353, 108)
        Me.GroupBox5.TabIndex = 60
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Select and view"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.cboCategory, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label23, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Panel2, 1, 1)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(4, 22)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(345, 82)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'cboCategory
        '
        Me.cboCategory.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(79, 7)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(261, 25)
        Me.cboCategory.TabIndex = 60
        Me.cboCategory.TabStop = False
        Me.ToolTip1.SetToolTip(Me.cboCategory, "Book category")
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(4, 11)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(68, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Category:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnViewAll)
        Me.Panel2.Controls.Add(Me.btnFilterView)
        Me.Panel2.Location = New System.Drawing.Point(79, 42)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(261, 37)
        Me.Panel2.TabIndex = 24
        '
        'btnViewAll
        '
        Me.btnViewAll.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnViewAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAll.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAll.Location = New System.Drawing.Point(136, 2)
        Me.btnViewAll.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAll.Name = "btnViewAll"
        Me.btnViewAll.Size = New System.Drawing.Size(125, 32)
        Me.btnViewAll.TabIndex = 57
        Me.btnViewAll.TabStop = False
        Me.btnViewAll.Text = "View all"
        Me.ToolTip1.SetToolTip(Me.btnViewAll, "View all of library books with no selection.")
        Me.btnViewAll.UseVisualStyleBackColor = True
        '
        'btnFilterView
        '
        Me.btnFilterView.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnFilterView.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFilterView.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnFilterView.Location = New System.Drawing.Point(1, 2)
        Me.btnFilterView.Margin = New System.Windows.Forms.Padding(4)
        Me.btnFilterView.Name = "btnFilterView"
        Me.btnFilterView.Size = New System.Drawing.Size(125, 31)
        Me.btnFilterView.TabIndex = 54
        Me.btnFilterView.TabStop = False
        Me.btnFilterView.Text = "Filter view"
        Me.ToolTip1.SetToolTip(Me.btnFilterView, "View all of library books based on the selection of this section.")
        Me.btnFilterView.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel2)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(703, 150)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox1.Size = New System.Drawing.Size(401, 428)
        Me.GroupBox1.TabIndex = 65
        Me.GroupBox1.TabStop = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 270.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.txtPublisher, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtAuthor, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.txtIsbn, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.txtAvailableQuantity, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.txtTotalQuantity, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.txtTitle, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel1, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label26, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.cboUpdateCategory, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpPublishDate, 1, 4)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 9
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 13.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(391, 401)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'txtPublisher
        '
        Me.txtPublisher.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPublisher.Location = New System.Drawing.Point(124, 85)
        Me.txtPublisher.MaxLength = 75
        Me.txtPublisher.Name = "txtPublisher"
        Me.txtPublisher.Size = New System.Drawing.Size(262, 25)
        Me.txtPublisher.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtPublisher, "Publisher")
        '
        'txtAuthor
        '
        Me.txtAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtAuthor.Location = New System.Drawing.Point(124, 124)
        Me.txtAuthor.MaxLength = 350
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(262, 25)
        Me.txtAuthor.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtAuthor, "Author")
        '
        'txtIsbn
        '
        Me.txtIsbn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtIsbn.Location = New System.Drawing.Point(124, 7)
        Me.txtIsbn.MaxLength = 17
        Me.txtIsbn.Name = "txtIsbn"
        Me.txtIsbn.Size = New System.Drawing.Size(262, 25)
        Me.txtIsbn.TabIndex = 70
        Me.ToolTip1.SetToolTip(Me.txtIsbn, "Isbn")
        '
        'txtAvailableQuantity
        '
        Me.txtAvailableQuantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtAvailableQuantity.Location = New System.Drawing.Point(124, 305)
        Me.txtAvailableQuantity.MaxLength = 5
        Me.txtAvailableQuantity.Name = "txtAvailableQuantity"
        Me.txtAvailableQuantity.Size = New System.Drawing.Size(262, 25)
        Me.txtAvailableQuantity.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtAvailableQuantity, "Available quantity in library")
        '
        'txtTotalQuantity
        '
        Me.txtTotalQuantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtTotalQuantity.Location = New System.Drawing.Point(124, 250)
        Me.txtTotalQuantity.MaxLength = 5
        Me.txtTotalQuantity.Name = "txtTotalQuantity"
        Me.txtTotalQuantity.Size = New System.Drawing.Size(262, 25)
        Me.txtTotalQuantity.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtTotalQuantity, "Total quantity in library")
        '
        'txtTitle
        '
        Me.txtTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtTitle.Location = New System.Drawing.Point(124, 46)
        Me.txtTitle.MaxLength = 255
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(262, 25)
        Me.txtTitle.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtTitle, "Book title")
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 128)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "Author:"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 89)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 17)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Publisher:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ISBN:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(5, 50)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Title:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 292)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 51)
        Me.Label3.TabIndex = 67
        Me.Label3.Text = "Available Quantity in Library"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(5, 246)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 34)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Total Quantity in Library"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(5, 207)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(68, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Category:"
        '
        'cboUpdateCategory
        '
        Me.cboUpdateCategory.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboUpdateCategory.FormattingEnabled = True
        Me.cboUpdateCategory.Location = New System.Drawing.Point(124, 203)
        Me.cboUpdateCategory.Name = "cboUpdateCategory"
        Me.cboUpdateCategory.Size = New System.Drawing.Size(261, 25)
        Me.cboUpdateCategory.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboUpdateCategory, "Book category")
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 168)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(91, 17)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Publish Date:"
        '
        'dtpPublishDate
        '
        Me.dtpPublishDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpPublishDate.Location = New System.Drawing.Point(125, 164)
        Me.dtpPublishDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpPublishDate.Name = "dtpPublishDate"
        Me.dtpPublishDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpPublishDate.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.dtpPublishDate, "Publish date")
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(378, 129)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 66
        Me.lblResult.Text = "0"
        '
        'BookView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox5)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "BookView"
        Me.Size = New System.Drawing.Size(1116, 591)
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdBook, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents grdBook As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnViewAll As System.Windows.Forms.Button
    Friend WithEvents btnFilterView As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cboUpdateCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents dtpPublishDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalQuantity As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtAvailableQuantity As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtIsbn As ControlLibrary_IMS.TextBoxNumericAndHyphon
    Friend WithEvents txtAuthor As ControlLibrary_IMS.TextBoxAuthorName
    Friend WithEvents txtPublisher As ControlLibrary_IMS.TextBoxCharacterPunctuation

End Class
