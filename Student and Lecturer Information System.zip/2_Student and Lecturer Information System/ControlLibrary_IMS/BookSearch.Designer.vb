﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BookSearch
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnShowEditSection = New System.Windows.Forms.Button()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.btnViewAllStudents = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtPublisher = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.txtAuthor = New ControlLibrary_IMS.TextBoxAuthorName()
        Me.txtIsbnNo = New ControlLibrary_IMS.TextBoxNumericAndHyphon()
        Me.txtCategory = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpResult = New System.Windows.Forms.GroupBox()
        Me.grdBook = New System.Windows.Forms.DataGridView()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtEditTitle = New System.Windows.Forms.TextBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cboEditCategory = New System.Windows.Forms.ComboBox()
        Me.dtpEditPublishDate = New System.Windows.Forms.DateTimePicker()
        Me.txtEditAvailableQuantity = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtEditTotalQuantity = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtEditIsbn = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtEditAuthor = New ControlLibrary_IMS.TextBoxAuthorName()
        Me.txtEditPublisher = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.pnlListOfStudent = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.grpResult.SuspendLayout()
        CType(Me.grdBook, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpEdit.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnlListOfStudent.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnShowEditSection)
        Me.Panel1.Controls.Add(Me.btnGetReport)
        Me.Panel1.Controls.Add(Me.btnViewAllStudents)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 379)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1026, 43)
        Me.Panel1.TabIndex = 20
        '
        'btnShowEditSection
        '
        Me.btnShowEditSection.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnShowEditSection.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShowEditSection.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnShowEditSection.Location = New System.Drawing.Point(469, 4)
        Me.btnShowEditSection.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShowEditSection.Name = "btnShowEditSection"
        Me.btnShowEditSection.Size = New System.Drawing.Size(132, 35)
        Me.btnShowEditSection.TabIndex = 56
        Me.btnShowEditSection.TabStop = False
        Me.btnShowEditSection.Text = "Show Edit section"
        Me.ToolTip1.SetToolTip(Me.btnShowEditSection, "Refresh the view list.")
        Me.btnShowEditSection.UseVisualStyleBackColor = True
        '
        'btnGetReport
        '
        Me.btnGetReport.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(609, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 55
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'btnViewAllStudents
        '
        Me.btnViewAllStudents.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnViewAllStudents.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllStudents.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllStudents.Location = New System.Drawing.Point(339, 4)
        Me.btnViewAllStudents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllStudents.Name = "btnViewAllStudents"
        Me.btnViewAllStudents.Size = New System.Drawing.Size(122, 34)
        Me.btnViewAllStudents.TabIndex = 0
        Me.btnViewAllStudents.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllStudents, "View all of library books available in the college.")
        Me.btnViewAllStudents.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Location = New System.Drawing.Point(185, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(615, 153)
        Me.GroupBox1.TabIndex = 52
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search By:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.txtPublisher, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtAuthor, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtIsbnNo, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtCategory, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtTitle, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(609, 125)
        Me.TableLayoutPanel1.TabIndex = 45
        '
        'txtPublisher
        '
        Me.txtPublisher.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPublisher.Location = New System.Drawing.Point(85, 46)
        Me.txtPublisher.MaxLength = 75
        Me.txtPublisher.Name = "txtPublisher"
        Me.txtPublisher.Size = New System.Drawing.Size(215, 25)
        Me.txtPublisher.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtPublisher, "Publisher")
        '
        'txtAuthor
        '
        Me.txtAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtAuthor.Location = New System.Drawing.Point(85, 89)
        Me.txtAuthor.MaxLength = 350
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(215, 25)
        Me.txtAuthor.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtAuthor, "Author")
        '
        'txtIsbnNo
        '
        Me.txtIsbnNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtIsbnNo.Location = New System.Drawing.Point(85, 7)
        Me.txtIsbnNo.MaxLength = 17
        Me.txtIsbnNo.Name = "txtIsbnNo"
        Me.txtIsbnNo.Size = New System.Drawing.Size(215, 25)
        Me.txtIsbnNo.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtIsbnNo, "Isbn no")
        '
        'txtCategory
        '
        Me.txtCategory.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtCategory.Location = New System.Drawing.Point(384, 46)
        Me.txtCategory.MaxLength = 25
        Me.txtCategory.Name = "txtCategory"
        Me.txtCategory.Size = New System.Drawing.Size(215, 25)
        Me.txtCategory.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtCategory, "Book category")
        '
        'txtTitle
        '
        Me.txtTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtTitle.Location = New System.Drawing.Point(384, 7)
        Me.txtTitle.MaxLength = 255
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(215, 25)
        Me.txtTitle.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtTitle, "Book title")
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 11)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(58, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Isbn no:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(308, 11)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 17)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Title:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 93)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Author:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(308, 50)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 17)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Category:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 50)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 17)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Publisher:"
        '
        'grpResult
        '
        Me.grpResult.BackColor = System.Drawing.Color.Transparent
        Me.grpResult.Controls.Add(Me.Panel1)
        Me.grpResult.Controls.Add(Me.grdBook)
        Me.grpResult.Location = New System.Drawing.Point(11, 194)
        Me.grpResult.Name = "grpResult"
        Me.grpResult.Padding = New System.Windows.Forms.Padding(0)
        Me.grpResult.Size = New System.Drawing.Size(1026, 422)
        Me.grpResult.TabIndex = 0
        Me.grpResult.TabStop = False
        '
        'grdBook
        '
        Me.grdBook.AllowUserToAddRows = False
        Me.grdBook.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdBook.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdBook.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdBook.Location = New System.Drawing.Point(0, 18)
        Me.grdBook.MultiSelect = False
        Me.grdBook.Name = "grdBook"
        Me.grdBook.ReadOnly = True
        Me.grdBook.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdBook.ShowCellToolTips = False
        Me.grdBook.Size = New System.Drawing.Size(1026, 354)
        Me.grdBook.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdBook, "Click 'Show Enable section' button to view the Edit section and select a record a" & _
        "nd get the data in the Details section.")
        '
        'txtEditTitle
        '
        Me.txtEditTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditTitle.Location = New System.Drawing.Point(124, 46)
        Me.txtEditTitle.MaxLength = 255
        Me.txtEditTitle.Name = "txtEditTitle"
        Me.txtEditTitle.Size = New System.Drawing.Size(262, 25)
        Me.txtEditTitle.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtEditTitle, "Book title")
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(132, 3)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(2, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cboEditCategory
        '
        Me.cboEditCategory.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditCategory.FormattingEnabled = True
        Me.cboEditCategory.Location = New System.Drawing.Point(124, 203)
        Me.cboEditCategory.Name = "cboEditCategory"
        Me.cboEditCategory.Size = New System.Drawing.Size(261, 25)
        Me.cboEditCategory.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboEditCategory, "Book category")
        '
        'dtpEditPublishDate
        '
        Me.dtpEditPublishDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpEditPublishDate.Location = New System.Drawing.Point(125, 164)
        Me.dtpEditPublishDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpEditPublishDate.Name = "dtpEditPublishDate"
        Me.dtpEditPublishDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpEditPublishDate.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.dtpEditPublishDate, "Publish date")
        '
        'txtEditAvailableQuantity
        '
        Me.txtEditAvailableQuantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditAvailableQuantity.Location = New System.Drawing.Point(124, 305)
        Me.txtEditAvailableQuantity.MaxLength = 5
        Me.txtEditAvailableQuantity.Name = "txtEditAvailableQuantity"
        Me.txtEditAvailableQuantity.Size = New System.Drawing.Size(262, 25)
        Me.txtEditAvailableQuantity.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtEditAvailableQuantity, "Available quantity in library")
        '
        'txtEditTotalQuantity
        '
        Me.txtEditTotalQuantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditTotalQuantity.Location = New System.Drawing.Point(124, 250)
        Me.txtEditTotalQuantity.MaxLength = 5
        Me.txtEditTotalQuantity.Name = "txtEditTotalQuantity"
        Me.txtEditTotalQuantity.Size = New System.Drawing.Size(262, 25)
        Me.txtEditTotalQuantity.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtEditTotalQuantity, "Total quantity in library")
        '
        'txtEditIsbn
        '
        Me.txtEditIsbn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditIsbn.Location = New System.Drawing.Point(124, 7)
        Me.txtEditIsbn.MaxLength = 17
        Me.txtEditIsbn.Name = "txtEditIsbn"
        Me.txtEditIsbn.Size = New System.Drawing.Size(262, 25)
        Me.txtEditIsbn.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtEditIsbn, "Isbn")
        '
        'txtEditAuthor
        '
        Me.txtEditAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditAuthor.Location = New System.Drawing.Point(124, 124)
        Me.txtEditAuthor.MaxLength = 350
        Me.txtEditAuthor.Name = "txtEditAuthor"
        Me.txtEditAuthor.Size = New System.Drawing.Size(262, 25)
        Me.txtEditAuthor.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtEditAuthor, "Author")
        '
        'txtEditPublisher
        '
        Me.txtEditPublisher.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditPublisher.Location = New System.Drawing.Point(124, 85)
        Me.txtEditPublisher.MaxLength = 75
        Me.txtEditPublisher.Name = "txtEditPublisher"
        Me.txtEditPublisher.Size = New System.Drawing.Size(262, 25)
        Me.txtEditPublisher.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtEditPublisher, "Publisher")
        '
        'grpEdit
        '
        Me.grpEdit.Controls.Add(Me.TableLayoutPanel2)
        Me.grpEdit.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpEdit.Location = New System.Drawing.Point(636, 194)
        Me.grpEdit.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.grpEdit.Size = New System.Drawing.Size(401, 422)
        Me.grpEdit.TabIndex = 67
        Me.grpEdit.TabStop = False
        Me.grpEdit.Visible = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 270.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditPublisher, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditAuthor, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditAvailableQuantity, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditTotalQuantity, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditTitle, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditIsbn, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel2, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label11, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label26, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.cboEditCategory, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpEditPublishDate, 1, 4)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 9
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 13.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(391, 395)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(5, 128)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 17)
        Me.Label2.TabIndex = 66
        Me.Label2.Text = "Author:"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 89)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 17)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Publisher:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 11)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "ISBN:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnDelete)
        Me.Panel2.Controls.Add(Me.btnUpdate)
        Me.Panel2.Location = New System.Drawing.Point(124, 348)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(261, 38)
        Me.Panel2.TabIndex = 60
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 50)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 17)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Title:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 292)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 51)
        Me.Label8.TabIndex = 67
        Me.Label8.Text = "Available Quantity in Library"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(5, 246)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 34)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Total Quantity in Library"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(5, 207)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(68, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Category:"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(5, 168)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(91, 17)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Publish Date:"
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(810, 173)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(61, 17)
        Me.lblDetails.TabIndex = 66
        Me.lblDetails.Text = "Details:"
        Me.lblDetails.Visible = False
        '
        'pnlListOfStudent
        '
        Me.pnlListOfStudent.BackColor = System.Drawing.Color.Transparent
        Me.pnlListOfStudent.Controls.Add(Me.Label10)
        Me.pnlListOfStudent.Controls.Add(Me.lblResult)
        Me.pnlListOfStudent.Location = New System.Drawing.Point(424, 173)
        Me.pnlListOfStudent.Name = "pnlListOfStudent"
        Me.pnlListOfStudent.Size = New System.Drawing.Size(148, 20)
        Me.pnlListOfStudent.TabIndex = 68
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 3)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 17)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "List of books:"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(116, 3)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 50
        Me.lblResult.Text = "0"
        '
        'BookSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.pnlListOfStudent)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpResult)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "BookSearch"
        Me.Size = New System.Drawing.Size(1051, 623)
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.grpResult.ResumeLayout(False)
        CType(Me.grdBook, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpEdit.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.pnlListOfStudent.ResumeLayout(False)
        Me.pnlListOfStudent.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents grpResult As System.Windows.Forms.GroupBox
    Friend WithEvents grdBook As System.Windows.Forms.DataGridView
    Friend WithEvents btnViewAllStudents As System.Windows.Forms.Button
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtCategory As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents grpEdit As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtEditAvailableQuantity As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtEditTotalQuantity As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtEditTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtEditIsbn As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents cboEditCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents dtpEditPublishDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents btnShowEditSection As System.Windows.Forms.Button
    Friend WithEvents pnlListOfStudent As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents txtIsbnNo As ControlLibrary_IMS.TextBoxNumericAndHyphon
    Friend WithEvents txtAuthor As ControlLibrary_IMS.TextBoxAuthorName
    Friend WithEvents txtEditAuthor As ControlLibrary_IMS.TextBoxAuthorName
    Friend WithEvents txtPublisher As ControlLibrary_IMS.TextBoxCharacterPunctuation
    Friend WithEvents txtEditPublisher As ControlLibrary_IMS.TextBoxCharacterPunctuation

End Class
