﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class StudentAddPhone
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtStudentList As New DataTable
    Dim strExceptionId As String = "errStudentId"
    Dim strExceptionPhoneNumber As String = "errPhoneNumber"

    'METHOD: GET STUDENT ID AND NAME BASED ON COMBOBOX SELECTION
    Private Sub GetStudentIdAndName()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Student; "

        'Call GetStudentName method to get list of name and id
        DataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If DataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(DataAccess.strExceptionGetListForComboBox, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            DataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtStudentList = DataAccess.dtListForComboBox
            cboId.DataSource = dtStudentList
            cboId.DisplayMember = "StudentId"

            If cboId.Text = "" Then
                txtName.Clear()
            Else
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Check whether to enable save button or not
                EnabledSaveButton()
            End If
        End If
    End Sub


    'FORM LOAD EVENT 
    Private Sub StudentAddPhone_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Call procedure to get list of student
        GetStudentIdAndName()

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    ''SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    'Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
    '    If cboYear.SelectedIndex = 0 Then
    '        'Insert and Select FCHE as facutly and disable the Faculty combobox
    '        If Not cboFaculty.Items.Contains("FCHE") Then
    '            cboFaculty.Items.Add("FCHE")
    '        End If
    '        cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
    '        cboFaculty.Enabled = False
    '    Else
    '        'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
    '        cboFaculty.Enabled = True
    '        cboFaculty.Items.Remove("FCHE")
    '    End If

    '    'Call GetStudentIdAndName procedure to get list of student id and name
    '    GetStudentIdAndName()

    '    'Fill the datagridview
    '    GetStudentIdAndNameAndPhoneNo()
    'End Sub



    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
    Private Sub cboId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
        'Clear any previous bindings..
        txtName.DataBindings.Clear()

        'Binding process
        txtName.DataBindings.Add("Text", dtStudentList, "Name")

        'Fill the datagridview
        GetStudentIdAndNameAndPhoneNo()
    End Sub

    ''SELECTEDINDEXCHANGED EVEN TO GET LIST OF STUDENTS
    'Private Sub cboFaculty_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFaculty.SelectedIndexChanged
    '    'Call GetStudentName to get list in the combobox
    '    GetStudentIdAndName()
    'End Sub

    'CLICK EVENT TO SAVE STUDENT PHONE NUMBER
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtPhoneNumber.Text.Trim.Length > 5 Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you want to add the following phone number information?")
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
            objStringBuilder.AppendLine("Phone-Info: " & txtPhoneNumber.Text)

            'Show message box
            If MessageBox.Show(objStringBuilder.ToString, "Add New Phone Number", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                objCommand = New SqlCommand
                objCommand.CommandText = "INSERT INTO StudentPhoneNumber " & _
                    "VALUES(@studentId,@phoneNumber); "

                'Add parameters for the placeholder in the SQL CommandText property..
                objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
                objCommand.Parameters.AddWithValue("@phoneNumber", txtPhoneNumber.Text)

                'Call AddDetails method to add phone number
                dataAccess.AddDetails(objCommand)

                'Check for errors
                If dataAccess.strExceptionAddDetails <> "" Then
                    If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                        'Show error message
                        MessageBox.Show("The phone number of the student already exists.", "Add Phone Number | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Else
                        'Show error message
                        MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Phone Number | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If

                    'Set the variable to nothing
                    dataAccess.strExceptionAddDetails = Nothing

                    'Select and focus on phone number textbox
                    txtPhoneNumber.SelectAll()
                    txtPhoneNumber.Focus()
                Else
                    'If there is no error, show succeed message

                    Dim objStringBuilder1 As New System.Text.StringBuilder
                    objStringBuilder1.AppendLine("The following phone number information has been successfully added.")
                    objStringBuilder1.AppendLine(String.Empty)
                    objStringBuilder1.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
                    objStringBuilder1.AppendLine("Phone-Info: " & txtPhoneNumber.Text)

                    'Show message box
                    MessageBox.Show(objStringBuilder1.ToString, "Add Phone Number | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    'Clear and focus on phone number textbox
                    txtPhoneNumber.Clear()
                    txtPhoneNumber.Focus()

                    'Refresh datagridview
                    GetStudentIdAndNameAndPhoneNo()
                End If
            End If
        Else
            'Show error message
            MsgBox("The phone number must be at least greater than 5 digits.", MsgBoxStyle.Exclamation, "Student phone number details")

            'Clear and focus on phone number textbox
            txtPhoneNumber.Clear()
            txtPhoneNumber.Focus()
        End If

    End Sub

    Private Sub EnabledSaveButton()
        If strExceptionId = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub cboId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboId.Validating
        'Check if the student already exists
        If cboId.Text.Trim.Length = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSetStudentCheck IsNot Nothing Then
                dataAccess.objDataSetStudentCheck.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSetIdCheck("SELECT *  " & _
                "FROM Student " & _
                "WHERE StudentId LIKE '%" & cboId.Text & "%';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSetIdCheck <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSetIdCheck, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSetIdCheck = Nothing
            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 1 Then
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 0 Then
                strExceptionId = "This student does not exist."
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtName.Clear()
            End If
        Else
            strExceptionId = "Select or enter 12 character student Id."
            ErrorProvider1.SetError(cboId, strExceptionId)

            'Clear the name textbox
            txtName.Clear()
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtPhoneNumber_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtPhoneNumber.Validating
        If txtPhoneNumber.Text.Trim.Length = 0 Then
            strExceptionPhoneNumber = "Please enter phone number."
            ErrorProvider1.SetError(txtPhoneNumber, strExceptionPhoneNumber)
        Else
            strExceptionPhoneNumber = ""
            ErrorProvider1.SetError(txtPhoneNumber, strExceptionPhoneNumber)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtPhoneNumber_TextChanged(sender As Object, e As EventArgs) Handles txtPhoneNumber.TextChanged
        'Enable save button
        btnSave.Enabled = True
    End Sub



    'LIST OF METHOD FOR THE DATAGRIDVIEW SECTION
    'METHOD: GET STUDENT ID AND NAME AND PHONE NUMBER FOR THE DATAGRIDVIEW
    Private Sub GetStudentIdAndNameAndPhoneNo()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name, PhoneNumber As [Phone number] " & _
            "FROM Student " & _
            "JOIN StudentPhoneNumber ON Student.StudentId=StudentPhoneNumber.StudentId " & _
            "WHERE Student.StudentId='" & cboId.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdPhoneNumber.DataSource = Nothing

            'Get the datasource for datagridview
            grdPhoneNumber.DataSource = dataAccess.objDataSet.Tables(0)

            'Make sure the following changes
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Make DataGridView ReadOnly property to true
            grdPhoneNumber.ReadOnly = True

            If grdPhoneNumber.RowCount > 0 Then
                'Enable the Enable edit button
                btnEnableEdit.Enabled = True
            Else
                'Disable the Enable edit button
                btnEnableEdit.Enabled = False
            End If

            grdPhoneNumber.Columns(1).Frozen = True
        End If
    End Sub

    'METHOD: GET STUDENT ID AND PHONE NUMBER FOR THE DATAGRIDVIEW FROM A SINGLE TABLE
    Private Sub GetStudentIdAndPhoneNo()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT StudentId As [Student Id],PhoneNumber As [Phone number] " & _
            "FROM StudentPhoneNumber " & _
            "WHERE StudentId='" & cboId.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdPhoneNumber.DataSource = Nothing

            'Get the datasource for datagridview
            grdPhoneNumber.DataSource = dataAccess.objDataSet.Tables(0)

            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand
        End If
    End Sub

    Private Sub btnEnableEdit_Click(sender As Object, e As EventArgs) Handles btnEnableEdit.Click
        If btnEnableEdit.Text = "Enable Edit" Then
            'Change the text
            btnEnableEdit.Text = "Disable Edit"

            'Fill datagridview from a single phone number table
            GetStudentIdAndPhoneNo()

            'Make the GridView readonly property to false
            grdPhoneNumber.ReadOnly = False

            'Allow user to delete rows
            grdPhoneNumber.AllowUserToDeleteRows = True

            'Make sure the the 1st column is unable to edit
            grdPhoneNumber.Columns(0).ReadOnly = True
        Else
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Fill datagridview from a single phone number table
            GetStudentIdAndNameAndPhoneNo()

            'Set GridView readonly property to true
            grdPhoneNumber.ReadOnly = True


            'Donot allow user to delete rows
            grdPhoneNumber.AllowUserToDeleteRows = False
        End If
    End Sub

    Private Sub btnGridSave_Click(sender As Object, e As EventArgs) Handles btnGrdSave.Click
        'Show question box
        If MessageBox.Show("Do you want to save the modification that you have made?", "Phone Number Modification", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then

            Try
                'Save updates to the datbase
                dataAccess.objDataAdapter.Update(dataAccess.objDataSet)

                'Fill datagridview from a single phone number table
                GetStudentIdAndPhoneNo()

                'Show message box
                MessageBox.Show("The modification that you have made is successfully saved.", "Phone Number Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Make sure the the 1st column is unable to edit
                grdPhoneNumber.Columns(0).ReadOnly = True

                'Disable the Save button inside 'View and Modify' groupbox
                btnGrdSave.Enabled = False
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        'Fill datagridview 
        GetStudentIdAndNameAndPhoneNo()
    End Sub

    Private Sub grdPhoneNumber_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles grdPhoneNumber.CellValueChanged
        'Enable the save button
        btnGrdSave.Enabled = True
    End Sub

    Private Sub grdPhoneNumber_UserDeletedRow(sender As Object, e As DataGridViewRowEventArgs) Handles grdPhoneNumber.UserDeletedRow
        'Enable the save button
        btnGrdSave.Enabled = True
    End Sub

    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear and focus on phone number textbox
        txtPhoneNumber.Clear()
        txtPhoneNumber.Focus()
    End Sub
End Class
