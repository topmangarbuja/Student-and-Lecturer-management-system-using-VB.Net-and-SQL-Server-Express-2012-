﻿Imports ClassLibrary_IMS

Partial Class DataSetModuleSearch
    Public dt As New DataTable


    Private Sub DataSetModuleSearch_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt = GblAccessItem.DataTableModuleSearch
    End Sub
End Class
