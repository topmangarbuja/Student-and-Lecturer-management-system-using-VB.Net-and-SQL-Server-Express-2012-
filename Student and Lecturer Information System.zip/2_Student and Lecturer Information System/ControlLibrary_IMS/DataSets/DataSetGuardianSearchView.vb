﻿Imports ClassLibrary_IMS

Partial Class DataSetGuardianSearchView
    Public dt As New DataTable


    Private Sub DataSetGuardianSearchView_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Column1")
        dt.Columns.Add("GuardianName")
        dt.Columns.Add("StudentName")
        dt.Columns.Add("PhoneNo")
        dt.Columns.Add("Relationship")

        Dim resultTable As DataTable = GblAccessItem.DataTableGuardianSearchView
        For Each r As DataRow In resultTable.Rows
            dt.Rows.Add(r(0), r(3) + " " + r(4), r(2) + " (" + r(1).ToString + ")", r(5), r(6))
        Next
    End Sub
End Class
