﻿Imports ClassLibrary_IMS
Partial Class DataSetBookView
    Public dt As New DataTable

    Private Sub DataSetBookView_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Column1")
        dt.Columns.Add("Isbn")
        dt.Columns.Add("Title")
        dt.Columns.Add("Publisher")
        dt.Columns.Add("Author")
        dt.Columns.Add("PublishDate", GetType(Date))
        dt.Columns.Add("Category")
        dt.Columns.Add("TotalQuantity")
        dt.Columns.Add("AvailableQuantity")

        Dim resultTable As DataTable = GblAccessItem.DataTableBookView
        For Each r As DataRow In resultTable.Rows
            dt.Rows.Add(r(0), r(2), r(3), r(4), r(5), r(6), r(7), r(8), r(9))
        Next
    End Sub
End Class
