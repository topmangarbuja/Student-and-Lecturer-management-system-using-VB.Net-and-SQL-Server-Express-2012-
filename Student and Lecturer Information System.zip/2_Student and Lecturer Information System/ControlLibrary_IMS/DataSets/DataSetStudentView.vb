﻿Imports ClassLibrary_IMS
Partial Class DataSetStudentView
    Public dt As New DataTable

    Private Sub DataSetStudentView_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Column1")
        dt.Columns.Add("StudentId")
        dt.Columns.Add("Name")
        dt.Columns.Add("DateOfBirth", GetType(Date))
        dt.Columns.Add("Gender")
        dt.Columns.Add("Address")
        dt.Columns.Add("CitizenshipNo")
        dt.Columns.Add("PassportNo")
        dt.Columns.Add("Status")

        Dim resultTable As DataTable = GblAccessItem.DataTableStudentView
        For Each r As DataRow In resultTable.Rows
            'dt.Rows.Add(r(0), r(1), r(2) r(3), r(3), r(4), r(5), r(6), r(7), r(8))
            dt.Rows.Add(r(0), r(1), r(2) + " " + r(3), r(4), r(5), r(8).ToString + "-" + r(7).ToString + ", " + r(6).ToString + ", " + r(9).ToString, r(10), r(11), r(12))
        Next
    End Sub
End Class
