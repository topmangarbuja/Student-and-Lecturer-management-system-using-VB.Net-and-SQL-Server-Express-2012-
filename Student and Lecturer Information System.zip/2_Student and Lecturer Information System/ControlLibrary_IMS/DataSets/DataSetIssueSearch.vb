﻿Imports ClassLibrary_IMS

Partial Class DataSetIssueSearch
    Public dt As New DataTable


    Private Sub DataSetIssueSearch_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Column1")
        dt.Columns.Add("Name")
        dt.Columns.Add("Book")
        dt.Columns.Add("Author")
        dt.Columns.Add("IssueDate", GetType(Date))
        dt.Columns.Add("IssueTime")
        dt.Columns.Add("Remarks")

        Dim resultTable As DataTable = GblAccessItem.DataTableIssueSearch
        For Each r As DataRow In resultTable.Rows
            dt.Rows.Add(r(0), r(3) + " (" + r(2) + ")", r(5) + " (" + r(4) + ")", r(6), r(7), r(8), r(11))
        Next
    End Sub
End Class
