﻿Imports ClassLibrary_IMS
Partial Class DataSetIssueView
    Public dt As New DataTable

    Private Sub DataSetIssueView_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Column1")
        dt.Columns.Add("Name")
        dt.Columns.Add("Book")
        dt.Columns.Add("Author")
        dt.Columns.Add("IssueDate", GetType(Date))
        dt.Columns.Add("IssueTime")
        dt.Columns.Add("ReturnDate", GetType(Date))
        dt.Columns.Add("ReturnTime")
        dt.Columns.Add("Remarks")

        Dim resultTable As DataTable = GblAccessItem.DataTableIssueView
        For Each r As DataRow In resultTable.Rows
            dt.Rows.Add(r(0), r(3) + " (" + r(2) + ")", r(5) + " (" + r(4) + ")", r(6), r(7), r(8), r(9), r(10), r(11))
        Next
    End Sub
End Class
