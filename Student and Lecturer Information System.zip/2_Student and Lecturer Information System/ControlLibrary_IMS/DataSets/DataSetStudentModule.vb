﻿Imports ClassLibrary_IMS

Partial Class DataSetStudentModule
    
    Partial Class DataTable1DataTable

    End Class

    Public dt As New DataTable



    Private Sub DataSetStudentModule_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Sn")
        dt.Columns.Add("Name")
        dt.Columns.Add("Id")
        dt.Columns.Add("Semester")
        dt.Columns.Add("ModuleName")
        dt.Columns.Add("ModuleCode")
        dt.Columns.Add("StartDate", GetType(Date))
        dt.Columns.Add("Faculty")
        dt.Columns.Add("Year")

        Dim resultTable As DataTable = GblAccessItem.DataTableStudentModule

        For Each r As DataRow In resultTable.Rows
            dt.Rows.Add(r(0), r(2), r(1), r(3), r(5), r(4), r(6), r(7), r(8))
        Next
    End Sub
End Class
