﻿Imports ClassLibrary_IMS
Partial Class DataSetModuleView
   


    Public dt As New DataTable

    Private Sub DataSetModuleView_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt = GblAccessItem.DataTableModuleView
    End Sub
End Class
