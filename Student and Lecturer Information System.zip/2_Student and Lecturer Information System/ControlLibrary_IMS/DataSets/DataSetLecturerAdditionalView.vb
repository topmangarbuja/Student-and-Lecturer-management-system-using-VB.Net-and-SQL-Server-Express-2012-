﻿Imports ClassLibrary_IMS

Partial Class DataSetLecturerAdditionalView
   

    Public dt As New DataTable
    Private Sub DataSetLecturerAdditionalView_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        dt.Columns.Add("Sn")
        dt.Columns.Add("Lecturer")
        dt.Columns.Add("Name")
        dt.Columns.Add("EmailPhone")
        dt.Columns.Add("Status")

        Dim resultTable As DataTable = GblAccessItem.DataTableLecturerAdditionalView

        For Each r As DataRow In resultTable.Rows
            dt.Rows.Add(r(0), r(1), r(2), r(3), r(4))
        Next
    End Sub
End Class
