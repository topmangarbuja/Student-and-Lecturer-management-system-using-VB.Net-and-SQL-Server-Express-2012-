﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentModuleAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StudentModuleAddNew))
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.cboSemester = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.grdStudentModule = New System.Windows.Forms.DataGridView()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lstSelectedModule = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.cboFaculty = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboId = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lstListOfModules = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.dtpStartDate = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.GroupBox2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.grdStudentModule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(58, 80)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(159, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.TabStop = False
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Select a module in the 'Selected Module' list and click 'Delete' to remove from t" & _
        "he list.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'cboSemester
        '
        Me.cboSemester.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboSemester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSemester.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboSemester, "Select a corresponding semester for the student.")
        Me.cboSemester.Items.AddRange(New Object() {"1", "2", "3", "4"})
        Me.cboSemester.Location = New System.Drawing.Point(125, 436)
        Me.cboSemester.Name = "cboSemester"
        Me.HelpProvider1.SetShowHelp(Me.cboSemester, True)
        Me.cboSemester.Size = New System.Drawing.Size(268, 25)
        Me.cboSemester.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboSemester, "Semester")
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 438)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 17)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Semester:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 356)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(114, 17)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Selected Module:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Panel4)
        Me.GroupBox2.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(441, 8)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(625, 272)
        Me.GroupBox2.TabIndex = 24
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "View and Modify"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.grdStudentModule)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(4, 19)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(617, 245)
        Me.Panel4.TabIndex = 20
        '
        'grdStudentModule
        '
        Me.grdStudentModule.AllowUserToAddRows = False
        Me.grdStudentModule.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdStudentModule.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdStudentModule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdStudentModule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdStudentModule.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdStudentModule.Location = New System.Drawing.Point(0, 0)
        Me.grdStudentModule.MultiSelect = False
        Me.grdStudentModule.Name = "grdStudentModule"
        Me.grdStudentModule.ReadOnly = True
        Me.grdStudentModule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdStudentModule.Size = New System.Drawing.Size(617, 245)
        Me.grdStudentModule.TabIndex = 20
        Me.grdStudentModule.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.Controls.Add(Me.lstSelectedModule)
        Me.Panel3.Controls.Add(Me.btnDelete)
        Me.Panel3.Location = New System.Drawing.Point(126, 307)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(275, 116)
        Me.Panel3.TabIndex = 21
        '
        'lstSelectedModule
        '
        Me.lstSelectedModule.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lstSelectedModule.BackColor = System.Drawing.SystemColors.Window
        Me.lstSelectedModule.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.lstSelectedModule, "Here, you get the module that you clicked in the LIst of Module section.")
        Me.lstSelectedModule.HorizontalScrollbar = True
        Me.lstSelectedModule.ItemHeight = 17
        Me.lstSelectedModule.Location = New System.Drawing.Point(7, 3)
        Me.lstSelectedModule.Name = "lstSelectedModule"
        Me.HelpProvider1.SetShowHelp(Me.lstSelectedModule, True)
        Me.lstSelectedModule.Size = New System.Drawing.Size(260, 72)
        Me.lstSelectedModule.TabIndex = 0
        Me.lstSelectedModule.TabStop = False
        Me.ToolTip1.SetToolTip(Me.lstSelectedModule, "Selected Module")
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 128)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Name:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 50)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Faculty:"
        '
        'txtName
        '
        Me.txtName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtName, "Here, you get the corresponding name of the selected student id.")
        Me.txtName.Location = New System.Drawing.Point(126, 124)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtName.Name = "txtName"
        Me.txtName.ReadOnly = True
        Me.HelpProvider1.SetShowHelp(Me.txtName, True)
        Me.txtName.Size = New System.Drawing.Size(266, 25)
        Me.txtName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtName, "Name")
        '
        'cboFaculty
        '
        Me.cboFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFaculty.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboFaculty, "Select a faculty to get the corresponding list of students as well as modules bel" & _
        "ow in Id  and List of Modules section.")
        Me.cboFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboFaculty.Location = New System.Drawing.Point(125, 46)
        Me.cboFaculty.Name = "cboFaculty"
        Me.HelpProvider1.SetShowHelp(Me.cboFaculty, True)
        Me.cboFaculty.Size = New System.Drawing.Size(268, 25)
        Me.cboFaculty.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cboFaculty, "Faculty")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 17)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Year:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 89)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Student Id:"
        '
        'cboId
        '
        Me.cboId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboId.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboId, "Select from the list or type 12 character student Id.")
        Me.cboId.Location = New System.Drawing.Point(125, 87)
        Me.cboId.MaxLength = 12
        Me.cboId.Name = "cboId"
        Me.HelpProvider1.SetShowHelp(Me.cboId, True)
        Me.cboId.Size = New System.Drawing.Size(268, 25)
        Me.cboId.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.cboId, "Student Id")
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 221)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 17)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "List of modules:"
        '
        'lstListOfModules
        '
        Me.lstListOfModules.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lstListOfModules.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.lstListOfModules, resources.GetString("lstListOfModules.HelpString"))
        Me.lstListOfModules.HorizontalScrollbar = True
        Me.lstListOfModules.ItemHeight = 17
        Me.lstListOfModules.Location = New System.Drawing.Point(133, 159)
        Me.lstListOfModules.Margin = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.lstListOfModules.Name = "lstListOfModules"
        Me.HelpProvider1.SetShowHelp(Me.lstListOfModules, True)
        Me.lstListOfModules.Size = New System.Drawing.Size(260, 140)
        Me.lstListOfModules.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.lstListOfModules, "Double click on the module to get in the selected module.")
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.cboSemester, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtName, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.cboFaculty, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.cboYear, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.cboId, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel3, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.lstListOfModules, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.dtpStartDate, 1, 7)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 8
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 147.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 124.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(417, 516)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 482)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 17)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Start date:"
        '
        'cboYear
        '
        Me.cboYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYear.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboYear, "Select a year to get the corresponding list of students as well as modules below " & _
        "in Id  and List of Modules section.")
        Me.cboYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboYear.Location = New System.Drawing.Point(125, 7)
        Me.cboYear.Name = "cboYear"
        Me.HelpProvider1.SetShowHelp(Me.cboYear, True)
        Me.cboYear.Size = New System.Drawing.Size(268, 25)
        Me.cboYear.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboYear, "Year")
        '
        'dtpStartDate
        '
        Me.dtpStartDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.dtpStartDate, "Select a date when the module will be started teaching.")
        Me.dtpStartDate.Location = New System.Drawing.Point(125, 478)
        Me.dtpStartDate.Name = "dtpStartDate"
        Me.HelpProvider1.SetShowHelp(Me.dtpStartDate, True)
        Me.dtpStartDate.Size = New System.Drawing.Size(262, 25)
        Me.dtpStartDate.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.dtpStartDate, "Start date")
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(425, 539)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select module for student"
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(138, 4)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(3, 4)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.btnClear)
        Me.Panel2.Controls.Add(Me.btnSave)
        Me.Panel2.Location = New System.Drawing.Point(143, 551)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(266, 43)
        Me.Panel2.TabIndex = 23
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'StudentModuleAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "StudentModuleAddNew"
        Me.Size = New System.Drawing.Size(1081, 606)
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        CType(Me.grdStudentModule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents cboSemester As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lstSelectedModule As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents cboFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cboId As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lstListOfModules As System.Windows.Forms.ListBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cboYear As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dtpStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents grdStudentModule As System.Windows.Forms.DataGridView
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider

End Class
