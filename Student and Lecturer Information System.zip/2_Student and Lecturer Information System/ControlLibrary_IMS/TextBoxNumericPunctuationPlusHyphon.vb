﻿Public Class TextBoxNumericPunctuationPlusHyphon
    Inherits TextBox

    Protected Overrides Sub OnKeyPress(e As KeyPressEventArgs)
        MyBase.OnKeyPress(e)

        Dim s As String = "+- ()"

        If Not Char.IsDigit(e.KeyChar) And Not Asc(e.KeyChar) = 8 And Not s.Contains(e.KeyChar) Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub
End Class
