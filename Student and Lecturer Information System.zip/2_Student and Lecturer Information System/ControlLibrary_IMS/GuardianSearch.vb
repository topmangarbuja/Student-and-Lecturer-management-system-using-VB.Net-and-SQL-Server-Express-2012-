﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class GuardianSearch
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtGuardianList As New DataTable
    Dim dtRelationship As New DataTable
    Dim strStudentId As String
    Dim strGuardianFirstName As String
    Dim strGuardianLastName As String
    Dim blnDeleteSucceed As Boolean
    Dim rowNumber As Int16

    'FORM LOAD EVENT
    Private Sub GuardianSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Clear the searching fields
        ClearSearchingFields()

        'Get list of relationship in the combobox
        GetRelationship()

        'Disable the controls of view sections
        DisableControls()
    End Sub

    'METHOD: GET STUDENT AND GUARDIAN DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetStudentAndGuardianList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'METHOD:GET LIST OF RELATIONSHIP 
    Private Sub GetRelationship()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT DISTINCT Relationship FROM Guardian; "

        'Call GetStudentName method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Relationship | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtRelationship = dataAccess.dtListForComboBox
            cboRelationship.DataSource = dtRelationship
            cboRelationship.DisplayMember = "Relationship"
        End If
    End Sub

    'METHOD: REMOVE THE SEARCHING FIELDS
    Private Sub ClearSearchingFields()
        'Clear other textboxes and combobox items
        txtStudentId.Clear()
        txtStudentFirstName.Clear()
        txtStudentLastName.Clear()
        txtGuardianFirstName.Clear()
        txtGuardianLastName.Clear()
        txtPhoneNumber.Clear()
        txtRelationship.Clear()
    End Sub

    'METHOD:FILL DATAGRIDVIEW CONTROL
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdGuardian.DataSource = Nothing

            'Get the table data
            dtGuardianList = dataAccess.objDataSet.Tables(0)

            'Get the datasource for datagridview
            grdGuardian.DataSource = dtGuardianList


            GblAccessItem.DataTableGuardianSearchView = dataAccess.AutoNumberedTable(dtGuardianList)

            If grdGuardian.RowCount > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If
            'List the number of rows in the result
            lblResult.Text = grdGuardian.RowCount

            grdGuardian.Columns(0).Frozen = True
        End If

        'Call procedure:make sure that the View sections control are disabled
        DisableControls()
    End Sub

    Private Sub txtSearchingFields_Enter(Sender As Object, e As EventArgs) Handles txtStudentId.Enter, txtStudentFirstName.Enter, txtStudentLastName.Enter, txtGuardianFirstName.Enter, txtGuardianLastName.Enter, txtPhoneNumber.Enter, txtRelationship.Enter
        'Clear the searching fields
        ClearSearchingFields()

        'Set the datasource property of datagridview to nothing
        grdGuardian.DataSource = Nothing

        If grdGuardian.RowCount > 0 Then
            'Enable the GetReport button
            btnGetReport.Enabled = True
        Else
            'Disable the GetReport button
            btnGetReport.Enabled = False
        End If

        'List the number of rows in the result
        lblResult.Text = grdGuardian.RowCount
    End Sub

    'TEXTCHANGED EVENT OF STUDENTID TEXTBOX
    Private Sub txtStudentId_TextChanged(sender As Object, e As EventArgs) Handles txtStudentId.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE Student.StudentId LIKE '%" & txtStudentId.Text & "%';")

    'Fill the datagridview
        FillDataGridView()
    End Sub



    'TEXTCHANGED EVENT OF STUDENT FIRSTNAME TEXTBOX
    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtStudentFirstName.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE Student.FirstName LIKE '%" & txtStudentFirstName.Text & "%';")

      'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF LASTNAME TEXTBOX
    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtStudentLastName.TextChanged
       'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE Student.LastName LIKE '%" & txtStudentLastName.Text & "%';")

       'Fill the datagridview
        FillDataGridView()
    End Sub


    'TEXTCHANGED EVENT OF GUARDIAN FIRSTNAME TEXTBOX
    Private Sub txtGuardianFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtGuardianFirstName.TextChanged
       'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name],Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE Guardian.FirstName LIKE '%" & txtGuardianFirstName.Text & "%';")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF GUARDIAN LASTNAME TEXTBOX
    Private Sub txtGuardianLastName_TextChanged(sender As Object, e As EventArgs) Handles txtGuardianLastName.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE Guardian.LastName LIKE '%" & txtGuardianLastName.Text & "%';")

   'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF PHONE NUMBER TEXTBOX
    Private Sub txtPhoneNumber_TextChanged(sender As Object, e As EventArgs) Handles txtPhoneNumber.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName, PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE PhoneNo LIKE '%" & txtPhoneNumber.Text & "%';")

     'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF RELATIONSHIP TEXTBOX
    Private Sub txtRelationship_TextChanged(sender As Object, e As EventArgs) Handles txtRelationship.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName, PhoneNo As [Phone number], Relationship " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "WHERE Relationship LIKE '%" & txtRelationship.Text & "%';")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'CLICK EVENT OF VIEWALL STUDENTS BUTTON
    Private Sub btnViewAllGuardians_Click(sender As Object, e As EventArgs) Handles btnViewAllGuardians.Click
        'Get list of students
        GetStudentAndGuardianList()
    End Sub






    'EVENTS AND METHODS FOR THE DATAGRIDVIEW SECTION
    'METHOD: GET STUDENT AND GUARDIAN DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetGuardianList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT StudentId, FirstName As [Guardian First Name], LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
            "FROM Guardian " & _
            "WHERE StudentId='" & strStudentId & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdGuardian.DataSource = Nothing

            'Get the datasource for datagridview
            grdGuardian.DataSource = dataAccess.objDataSet.Tables(0)

            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand
        End If

        'Call procedure: Make sure the gridview sections are set to default 
        'SetControlsToDefault()
    End Sub

    'CELLCLICK EVENT OF STUDENTMODULE DATAGRIDVIEW
    Private Sub grdGuardian_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdGuardian.CellClick
        If grpEdit.Visible = True Then
            rowNumber = grdGuardian.CurrentCell.RowIndex

            'Clear the fields in the view sections
            ClearFields()

            'Enable the controls of view sections
            EnableControls()

            For i As Integer = 0 To grdGuardian.ColumnCount - 1
                Try
                    Select Case i
                        Case 0
                            strStudentId = grdGuardian.Item(0, e.RowIndex).Value
                            txtViewStudentId.Text = grdGuardian.Item(0, e.RowIndex).Value
                        Case 1
                            txtViewStudentName.Text = grdGuardian.Item(1, e.RowIndex).Value
                        Case 2
                            strGuardianFirstName = grdGuardian.Item(2, e.RowIndex).Value
                            txtViewGuardianFirstName.Text = grdGuardian.Item(2, e.RowIndex).Value

                        Case 3
                            strGuardianLastName = grdGuardian.Item(3, e.RowIndex).Value
                            txtViewGuardianLastName.Text = grdGuardian.Item(3, e.RowIndex).Value

                        Case 4
                            txtViewPhoneNumber.Text = grdGuardian.Item(4, e.RowIndex).Value
                        Case 5
                            cboRelationship.Text = grdGuardian.Item(5, e.RowIndex).Value
                    End Select

                Catch ex As Exception

                End Try
            Next
          

            'Make sure that the Update button is disabled
            btnUpdate.Enabled = False
        End If
    End Sub

    ''CELL VALUE CHANGED EVENT OF STUDENTMODULE DATAGRIDVIEW
    'Private Sub grdGuardian_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles grdGuardian.CellValueChanged
    '    'objCommand = New SqlCommand
    '    'objCommand.CommandText = "UPDATE Guardian " & _
    '    '    "SET FirstName=@firstName, " & _
    '    '    "LastName=@lastName, " & _
    '    '    "PhoneNo=@phoneNo, " & _
    '    '    "Relationship=@relationship " & _
    '    '    "WHERE StudentId=@studentId " & _
    '    '    "AND FirstName=@previousFirstName " & _
    '    '    "AND LastName=@previousLastName;"

    '    ''Add parameters for the placeholder in the SQL CommandText property..
    '    'objCommand.Parameters.AddWithValue("@firstName", grdGuardian.Item(2, e.RowIndex).Value)
    '    'objCommand.Parameters.AddWithValue("@lastName", grdGuardian.Item(3, e.RowIndex).Value)
    '    'objCommand.Parameters.AddWithValue("@phoneNo", grdGuardian.Item(4, e.RowIndex).Value)
    '    'objCommand.Parameters.AddWithValue("@relationship", grdGuardian.Item(5, e.RowIndex).Value)
    '    'objCommand.Parameters.AddWithValue("@studentId", strStudentId)
    '    'objCommand.Parameters.AddWithValue("@previousFirstName", strGuardianFirstName)
    '    'objCommand.Parameters.AddWithValue("@previousLastName", strGuardianLastName)


    '    ''Call RunQuery method to update the guardian details
    '    'dataAccess.RunQuery(objCommand)

    '    ''Check for errors
    '    'If dataAccess.strExceptionRunQuery <> "" Then
    '    '    'Show error message
    '    '    MessageBox.Show(dataAccess.strExceptionRunQuery, "Update Guardian | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    '    'Set the variable to nothing
    '    '    dataAccess.strExceptionRunQuery = Nothing
    '    'ElseIf dataAccess.intCountRecord = 1 Then
    '    '    'Show message box
    '    '    MessageBox.Show("The modification that you have made is successfully saved.", "Guardian Details Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '    'ElseIf dataAccess.intCountRecord = 0 Then
    '    '    'Show error add message
    '    '    MsgBox("There's no student with details: |" & strStudentId & "|.", MsgBoxStyle.Exclamation, "Student Details")

    '    'End If
    'End Sub

    ''USERDELETED ROW EVENT OF STUDENTMODULE DATAGRIDVIEW
    'Private Sub grdGuardian_UserDeletedRow(sender As Object, e As DataGridViewRowEventArgs) Handles grdGuardian.UserDeletedRow
    '    If blnDeleteSucceed = True Then
    '        'Show message box
    '        MessageBox.Show("The modification that you have made is successfully saved.", "Guardian Details Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

    '        'Set the boolean value itself to false
    '        blnDeleteSucceed = False
    '    End If
    'End Sub

    ''USERDELETINGROW EVENT OF STUDENTMODULE DATAGRIDVIEW
    'Private Sub grdGuardian_UserDeletingRow(sender As Object, e As DataGridViewRowCancelEventArgs) Handles grdGuardian.UserDeletingRow
    '    If grdGuardian.ReadOnly = False Then
    '        objCommand = New SqlCommand
    '        objCommand.CommandText = "DELETE FROM Guardian " & _
    '           "WHERE StudentId=@studentId " & _
    '        "AND FirstName=@FirstName " & _
    '        "AND LastName=@LastName;"

    '        'Add parameters for the placeholder in the SQL CommandText property..
    '        objCommand.Parameters.AddWithValue("@studentId", strStudentId)
    '        objCommand.Parameters.AddWithValue("@FirstName", strGuardianFirstName)
    '        objCommand.Parameters.AddWithValue("@LastName", strGuardianLastName)

    '        'Call RunQuery method to delete guardian details
    '        dataAccess.RunQuery(objCommand)

    '        'Check for errors
    '        If dataAccess.strExceptionRunQuery <> "" Then
    '            'Show error message
    '            MessageBox.Show(dataAccess.strExceptionRunQuery, "Delete Guardian Details | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '            'Set the variable to nothing
    '            dataAccess.strExceptionRunQuery = Nothing

    '            'Cancel the delete process
    '            e.Cancel = True

    '            'Set the boolean value to false
    '            blnDeleteSucceed = False
    '        ElseIf dataAccess.intCountRecord = 1 Then
    '            'Do not cancel the delete process
    '            e.Cancel = False

    '            'Set the boolean value to true
    '            blnDeleteSucceed = True
    '        ElseIf dataAccess.intCountRecord = 0 Then
    '            'Show error add message
    '            MsgBox("There's no student with details: |" & strStudentId & "|.", MsgBoxStyle.Exclamation, "Student Module Details")

    '            'Cancel the delete process
    '            e.Cancel = True
    '        End If
    '    Else
    '        'Cancel the delete process
    '        e.Cancel = True
    '    End If
    'End Sub

    'CLICK EVENT OF SAVE BUTTON
  
    'CELLVALUECHANGED EVENT OF GRIDVIEW 

    Private Sub DisableControls()
        txtViewStudentId.Enabled = False
        txtViewStudentName.Enabled = False
        txtViewGuardianFirstName.Enabled = False
        txtViewGuardianLastName.Enabled = False
        txtViewPhoneNumber.Enabled = False
        cboRelationship.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    Private Sub EnableControls()
        txtViewStudentId.Enabled = True
        txtViewStudentName.Enabled = True
        txtViewGuardianFirstName.Enabled = True
        txtViewGuardianLastName.Enabled = True
        txtViewPhoneNumber.Enabled = True
        cboRelationship.Enabled = True
        'btnUpdate.Enabled = True
        btnDelete.Enabled = True
    End Sub


    'METHOD: REMOVE THE FIELDS IN THE VIEW SECTIONS
    Private Sub ClearFields()
        'Clear other textboxes and combobox items
        txtViewStudentId.Clear()
        txtViewStudentName.Clear()
        txtViewGuardianFirstName.Clear()
        txtViewGuardianLastName.Clear()
        txtViewPhoneNumber.Clear()
        cboRelationship.Text = ""
    End Sub

    Private Sub txtViewGuardianFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtViewGuardianFirstName.TextChanged, txtViewGuardianLastName.TextChanged, txtViewPhoneNumber.TextChanged, cboRelationship.SelectedIndexChanged, cboRelationship.TextChanged
        'Enable the update button
        btnUpdate.Enabled = True
    End Sub


    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckGuardianFirstNameAndLastName() As Boolean
        If txtViewGuardianFirstName.Text.Trim.Length > 0 And txtViewGuardianLastName.Text.Trim.Length > 0 Then
            Return True
        ElseIf txtViewGuardianFirstName.Text.Trim.Length <= 0 And txtViewGuardianLastName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter guardian first name and last name.", "Guardian Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtViewGuardianFirstName.Text.Trim.Length <= 0 And txtViewGuardianLastName.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter guardian first name.", "Guardian Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            MessageBox.Show("You have to enter guardian last name.", "Guardian Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If CheckGuardianFirstNameAndLastName() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update guardian: |" & strGuardianFirstName & "| (" & strGuardianLastName & ") details?", "Guardian Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                objCommand = New SqlCommand
                objCommand.CommandText = "UPDATE Guardian " & _
                    "SET FirstName=@firstName, " & _
                    "LastName=@lastName, " & _
                    "PhoneNo=@phoneNo, " & _
                    "Relationship=@relationship " & _
                    "WHERE StudentId=@studentId " & _
                    "AND FirstName=@previousFirstName " & _
                    "AND LastName=@previousLastName;"

                'Add parameters for the placeholder in the SQL CommandText property..
                objCommand.Parameters.AddWithValue("@firstName", txtViewGuardianFirstName.Text)
                objCommand.Parameters.AddWithValue("@lastName", txtViewGuardianLastName.Text)
                objCommand.Parameters.AddWithValue("@phoneNo", txtViewPhoneNumber.Text)
                objCommand.Parameters.AddWithValue("@relationship", cboRelationship.Text)
                objCommand.Parameters.AddWithValue("@studentId", strStudentId)
                objCommand.Parameters.AddWithValue("@previousFirstName", strGuardianFirstName)
                objCommand.Parameters.AddWithValue("@previousLastName", strGuardianLastName)


                'Call RunQuery method to update the guardian details
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MessageBox.Show(dataAccess.strExceptionRunQuery, "Update Guardian | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show message box
                    MessageBox.Show("The guardian  details of student:|" & strStudentId & "| have been successfully updated.", "Guardian Details | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    'Get list of name and id and phone
                    dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (Student.FirstName+' ' + Student.LastName) As [Student Name], Guardian.FirstName As [Guardian First Name], Guardian.LastName As [Guardian Last Name], PhoneNo As [Phone number], Relationship " & _
                        "FROM Student " & _
                        "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
                        "WHERE Student.StudentId = '" & strStudentId & "';")

                    'Fill the datagridview
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error add message
                    MsgBox("There's no guardian: " & strGuardianFirstName & " " & strGuardianLastName & " of student: (" & strStudentId & ").", MsgBoxStyle.Exclamation, "Guardian Details")

                    'Call procedure to get list of guardians
                    btnViewAllGuardians_Click(Nothing, Nothing)
                End If

                'Call ClearFields method to clear the text of the View sections
                ClearFields()
            End If
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Do you really want to delete guardian: |" & strGuardianFirstName & "| (" & strGuardianLastName & ") details?", "Guardian Details", _
                          MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            objCommand = New SqlCommand
            objCommand.CommandText = "DELETE FROM Guardian " & _
               "WHERE StudentId=@studentId " & _
            "AND FirstName=@FirstName " & _
            "AND LastName=@LastName;"

            'Add parameters for the placeholder in the SQL CommandText property..
            objCommand.Parameters.AddWithValue("@studentId", strStudentId)
            objCommand.Parameters.AddWithValue("@FirstName", strGuardianFirstName)
            objCommand.Parameters.AddWithValue("@LastName", strGuardianLastName)

            'Call RunQuery method to delete guardian details
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionRunQuery, "Delete Guardian | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show message box
                MessageBox.Show("The guardian details of student:|" & strStudentId & "| have been successfully deleted.", "Guardian Details | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Remove a record from the datagridview
                grdGuardian.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdGuardian.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show error add message
                MsgBox("There's no guardian: " & strGuardianFirstName & " " & strGuardianLastName & " of student: (" & strStudentId & ").", MsgBoxStyle.Exclamation, "Guardian Details")

                'Call procedure to get list of guardians
                btnViewAllGuardians_Click(Nothing, Nothing)
            End If

            'Call ClearFields method to clear the text of the View sections
            ClearFields()

            'Disable the controls in the Edit sections
            DisableControls()
        End If
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "GuardianSearchView"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub




    Private Sub btnShowEditSection_Click(sender As Object, e As EventArgs) Handles btnShowEditSection.Click
        'Dim s As Point = pnlListOfStudent.Location
        If btnShowEditSection.Text = "Show Edit section" Then
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X - 235
            pnlListOfStudent.Location = p

            grpResult.Size = New Size(742, 341)


            Dim g As Point = grpResult.Location
            g.X = grpResult.Width + 20
            grpEdit.Location = g



            grpEdit.Visible = True
            lblDetails.Visible = True

            btnShowEditSection.Text = "Hide Edit section"
        Else
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X + 235
            pnlListOfStudent.Location = p


            grpResult.Size = New Size(1140, 341)


            grpEdit.Visible = False
            lblDetails.Visible = False

            btnShowEditSection.Text = "Show Edit section"

            'Disable the controls of the textboxes and buttons
            DisableControls()
        End If

        'First clear the text fields
        ClearFields()
    End Sub
End Class