﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class StudentAddEmail
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtStudentList As New DataTable
    Dim strExceptionId As String = "errStudentId"
    Dim strExceptionEmail As String = "errEmailAddress"


    'METHOD: GET STUDENT ID AND NAME BASED ON COMBOBOX SELECTION
    Private Sub GetStudentIdAndName()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Student;"

        'Call GetStudentName method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtStudentList = dataAccess.dtListForComboBox
            cboId.DataSource = dtStudentList
            cboId.DisplayMember = "StudentId"

            If cboId.Text = "" Then
                txtName.Clear()
            Else
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Check whether to enable save button or not
                EnabledSaveButton()
            End If
        End If
    End Sub

    'FORM LOAD EVENT 
    Private Sub StudentAddPhone_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Get list of students for combobox
        GetStudentIdAndName()
    End Sub

    Private Sub txtEmailAddress_TextChanged(sender As Object, e As EventArgs) Handles txtEmailAddress.TextChanged
        'Enable save button
        btnSave.Enabled = True
    End Sub

    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
    Private Sub cboId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
        'Clear any previous bindings..
        txtName.DataBindings.Clear()

        'Binding process
        txtName.DataBindings.Add("Text", dtStudentList, "Name")

        'Refresh datagridview
        GetStudentIdAndNameAndEmail()
    End Sub

    'CLICK EVENT TO SAVE STUDENT PHONE NUMBER
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtEmailAddress.Text.Trim.Length > 8 Then
            If CheckEmail() = True Then
                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you want to add the following email address information?")
                objStringBuilder.AppendLine(String.Empty)
                objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
                objStringBuilder.AppendLine("Phone-Info: " & txtEmailAddress.Text)

                'Show message box
                If MessageBox.Show(objStringBuilder.ToString, "Add New Email Address", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    objCommand = New SqlCommand
                    objCommand.CommandText = "INSERT INTO StudentEmailId " & _
                        "VALUES(@studentId,@emailId); "

                    'Add parameters for the placeholder in the SQL CommandText property..
                    objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
                    objCommand.Parameters.AddWithValue("@emailId", txtEmailAddress.Text)

                    'Call AddDetails method to add phone number
                    dataAccess.AddDetails(objCommand)

                    'Check for errors
                    If dataAccess.strExceptionAddDetails <> "" Then
                        If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                            'Show error message
                            MessageBox.Show("This email address of the student already exists.", "Email Address | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Else
                            'Show error message
                            MessageBox.Show(dataAccess.strExceptionAddDetails, "Email Address | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If

                        'Set the variable to nothing
                        dataAccess.strExceptionAddDetails = Nothing

                        'Select and focus on phone number textbox
                        txtEmailAddress.SelectAll()
                        txtEmailAddress.Focus()
                    Else
                        'If there is no error, show succeed message

                        Dim objStringBuilder1 As New System.Text.StringBuilder
                        objStringBuilder1.AppendLine("The following email address information has been successfully added.")
                        objStringBuilder1.AppendLine(String.Empty)
                        objStringBuilder1.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
                        objStringBuilder1.AppendLine("Email-Info: " & txtEmailAddress.Text)

                        'Show message box
                        MessageBox.Show(objStringBuilder1.ToString, "Email Address | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        'Clear and focus on email address textbox
                        txtEmailAddress.Clear()
                        txtEmailAddress.Focus()

                        'Refresh datagridview
                        GetStudentIdAndNameAndEmail()
                    End If
                End If
            End If
        Else
            'Show error message
            MsgBox("The email address must be at least greater than 8 digits.", MsgBoxStyle.Exclamation, "Student email address details")

            'Select and focus on email address textbox
            txtEmailAddress.SelectAll()
            txtEmailAddress.Focus()
        End If
        
    End Sub

    Private Sub EnabledSaveButton()
        If strExceptionId = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub cboId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboId.Validating
        'Check if the student already exists
        If cboId.Text.Trim.Length = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSetStudentCheck IsNot Nothing Then
                dataAccess.objDataSetStudentCheck.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSetIdCheck("SELECT *  " & _
                "FROM Student " & _
                "WHERE StudentId LIKE '%" & cboId.Text & "%';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSetIdCheck <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSetIdCheck, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSetIdCheck = Nothing
            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 1 Then
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 0 Then
                strExceptionId = "This student does not exist."
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtName.Clear()
            End If
        Else
            strExceptionId = "Select or enter 12 character student Id."
            ErrorProvider1.SetError(cboId, strExceptionId)

            'Clear the name textbox
            txtName.Clear()
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtEmailAddress_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmailAddress.KeyPress
        Dim ac As String = "@"
        If e.KeyChar <> ChrW(Keys.Back) Then
            If Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then
                If Asc(e.KeyChar) <> 46 And Asc(e.KeyChar) <> 95 Then
                    If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                        If ac.IndexOf(e.KeyChar) = -1 Then
                            e.Handled = True

                        Else

                            If txtEmailAddress.Text.Contains("@") And e.KeyChar = "@" Then
                                e.Handled = True
                            End If

                        End If
                    End If
                End If
            End If

        End If
    End Sub


    Private Function CheckEmail() As Boolean
        Dim pattern As String = "^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$"
        Dim match As System.Text.RegularExpressions.Match = System.Text.RegularExpressions.Regex.Match(txtEmailAddress.Text.Trim(), pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase)
        If (match.Success) Then
            Return True

            'Check whether to enable save button or not
            'EnabledSaveButton()
        Else
            'Show error message
            MsgBox("Type email address in a valid format.", MsgBoxStyle.Exclamation, "Student email address details")

            'Clear and focus on email address textbox
            txtEmailAddress.SelectAll()
            txtEmailAddress.Focus()

            Return False
        End If
    End Function

    'LIST OF METHOD FOR THE DATAGRIDVIEW SECTION
    'METHOD: GET STUDENT ID AND NAME AND EMAIL ADDRESS FOR THE DATAGRIDVIEW
    Private Sub GetStudentIdAndNameAndEmail()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name, EmailId As [Email address] " & _
            "FROM Student " & _
            "JOIN StudentEmailId ON Student.StudentId=StudentEmailId.StudentId " & _
            "WHERE Student.StudentId='" & cboId.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdEmail.DataSource = Nothing

            'Get the datasource for datagridview
            grdEmail.DataSource = dataAccess.objDataSet.Tables(0)

            'Make sure the following changes
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Make DataGridView ReadOnly property to true
            grdEmail.ReadOnly = True


            If grdEmail.RowCount > 0 Then
                'Enable the Enable edit button
                btnEnableEdit.Enabled = True
            Else
                'Disable the Enable edit button
                btnEnableEdit.Enabled = False
            End If

            grdEmail.Columns(1).Frozen = True
        End If
    End Sub

    'METHOD: GET STUDENT ID AND EMAIL ADDRESS FOR THE DATAGRIDVIEW FROM A SINGLE TABLE
    Private Sub GetStudentIdAndEmail()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT StudentId As [Student Id],EmailId As [Email address] " & _
            "FROM StudentEmailId " & _
            "WHERE StudentId='" & cboId.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdEmail.DataSource = Nothing

            'Get the datasource for datagridview
            grdEmail.DataSource = dataAccess.objDataSet.Tables(0)

            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand
        End If
    End Sub
    Private Sub btnEnableEdit_Click(sender As Object, e As EventArgs) Handles btnEnableEdit.Click
        If btnEnableEdit.Text = "Enable Edit" Then
            'Change the text
            btnEnableEdit.Text = "Disable Edit"

            'Fill datagridview from a single phone number table
            GetStudentIdAndEmail()

            'Make the GridView readonly property to false
            grdEmail.ReadOnly = False

            'Allow user to delete rows
            grdEmail.AllowUserToDeleteRows = True

            'Make sure the the 1st column is unable to edit
            grdEmail.Columns(0).ReadOnly = True
        Else
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Fill datagridview
            GetStudentIdAndNameAndEmail()

            'Make the GridView readonly property to true
            grdEmail.ReadOnly = True

            'Do not allow user to delete rows
            grdEmail.AllowUserToDeleteRows = False
        End If
    End Sub

    Private Sub btnGrdSave_Click(sender As Object, e As EventArgs) Handles btnGrdSave.Click
        'Show question box
        If MessageBox.Show("Do you want to save the modification that you have made?", "Email Address Modification", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                'Save updates to the datbase
                dataAccess.objDataAdapter.Update(dataAccess.objDataSet)

                'Change the text
                btnEnableEdit.Text = "Enable Edit"

                'Fill datagridview from a single phone number table
                GetStudentIdAndEmail()

                'Show message box
                MessageBox.Show("The modification that you have made is successfully saved.", "Email Address Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Make sure the the 1st column is unable to edit
                grdEmail.Columns(0).ReadOnly = True

                'Disable the Save button inside 'View and Modify' groupbox
                btnGrdSave.Enabled = False
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        'Fill datagridview 
        GetStudentIdAndNameAndEmail()
    End Sub

    Private Sub grdEmail_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles grdEmail.CellValueChanged
        'Enable the save button
        btnGrdSave.Enabled = True
    End Sub

    Private Sub grdEmail_UserDeletedRow(sender As Object, e As DataGridViewRowEventArgs) Handles grdEmail.UserDeletedRow
        'Enable the save button
        btnGrdSave.Enabled = True
    End Sub


    'CLICK EVENT OF SAVE BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear and focus on email address textbox
        txtEmailAddress.Clear()
        txtEmailAddress.Focus()
    End Sub
End Class
