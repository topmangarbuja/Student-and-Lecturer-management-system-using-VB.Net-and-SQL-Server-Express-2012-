﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IssueView
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnView = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdbBoth = New System.Windows.Forms.RadioButton()
        Me.rdbLecturer = New System.Windows.Forms.RadioButton()
        Me.rdbStudent = New System.Windows.Forms.RadioButton()
        Me.cboRemarks = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtViewAuthor = New ControlLibrary_IMS.TextBoxAuthorName()
        Me.dtpViewIssueTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtViewName = New System.Windows.Forms.TextBox()
        Me.txtViewId = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dtpViewReturnTime = New System.Windows.Forms.DateTimePicker()
        Me.txtViewIsbn = New ControlLibrary_IMS.TextBoxNumericAndHyphon()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.dtpViewReturnDate = New System.Windows.Forms.DateTimePicker()
        Me.dtpViewIssueDate = New System.Windows.Forms.DateTimePicker()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtViewTitle = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cboViewRemarks = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.grdBookIssue = New System.Windows.Forms.DataGridView()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdBookIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnView
        '
        Me.btnView.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnView.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnView.Location = New System.Drawing.Point(81, 73)
        Me.btnView.Margin = New System.Windows.Forms.Padding(4)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(143, 31)
        Me.btnView.TabIndex = 56
        Me.btnView.TabStop = False
        Me.btnView.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnView, "View all of library books based on the selection of this section.")
        Me.btnView.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(318, 133)
        Me.GroupBox1.TabIndex = 55
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select and view:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.cboRemarks, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.btnView, 1, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(312, 109)
        Me.TableLayoutPanel1.TabIndex = 45
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 10)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 17)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Select:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rdbBoth)
        Me.Panel1.Controls.Add(Me.rdbLecturer)
        Me.Panel1.Controls.Add(Me.rdbStudent)
        Me.Panel1.Location = New System.Drawing.Point(80, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(227, 32)
        Me.Panel1.TabIndex = 46
        '
        'rdbBoth
        '
        Me.rdbBoth.AutoSize = True
        Me.rdbBoth.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbBoth.Location = New System.Drawing.Point(169, 6)
        Me.rdbBoth.Name = "rdbBoth"
        Me.rdbBoth.Size = New System.Drawing.Size(56, 21)
        Me.rdbBoth.TabIndex = 57
        Me.rdbBoth.Text = "Both"
        Me.ToolTip1.SetToolTip(Me.rdbBoth, "Both")
        Me.rdbBoth.UseVisualStyleBackColor = True
        '
        'rdbLecturer
        '
        Me.rdbLecturer.AutoSize = True
        Me.rdbLecturer.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbLecturer.Location = New System.Drawing.Point(83, 6)
        Me.rdbLecturer.Name = "rdbLecturer"
        Me.rdbLecturer.Size = New System.Drawing.Size(80, 21)
        Me.rdbLecturer.TabIndex = 23
        Me.rdbLecturer.Text = "Lecturer"
        Me.ToolTip1.SetToolTip(Me.rdbLecturer, "Lecturer")
        Me.rdbLecturer.UseVisualStyleBackColor = True
        '
        'rdbStudent
        '
        Me.rdbStudent.AutoSize = True
        Me.rdbStudent.Checked = True
        Me.rdbStudent.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbStudent.Location = New System.Drawing.Point(3, 6)
        Me.rdbStudent.Name = "rdbStudent"
        Me.rdbStudent.Size = New System.Drawing.Size(74, 21)
        Me.rdbStudent.TabIndex = 22
        Me.rdbStudent.TabStop = True
        Me.rdbStudent.Text = "Student"
        Me.ToolTip1.SetToolTip(Me.rdbStudent, "Student")
        Me.rdbStudent.UseVisualStyleBackColor = True
        '
        'cboRemarks
        '
        Me.cboRemarks.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboRemarks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRemarks.FormattingEnabled = True
        Me.cboRemarks.Items.AddRange(New Object() {"Borrowed", "Returned", "Lost", "All"})
        Me.cboRemarks.Location = New System.Drawing.Point(80, 41)
        Me.cboRemarks.Name = "cboRemarks"
        Me.cboRemarks.Size = New System.Drawing.Size(227, 25)
        Me.cboRemarks.TabIndex = 75
        Me.cboRemarks.TabStop = False
        Me.ToolTip1.SetToolTip(Me.cboRemarks, "Remarks")
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 45)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 17)
        Me.Label9.TabIndex = 74
        Me.Label9.Text = "Remarks:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TableLayoutPanel2)
        Me.GroupBox3.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(774, 182)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox3.Size = New System.Drawing.Size(384, 416)
        Me.GroupBox3.TabIndex = 71
        Me.GroupBox3.TabStop = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewAuthor, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewIssueTime, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewName, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label14, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewReturnTime, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewIsbn, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label26, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewReturnDate, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewIssueDate, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label15, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewTitle, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 1, 10)
        Me.TableLayoutPanel2.Controls.Add(Me.cboViewRemarks, 1, 9)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 11
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(374, 389)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'txtViewAuthor
        '
        Me.txtViewAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewAuthor.Location = New System.Drawing.Point(99, 145)
        Me.txtViewAuthor.MaxLength = 350
        Me.txtViewAuthor.Name = "txtViewAuthor"
        Me.txtViewAuthor.ReadOnly = True
        Me.txtViewAuthor.Size = New System.Drawing.Size(262, 25)
        Me.txtViewAuthor.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtViewAuthor, "Author")
        '
        'dtpViewIssueTime
        '
        Me.dtpViewIssueTime.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewIssueTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpViewIssueTime.Location = New System.Drawing.Point(100, 210)
        Me.dtpViewIssueTime.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewIssueTime.Name = "dtpViewIssueTime"
        Me.dtpViewIssueTime.ShowUpDown = True
        Me.dtpViewIssueTime.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewIssueTime.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.dtpViewIssueTime, "Issue time")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 312)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 17)
        Me.Label1.TabIndex = 71
        Me.Label1.Text = "Remarks:"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(5, 47)
        Me.Label16.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(48, 17)
        Me.Label16.TabIndex = 68
        Me.Label16.Text = "Name:"
        '
        'txtViewName
        '
        Me.txtViewName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewName.Location = New System.Drawing.Point(101, 43)
        Me.txtViewName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewName.Name = "txtViewName"
        Me.txtViewName.ReadOnly = True
        Me.txtViewName.Size = New System.Drawing.Size(260, 25)
        Me.txtViewName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtViewName, "Name")
        '
        'txtViewId
        '
        Me.txtViewId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewId.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewId.Location = New System.Drawing.Point(101, 6)
        Me.txtViewId.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewId.Name = "txtViewId"
        Me.txtViewId.ReadOnly = True
        Me.txtViewId.Size = New System.Drawing.Size(260, 25)
        Me.txtViewId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtViewId, "Id")
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 10)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(25, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Id:"
        '
        'dtpViewReturnTime
        '
        Me.dtpViewReturnTime.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewReturnTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpViewReturnTime.Location = New System.Drawing.Point(100, 276)
        Me.dtpViewReturnTime.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewReturnTime.Name = "dtpViewReturnTime"
        Me.dtpViewReturnTime.ShowUpDown = True
        Me.dtpViewReturnTime.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewReturnTime.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.dtpViewReturnTime, "Return time")
        '
        'txtViewIsbn
        '
        Me.txtViewIsbn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewIsbn.Location = New System.Drawing.Point(99, 77)
        Me.txtViewIsbn.MaxLength = 17
        Me.txtViewIsbn.Name = "txtViewIsbn"
        Me.txtViewIsbn.ReadOnly = True
        Me.txtViewIsbn.Size = New System.Drawing.Size(260, 25)
        Me.txtViewIsbn.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtViewIsbn, "Isbn no")
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(5, 280)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 17)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Return time:"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(5, 247)
        Me.Label13.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 17)
        Me.Label13.TabIndex = 69
        Me.Label13.Text = "Return date:"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(5, 214)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(75, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Issue time:"
        '
        'dtpViewReturnDate
        '
        Me.dtpViewReturnDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewReturnDate.Location = New System.Drawing.Point(100, 243)
        Me.dtpViewReturnDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewReturnDate.Name = "dtpViewReturnDate"
        Me.dtpViewReturnDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewReturnDate.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.dtpViewReturnDate, "Return date")
        '
        'dtpViewIssueDate
        '
        Me.dtpViewIssueDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewIssueDate.Location = New System.Drawing.Point(100, 177)
        Me.dtpViewIssueDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewIssueDate.Name = "dtpViewIssueDate"
        Me.dtpViewIssueDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewIssueDate.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.dtpViewIssueDate, "Issue date")
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(5, 181)
        Me.Label15.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(74, 17)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Issue date:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 149)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "Author:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 115)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 17)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Title:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 81)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(43, 17)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "ISBN:"
        '
        'txtViewTitle
        '
        Me.txtViewTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewTitle.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewTitle.Location = New System.Drawing.Point(101, 111)
        Me.txtViewTitle.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewTitle.Name = "txtViewTitle"
        Me.txtViewTitle.ReadOnly = True
        Me.txtViewTitle.Size = New System.Drawing.Size(260, 25)
        Me.txtViewTitle.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtViewTitle, "Book title")
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnDelete)
        Me.Panel3.Controls.Add(Me.btnUpdate)
        Me.Panel3.Location = New System.Drawing.Point(99, 339)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(261, 38)
        Me.Panel3.TabIndex = 60
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(132, 3)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(2, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cboViewRemarks
        '
        Me.cboViewRemarks.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboViewRemarks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboViewRemarks.FormattingEnabled = True
        Me.cboViewRemarks.Items.AddRange(New Object() {"Borrowed", "Returned", "Lost"})
        Me.cboViewRemarks.Location = New System.Drawing.Point(99, 308)
        Me.cboViewRemarks.Name = "cboViewRemarks"
        Me.cboViewRemarks.Size = New System.Drawing.Size(262, 25)
        Me.cboViewRemarks.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.cboViewRemarks, "E")
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(911, 160)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 17)
        Me.Label18.TabIndex = 70
        Me.Label18.Text = "Details:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(294, 160)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 17)
        Me.Label3.TabIndex = 68
        Me.Label3.Text = "List of issued books:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btnGetReport)
        Me.GroupBox2.Controls.Add(Me.grdBookIssue)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 180)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(0)
        Me.GroupBox2.Size = New System.Drawing.Size(758, 418)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        '
        'btnGetReport
        '
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(290, 378)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 73
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'grdBookIssue
        '
        Me.grdBookIssue.AllowUserToAddRows = False
        Me.grdBookIssue.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdBookIssue.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdBookIssue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdBookIssue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdBookIssue.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdBookIssue.Location = New System.Drawing.Point(0, 18)
        Me.grdBookIssue.MultiSelect = False
        Me.grdBookIssue.Name = "grdBookIssue"
        Me.grdBookIssue.ReadOnly = True
        Me.grdBookIssue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdBookIssue.Size = New System.Drawing.Size(758, 350)
        Me.grdBookIssue.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdBookIssue, "Select a record and get the data in the Details section.")
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(450, 160)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 72
        Me.lblResult.Text = "0"
        '
        'IssueView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "IssueView"
        Me.Size = New System.Drawing.Size(1168, 607)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdBookIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnView As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents rdbLecturer As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStudent As System.Windows.Forms.RadioButton
    Friend WithEvents rdbBoth As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cboRemarks As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents dtpViewIssueTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtViewName As System.Windows.Forms.TextBox
    Friend WithEvents txtViewId As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents dtpViewReturnTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents dtpViewReturnDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpViewIssueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtViewTitle As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents cboViewRemarks As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents grdBookIssue As System.Windows.Forms.DataGridView
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtViewIsbn As ControlLibrary_IMS.TextBoxNumericAndHyphon
    Friend WithEvents txtViewAuthor As ControlLibrary_IMS.TextBoxAuthorName

End Class
