﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class LecturerAdditionalView
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtLecturerDetailsList As New DataTable
    Dim blnPhone As Boolean
    Dim strId As String
    Dim strPhone As String
    Dim strEmail As String
    Dim rowNumber As Int16

    'METHOD: GET ALL THE LecturerS DETAILS LIST
    Private Sub GetLecturerDetailsList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of active or inactive or both Lecturers
        If rdbActive.Checked = True And rdbPhoneNumber.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], PhoneNumber, Status  FROM Lecturer " & _
                                              "INNER JOIN LecturerPhoneNumber ON Lecturer.LecturerId=LecturerPhoneNumber.LecturerId " & _
                                              "WHERE Status='Active' " & _
            "ORDER BY Name;")
        ElseIf rdbActive.Checked = True And rdbEmailAddress.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], EmailId, Status  FROM Lecturer " & _
                                              "INNER JOIN LecturerEmailId ON Lecturer.LecturerId=LecturerEmailId.LecturerId " & _
                                              "WHERE Status='Active' " & _
            "ORDER BY Name;")

        ElseIf rdbInactive.Checked = True And rdbPhoneNumber.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], PhoneNumber, Status  FROM Lecturer " & _
                                              "INNER JOIN LecturerPhoneNumber ON Lecturer.LecturerId=LecturerPhoneNumber.LecturerId " & _
                                              "WHERE Status='Inactive' " & _
            "ORDER BY Name;")

        ElseIf rdbInactive.Checked = True And rdbEmailAddress.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], EmailId, Status  FROM Lecturer " & _
                                              "INNER JOIN LecturerEmailId ON Lecturer.LecturerId=LecturerEmailId.LecturerId " & _
                                              "WHERE Status='Inactive' " & _
            "ORDER BY Name;")


        ElseIf rdbBoth.Checked = True And rdbPhoneNumber.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], PhoneNumber, Status  FROM Lecturer " & _
                                              "INNER JOIN LecturerPhoneNumber ON Lecturer.LecturerId=LecturerPhoneNumber.LecturerId " & _
                                              "ORDER BY Status,Name;")


        ElseIf rdbBoth.Checked = True And rdbEmailAddress.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], EmailId, Status  FROM Lecturer " & _
                                              "INNER JOIN LecturerEmailId ON Lecturer.LecturerId=LecturerEmailId.LecturerId " & _
            "ORDER BY Status,Name;")

        End If

        If rdbPhoneNumber.Checked = True Then
            blnPhone = True

            GblAccessItem.blnLecturerPhone = True
        ElseIf rdbEmailAddress.Checked = True Then
            blnPhone = False

            GblAccessItem.blnLecturerPhone = False
        End If

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'METHOD: FILL THE DATAGRIDVIEW
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdLecturer.DataSource = Nothing

            'Get the table data
            dtLecturerDetailsList = dataAccess.objDataSet.Tables(0)

            'Get the datasource for datagridview
            grdLecturer.DataSource = dtLecturerDetailsList

            GblAccessItem.DataTableLecturerAdditionalView = dataAccess.AutoNumberedTable(dtLecturerDetailsList)

            If grdLecturer.RowCount > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = dtLecturerDetailsList.Rows.Count
        End If
    End Sub



    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        'Call procedure to get Lecturers details list
        GetLecturerDetailsList()

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub





    'METHODS AND EVENTS OF THE VIEW SECTIONS
    'CLEAR TEXT FIELD and SET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtId.Clear()
        txtName.Clear()
        txtPhoneNumber.Clear()
        txtEmailAddress.Clear()
    End Sub


    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtId.Enabled = True
        txtName.Enabled = True
        txtPhoneNumber.Enabled = True
        txtEmailAddress.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtId.Enabled = False
        txtName.Enabled = False
        txtPhoneNumber.Enabled = False
        txtEmailAddress.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub


    Private Sub grdLecturer_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdLecturer.CellClick
        'Get the selected row number
        rowNumber = grdLecturer.CurrentCell.RowIndex

        'Clear the fields
        ClearFields()

        'Enable the controls
        EnableControls()

        'Hide or show panel in the view sections
        If blnPhone = True Then
            pnlPhone.Visible = True
            pnlEmail.Visible = False
        Else
            pnlPhone.Visible = False
            pnlEmail.Visible = True
        End If

        For i As Integer = 0 To grdLecturer.ColumnCount - 1
            Try
                Select Case i
                    Case 0
                        strId = grdLecturer.Item(0, e.RowIndex).Value.ToString
                        txtId.Text = grdLecturer.Item(0, e.RowIndex).Value.ToString
                    Case 1
                        txtName.Text = grdLecturer.Item(1, e.RowIndex).Value.ToString
                    Case 2
                        If blnPhone = True Then
                            strPhone = ""
                            strPhone = grdLecturer.Item(2, e.RowIndex).Value.ToString
                            txtPhoneNumber.Text = grdLecturer.Item(2, e.RowIndex).Value.ToString
                        Else
                            strEmail = ""
                            strEmail = grdLecturer.Item(2, e.RowIndex).Value.ToString
                            txtEmailAddress.Text = grdLecturer.Item(2, e.RowIndex).Value.ToString
                        End If
                    Case 3

                End Select
            Catch ex As Exception

            End Try
        Next

        'Make sure that the update button is disabled
        btnUpdate.Enabled = False
    End Sub

    Private Sub LecturerAdditionalView_Load(sender As Object, e As EventArgs) Handles Me.Load
        'set the size of the group box
        grpDetails.Size = New Size(387, 216)

        'hide the Email panel
        pnlEmail.Visible = False

        'Disable the controls of the View sections
        DisabledControls()
    End Sub



    Private Function CheckPhone() As Boolean
        If txtPhoneNumber.Text.Trim.Length > 5 Then
            Return True
        Else

            'Show error message
            MsgBox("The phone number must be at least greater than 5 digits.", MsgBoxStyle.Exclamation, "Lecturer details")

            'select all and focus on phone number textbox
            txtPhoneNumber.SelectAll()
            txtPhoneNumber.Focus()

            Return False
        End If
    End Function

    Private Function CheckEmail() As Boolean
        If txtEmailAddress.Text.Trim.Length > 8 Then
            Dim pattern As String = "^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$"
            Dim match As System.Text.RegularExpressions.Match = System.Text.RegularExpressions.Regex.Match(txtEmailAddress.Text.Trim(), pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase)
            If (match.Success) Then
                Return True

                'Check whether to enable save button or not
                'EnabledSaveButton()
            Else
                'Show error message
                MsgBox("Type email address in a valid format.", MsgBoxStyle.Exclamation, "Lecturer email address details")

                'Clear and focus on email address textbox
                txtEmailAddress.SelectAll()
                txtEmailAddress.Focus()

                Return False
            End If
        Else
            'Show error message
            MsgBox("The email address must be at least greater than 8 digits.", MsgBoxStyle.Exclamation, "Lecturer email address details")

            'Select and focus on email address textbox
            txtEmailAddress.SelectAll()
            txtEmailAddress.Focus()

            Return False
        End If

    End Function

    Private Sub txtEmailAddress_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmailAddress.KeyPress
        Dim ac As String = "@"
        If e.KeyChar <> ChrW(Keys.Back) Then
            If Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then
                If Asc(e.KeyChar) <> 46 And Asc(e.KeyChar) <> 95 Then
                    If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                        If ac.IndexOf(e.KeyChar) = -1 Then
                            e.Handled = True

                        Else

                            If txtEmailAddress.Text.Contains("@") And e.KeyChar = "@" Then
                                e.Handled = True
                            End If

                        End If
                    End If
                End If
            End If

        End If
    End Sub

    Private Sub txtFields_TextChanged(sender As Object, e As EventArgs) Handles txtPhoneNumber.TextChanged, txtEmailAddress.TextChanged
        'Enable the update button
        btnUpdate.Enabled = True
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If blnPhone = True Then
            If CheckPhone() = True Then
                If MessageBox.Show("Do you really want to update phone number details of Lecturer: " & txtName.Text & "| (" & strId & ")?", _
                                   "Lecturer Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                    = DialogResult.Yes Then
                    objCommand = New SqlCommand
                    objCommand.CommandText = "UPDATE LecturerPhoneNumber " & _
                        "SET PhoneNumber=@phoneNumber " & _
                        "WHERE LecturerId=@lecturerId " & _
                    "AND PhoneNumber=@originalPhoneNumber;"

                    'Add parameters
                    objCommand.Parameters.AddWithValue("@phoneNumber", txtPhoneNumber.Text)
                    objCommand.Parameters.AddWithValue("@lecturerId", strId)
                    objCommand.Parameters.AddWithValue("@originalPhoneNumber", strPhone)
                Else
                    Exit Sub
                End If
            Else
                Exit Sub
            End If
        Else
            If CheckEmail() = True Then
                If MessageBox.Show("Do you really want to update email id details of Lecturer: " & txtName.Text & "| (" & strId & ")?", _
                           "Lecturer Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
            = DialogResult.Yes Then
                    objCommand = New SqlCommand
                    objCommand.CommandText = "UPDATE LecturerEmailId " & _
                        "SET EmailId= @emailId " & _
                        "WHERE LecturerId=@lecturerId " & _
                    "AND EmailId=@originalEmailId;"

                    'Add parameters
                    objCommand.Parameters.AddWithValue("@emailId", txtEmailAddress.Text)
                    objCommand.Parameters.AddWithValue("@lecturerId", strId)
                    objCommand.Parameters.AddWithValue("@originalEmailId", strEmail)

                Else
                    Exit Sub
                End If
            Else
                Exit Sub
            End If
        End If


        'Call RunQuery Method to update the selected user
        dataAccess.RunQuery(objCommand)

        'Check for errors
        If dataAccess.strExceptionRunQuery <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Lecturer Details")

            'Set the variable to nothing
            dataAccess.strExceptionRunQuery = Nothing

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        ElseIf dataAccess.intCountRecord = 1 Then

            If blnPhone = True Then
                'Show successfully update message
                MsgBox("The phone number details of lecturer: " & txtName.Text & " | (" & strId & ") details has been successfully updated.", MsgBoxStyle.Information, "Lecturer Details")

                'Clear existing records from the dataset
                If dataAccess.objDataSet IsNot Nothing Then
                    dataAccess.objDataSet.Clear()
                End If

                'Get list of name and id
                dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], PhoneNumber, Status  FROM Lecturer " & _
                                                  "INNER JOIN LecturerPhoneNumber ON Lecturer.LecturerId=LecturerPhoneNumber.LecturerId " & _
                                                  "WHERE Lecturer.LecturerId='" & strId & "' " & _
                                                  "AND PhoneNumber='" & txtPhoneNumber.Text & "';")

            Else
                'Show successfully update message
                MsgBox("The email details of lecturer: " & txtName.Text & " | (" & strId & ") details has been successfully updated.", MsgBoxStyle.Information, "Lecturer Details")

                'Clear existing records from the dataset
                If dataAccess.objDataSet IsNot Nothing Then
                    dataAccess.objDataSet.Clear()
                End If

                'Get list of name and id
                dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+ ' ' + LastName As [Name], EmailId, Status  FROM Lecturer " & _
                                                  "INNER JOIN LecturerEmailId ON Lecturer.LecturerId=LecturerEmailId.LecturerId " & _
                                                  "WHERE Lecturer.LecturerId='" & strId & "' " & _
                                                  "AND EmailId='" & txtEmailAddress.Text & "';")
            End If

            'Fill the datagridview
            FillDataGridView()

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        ElseIf dataAccess.intCountRecord = 0 Then
            If blnPhone = True Then
                'Show error message
                MsgBox("There's no such phone number details of " & txtName.Text & " | (" & strId & ") .", MsgBoxStyle.Exclamation, "Lecturer Details")
            Else
                'Show error message
                MsgBox("There's no such email address details of " & txtName.Text & " | (" & strId & ") .", MsgBoxStyle.Exclamation, "Lecturer Details")
            End If
            'Call btnView_Click procedure

            btnView_Click(Nothing, Nothing)
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If blnPhone = True Then
            If MessageBox.Show("Do you want to delete phone number details of lecturer: " & txtName.Text & "| (" & strId & ")?", _
                                "Lecturer Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                 = DialogResult.Yes Then
                objCommand = New SqlCommand
                objCommand.CommandText = "DELETE FROM LecturerPhoneNumber " & _
                                        "WHERE LecturerId=@lecturerId " & _
                "AND PhoneNumber=@originalPhoneNumber;"

                'Add parameters
                objCommand.Parameters.AddWithValue("@lecturerId", strId)
                objCommand.Parameters.AddWithValue("@originalPhoneNumber", strPhone)
            Else
                Exit Sub
            End If
        Else
            If MessageBox.Show("Do you want to delete email id details of Lecturer: " & txtName.Text & "| (" & strId & ")?", _
                         "Lecturer Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
          = DialogResult.Yes Then
                objCommand = New SqlCommand
                objCommand.CommandText = "DELETE LecturerEmailId " & _
                                        "WHERE LecturerId=@lecturerId " & _
                "AND EmailId=@originalEmailId;"

                'Add parameters
                objCommand.Parameters.AddWithValue("@lecturerId", strId)
                objCommand.Parameters.AddWithValue("@originalEmailId", strEmail)
            Else
                Exit Sub
            End If
        End If

        'Call RunQuery Method to update the selected user
        dataAccess.RunQuery(objCommand)

        'Check for errors
        If dataAccess.strExceptionRunQuery <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Lecturer Details")

            'Set the variable to nothing
            dataAccess.strExceptionRunQuery = Nothing

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        ElseIf dataAccess.intCountRecord = 1 Then
            If blnPhone = True Then
                'Show successfully update message
                MsgBox("The phone number details of lecturer: " & txtName.Text & " | (" & strId & ") details has been successfully deleted.", MsgBoxStyle.Information, "Lecturer Details")
            Else
                'Show successfully update message
                MsgBox("The email details of lecturer: " & txtName.Text & " | (" & strId & ") details has been successfully deleted.", MsgBoxStyle.Information, "Lecturer Details")
            End If

            'Remove a row from the datagridview
            grdLecturer.Rows.RemoveAt(rowNumber)

            'Get the number of rows in a text
            lblResult.Text = grdLecturer.RowCount

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()

            'Disable the GetReport button
            btnGetReport.Enabled = False
        ElseIf dataAccess.intCountRecord = 0 Then
            If blnPhone = True Then
                'Show error message
                MsgBox("There's no such phone number details of " & txtName.Text & " | (" & strId & ") .", MsgBoxStyle.Exclamation, "Lecturer Details")
            Else
                'Show error message
                MsgBox("There's no such email address details of " & txtName.Text & " | (" & strId & ") .", MsgBoxStyle.Exclamation, "Lecturer Details")
            End If
            'Call btnView_Click procedure

            btnView_Click(Nothing, Nothing)
        End If
    End Sub


    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        If GblAccessItem.blnLecturerPhone = True Then
            formReport.strReport = "LecturerAdditionalViewPhone"
        Else
            formReport.strReport = "LecturerAdditionalViewEmail"
        End If

        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub
End Class