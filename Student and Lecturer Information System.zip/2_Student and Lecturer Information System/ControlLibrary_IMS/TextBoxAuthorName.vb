﻿Public Class TextBoxAuthorName
    Inherits TextBox

    Protected Overrides Sub OnKeyPress(e As KeyPressEventArgs)
        MyBase.OnKeyPress(e)

        Dim s As String = ".,"

        If Not Char.IsLetter(e.KeyChar) And Not s.Contains(e.KeyChar) And Not e.KeyChar = Chr(Keys.Delete) _
            And Not e.KeyChar = Chr(Keys.Back) And Not e.KeyChar = Chr(Keys.Space) Then
            e.Handled = True
        End If
    End Sub
End Class
