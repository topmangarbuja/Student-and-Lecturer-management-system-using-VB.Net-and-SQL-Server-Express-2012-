﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class IssueSearch
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtIssueList As New DataTable
    Dim intBookId As Integer
    Dim strId As String
    Dim issueDate As Date
    Dim blnIsStudent = True

    Dim rowNumber As Int16

    'FORM LOAD EVENT
    Private Sub StudentSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Select first item in the Gender combobox
        'cboGender.SelectedIndex = 0
        'Clear the searching fields
        'ClearSearchingFields()

        'Set the value of issue date searching field to today's date
        ' dtpIssueDate.Value = Now

        'Call ClearFields method to clear the text of the View sections
        ClearFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub


    Private Sub ClearSearchingFields()
        'Clear other textboxes and combobox items
        txtId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtIsbnNo.Clear()
        txtTitle.Clear()
        txtAuthor.Clear()
    End Sub

    'METHOD: GET BOOK-ISSUE DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetBookIssuedList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE ReturnDate Is Null " & _
                                              "AND Remarks='borrowed';")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE ReturnDate Is Null " & _
                                              "AND Remarks='borrowed';")

            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()


    End Sub


    'METHOD:FILL DATAGRIDVIEW CONTROL
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdBookIssue.DataSource = Nothing

            'Get the table data
            dtIssueList = dataAccess.objDataSet.Tables(0)

            'Get the datasource for datagridview
            grdBookIssue.DataSource = dtIssueList

            GblAccessItem.DataTableIssueSearch = dataAccess.AutoNumberedTable(dtIssueList)

            'Do not show the first column
            grdBookIssue.Columns(0).Visible = False

            If grdBookIssue.Rows.Count > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = grdBookIssue.RowCount

            grdBookIssue.Columns(1).Frozen = True
        End If

        'Call procedure:make sure that the View sections control are disabled
        DisabledControls()

        '
    End Sub

    'ENTEREVENT OF SEARCHING CONTROLS
    Private Sub txtSerchingFields_Enter(sender As Object, e As EventArgs) Handles txtId.Enter, txtFirstName.Enter, txtLastName.Enter, txtIsbnNo.Enter, txtTitle.Enter, txtAuthor.Enter, dtpIssueDate.Enter
        'Clear searching fields 
        ClearSearchingFields()

        'Call ClearFields method to clear the text of the View sections
        ClearFields()

        'Clear the datasource of datagridview
        grdBookIssue.DataSource = Nothing

        If grdBookIssue.Rows.Count > 0 Then
            'Enable the GetReport button
            btnGetReport.Enabled = True
        Else
            'Disable the GetReport button
            btnGetReport.Enabled = False
        End If

        'List the result too
        lblResult.Text = grdBookIssue.RowCount

        'grdBookIssue.Columns(3).Frozen = True
    End Sub

    'TEXTCHANGED EVENT OF ID TEXTBOX
    Private Sub txtId_TextChanged(sender As Object, e As EventArgs) Handles txtId.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Student.StudentId LIKE '%" & txtId.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE Lecturer.LecturerId LIKE '%" & txtId.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub


    'TEXTCHANGED EVENT OF FIRSTNAME COMBOBOX
    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged

        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE FirstName LIKE '%" & txtFirstName.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE FirstName LIKE '%" & txtFirstName.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub


    'TEXTCHANGED EVENT OF LASTNAME COMBOBOX
    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE LastName LIKE '%" & txtLastName.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE LastName LIKE '%" & txtLastName.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()

    End Sub

    'TEXTCHANGED EVENT OF ISBNNO TEXTBOX
    Private Sub txtIsbnNo_TextChanged(sender As Object, e As EventArgs) Handles txtIsbnNo.TextChanged


        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Isbn LIKE '%" & txtIsbnNo.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE Isbn LIKE '%" & txtIsbnNo.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()

    End Sub

    'TEXTCHANGED EVENT OF TITLE TEXTBOX
    Private Sub txtTitle_TextChanged(sender As Object, e As EventArgs) Handles txtTitle.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Title LIKE '%" & txtTitle.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE Title LIKE '%" & txtTitle.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()

    End Sub

    'TEXCHANGED EVENT OF AUTHOR TEXTBOX
    Private Sub txtAuthor_TextChanged(sender As Object, e As EventArgs) Handles txtAuthor.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Author LIKE '%" & txtAuthor.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE Author LIKE '%" & txtAuthor.Text & "%' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = False
        End If
        'Call procedure FillDataGridView to fill
        FillDataGridView()

    End Sub

    'VALUECHANGED EVENT OF DATETIMEPICKER
    Private Sub dtpIssueDate_ValueChanged(sender As Object, e As EventArgs) Handles dtpIssueDate.ValueChanged, dtpIssueDate.Enter
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE IssueDate='" & dtpIssueDate.Value.Date & "' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")

            'Change boolean variable
            blnIsStudent = True
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                              "WHERE IssueDate='" & dtpIssueDate.Value.Date & "' " & _
                                              "AND ReturnDate Is Null " & _
                                              "ORDER BY Name;")
            'Change boolean variable
            blnIsStudent = False
        End If

        'Call procedure FillDataGridView to fill
        FillDataGridView()
    End Sub








    'EVENTS AND METHODS FOR THE DATAGRIDVIEW SECTION

    Private Sub rdbStudent_CheckedChanged(sender As Object, e As EventArgs) Handles rdbStudent.CheckedChanged
        'Clear other textboxes and combobox items
        txtId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtIsbnNo.Clear()
        txtTitle.Clear()
    End Sub

    Private Sub rdbLecturer_CheckedChanged(sender As Object, e As EventArgs) Handles rdbLecturer.CheckedChanged
        'Clear other textboxes and combobox items
        txtId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtIsbnNo.Clear()
        txtTitle.Clear()
    End Sub

    'CELL CLICK EVENT OF GRIDVIEW
    Private Sub grdBookIssue_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdBookIssue.CellClick
        If grpEdit.Visible = True Then
            rowNumber = grdBookIssue.CurrentCell.RowIndex

            'Call ClearFields method to clear the text of the View sections
            ClearFields()

            'Enable the controls of view sections
            EnableControls()


            For i As Integer = 0 To grdBookIssue.ColumnCount - 1
                Try
                    Select Case i
                        Case 0
                            intBookId = grdBookIssue.Item(0, e.RowIndex).Value
                        Case 1
                            strId = grdBookIssue.Item(1, e.RowIndex).Value
                            txtViewId.Text = grdBookIssue.Item(1, e.RowIndex).Value
                        Case 2
                            txtViewName.Text = grdBookIssue.Item(2, e.RowIndex).Value
                        Case 3
                            txtViewIsbn.Text = grdBookIssue.Item(3, e.RowIndex).Value
                        Case 4
                            txtViewTitle.Text = grdBookIssue.Item(4, e.RowIndex).Value
                        Case 5
                            txtViewAuthor.Text = grdBookIssue.Item(5, e.RowIndex).Value
                        Case 6
                            issueDate = grdBookIssue.Item(6, e.RowIndex).Value
                            dtpViewIssueDate.Value = grdBookIssue.Item(6, e.RowIndex).Value
                            dtpViewIssueTime.Value = grdBookIssue.Item(6, e.RowIndex).Value + grdBookIssue.Item(7, e.RowIndex).Value
                        Case 7
                            If grdBookIssue.Item(10, e.RowIndex).Value.ToString.ToLower.Contains("borrowed") Then
                                cboViewRemarks.SelectedIndex = 0
                            ElseIf grdBookIssue.Item(10, e.RowIndex).Value.ToString.ToLower.Contains("returned") Then
                                cboViewRemarks.SelectedIndex = 1
                            ElseIf grdBookIssue.Item(10, e.RowIndex).Value.ToString.ToLower.Contains("lost") Then
                                cboViewRemarks.SelectedIndex = 2
                            End If
                    End Select
                Catch ex As Exception

                End Try

            Next

            'Make sure that the Update button is disabled
            btnUpdate.Enabled = False
        End If
    End Sub

    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles cboViewRemarks.TextChanged, cboViewRemarks.SelectedIndexChanged, dtpViewIssueDate.ValueChanged, dtpViewIssueTime.ValueChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub


    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtViewId.Enabled = True
        txtViewName.Enabled = True
        txtViewIsbn.Enabled = True
        txtViewTitle.Enabled = True
        txtViewAuthor.Enabled = True
        dtpViewIssueDate.Enabled = True
        dtpViewIssueTime.Enabled = True
        dtpViewReturnDate.Enabled = True
        dtpViewReturnTime.Enabled = True
        cboViewRemarks.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtViewId.Enabled = False
        txtViewName.Enabled = False
        txtViewIsbn.Enabled = False
        txtViewTitle.Enabled = False
        txtViewAuthor.Enabled = False
        dtpViewIssueDate.Enabled = False
        dtpViewIssueTime.Enabled = False
        dtpViewReturnDate.Enabled = False
        dtpViewReturnTime.Enabled = False
        cboViewRemarks.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub


    'CLEAR TEXT FIELD AND SET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtViewId.Clear()
        txtViewName.Clear()
        txtViewIsbn.Clear()
        txtViewTitle.Clear()
        txtAuthor.Clear()
        dtpViewIssueDate.Value = Now
        dtpViewIssueTime.Value = Now
        dtpViewReturnDate.Value = Now
        dtpViewReturnTime.Value = Now
        cboViewRemarks.Text = ""
    End Sub

    'CLICK EVENT OF VIEWALLISSUEBOOK BUTTON
    Private Sub btnViewAllIssueBook_Click(sender As Object, e As EventArgs) Handles btnViewAllIssueBook.Click
        'Call procedure to get list of issue book
        GetBookIssuedList()
    End Sub

    'CLICK EVENT OF UPDATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If blnIsStudent = True Then
            'Call procedure to update the book-issue details
            UpdateStudentBookReturn()

            ''Clear existing records from the dataset
            'If dataAccess.objDataSet IsNot Nothing Then
            '    dataAccess.objDataSet.Clear()
            'End If

            ''Get the list of issued-books by students
            'dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
            '                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
            '                              "join Student on studentbookissue.studentid = student.studentid " & _
            '                              "WHERE ReturnDate Is Null " & _
            '                              "AND Remarks='borrowed';")
            ''Change boolean variable
            'blnIsStudent = True
        Else
            'Call procedure to update the book-issue details
            UpdateLecturerBookReturn()

            ''Clear existing records from the dataset
            'If dataAccess.objDataSet IsNot Nothing Then
            '    dataAccess.objDataSet.Clear()
            'End If

            ''Get the list of issued-books by lecturers
            'dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
            '                          "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
            '                          "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
            '                          "WHERE ReturnDate Is Null " & _
            '                          "AND Remarks='borrowed';")

            ''Change boolean variable
            'blnIsStudent = False
        End If

        'Call procedure to fill the datagridview
        ' FillDataGridView()

        'Call ClearFields method to clear the text of the View sections
        ClearFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    Private Sub UpdateStudentBookReturn()
        If Not cboViewRemarks.Text.ToLower.Contains("returned") Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you really want to update book issue details with date and time :" & dtpViewIssueDate.Value.ToShortDateString & " | " & dtpViewIssueTime.Value.ToLongTimeString.ToString & _
                                     " of book: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") ?")
            objStringBuilder.AppendLine(String.Empty)
            'objStringBuilder.AppendLine("Do you really want to update book issue: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
            'objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
            'Raise a YesNo question
            If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE StudentBookIssue " & _
                                     "SET IssueDate= @issueDate, " & _
                                     "IssueTime=@issueTime, " & _
                                     "Remarks=@remarks " & _
                                     "WHERE BookId=@bookId " & _
                                     "AND StudentId=@studentId " & _
                                    "AND IssueDate=@issueDateOriginal; "

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value.Date)
                objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                objCommand.Parameters.AddWithValue("@bookId", intBookId)
                objCommand.Parameters.AddWithValue("@studentId", strId)
                objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If


                    dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                      "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                                      "join Student on studentbookissue.studentid = student.studentid " & _
                                                      "WHERE Student.StudentId = '" & strId & "' " & _
                                                      "AND Book.BookId= " & intBookId & " " & _
                                                      "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")

                    'Change boolean variable
                    blnIsStudent = True


                    'Call procedure FillDataGridView to fill
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                End If
            End If
        ElseIf cboViewRemarks.Text.ToLower.Contains("returned") Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
            objStringBuilder.AppendLine(String.Empty)

            'Raise a YesNo question
            If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE StudentBookIssue " & _
                                     "SET IssueDate= @issueDate, " & _
                                     "IssueTime=@issueTime, " & _
                                     "ReturnDate=@returnDate, " & _
                                     "ReturnTime=@returnTime, " & _
                                     "Remarks=@remarks " & _
                                     "WHERE BookId=@bookId " & _
                                     "AND StudentId=@studentId " & _
                                     "AND IssueDate=@issueDateOriginal; " & _
                                     "UPDATE BOOK " & _
                                     "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                     "WHERE BookId = @bookId; "

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                objCommand.Parameters.AddWithValue("@returnDate", dtpViewReturnDate.Value)
                objCommand.Parameters.AddWithValue("@returnTime", dtpViewReturnTime.Value.TimeOfDay)
                objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                objCommand.Parameters.AddWithValue("@bookId", intBookId)
                objCommand.Parameters.AddWithValue("@studentId", strId)
                objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 2 Then
                    'Show successfully update message
                    MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId,Student.StudentId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                          "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                                          "join Student on studentbookissue.studentid = student.studentid " & _
                                                          "WHERE Student.StudentId = '" & strId & "' " & _
                                                        "AND Book.BookId= " & intBookId & " " & _
                                                          "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")

                    'Change boolean variable
                    blnIsStudent = True


                    'Call procedure FillDataGridView to fill
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                End If
            End If
        End If
    End Sub

    Private Sub UpdateLecturerBookReturn()
        If Not cboViewRemarks.Text.ToLower.Contains("returned") Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you really want to update book issue details with date and time :" & dtpViewIssueDate.Value.ToShortDateString & " | " & dtpViewIssueTime.Value.ToLongTimeString.ToString & _
                                       " of book: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") ?")
            objStringBuilder.AppendLine(String.Empty)
            'objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
            'Raise a YesNo question
            If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE LecturerBookIssue " & _
                                     "SET IssueDate= @issueDate, " & _
                                     "IssueTime=@issueTime, " & _
                                     "Remarks=@remarks " & _
                                     "WHERE BookId=@bookId " & _
                                     "AND LecturerId=@lecturerId " & _
                                    "AND IssueDate=@issueDateOriginal; "

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@issueDate", dtpViewIssueDate.Value)
                objCommand.Parameters.AddWithValue("@issueTime", dtpViewIssueTime.Value.TimeOfDay)
                objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                objCommand.Parameters.AddWithValue("@bookId", intBookId)
                objCommand.Parameters.AddWithValue("@lecturerId", strId)
                objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                          "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                                          "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                                          "WHERE Lecturer.LecturerId = '" & strId & "' " & _
                                                     "AND Book.BookId= " & intBookId & " " & _
                                                          "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")
                    'Change boolean variable
                    blnIsStudent = False


                    'Call procedure FillDataGridView to fill
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")

                End If
            End If
        ElseIf cboViewRemarks.Text.ToLower.Contains("returned") Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you really want to update book returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details?")
            objStringBuilder.AppendLine(String.Empty)

            'Raise a YesNo question
            If MessageBox.Show(objStringBuilder.ToString, "Book-Issue Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE LecturerBookIssue " & _
                                     "SET ReturnDate=@returnDate, " & _
                                     "ReturnTime=@returnTime, " & _
                                     "Remarks=@remarks " & _
                                     "WHERE BookId=@bookId " & _
                                     "AND LecturerId=@lecturerId " & _
                                     "AND IssueDate=@issueDateOriginal; " & _
                                     "UPDATE BOOK " & _
                                     "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                     "WHERE BookId = @bookId; "

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@returnDate", dtpViewReturnDate.Value)
                objCommand.Parameters.AddWithValue("@returnTime", dtpViewReturnTime.Value.TimeOfDay)
                objCommand.Parameters.AddWithValue("@remarks", cboViewRemarks.Text)
                objCommand.Parameters.AddWithValue("@bookId", intBookId)
                objCommand.Parameters.AddWithValue("@lecturerId", strId)
                objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)

                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 2 Then
                    'Show successfully update message
                    MsgBox("Book-Returned: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ") details has been successfully updated.", MsgBoxStyle.Information, "Book-Returned Details")

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    dataAccess.RunQueryAndFillDataSet("SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Isbn, Title, Author, issuedate, issuetime, returndate, returntime, remarks  from book " & _
                                                          "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                                          "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                                          "WHERE Lecturer.LecturerId = '" & strId & "' " & _
                                                 "AND Book.BookId= " & intBookId & " " & _
                                                          "And IssueDate='" & dtpViewIssueDate.Value.Date & "';")
                    'Change boolean variable
                    blnIsStudent = False


                    'Call procedure FillDataGridView to fill
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with details: |" & txtViewTitle.Text & "| (" & txtViewIsbn.Text & ").", MsgBoxStyle.Exclamation, "Book Details")
                End If
            End If
        End If
    End Sub

    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If blnIsStudent = True Then
            'Call procedure to delete student issue details
            DeleteStudentBookIssue()
        Else
            'Call procedure to delete lecturer issue details
            DeleteLecturerBookIssue()
        End If

        'List the number of rows in the result
        lblResult.Text = grdBookIssue.RowCount
    End Sub

    'DELETE STUDENT BOOK ISSUE DETAILS
    Private Sub DeleteStudentBookIssue()
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you really want to delete following book issue details? ")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Student id :" & strId)
        objStringBuilder.AppendLine("Name :" & txtViewName.Text)
        objStringBuilder.AppendLine("Book: " & txtViewTitle.Text & " |" & txtViewIsbn.Text & "|")
        objStringBuilder.AppendLine("Issue-Date: " & issueDate)
        If MessageBox.Show(objStringBuilder.ToString, "Book-issue details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                       = DialogResult.Yes Then

            'Create a sql query text
            Dim strCommand As String = "DELETE FROM StudentBookIssue " & _
                                 "WHERE BookId=@bookId " & _
                                 "AND StudentId=@studentId " & _
                                "AND IssueDate=@issueDateOriginal; "

            'Create a new sql command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add parameters
            objCommand.Parameters.AddWithValue("@bookId", intBookId)
            objCommand.Parameters.AddWithValue("@studentId", strId)
            objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)

            'Call RunQuery Method to update the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Create a sql query text
                Dim strCommandText As String = "UPDATE BOOK " & _
                                     "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                     "WHERE BookId = @bookId; "

                'Create a new sql command
                Dim objNewCommand As New SqlCommand
                objNewCommand.CommandText = strCommandText

                'Add parameters
                objNewCommand.Parameters.AddWithValue("@bookId", intBookId)

                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objNewCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Book-Issue details of student id :" & strId & " details has been successfully deleted.", MsgBoxStyle.Information, "Book-Issue Details")

                    'Remove the record from the gridview
                    grdBookIssue.Rows.RemoveAt(rowNumber)
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with student id :" & strId & " having details Book: " & txtViewTitle.Text & _
                               "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")
                End If
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show error message
                MsgBox("There's no book with student id :" & strId & " having details Book: " & txtViewTitle.Text & _
                           "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")


                'Refresh the datagridview
                GetBookIssuedList()
            End If

        End If
    End Sub

    'DELETE LECTURER BOOK ISSUE DETAILS
    Private Sub DeleteLecturerBookIssue()
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you really want to delete following book issue details? ")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Lecturer id :" & strId)
        objStringBuilder.AppendLine("Name :" & txtViewName.Text)
        objStringBuilder.AppendLine("Book: " & txtViewTitle.Text & " |" & txtViewIsbn.Text & "|")
        objStringBuilder.AppendLine("Issue-Date: " & issueDate)
        If MessageBox.Show(objStringBuilder.ToString, "Book-issue details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                       = DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM LecturerBookIssue " & _
                                 "WHERE BookId=@bookId " & _
                                 "AND LecturerId = @lecturerId " & _
                                "AND IssueDate=@issueDateOriginal; "

            'Create a new sql command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add parameters
            objCommand.Parameters.AddWithValue("@bookId", intBookId)
            objCommand.Parameters.AddWithValue("@lecturerId", strId)
            objCommand.Parameters.AddWithValue("@issueDateOriginal", issueDate)


            'Call RunQuery Method to update the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Create a sql query text
                Dim strCommandText As String = "UPDATE BOOK " & _
                                     "SET AvailableQuantity= (AvailableQuantity+1) " & _
                                     "WHERE BookId = @bookId; "

                'Create a new sql command
                Dim objNewCommand As New SqlCommand
                objNewCommand.CommandText = strCommandText

                'Add parameters
                objNewCommand.Parameters.AddWithValue("@bookId", intBookId)

                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objNewCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Book-Issue details of lecturer id :" & strId & " details has been successfully deleted.", MsgBoxStyle.Information, "Book-Issue Details")

                    'Remove the record from the gridview
                    grdBookIssue.Rows.RemoveAt(rowNumber)
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with student id :" & strId & " having details Book: " & txtViewTitle.Text & _
                               "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")
                End If
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show error message
                MsgBox("There's no book with lecturer id :" & strId & " having details Book: " & txtViewTitle.Text & _
                           "(" & txtViewIsbn.Text & ") | Issue-Date: " & issueDate.Date & ".", MsgBoxStyle.Exclamation, "Book Details")

                'Refresh the datagridview
                GetBookIssuedList()
            End If


        End If
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "IssueSearch"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub




    Private Sub btnShowEditSection_Click(sender As Object, e As EventArgs) Handles btnShowEditSection.Click
        'Dim s As Point = pnlListOfStudent.Location
        If btnShowEditSection.Text = "Show Edit section" Then
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X - 220
            pnlListOfStudent.Location = p

            grpResult.Size = New Size(762, 418)


            Dim g As Point = grpResult.Location
            g.X = grpResult.Width + 20
            grpEdit.Location = g



            grpEdit.Visible = True
            lblDetails.Visible = True

            btnShowEditSection.Text = "Hide Edit section"
        Else
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X + 220
            pnlListOfStudent.Location = p


            grpResult.Size = New Size(1154, 418)


            grpEdit.Visible = False
            lblDetails.Visible = False

            btnShowEditSection.Text = "Show Edit section"

            'Disable the controls of the textboxes and buttons
            DisabledControls()
        End If

        'First clear the text fields
        ClearFields()
    End Sub
End Class