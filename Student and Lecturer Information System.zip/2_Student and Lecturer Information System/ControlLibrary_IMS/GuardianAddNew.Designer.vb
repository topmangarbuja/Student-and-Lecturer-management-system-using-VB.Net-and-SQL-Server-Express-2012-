﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GuardianAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.cboRelationship = New System.Windows.Forms.ComboBox()
        Me.txtGuardianPhoneNumber = New ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon()
        Me.txtGuardianLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtGuardianFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboId = New System.Windows.Forms.ComboBox()
        Me.txtStudentName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.grdGuardian = New System.Windows.Forms.DataGridView()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.btnViewGuardians = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.grdGuardian, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(11, 3)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox1.Size = New System.Drawing.Size(415, 298)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Guardian"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.cboRelationship, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.txtGuardianPhoneNumber, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.txtGuardianLastName, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtGuardianFirstName, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.cboId, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtStudentName, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 6
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(405, 271)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'cboRelationship
        '
        Me.cboRelationship.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboRelationship.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboRelationship, "Select relationship type from the list if exists, otherwise type eg: Brother")
        Me.cboRelationship.Location = New System.Drawing.Point(117, 237)
        Me.cboRelationship.Name = "cboRelationship"
        Me.HelpProvider1.SetShowHelp(Me.cboRelationship, True)
        Me.cboRelationship.Size = New System.Drawing.Size(261, 25)
        Me.cboRelationship.Sorted = True
        Me.cboRelationship.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboRelationship, "Relationship")
        '
        'txtGuardianPhoneNumber
        '
        Me.txtGuardianPhoneNumber.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtGuardianPhoneNumber, "Type phone number of the guardian.")
        Me.txtGuardianPhoneNumber.Location = New System.Drawing.Point(117, 190)
        Me.txtGuardianPhoneNumber.MaxLength = 20
        Me.txtGuardianPhoneNumber.Name = "txtGuardianPhoneNumber"
        Me.HelpProvider1.SetShowHelp(Me.txtGuardianPhoneNumber, True)
        Me.txtGuardianPhoneNumber.Size = New System.Drawing.Size(261, 25)
        Me.txtGuardianPhoneNumber.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtGuardianPhoneNumber, "Phone number")
        '
        'txtGuardianLastName
        '
        Me.txtGuardianLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtGuardianLastName, "Type last name of the guardian.")
        Me.txtGuardianLastName.Location = New System.Drawing.Point(117, 145)
        Me.txtGuardianLastName.MaxLength = 35
        Me.txtGuardianLastName.Name = "txtGuardianLastName"
        Me.HelpProvider1.SetShowHelp(Me.txtGuardianLastName, True)
        Me.txtGuardianLastName.Size = New System.Drawing.Size(261, 25)
        Me.txtGuardianLastName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtGuardianLastName, "Guardian Last Name")
        '
        'txtGuardianFirstName
        '
        Me.txtGuardianFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtGuardianFirstName, "Type first name (and last name if exists) of the guardian for the selected studen" & _
        "t.")
        Me.txtGuardianFirstName.Location = New System.Drawing.Point(117, 100)
        Me.txtGuardianFirstName.MaxLength = 70
        Me.txtGuardianFirstName.Name = "txtGuardianFirstName"
        Me.HelpProvider1.SetShowHelp(Me.txtGuardianFirstName, True)
        Me.txtGuardianFirstName.Size = New System.Drawing.Size(261, 25)
        Me.txtGuardianFirstName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtGuardianFirstName, "Guardian First Name")
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 194)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 17)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Phone number:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(5, 104)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "First Name:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 149)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Last Name:"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(5, 239)
        Me.Label20.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(90, 17)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Relationship:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(5, 14)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Student Id:"
        '
        'cboId
        '
        Me.cboId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboId.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboId, "Select from the list or type 12 character student Id.")
        Me.cboId.Location = New System.Drawing.Point(117, 12)
        Me.cboId.MaxLength = 12
        Me.cboId.Name = "cboId"
        Me.HelpProvider1.SetShowHelp(Me.cboId, True)
        Me.cboId.Size = New System.Drawing.Size(262, 25)
        Me.cboId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboId, "Student Id")
        '
        'txtStudentName
        '
        Me.txtStudentName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStudentName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtStudentName, "Here, you get the corresponding name of the selected student id.")
        Me.txtStudentName.Location = New System.Drawing.Point(119, 55)
        Me.txtStudentName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtStudentName.Name = "txtStudentName"
        Me.txtStudentName.ReadOnly = True
        Me.HelpProvider1.SetShowHelp(Me.txtStudentName, True)
        Me.txtStudentName.Size = New System.Drawing.Size(261, 25)
        Me.txtStudentName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtStudentName, "Student Name")
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 59)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Name:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnClear)
        Me.Panel2.Controls.Add(Me.btnSave)
        Me.Panel2.Location = New System.Drawing.Point(133, 308)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(270, 43)
        Me.Panel2.TabIndex = 15
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(141, 5)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(5, 5)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'grdGuardian
        '
        Me.grdGuardian.AllowUserToAddRows = False
        Me.grdGuardian.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdGuardian.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdGuardian.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdGuardian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdGuardian.Location = New System.Drawing.Point(434, 51)
        Me.grdGuardian.MultiSelect = False
        Me.grdGuardian.Name = "grdGuardian"
        Me.grdGuardian.ReadOnly = True
        Me.grdGuardian.RowHeadersVisible = False
        Me.grdGuardian.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdGuardian.ShowCellToolTips = False
        Me.grdGuardian.Size = New System.Drawing.Size(427, 297)
        Me.grdGuardian.TabIndex = 21
        Me.grdGuardian.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdGuardian, "Click header to sort the list of students.")
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'btnViewGuardians
        '
        Me.btnViewGuardians.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewGuardians.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewGuardians.Location = New System.Drawing.Point(434, 9)
        Me.btnViewGuardians.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewGuardians.Name = "btnViewGuardians"
        Me.btnViewGuardians.Size = New System.Drawing.Size(125, 35)
        Me.btnViewGuardians.TabIndex = 24
        Me.btnViewGuardians.TabStop = False
        Me.btnViewGuardians.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewGuardians, "View all of the guardian details.")
        Me.btnViewGuardians.UseVisualStyleBackColor = True
        '
        'GuardianAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grdGuardian)
        Me.Controls.Add(Me.btnViewGuardians)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "GuardianAddNew"
        Me.Size = New System.Drawing.Size(876, 367)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.grdGuardian, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtStudentName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents cboId As System.Windows.Forms.ComboBox
    Friend WithEvents grdGuardian As System.Windows.Forms.DataGridView
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents txtGuardianFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtGuardianLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtGuardianPhoneNumber As ControlLibrary_IMS.TextBoxNumericPunctuationPlusHyphon
    Friend WithEvents cboRelationship As System.Windows.Forms.ComboBox
    Friend WithEvents btnViewGuardians As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider

End Class
