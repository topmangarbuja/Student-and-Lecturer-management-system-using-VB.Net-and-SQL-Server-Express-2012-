﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class BookView
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtBookList As DataTable
    Dim dtBookCategory As DataTable
    Dim dtBookUpdateCategory As DataTable
    Dim intBookId As Integer
    Dim strBookIsbn As String
    Dim strBookTitle As String
    Dim rowNumber As Int16

    'METHOD: GET BOOK CATEGORY
    Private Sub GetBookCategory()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Category FROM BOOK; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Book Category | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtBookCategory = dataAccess.dtListForComboBox
            cboCategory.DataSource = dtBookCategory
            cboCategory.DisplayMember = "Category"
            If cboCategory.Text = "" Then

            End If
        End If
    End Sub


    Private Sub GetBookUpdateCategory()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Category FROM BOOK; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Book Category | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtBookUpdateCategory = dataAccess.dtListForComboBox
            cboUpdateCategory.DataSource = dtBookUpdateCategory
            cboUpdateCategory.DisplayMember = "Category"

            If cboCategory.Text = "" Then

            End If
        End If
    End Sub


    Private Sub btnFilterView_Click(sender As Object, e As EventArgs) Handles btnFilterView.Click
        'Call procedure to get list of books
        GetBookList(sender, e)

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub


    'METHOD: GET ALL THE BOOKS LIST
    Private Sub GetBookList(ByVal sender, ByVal e)
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If


        'Get list of books
        If sender Is btnFilterView Then
            'Get list of books by filtering
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM BOOK " & _
                                             "WHERE Category='" & cboCategory.Text & "' " & _
            "ORDER BY Title;")
        ElseIf sender Is btnViewAll Then
            'Get list of all books
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM BOOK " & _
            "ORDER BY Title;")
        End If

        FillDataGridView()
    End Sub

    Private Sub FillDataGridView()

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdBook.DataSource = Nothing

            'Get the table data
            dtBookList = dataAccess.objDataSet.Tables(0)

            'Get the datasource for datagridview
            grdBook.DataSource = dtBookList

            GblAccessItem.DataTableBookView = dataAccess.AutoNumberedTable(dtBookList)

            'Hide the first column
            grdBook.Columns(0).Visible = False

            'Make DataGridView ReadOnly property to true
            grdBook.ReadOnly = True


            If grdBook.Rows.Count > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            grdBook.Columns(1).Frozen = True
        End If

        'Display the number of records 
        lblResult.Text = grdBook.RowCount
    End Sub

    'CLICK EVENT OF VIEWALL BUTTON
    Private Sub btnViewAll_Click(sender As Object, e As EventArgs) Handles btnViewAll.Click
        'Call procedure to get list of books
        GetBookList(sender, e)

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub

    'FORM LOAD EVENT
    Private Sub BookView_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Call procedure to get all the category
        GetBookCategory()

        'Call ClearFields method to clear the text
        ClearFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'CELL CLICK EVENT OF DATAGRID
    Private Sub grdBook_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdBook.CellClick
        rowNumber = grdBook.CurrentCell.RowIndex
        'Call ClearFields method to clear the text
        ClearFields()

        'Enable the controls of the datagridview sections
        EnableControls()

        'Get list of category for book
        GetBookUpdateCategory()

        For i As Integer = 0 To grdBook.ColumnCount - 1
            Try
                Select Case i
                    Case 0
                        intBookId = grdBook.Item(0, e.RowIndex).Value

                    Case 1
                        strBookIsbn = grdBook.Item(1, e.RowIndex).Value
                        txtIsbn.Text = grdBook.Item(1, e.RowIndex).Value

                    Case 2
                        strBookTitle = grdBook.Item(2, e.RowIndex).Value
                        txtTitle.Text = grdBook.Item(2, e.RowIndex).Value

                    Case 3
                        txtPublisher.Text = grdBook.Item(3, e.RowIndex).Value
                    Case 4

                        txtAuthor.Text = grdBook.Item(4, e.RowIndex).Value

                    Case 5
                        dtpPublishDate.Value = grdBook.Item(5, e.RowIndex).Value

                    Case 6
                        cboUpdateCategory.Text = grdBook.Item(6, e.RowIndex).Value

                    Case 7
                        txtTotalQuantity.Text = grdBook.Item(7, e.RowIndex).Value

                    Case 8
                        txtAvailableQuantity.Text = grdBook.Item(8, e.RowIndex).Value

                End Select
            Catch ex As Exception

            End Try
        Next

        'Make sure that the Update button is disabled
        btnUpdate.Enabled = False
    End Sub

    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtIsbn.Enabled = True
        txtTitle.Enabled = True
        txtPublisher.Enabled = True
        txtAuthor.Enabled = True
        dtpPublishDate.Enabled = True
        cboUpdateCategory.Enabled = True
        txtTotalQuantity.Enabled = True
        txtAvailableQuantity.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtIsbn.Enabled = False
        txtTitle.Enabled = False
        txtPublisher.Enabled = False
        txtAuthor.Enabled = False
        dtpPublishDate.Enabled = False
        cboUpdateCategory.Enabled = False
        txtTotalQuantity.Enabled = False
        txtAvailableQuantity.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub


    'CLEAR TEXT FIELDSSET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtIsbn.Clear()
        txtTitle.Clear()
        txtPublisher.Clear()
        txtAuthor.Clear()
        dtpPublishDate.Value = Now
        cboUpdateCategory.Text = ""
        txtTotalQuantity.Clear()
        txtAvailableQuantity.Clear()
    End Sub


    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtIsbn.TextChanged, txtTitle.TextChanged, txtPublisher.TextChanged, dtpPublishDate.ValueChanged, _
        txtAuthor.TextChanged, cboUpdateCategory.SelectedIndexChanged, cboUpdateCategory.TextChanged, txtTotalQuantity.TextChanged, txtAvailableQuantity.TextChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete book: |" & strBookTitle & "| (" & strBookIsbn & ") details?", "Book Details", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM BOOK " & _
                                 "WHERE BookId= @bookId"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@bookId", intBookId)

            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("Book: |" & strBookTitle & "| (" & strBookIsbn & ") details has been successfully deleted.", MsgBoxStyle.Information, "Book Details")

                'Call btnFilterView_Click procedure
                'btnFilterView_Click(btnFilterView, Nothing)

                'Remove the row from the data gridview
                grdBook.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdBook.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no book with details: |" & strBookTitle & "| (" & strBookIsbn & ").", MsgBoxStyle.Exclamation, "Book Details")

                'Call btnView_Click procedure
                btnFilterView_Click(btnFilterView, Nothing)
            End If

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub

    'CLICK EVENT OF UPDATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If CheckIsbnAndTitle() = True And CheckAvailableAndTotalQuantity() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update book: |" & strBookTitle & "| (" & strBookIsbn & ") details?", "Book Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE BOOK " & _
                                     "SET Isbn= @isbn, " & _
                                     "Title=@title, " & _
                                     "Publisher=@publisher, " & _
                                     "Author=@author, " & _
                                     "PublishDate=@pubDate, " & _
                                     "Category=@category, " & _
                                     "TotalQuantity=@totalQuantity, " & _
                                     "AvailableQuantity=@availableQuantity " & _
                                     "WHERE BookId=@bookId;"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                'objCommand.Parameters.AddWithValue("@bookId", txt)
                objCommand.Parameters.AddWithValue("@isbn", txtIsbn.Text)
                objCommand.Parameters.AddWithValue("@title", txtTitle.Text)
                objCommand.Parameters.AddWithValue("@publisher", txtPublisher.Text)
                objCommand.Parameters.AddWithValue("@author", txtAuthor.Text)
                objCommand.Parameters.AddWithValue("@pubDate", dtpPublishDate.Value.Date)
                objCommand.Parameters.AddWithValue("@category", cboCategory.Text)
                objCommand.Parameters.AddWithValue("@totalQuantity", txtTotalQuantity.Text)
                objCommand.Parameters.AddWithValue("@availableQuantity", txtAvailableQuantity.Text)
                objCommand.Parameters.AddWithValue("@bookId", intBookId)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Book Details")

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Book: |" & strBookTitle & "| (" & strBookIsbn & ") details has been successfully updated.", MsgBoxStyle.Information, "Book Details")

                    'Call btnView_Click procedure
                    'btnFilterView_Click(btnFilterView, Nothing)

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
                                                      "WHERE BookId =" & intBookId & ";")


                    'Fill the datagridview
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with details: |" & strBookTitle & "| (" & strBookIsbn & ").", MsgBoxStyle.Exclamation, "Book Details")

                    'Call btnView_Click procedure
                    btnFilterView_Click(btnFilterView, Nothing)
                End If

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            End If
        End If

    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckIsbnAndTitle() As Boolean
        If txtIsbn.Text.Trim.Length > 0 And txtTitle.Text.Trim.Length > 0 Then
            Return True
        ElseIf txtIsbn.Text.Trim.Length <= 0 And txtTitle.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter book isbn and title.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtIsbn.Text.Trim.Length <= 0 And txtTitle.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter book isbn.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            MessageBox.Show("You have to enter book title.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    'CHECK WHETHER AVAILABLE IS GREATER THAN TOTAL QUANTITY
    Private Function CheckAvailableAndTotalQuantity() As Boolean
        Dim availableQuantity As String = txtAvailableQuantity.Text
        Dim totalQuantity As String = txtTotalQuantity.Text

        If availableQuantity = "" Then
            availableQuantity = "0"
        End If
        If totalQuantity = "" Then
            totalQuantity = "0"
        End If
        If CInt(availableQuantity) > CInt(totalQuantity) Then
            MessageBox.Show("The availabe quantity should not be greater than the total quantity of library books.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "BookView"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub
End Class