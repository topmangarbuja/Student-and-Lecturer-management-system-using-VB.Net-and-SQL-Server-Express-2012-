﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class LecturerAddPhone
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtLecturerList As New DataTable
    Dim strExceptionId As String = "errLecturerId"


    'METHOD: GET LECTURER ID AND NAME
    Private Sub GetLecturerIdAndName()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT LecturerId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Lecturer; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Lecturer Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtLecturerList = dataAccess.dtListForComboBox
            cboId.DataSource = dtLecturerList
            cboId.DisplayMember = "LecturerId"

            If cboId.Text = "" Then
                txtName.Clear()
            Else
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Check whether to enable save button or not
                EnabledSaveButton()
            End If
        End If
    End Sub

    'METHOD: GET LECTURER ID AND NAME AND PHONE NUMBER FOR THE DATAGRIDVIEW
    Private Sub GetLecturerIdAndNameAndPhoneNo()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId As [Lecturer Id], (FirstName + ' ' + LastName) As Name, PhoneNumber As [Phone number] " & _
            "FROM Lecturer " & _
            "JOIN LecturerPhoneNumber ON Lecturer.LecturerId=LecturerPhoneNumber.LecturerId " & _
            "WHERE Lecturer.LecturerId='" & cboId.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdPhone.DataSource = Nothing

            'Get the datasource for datagridview
            grdPhone.DataSource = dataAccess.objDataSet.Tables(0)

            If grdPhone.RowCount > 0 Then
                'Enable the Enable edit button
                btnEnableEdit.Enabled = True
            Else
                'Disable the Enable edit button
                btnEnableEdit.Enabled = False
            End If
        End If
    End Sub

    'METHOD: GET LECTURER ID AND PHONE NUMBER FOR THE DATAGRIDVIEW FROM A SINGLE TABLE
    Private Sub GetLecturerIdAndPhoneNo()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT LecturerId As [Lecturer Id], PhoneNumber As [Phone number] " & _
            "FROM LecturerPhoneNumber " & _
            "WHERE LecturerId='" & cboId.Text & "';")


        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdPhone.DataSource = Nothing

            'Get the datasource for datagridview
            grdPhone.DataSource = dataAccess.objDataSet.Tables(0)

            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand
        End If
    End Sub


    'FORM LOAD EVENT 
    Private Sub StudentAddPhone_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Get list for ID combobox
        GetLecturerIdAndName()

        'Get list for DataGridView control
        GetLecturerIdAndNameAndPhoneNo()

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub




    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
    Private Sub cboId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
        'Clear any previous bindings..
        txtName.DataBindings.Clear()

        'Binding process
        txtName.DataBindings.Add("Text", dtLecturerList, "Name")

        'Refresh datagridview
        GetLecturerIdAndNameAndPhoneNo()
    End Sub

    Private Sub EnabledSaveButton()
        If strExceptionId = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub


    Private Sub cboId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboId.Validating
        'Check if the lecturer already exists
        If cboId.Text.Trim.Length = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSetStudentCheck IsNot Nothing Then
                dataAccess.objDataSetStudentCheck.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSetIdCheck("SELECT *  " & _
                "FROM Lecturer " & _
                "WHERE LecturerId LIKE '%" & cboId.Text & "%';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSetIdCheck <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSetIdCheck, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSetIdCheck = Nothing
            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 1 Then
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

                'clear the textbox
                'txtStudentId.Clear()
            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 0 Then
                strExceptionId = "This lecturer does not exist"
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtName.Clear()
            End If
        Else
            strExceptionId = "Select or enter 12 character lecturer Id."
            ErrorProvider1.SetError(cboId, strExceptionId)

            'Clear the name textbox
            txtName.Clear()
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    'CLICK EVENT TO SAVE STUDENT PHONE NUMBER
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtPhoneNumber.Text.Trim.Length > 5 Then
            Dim objStringBuilder As New System.Text.StringBuilder
            objStringBuilder.AppendLine("Do you want to add the following phone number information?")
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Lecturer-Info: " & txtName.Text & " | " & cboId.Text)
            objStringBuilder.AppendLine("Phone-Info: " & txtPhoneNumber.Text)

            'Show message box
            If MessageBox.Show(objStringBuilder.ToString, "Add New Phone Number", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                objCommand = New SqlCommand
                objCommand.CommandText = "INSERT INTO LecturerPhoneNumber " & _
                    "VALUES(@studentId,@phoneNumber); "

                'Add parameters for the placeholder in the SQL CommandText property..
                objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
                objCommand.Parameters.AddWithValue("@phoneNumber", txtPhoneNumber.Text)

                'Call AddDetails method to add phone number
                dataAccess.AddDetails(objCommand)

                'Check for errors
                If dataAccess.strExceptionAddDetails <> "" Then
                    If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                        'Show error message
                        MessageBox.Show("The phone number of the lecturer already exists.", "Add Phone Number | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Else
                        'Show error message
                        MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Phone Number | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If

                    'Set the variable to nothing
                    dataAccess.strExceptionAddDetails = Nothing


                    'select text and focus on phone number textbox
                    txtPhoneNumber.SelectAll()
                    txtPhoneNumber.Focus()
                Else
                    'If there is no error, show succeed message

                    Dim objStringBuilder1 As New System.Text.StringBuilder
                    objStringBuilder1.AppendLine("The following phone number information has been successfully added.")
                    objStringBuilder1.AppendLine(String.Empty)
                    objStringBuilder1.AppendLine("Lecturer-Info: " & txtName.Text & " | " & cboId.Text)
                    objStringBuilder1.AppendLine("Phone-Info: " & txtPhoneNumber.Text)

                    'Show message box
                    MessageBox.Show(objStringBuilder1.ToString, "Add Phone Number | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    'Clear text and focus on phone number textbox
                    txtPhoneNumber.Clear()
                    txtPhoneNumber.Focus()

                    'Refresh datagridview
                    GetLecturerIdAndNameAndPhoneNo()
                End If
            End If
        Else
            'Show error message
            MsgBox("The phone number must be at least greater than 5 digits.", MsgBoxStyle.Exclamation, "Lecturer phone number details")

            'Clear and focus on phone number textbox
            txtPhoneNumber.Clear()
            txtPhoneNumber.Focus()
        End If
    End Sub

    Private Sub btnEnableEdit_Click(sender As Object, e As EventArgs) Handles btnEnableEdit.Click
        If btnEnableEdit.Text = "Enable Edit" Then
            'Change the text
            btnEnableEdit.Text = "Disable Edit"

            'Fill datagridview from a single phone number table
            GetLecturerIdAndPhoneNo()

            grdPhone.ReadOnly = False

            'Allow user to delete rows
            grdPhone.AllowUserToDeleteRows = True

        Else
            'Change the text
            btnEnableEdit.Text = "Enable Edit"

            'Fill datagridview
            GetLecturerIdAndNameAndPhoneNo()

            grdPhone.ReadOnly = True

            'Donot allow user to delete rows
            grdPhone.AllowUserToDeleteRows = False
        End If
    End Sub

    Private Sub btnGrdSave_Click(sender As Object, e As EventArgs) Handles btnGrdSave.Click
        'Show question box
        If MessageBox.Show("Do you want to save the modification that you have made?", "Phone Number Modification", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                'Save updates to the datbase
                dataAccess.objDataAdapter.Update(dataAccess.objDataSet)

                'Change the text
                btnEnableEdit.Text = "Enable Edit"

                'Fill datagridview from a email address table
                GetLecturerIdAndPhoneNo()

                'Show message box
                MessageBox.Show("The modification that you have made is successfully saved.", "Phone Number Modification | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Disable the DataGridView Control
                grdPhone.Enabled = False

                'Disable the Save button inside 'View and Modify' groupbox
                btnGrdSave.Enabled = False
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        'Fill datagridview 
        GetLecturerIdAndNameAndPhoneNo()

        'Change the text
        btnEnableEdit.Text = "Enable Edit"

        'Disable DataGridView
        grdPhone.Enabled = False
    End Sub


    Private Sub grdPhone_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles grdPhone.CellValueChanged
        'Enable the save button
        btnGrdSave.Enabled = True
    End Sub

    Private Sub grdPhone_UserDeletedRow(sender As Object, e As DataGridViewRowEventArgs) Handles grdPhone.UserDeletedRow
        'Enable the save button
        btnGrdSave.Enabled = True
    End Sub

    'CLICK EVENT OF CLEAR BUTTON  
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear text and focus on phone number textbox
        txtPhoneNumber.Clear()
        txtPhoneNumber.Focus()

    End Sub
End Class
