﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IssueAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.dtpIssueTime = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdbLecturer = New System.Windows.Forms.RadioButton()
        Me.rdbStudent = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.dtpIssueDate = New System.Windows.Forms.DateTimePicker()
        Me.cboBookTitle = New System.Windows.Forms.ComboBox()
        Me.txtIsbn = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cboBookCategory = New System.Windows.Forms.ComboBox()
        Me.cboId = New System.Windows.Forms.ComboBox()
        Me.cboFaculty = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnViewAllIssueBook = New System.Windows.Forms.Button()
        Me.grdBookIssue = New System.Windows.Forms.DataGridView()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.grdBookIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(4, 4)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnClear)
        Me.Panel2.Controls.Add(Me.btnSave)
        Me.Panel2.Location = New System.Drawing.Point(127, 480)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(270, 43)
        Me.Panel2.TabIndex = 16
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(141, 4)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'dtpIssueTime
        '
        Me.dtpIssueTime.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpIssueTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.HelpProvider1.SetHelpString(Me.dtpIssueTime, "Select the issue time.")
        Me.dtpIssueTime.Location = New System.Drawing.Point(114, 415)
        Me.dtpIssueTime.Name = "dtpIssueTime"
        Me.dtpIssueTime.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.HelpProvider1.SetShowHelp(Me.dtpIssueTime, True)
        Me.dtpIssueTime.ShowUpDown = True
        Me.dtpIssueTime.Size = New System.Drawing.Size(262, 25)
        Me.dtpIssueTime.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.dtpIssueTime, "Issue time")
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 419)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(75, 17)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Issue time:"
        '
        'txtName
        '
        Me.txtName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtName, "Here, you get the corresponding name of the selected student id.")
        Me.txtName.Location = New System.Drawing.Point(115, 190)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtName.Name = "txtName"
        Me.txtName.ReadOnly = True
        Me.HelpProvider1.SetShowHelp(Me.txtName, True)
        Me.txtName.Size = New System.Drawing.Size(261, 25)
        Me.txtName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtName, "Name")
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rdbLecturer)
        Me.Panel1.Controls.Add(Me.rdbStudent)
        Me.Panel1.Location = New System.Drawing.Point(114, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(262, 32)
        Me.Panel1.TabIndex = 0
        '
        'rdbLecturer
        '
        Me.rdbLecturer.AutoSize = True
        Me.rdbLecturer.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbLecturer.Location = New System.Drawing.Point(83, 6)
        Me.rdbLecturer.Name = "rdbLecturer"
        Me.rdbLecturer.Size = New System.Drawing.Size(80, 21)
        Me.rdbLecturer.TabIndex = 0
        Me.rdbLecturer.Text = "Lecturer"
        Me.ToolTip1.SetToolTip(Me.rdbLecturer, "Lecturer")
        Me.rdbLecturer.UseVisualStyleBackColor = True
        '
        'rdbStudent
        '
        Me.rdbStudent.AutoSize = True
        Me.rdbStudent.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbStudent.Location = New System.Drawing.Point(3, 6)
        Me.rdbStudent.Name = "rdbStudent"
        Me.rdbStudent.Size = New System.Drawing.Size(74, 21)
        Me.rdbStudent.TabIndex = 1
        Me.rdbStudent.Text = "Student"
        Me.ToolTip1.SetToolTip(Me.rdbStudent, "Student")
        Me.rdbStudent.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 14)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Borrower:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 194)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Name:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 149)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Id"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 239)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(103, 17)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Book category:"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(4, 284)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(73, 17)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Book title:"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(4, 374)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(74, 17)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Issue date:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.dtpIssueDate, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.cboBookTitle, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.txtIsbn, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.cboBookCategory, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.cboId, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.cboFaculty, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.txtName, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.cboYear, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.dtpIssueTime, 1, 9)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 10
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(408, 449)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'dtpIssueDate
        '
        Me.dtpIssueDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.dtpIssueDate, "Select the issue date.")
        Me.dtpIssueDate.Location = New System.Drawing.Point(114, 370)
        Me.dtpIssueDate.Name = "dtpIssueDate"
        Me.dtpIssueDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.HelpProvider1.SetShowHelp(Me.dtpIssueDate, True)
        Me.dtpIssueDate.Size = New System.Drawing.Size(262, 25)
        Me.dtpIssueDate.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.dtpIssueDate, "Issue date")
        '
        'cboBookTitle
        '
        Me.cboBookTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboBookTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBookTitle.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboBookTitle, "Select a book title from the list.")
        Me.cboBookTitle.Location = New System.Drawing.Point(114, 280)
        Me.cboBookTitle.Name = "cboBookTitle"
        Me.HelpProvider1.SetShowHelp(Me.cboBookTitle, True)
        Me.cboBookTitle.Size = New System.Drawing.Size(262, 25)
        Me.cboBookTitle.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboBookTitle, "Book title")
        '
        'txtIsbn
        '
        Me.txtIsbn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtIsbn.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtIsbn, "Here, you get the corresponding Isbn no of the selected book.")
        Me.txtIsbn.Location = New System.Drawing.Point(115, 325)
        Me.txtIsbn.Margin = New System.Windows.Forms.Padding(4)
        Me.txtIsbn.Name = "txtIsbn"
        Me.txtIsbn.ReadOnly = True
        Me.HelpProvider1.SetShowHelp(Me.txtIsbn, True)
        Me.txtIsbn.Size = New System.Drawing.Size(261, 25)
        Me.txtIsbn.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtIsbn, "Isbn")
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 329)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 17)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Isbn:"
        '
        'cboBookCategory
        '
        Me.cboBookCategory.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboBookCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBookCategory.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboBookCategory, "Select a book category from the list to get list of books related to category sel" & _
        "ected below in 'Book title' combobox ")
        Me.cboBookCategory.Location = New System.Drawing.Point(114, 237)
        Me.cboBookCategory.Name = "cboBookCategory"
        Me.HelpProvider1.SetShowHelp(Me.cboBookCategory, True)
        Me.cboBookCategory.Size = New System.Drawing.Size(262, 25)
        Me.cboBookCategory.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboBookCategory, "Book category")
        '
        'cboId
        '
        Me.cboId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboId.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboId, "Select from the list or type 12 character student Id.")
        Me.cboId.Location = New System.Drawing.Point(114, 147)
        Me.cboId.MaxLength = 12
        Me.cboId.Name = "cboId"
        Me.HelpProvider1.SetShowHelp(Me.cboId, True)
        Me.cboId.Size = New System.Drawing.Size(262, 25)
        Me.cboId.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.cboId, "Id")
        '
        'cboFaculty
        '
        Me.cboFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFaculty.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboFaculty, "Select a faculty to get the list of students below in Id section.")
        Me.cboFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboFaculty.Location = New System.Drawing.Point(114, 102)
        Me.cboFaculty.Name = "cboFaculty"
        Me.HelpProvider1.SetShowHelp(Me.cboFaculty, True)
        Me.cboFaculty.Size = New System.Drawing.Size(262, 25)
        Me.cboFaculty.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cboFaculty, "Faculty")
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 104)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Faculty:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 59)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 17)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Year:"
        '
        'cboYear
        '
        Me.cboYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYear.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboYear, "Select a year to get the list of students below in Id section.")
        Me.cboYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboYear.Location = New System.Drawing.Point(114, 55)
        Me.cboYear.Name = "cboYear"
        Me.HelpProvider1.SetShowHelp(Me.cboYear, True)
        Me.cboYear.Size = New System.Drawing.Size(262, 25)
        Me.cboYear.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboYear, "Year")
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(8, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(416, 472)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Issue Details"
        '
        'btnViewAllIssueBook
        '
        Me.btnViewAllIssueBook.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllIssueBook.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllIssueBook.Location = New System.Drawing.Point(432, 9)
        Me.btnViewAllIssueBook.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllIssueBook.Name = "btnViewAllIssueBook"
        Me.btnViewAllIssueBook.Size = New System.Drawing.Size(125, 35)
        Me.btnViewAllIssueBook.TabIndex = 55
        Me.btnViewAllIssueBook.TabStop = False
        Me.btnViewAllIssueBook.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllIssueBook, "View all of the issued details.")
        Me.btnViewAllIssueBook.UseVisualStyleBackColor = True
        '
        'grdBookIssue
        '
        Me.grdBookIssue.AllowUserToAddRows = False
        Me.grdBookIssue.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdBookIssue.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdBookIssue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdBookIssue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdBookIssue.Location = New System.Drawing.Point(432, 51)
        Me.grdBookIssue.MultiSelect = False
        Me.grdBookIssue.Name = "grdBookIssue"
        Me.grdBookIssue.ReadOnly = True
        Me.grdBookIssue.RowHeadersVisible = False
        Me.grdBookIssue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdBookIssue.Size = New System.Drawing.Size(653, 296)
        Me.grdBookIssue.TabIndex = 56
        Me.grdBookIssue.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdBookIssue, "Click header to sort the list of books")
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'IssueAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grdBookIssue)
        Me.Controls.Add(Me.btnViewAllIssueBook)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "IssueAddNew"
        Me.Size = New System.Drawing.Size(1100, 537)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.grdBookIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents dtpIssueTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents rdbLecturer As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStudent As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cboYear As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboBookCategory As System.Windows.Forms.ComboBox
    Friend WithEvents cboId As System.Windows.Forms.ComboBox
    Friend WithEvents txtIsbn As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cboBookTitle As System.Windows.Forms.ComboBox
    Friend WithEvents dtpIssueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents btnViewAllIssueBook As System.Windows.Forms.Button
    Friend WithEvents grdBookIssue As System.Windows.Forms.DataGridView

End Class
