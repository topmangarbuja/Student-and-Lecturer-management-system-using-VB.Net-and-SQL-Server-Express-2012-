﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModuleAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtModuleName = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.cboFaculty = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtModuleCode = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtCreditHours = New ControlLibrary_IMS.TextBoxNumeric()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnViewModules = New System.Windows.Forms.Button()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grdModule = New System.Windows.Forms.DataGridView()
        Me.GroupBox5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdModule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox5.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(13, 6)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(399, 249)
        Me.GroupBox5.TabIndex = 10
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Module Details"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.Controls.Add(Me.txtModuleName, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.cboFaculty, 1, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.Label22, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.cboYear, 1, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label23, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label24, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label25, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label26, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.txtModuleCode, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.txtCreditHours, 1, 2)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 5
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(391, 226)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'txtModuleName
        '
        Me.txtModuleName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtModuleName, "Type the corresponding name of the module code. eg: Information Processing")
        Me.txtModuleName.Location = New System.Drawing.Point(107, 55)
        Me.txtModuleName.MaxLength = 70
        Me.txtModuleName.Name = "txtModuleName"
        Me.HelpProvider1.SetShowHelp(Me.txtModuleName, True)
        Me.txtModuleName.Size = New System.Drawing.Size(261, 25)
        Me.txtModuleName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtModuleName, "Module name")
        '
        'cboFaculty
        '
        Me.cboFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFaculty.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboFaculty, "Select a corresponding faculty for the module.")
        Me.cboFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboFaculty.Location = New System.Drawing.Point(107, 192)
        Me.cboFaculty.Name = "cboFaculty"
        Me.HelpProvider1.SetShowHelp(Me.cboFaculty, True)
        Me.cboFaculty.Size = New System.Drawing.Size(261, 25)
        Me.cboFaculty.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboFaculty, "Faculty")
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 14)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(92, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Module code:"
        '
        'cboYear
        '
        Me.cboYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYear.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboYear, "Select a year according to the module.")
        Me.cboYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboYear.Location = New System.Drawing.Point(107, 147)
        Me.cboYear.Name = "cboYear"
        Me.HelpProvider1.SetShowHelp(Me.cboYear, True)
        Me.cboYear.Size = New System.Drawing.Size(261, 25)
        Me.cboYear.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.cboYear, "Year")
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(4, 149)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(36, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Year"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(4, 59)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(96, 17)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Module name:"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(4, 104)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(89, 17)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Credit hours:"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(4, 194)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(58, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Faculty:"
        '
        'txtModuleCode
        '
        Me.txtModuleCode.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtModuleCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.HelpProvider1.SetHelpString(Me.txtModuleCode, "Type a code for the module. eg: CCT101")
        Me.txtModuleCode.Location = New System.Drawing.Point(107, 10)
        Me.txtModuleCode.MaxLength = 10
        Me.txtModuleCode.Name = "txtModuleCode"
        Me.HelpProvider1.SetShowHelp(Me.txtModuleCode, True)
        Me.txtModuleCode.Size = New System.Drawing.Size(261, 25)
        Me.txtModuleCode.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtModuleCode, "Module code")
        '
        'txtCreditHours
        '
        Me.txtCreditHours.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtCreditHours, "Type the credit hours of the module. eg: 20")
        Me.txtCreditHours.Location = New System.Drawing.Point(107, 100)
        Me.txtCreditHours.MaxLength = 3
        Me.txtCreditHours.Name = "txtCreditHours"
        Me.HelpProvider1.SetShowHelp(Me.txtCreditHours, True)
        Me.txtCreditHours.Size = New System.Drawing.Size(261, 25)
        Me.txtCreditHours.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtCreditHours, "Credit hours")
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Location = New System.Drawing.Point(123, 262)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(270, 43)
        Me.Panel1.TabIndex = 12
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(140, 4)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(3, 4)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnViewModules
        '
        Me.btnViewModules.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewModules.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewModules.Location = New System.Drawing.Point(420, 13)
        Me.btnViewModules.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewModules.Name = "btnViewModules"
        Me.btnViewModules.Size = New System.Drawing.Size(125, 35)
        Me.btnViewModules.TabIndex = 19
        Me.btnViewModules.TabStop = False
        Me.btnViewModules.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewModules, "View all of modules available in the college.")
        Me.btnViewModules.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'grdModule
        '
        Me.grdModule.AllowUserToAddRows = False
        Me.grdModule.AllowUserToDeleteRows = False
        Me.grdModule.AllowUserToOrderColumns = True
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdModule.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle2
        Me.grdModule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdModule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdModule.Location = New System.Drawing.Point(420, 55)
        Me.grdModule.MultiSelect = False
        Me.grdModule.Name = "grdModule"
        Me.grdModule.ReadOnly = True
        Me.grdModule.RowHeadersVisible = False
        Me.grdModule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdModule.ShowCellToolTips = False
        Me.grdModule.Size = New System.Drawing.Size(509, 247)
        Me.grdModule.TabIndex = 20
        Me.grdModule.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdModule, "Click header to sort the list of students.")
        '
        'ModuleAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grdModule)
        Me.Controls.Add(Me.btnViewModules)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "ModuleAddNew"
        Me.Size = New System.Drawing.Size(941, 317)
        Me.GroupBox5.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdModule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents cboFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents cboYear As System.Windows.Forms.ComboBox
    Friend WithEvents btnViewModules As System.Windows.Forms.Button
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents grdModule As System.Windows.Forms.DataGridView
    Friend WithEvents txtModuleCode As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents txtCreditHours As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtModuleName As ControlLibrary_IMS.TextBoxCharacterPunctuation

End Class
