﻿Public Class TextBoxNumericPunctuation
    Inherits TextBox

    Protected Overrides Sub OnKeyPress(e As KeyPressEventArgs)
        MyBase.OnKeyPress(e)

        If Not Char.IsDigit(e.KeyChar) And Not Char.IsPunctuation(e.KeyChar) And Not Asc(e.KeyChar) = 8 Then
            e.Handled = True
        Else
            e.Handled = False
        End If
    End Sub
End Class
