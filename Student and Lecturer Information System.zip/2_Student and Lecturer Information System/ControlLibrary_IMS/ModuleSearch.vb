﻿Imports System.Data.SqlClient
Imports ClassLibrary_IMS

Public Class ModuleSearch
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtModuleList As New DataTable
    Dim strModuleCode As String
    Dim strModuleName As String
    Dim rowNumber As Int16


    'Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
    '    Dim objStringBuilder As New System.Text.StringBuilder

    '    objStringBuilder.AppendLine("Do you want to add the following module information?")
    '    objStringBuilder.AppendLine(String.Empty)
    '    objStringBuilder.AppendLine("Module-Code: " & txtModuleCode.Text)
    '    objStringBuilder.AppendLine("Module-Name: " & txtModuleName.Text)

    '    Dim intYear As Integer
    '    'Get year value for YEAR combobox
    '    Select Case cboYear.SelectedIndex
    '        Case 0
    '            intYear = 0
    '        Case 1
    '            intYear = 1
    '        Case 2
    '            intYear = 2
    '        Case 3
    '            intYear = 3
    '    End Select

    '    'Show message box
    '    If MessageBox.Show(objStringBuilder.ToString, "Add New Module | Process-Succeed", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = DialogResult.Yes Then

    '        objCommand = New SqlCommand
    '        objCommand.CommandText = "INSERT INTO Module " & _
    '            "VALUES(@moduleCode,@moduleName,@creditHours,@year,@faculty);"

    '        'Add parameters for the placeholders in the SQL CommandText property..

    '        'Module Details
    '        objCommand.Parameters.AddWithValue("@moduleCode", txtModuleCode.Text)
    '        objCommand.Parameters.AddWithValue("@moduleName", txtModuleName.Text)
    '        objCommand.Parameters.AddWithValue("@creditHours", txtCreditHours.Text)
    '        objCommand.Parameters.AddWithValue("@year", intYear)
    '        objCommand.Parameters.AddWithValue("@faculty", cboFaculty.Text)

    '        'Call AddDetails procedure to add Module Details
    '        dataAccess.AddDetails(objCommand)

    '        'Check for errors
    '        If dataAccess.strExceptionAddDetails <> "" Then
    '            'Show error message
    '            MessageBox.Show(dataAccess.strExceptionAddDetails, "Add New Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '            'Set variable to nothing
    '            dataAccess.strExceptionAddDetails = Nothing
    '        Else
    '            Dim objStringBuilder1 As New System.Text.StringBuilder

    '            objStringBuilder1.AppendLine("The following new information has been successfully added.")
    '            objStringBuilder1.AppendLine(String.Empty)
    '            objStringBuilder1.AppendLine("Module-Info: " & txtModuleCode.Text & " | " & txtModuleName.Text)

    '            'Show message box
    '            MessageBox.Show(objStringBuilder1.ToString, "Add New Module | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

    '            'Call ClearMainFields procedure to clear textboxes
    '            ClearMainFields()

    '            'Select first item in the Year combobox
    '            cboYear.SelectedIndex = 0

    '            'Focus on Module Code textbox
    '            txtModuleCode.Focus()

    '            'Call method to get list of module code and name
    '            GetModuleCodeAndName()
    '        End If
    '    End If

    'End Sub

    'METHOD:CLEARS TEXTBOXES

    'METHOD: GET LIST OF MODULE

    Private Sub GetModuleList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Module " & _
                                          "ORDER BY Year, Faculty, Name;")

        'Call method to fill datagridview
        FillDataGridView()
    End Sub

    'METHOD: GET LIST OF MODULE BASED ON YEAR AND FACULTY
    Private Sub GetFilterModuleList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Module " & _
                                          "WHERE Year=" & intYear & " " & _
                                          "AND Faculty='" & cboFaculty.Text & "' " & _
                                          "ORDER BY Year, Faculty, Name;")

        'Call method to fill datagridview
        FillDataGridView()
    End Sub

    'METHOD: FILL THE DATAGRIDVIEW
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Retrieving Module code and name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdModule.DataSource = Nothing

            'Get the datasource for datagridview
            dtModuleList = dataAccess.objDataSet.Tables(0)
            GblAccessItem.DataTableModuleSearch = dataAccess.AutoNumberedTable(dtModuleList)

            grdModule.DataSource = dtModuleList

            'Get the update command
            'dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand

            If grdModule.Rows.Count > 0 Then
                'Enable the Report button
                btnGetReport.Enabled = True
            Else
                'Disable the Report button
                btnGetReport.Enabled = False
            End If
            'List the number of rows in the result
            lblResult.Text = grdModule.RowCount

            grdModule.Columns(0).Frozen = True
        End If
    End Sub

    'FORM LOAD EVENT
    Private Sub ModuleAddNew_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Clear the searching fields
        ClearMainFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'METHOD:CLEARS TEXTBOXES
    Private Sub ClearMainFields()
        'Clear the textboxes
        txtModuleCode.Clear()
        txtModuleName.Clear()
        txtCreditHours.Clear()
        cboYear.Items.Clear()
        cboFaculty.Items.Clear()
    End Sub


    'CLICK EVENT OF YEAR COMBOBOX
    Private Sub cboYear_Click(sender As Object, e As EventArgs) Handles cboYear.Click
        'Clear existing items from the Year and Faculty combobox
        cboYear.Items.Clear()
        cboFaculty.Items.Clear()

        'Add following items to the combobox
        Dim strItemsYear() As String = {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"}
        cboYear.Items.AddRange(strItemsYear)

        Dim strItemsFaculty() As String = {"BBA", "BSC.IT", "FCHE"}
        cboFaculty.Items.AddRange(strItemsFaculty)
    End Sub

    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        'Clear other textboxes and combobox items
        txtModuleCode.Clear()
        txtModuleName.Clear()
        txtCreditHours.Clear()

        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If

        'Get list of modules
        GetFilterModuleList()
    End Sub

    'CLICK EVENT OF VIEWALLMODULES BUTTON
    Private Sub btnViewAllModules_Click(sender As Object, e As EventArgs) Handles btnViewAllModules.Click
        'Call method to get list of module code and name
        GetModuleList()
    End Sub

    'ENTER EVENT OF SEARCHING FIELDS
    Private Sub txtModule_Enter(sender As Object, e As EventArgs) Handles txtModuleCode.Enter, txtModuleName.Enter, txtCreditHours.Enter
        txtModuleCode.Clear()
        txtModuleName.Clear()
        txtCreditHours.Clear()
        cboFaculty.Items.Clear()
        cboYear.Items.Clear()

        'Call method to clear searching fields
        ClearMainFields()

        'Clear the datasource of the datagridview
        grdModule.DataSource = Nothing

        If grdModule.Rows.Count > 0 Then
            'Enable the Report button
            btnGetReport.Enabled = True
        Else
            'Disable the Report button
            btnGetReport.Enabled = False
        End If

        'List the number of rows in the result
        lblResult.Text = grdModule.RowCount
    End Sub


    'TEXCHANGED EVENT OF MODULECODE TEXTBOX
    Private Sub txtModuleCode_TextChanged(sender As Object, e As EventArgs) Handles txtModuleCode.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Module " & _
                                          "WHERE ModuleCode LIKE '%" & txtModuleCode.Text & "%' " & _
                                          "ORDER BY Year, Faculty, Name;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXCHANGED EVENT OF MODULENAME TEXTBOX
    Private Sub txtModuleName_TextChanged(sender As Object, e As EventArgs) Handles txtModuleName.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Module " & _
                                          "WHERE Name LIKE '%" & txtModuleName.Text & "%' " & _
                                          "ORDER BY Year, Faculty, Name;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXCHANGED EVENT OF CREDITHOURS TEXTBOX
    Private Sub txtCreditHours_TextChanged(sender As Object, e As EventArgs) Handles txtCreditHours.TextChanged
        'Clear other textboxes and combobox items
        txtModuleCode.Clear()
        txtModuleName.Clear()
        cboYear.Items.Clear()
        cboFaculty.Items.Clear()

        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Module " & _
                                          "WHERE CreditHours LIKE '%" & txtCreditHours.Text & "%' " & _
                                          "ORDER BY Year, Faculty, Name;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'SELECTEDINDEXCHANGED EVENT OF FACULTY COMBOBOX
    Private Sub cboFaculty_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFaculty.SelectedIndexChanged
        'Clear other textboxes and combobox items
        txtModuleCode.Clear()
        txtModuleName.Clear()
        txtCreditHours.Clear()

        'Get list of modules
        GetFilterModuleList()
    End Sub




    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "ModuleSearch"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub


















    'EDIT SECTIONS

    Private Sub btnShowEditSection_Click(sender As Object, e As EventArgs) Handles btnShowEditSection.Click
        'Dim s As Point = pnlListOfStudent.Location
        If btnShowEditSection.Text = "Show Edit section" Then
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X - 100
            pnlListOfStudent.Location = p

            grpResult.Size = New Size(483, 330)

            Dim g As Point = grpResult.Location
            g.X = grpResult.Width + 20
            grpEdit.Location = g

            grpEdit.Visible = True
            lblDetails.Visible = True

            btnShowEditSection.Text = "Hide Edit section"
        Else
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X + 100
            pnlListOfStudent.Location = p


            grpResult.Size = New Size(880, 330)

            grpEdit.Visible = False
            lblDetails.Visible = False

            btnShowEditSection.Text = "Show Edit section"

            'Disable the controls of the textboxes and buttons
            DisabledControls()
        End If

        'First clear the text fields
        ClearFields()
    End Sub


    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtEditModuleCode.Enabled = True
        txtEditModuleName.Enabled = True
        txtEditCreditHours.Enabled = True
        cboEditYear.Enabled = True
        cboEditFaculty.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtEditModuleCode.Enabled = False
        txtEditModuleName.Enabled = False
        txtEditCreditHours.Enabled = False
        cboEditYear.Enabled = False
        cboEditFaculty.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    'CLEAR TEXT FIELDSSET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtEditModuleCode.Clear()
        txtEditModuleName.Clear()
        txtEditCreditHours.Clear()
        cboEditYear.Text = ""
        cboEditFaculty.Text = ""
    End Sub




    Private Sub grdModule_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdModule.CellClick
        If grpEdit.Visible = True Then
            rowNumber = grdModule.CurrentCell.RowIndex

            'Clear the text fields in the view section
            ClearFields()

            'Enable the controls of the datagridview sections
            EnableControls()

            For i As Integer = 0 To grdModule.ColumnCount - 1
                Try
                    Select Case i
                        Case 0
                            'Get id and name
                            strModuleCode = grdModule.Item(0, e.RowIndex).Value
                            'Get values for the textboxes and combobox
                            txtEditModuleCode.Text = grdModule.Item(0, e.RowIndex).Value

                        Case 1
                            strModuleName = grdModule.Item(1, e.RowIndex).Value
                            txtEditModuleName.Text = grdModule.Item(1, e.RowIndex).Value

                        Case 2
                            txtEditCreditHours.Text = grdModule.Item(2, e.RowIndex).Value

                        Case 3
                            If grdModule.Item(3, e.RowIndex).Value = 0 Then
                                cboEditYear.SelectedIndex = 0
                            ElseIf grdModule.Item(3, e.RowIndex).Value = 1 Then
                                cboEditYear.SelectedIndex = 1
                            ElseIf grdModule.Item(3, e.RowIndex).Value = 2 Then
                                cboEditYear.SelectedIndex = 2
                            ElseIf grdModule.Item(3, e.RowIndex).Value = 3 Then
                                cboEditYear.SelectedIndex = 3
                            End If
                        Case 4
                            If grdModule.Item(4, e.RowIndex).Value.ToString.ToLower.Contains("bba") Then
                                cboEditFaculty.SelectedIndex = 0
                            ElseIf grdModule.Item(4, e.RowIndex).Value.ToString.ToLower.Contains("bsc.it") Then
                                cboEditFaculty.SelectedIndex = 1
                            ElseIf grdModule.Item(4, e.RowIndex).Value.ToString.ToLower.Contains("fche") Then
                                cboEditFaculty.SelectedIndex = 2
                            End If
                    End Select
                Catch ex As Exception

                End Try
            Next

            'Make sure that the Update button is disabled
            btnUpdate.Enabled = False
        End If
    End Sub

    Private Sub cboEditYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboEditYear.SelectedIndexChanged
        If cboEditYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboEditFaculty.Items.Contains("FCHE") Then
                cboEditFaculty.Items.Add("FCHE")
            End If
            cboEditFaculty.SelectedIndex = cboEditFaculty.Items.Count - 1
            cboEditFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboEditFaculty.Enabled = True
            cboEditFaculty.Items.Remove("FCHE")
        End If
    End Sub

    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtEditModuleCode.TextChanged, txtEditModuleName.TextChanged, txtEditCreditHours.TextChanged, _
        cboEditYear.SelectedIndexChanged, cboEditFaculty.SelectedIndexChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    'CLICK EVENT OF UPDATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Check whether required data is entered or not
        If CheckModuleCodeAndName() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update module: |" & strModuleCode & "| (" & strModuleName & ") details?", "ModuleDetails", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                Dim intYear As Integer
                'Get year value for YEAR combobox
                Select Case cboEditYear.SelectedIndex
                    Case 0
                        intYear = 0
                    Case 1
                        intYear = 1
                    Case 2
                        intYear = 2
                    Case 3
                        intYear = 3
                End Select

                'Create a sql query text
                Dim strCommand As String = "UPDATE MODULE " & _
                                     "SET ModuleCode=@moduleCode, " & _
                                     "Name= @moduleName, " & _
                                     "CreditHours=@creditHours, " & _
                                     "Year=@year, " & _
                                     "Faculty=@faculty " & _
                                     "WHERE ModuleCode=@moduleCodeOriginal;"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                'Module Details
                objCommand.Parameters.AddWithValue("@moduleCode", txtEditModuleCode.Text)
                objCommand.Parameters.AddWithValue("@moduleName", txtEditModuleName.Text)
                objCommand.Parameters.AddWithValue("@creditHours", txtEditCreditHours.Text)
                objCommand.Parameters.AddWithValue("@year", intYear)
                objCommand.Parameters.AddWithValue("@faculty", cboEditFaculty.Text)
                objCommand.Parameters.AddWithValue("@moduleCodeOriginal", strModuleCode)

                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Module Details")

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing

                    'Call ClearFields method to clear the text
                    ClearFields()

                    'Call DisableControl method to disable controls
                    DisabledControls()
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Module: |" & strModuleCode & "| (" & strModuleName & ") details has been successfully updated.", MsgBoxStyle.Information, "Module Details")

                    'Call btnView_Click procedure
                    'btnFilterView_Click(Nothing, Nothing)

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    'Call method to get list of name and code
                    dataAccess.RunQueryAndFillDataSet("SELECT * FROM Module " & _
                                                      "WHERE ModuleCode ='" & txtEditModuleCode.Text & "';")

                    'Fill the datagridview
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no module with details: |" & strModuleCode & "| (" & strModuleName & ").", MsgBoxStyle.Exclamation, "Module Details")

                    'Call btnView_Click procedure
                    'btnFilterView_Click(Nothing, Nothing)
                End If

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            End If
        End If
    End Sub

    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete module: |" & strModuleCode & "| (" & strModuleName & ") details?", "Module Details", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM MODULE " & _
                                 "WHERE ModuleCode= @moduleCode;"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@moduleCode", strModuleCode)

            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Module Details")

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("module: |" & strModuleCode & "| (" & strModuleName & ") details has been successfully deleted.", MsgBoxStyle.Information, "Module Details")

                'Call btnFilterView_Click procedure
                'btnFilterView_Click(Nothing, Nothing)

                'Remove row from the gridview
                grdModule.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdModule.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no module with details: |" & strModuleCode & "| (" & strModuleName & ").", MsgBoxStyle.Exclamation, "Module Details")

                'Call btnView_Click procedure
                'btnFilterView_Click(Nothing, Nothing)
            End If

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckModuleCodeAndName() As Boolean
        If txtEditModuleCode.Text.Trim.Length > 0 And txtEditModuleName.Text.Trim.Length > 0 Then
            Return True
        ElseIf txtEditModuleCode.Text.Trim.Length <= 0 And txtEditModuleName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter module code and name.", "Module Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtEditModuleCode.Text.Trim.Length <= 0 And txtEditModuleName.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter module code.", "Module Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            MessageBox.Show("You have to enter module name.", "Module Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

End Class
