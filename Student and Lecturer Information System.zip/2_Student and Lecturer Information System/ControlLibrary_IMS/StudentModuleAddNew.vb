﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class StudentModuleAddNew
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtStudentList As New DataTable
    Dim dtModuleList As New DataTable
    Private objModuleDictionary As New Dictionary(Of String, String)
    Private objModuleDictionarySecond As New Dictionary(Of String, String)
    Dim objModuleSelectedList As New List(Of String)


    'Variable used for the datagridview section
    Dim strStudentId As String
    Dim strValue As String
    Dim dtStartDate As Date
    Dim blnDeleteSucceed As Boolean = False
    Dim blnUpdate As Boolean = False
    Dim strExceptionId As String = "errStudentId"

    'METHOD: GET STUDENT ID AND NAME BASED ON COMBOBOX SELECTION
    Private Sub GetStudentIdAndName()
        'Set the datasource property of StudentId combobox to nothing
        cboId.DataSource = Nothing

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        objCommand = New SqlCommand
        'objCommand.CommandText = "SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
        '    "FROM Student " & _
        '    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    "WHERE Year=@year " & _
        '    "AND Faculty=@faculty;"

        If intYear = 3 Then
            'Get list of name and id and phone
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Student " & _
            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
            "WHERE Year=@year " & _
            "AND Faculty=@faculty " & _
            "AND Status=@status;"
        ElseIf intYear = 2 Then
            'Get list of name and id and phone
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Status=@status " & _
                                              "AND Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = @year " & _
                                              "AND Faculty=@faculty " & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = @year + 1 " & _
                                              "AND Faculty=@faculty ));"
        ElseIf intYear = 1 Then
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Status=@status " & _
                                              "AND Student.StudentId In " & _
                                              "(SELECT Student.StudentId " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE STudent.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = @year " & _
                                              "AND Faculty=@faculty " & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = @year + 1  " & _
                                              "AND Faculty= @faculty )));"
        ElseIf intYear = 0 Then
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Status=@status " & _
                                            "AND Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = @year " & _
                                            "AND Faculty= @faculty " & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = @year+1 " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA' " & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = @year + 2 " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA' " & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = @year + 3 " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA'))));"

        End If

        'Add parameters for the placeholders in the SQL CommandText property
        objCommand.Parameters.AddWithValue("@year", intYear)
        objCommand.Parameters.AddWithValue("@faculty", cboFaculty.Text)
        objCommand.Parameters.AddWithValue("@status", "Active")

        'Call GetStudentName method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtStudentList = dataAccess.dtListForComboBox
            cboId.DataSource = dtStudentList
            cboId.DisplayMember = "StudentId"

            If cboId.Text = "" Then
                txtName.Clear()
                strExceptionId = "errStudentId"
            Else
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)
            End If

            'Check whether to enable save button or not
            EnabledSaveButton()
        End If
    End Sub

    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If

        'Call procedure to get list of module code and name
        GetModuleCodeAndName()

        'Call GetStudentIdAndName procedure to get list in the combobox
        GetStudentIdAndName()

        'Refresh datagridview
        GetStudentIdAndNameAndModule()
    End Sub


    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
    Private Sub cboStudentIdId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
        'Make sure that the items in the dictionary are cleared
        'objModuleDictionarySecond.Clear()
        'Remove(lstSelectedModule.SelectedItem.ToString.Substring(0, lstSelectedModule.SelectedItem.ToString.IndexOf(" ")))

        'Clear any previous bindings..
        txtName.DataBindings.Clear()

        'Binding process
        txtName.DataBindings.Add("Text", dtStudentList, "Name")

        'Fill the datagridview
        GetStudentIdAndNameAndModule()
    End Sub

    'SELECTEDINDEXCHANGED EVEN TO GET LIST OF STUDENTS
    Private Sub cboFaculty_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFaculty.SelectedIndexChanged
        'Call GetStudentName to get list in the combobox
        GetStudentIdAndName()

        'Get list of modules
        GetModuleCodeAndName()

        'Refresh datagridview
        GetStudentIdAndNameAndModule()
    End Sub

    'FORM LOAD EVENT
    Private Sub StudentModuleAddNew_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0

        'Get list of modules
        GetModuleCodeAndName()

        'Select first item in the Semester combobox
        cboSemester.SelectedIndex = 0

        'Fill the datagridview
        GetStudentIdAndNameAndModule()

        'Make sure that the datagridview readonly property is true
        grdStudentModule.ReadOnly = True
    End Sub

    'METHOD: GET MODULE CODE AND NAME
    Private Sub GetModuleCodeAndName()
        'Clear the list of the list box
        lstListOfModules.Items.Clear()
        lstSelectedModule.Items.Clear()

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT ModuleCode, Name " & _
            "FROM Module " & _
            "WHERE Year= " & intYear & _
            " AND Faculty='" & cboFaculty.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Retrieving Module code and name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear the list of items from the dictionary
            objModuleDictionary.Clear()
            objModuleDictionarySecond.Clear()

            'Get the table data
            dtModuleList = dataAccess.objDataSet.Tables(0)

            'Add to each row to Dictionary variable
            For i = 0 To dtModuleList.Rows.Count - 1
                objModuleDictionary.Add(dtModuleList.Rows(i).Item(0), dtModuleList.Rows(i).Item(1))
            Next

            For Each j As KeyValuePair(Of String, String) In objModuleDictionary
                lstListOfModules.Items.Add(j.Key() & " | " & j.Value())
            Next
        End If
    End Sub

    'DOUBLE CLICK EVENT TO ADD MODULE TO ANOTHER LISTBOX
    Private Sub lstListOfModules_DoubleClick(sender As Object, e As EventArgs) Handles lstListOfModules.DoubleClick
        Try
            ' If Not lstSelectedModule.Items.Contains(objModuleDictionary.Keys(lstListOfModules.SelectedIndex)) Then
            If Not objModuleDictionarySecond.ContainsKey(objModuleDictionary.Keys(lstListOfModules.SelectedIndex)) Then
                objModuleDictionarySecond.Add(objModuleDictionary.Keys(lstListOfModules.SelectedIndex), objModuleDictionary.Values(lstListOfModules.SelectedIndex))

                lstSelectedModule.Items.Add(objModuleDictionary.Keys(lstListOfModules.SelectedIndex) & " | " & objModuleDictionary.Values(lstListOfModules.SelectedIndex))
            End If
        Catch ex As Exception

        End Try
    End Sub

    'REMOVE THE SELECTED ITEM IN THE SELECTED MODULE LISTBOX
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            'Remove the item from dictionary: By getting the all text upto until the first occurrence of a space
            objModuleDictionarySecond.Remove(lstSelectedModule.SelectedItem.ToString.Substring(0, lstSelectedModule.SelectedItem.ToString.IndexOf(" ")))

            'Remove the selected item
            lstSelectedModule.Items.RemoveAt(lstSelectedModule.SelectedIndex)
        Catch ex As Exception
            'Do nothing
        End Try
    End Sub

    'GET MODULE CODE FOR THE MODULE IN THE SELECTED MODULE LISTBOX  
    Private Sub GetSelectedModule()
        'Clear the items in the list of the ModuleSelectedList List variable
        objModuleSelectedList.Clear()

        'Add key item to list variable
        For Each j As KeyValuePair(Of String, String) In objModuleDictionarySecond
            objModuleSelectedList.Add(j.Key())
        Next
    End Sub

    'CLICK EVENT OF SAVE BUTTON
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you want to add the module information for the student?")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
        objStringBuilder.AppendLine("Start-Date: " & dtpStartDate.Text)
        objStringBuilder.AppendLine("Semester: " & cboSemester.Text)
        For intModule As Integer = 1 To lstSelectedModule.Items.Count
            objStringBuilder.AppendLine("Module Info: " & intModule & ") " & lstSelectedModule.Items(intModule - 1))
        Next

        'Check whether module is selected or not
        If lstSelectedModule.Items.Count > 0 Then
            'Show message box
            If MessageBox.Show(objStringBuilder.ToString, "Add New Student Module", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                'Call this procedure to get list of module code from the SelectedModule ListBox
                GetSelectedModule()

                'Call procedure to add module for the student
                AddStudentModule()
            End If
        Else
            'Show error message
            MsgBox("Please select at least one module from the 'List of modules' section to get in the 'Selected module' section.", MsgBoxStyle.Exclamation, "Student Module")
        End If
        
    End Sub

    'METHOD TO ADD SELECTED MODULE FOR THE STUDENT
    Private Sub AddStudentModule()
        'Integer variable
        Dim intCount As Integer = 0

        'Get each of module code from the List variable
        For Each i As Object In objModuleSelectedList
            objCommand = New SqlCommand
            objCommand.CommandText = "INSERT INTO StudentModule " & _
                "VALUES(@studentId,@moduleCode, @startDate,@semester); "

            'Add parameters for the placeholder in the SQL CommandText property..
            objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
            objCommand.Parameters.AddWithValue("@moduleCode", i)
            objCommand.Parameters.AddWithValue("@startDate", dtpStartDate.Value.Date)
            objCommand.Parameters.AddWithValue("@semester", cboSemester.Text)

            'Call AddDetails method to add selected module for the student
            dataAccess.AddDetails(objCommand)

            'Check for errors
            If dataAccess.strExceptionAddDetails <> "" Then

                If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                    'Show error message
                    MessageBox.Show("The student has already take this module at the same date.", "Add Student Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    'Show error message
                    MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Student Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

                'Set the variable to nothing
                dataAccess.strExceptionAddDetails = Nothing

                'Select and focus on phone number textbox
                lstSelectedModule.Select()
                lstSelectedModule.Focus()
            Else
                intCount += 1

                If intCount = objModuleDictionarySecond.Count Then
                    'If there is no error, show succeed message
                    Dim objStringBuilder1 As New System.Text.StringBuilder
                    objStringBuilder1.AppendLine("The following module information for the student has been successfully added.")
                    objStringBuilder1.AppendLine(String.Empty)
                    objStringBuilder1.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
                    objStringBuilder1.AppendLine("Start-Date: " & dtpStartDate.Text)
                    objStringBuilder1.AppendLine("Semester: " & cboSemester.Text)
                    For intModule As Integer = 1 To lstSelectedModule.Items.Count
                        objStringBuilder1.AppendLine("Module Info: " & intModule & ") " & lstSelectedModule.Items(intModule - 1))
                    Next


                    'Show message box
                    MessageBox.Show(objStringBuilder1.ToString, "Add Student Module | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    'Clear the selected module listbox
                    lstSelectedModule.Items.Clear()
                    objModuleDictionarySecond.Clear()

                    'Refresh datagridview
                    GetStudentIdAndNameAndModule()
                End If
            End If
        Next

    End Sub


    Private Sub EnabledSaveButton()
        If strExceptionId = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub cboStudentId_Validating(sender As Object, e As EventArgs) Handles cboId.Validating
        'Check if the student already exists
        If cboId.Text.Trim.Length = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSetStudentCheck IsNot Nothing Then
                dataAccess.objDataSetStudentCheck.Clear()
            End If

            Dim intYear As Integer
            'Get year value for YEAR combobox
            Select Case cboYear.SelectedIndex
                Case 0
                    intYear = 0
                Case 1
                    intYear = 1
                Case 2
                    intYear = 2
                Case 3
                    intYear = 3
            End Select
            ''Get list of name and id and phone
            'dataAccess.RunQueryAndFillDataSetIdCheck("SELECT *  " & _
            '    "FROM Student " & _
            '    "WHERE StudentId LIKE '%" & cboId.Text & "%';")

            If intYear = 3 Then
                'Get list of name and id and phone
                dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                "FROM Student " & _
                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                 "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                "AND Year= 3 " & _
                "AND Faculty='" & cboFaculty.Text & "' " & _
                "AND Status='Active';")
            ElseIf intYear = 2 Then
                'Get list of name and id and phone
                dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                 "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                                                  "AND Status='Active' " & _
                                                  "AND Student.StudentId In " & _
                                                  "(SELECT Student.StudentId As [Student Id] " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE Year = 2 " & _
                                                   "AND Faculty='" & cboFaculty.Text & "' " & _
                                                  "AND NOT Student.StudentId In " & _
                                                  "(SELECT Student.StudentId As [Student Id] " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE Year = 3 " & _
                                                   "AND Faculty='" & cboFaculty.Text & "')); ")
                '"AND Faculty=@faculty ));"
            ElseIf intYear = 1 Then
                dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                                                  "AND Status='Active' " & _
                                                  "AND Student.StudentId In " & _
                                                  "(SELECT Student.StudentId " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE STudent.StudentId In " & _
                                                  "(SELECT Student.StudentId As [Student Id] " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE Year =1 " & _
                                                   "AND Faculty='" & cboFaculty.Text & "' " & _
                                                  "AND NOT Student.StudentId In " & _
                                                  "(SELECT Student.StudentId As [Student Id] " & _
                                                  "FROM Student " & _
                                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE Year = 2  " & _
                                                    "AND Faculty='" & cboFaculty.Text & "'))); ")
                '"AND Faculty= @faculty )));"
            ElseIf intYear = 0 Then
                dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                                                "FROM Student " & _
                                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                                                 "AND Status='Active' " & _
                                                "AND Student.StudentId In " & _
                                                "(SELECT Student.StudentId As [Student Id] " & _
                                                "FROM Student " & _
                                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                "WHERE Year = 0 " & _
                                                "AND Faculty='" & cboFaculty.Text & "' " & _
                                                "AND NOT Student.StudentId In " & _
                                                "(SELECT Student.StudentId As [Student Id] " & _
                                                "FROM Student " & _
                                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                "WHERE Year = 1 " & _
                                                "AND Faculty='BSC.IT' OR Faculty ='BBA' " & _
                                                "AND NOT Student.StudentId In " & _
                                                "(SELECT Student.StudentId As [Student Id] " & _
                                                "FROM Student " & _
                                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                "WHERE Year = 2 " & _
                                                "AND Faculty='BSC.IT' OR Faculty ='BBA' " & _
                                                "AND NOT Student.StudentId In " & _
                                                "(SELECT Student.StudentId As [Student Id] " & _
                                                "FROM Student " & _
                                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                "WHERE Year = 3 " & _
                                                "AND Faculty='BSC.IT' OR Faculty ='BBA'))));")

            End If
          
            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSetIdCheck <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSetIdCheck, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSetIdCheck = Nothing
            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 1 Then
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

            ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 0 Then
                If intYear = 0 Then
                    strExceptionId = "This student does not exist or now the student is not in 'FCHE' level."
                Else
                    strExceptionId = "This student does not exist or now the student is not in " & cboYear.Text & " '" & cboFaculty.Text & "' level."
                End If

                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtName.Clear()
            End If
        Else
            strExceptionId = "Select or enter 12 character student Id."
            ErrorProvider1.SetError(cboId, strExceptionId)

            'Clear the name textbox
            txtName.Clear()
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub




    'LIST OF METHOD FOR THE DATAGRIDVIEW SECTION
    'METHOD: GET STUDENT ID AND NAME AND SELECTED MODULE FOR THE DATAGRIDVIEW
    Private Sub GetStudentIdAndNameAndModule()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name, Semester, Module.ModuleCode As [Module Code], Name As [Module Name], StartDate As [Start Date] " & _
            "FROM Student " & _
            "JOIN StudentModule ON Student.StudentId=StudentModule.StudentId " & _
            "JOIN Module ON StudentModule.ModuleCode=Module.ModuleCode " & _
            "WHERE Student.StudentId='" & cboId.Text & "'" & _
            "AND Year='" & intYear & "' " & _
           "AND Faculty='" & cboFaculty.Text & "';")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdStudentModule.DataSource = Nothing

            'Get the datasource for datagridview
            grdStudentModule.DataSource = dataAccess.objDataSet.Tables(0)

            'Make DataGridView ReadOnly property to true
            grdStudentModule.ReadOnly = True

            grdStudentModule.Columns(0).Frozen = True
        End If
    End Sub

    'METHOD: GET STUDENT ID AND MODULE CODE FOR THE DATAGRIDVIEW 
    Private Sub GetStudentIdAndModuleCode()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If


        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT StudentId As [Student Id], Semester, Module.ModuleCode As [Module Code], StartDate As [Start Date] " & _
            "FROM StudentModule " & _
            "JOIN Module ON StudentModule.ModuleCode=Module.ModuleCode " & _
            "WHERE StudentId='" & cboId.Text & "'" & _
            "AND Year='" & intYear & "' " & _
           "AND Faculty='" & cboFaculty.Text & "';")


        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdStudentModule.DataSource = Nothing

            'Get the datasource for datagridview
            grdStudentModule.DataSource = dataAccess.objDataSet.Tables(0)
        End If
    End Sub

    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Remove the item from dictionary
        objModuleDictionarySecond.Clear()

        'Remove the selected item
        lstSelectedModule.Items.Clear()

        cboSemester.SelectedIndex = 0
        dtpStartDate.Value = Now()
    End Sub
End Class
