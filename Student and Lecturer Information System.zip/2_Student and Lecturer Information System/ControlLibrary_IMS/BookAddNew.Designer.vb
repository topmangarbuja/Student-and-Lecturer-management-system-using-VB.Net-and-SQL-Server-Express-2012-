﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BookAddNew
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtPublisher = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.txtAuthor = New ControlLibrary_IMS.TextBoxAuthorName()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.dtpPublishDate = New System.Windows.Forms.DateTimePicker()
        Me.txtTotalQuantity = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.txtIsbn = New ControlLibrary_IMS.TextBoxNumericAndHyphon()
        Me.btnViewBooks = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grdBook = New System.Windows.Forms.DataGridView()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.GroupBox5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdBook, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox5.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(11, 3)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.GroupBox5.Size = New System.Drawing.Size(475, 345)
        Me.GroupBox5.TabIndex = 11
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Book Details"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.Controls.Add(Me.txtPublisher, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.txtAuthor, 1, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label1, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label9, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label22, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label24, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label10, 0, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.cboCategory, 1, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label26, 0, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label23, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.dtpPublishDate, 1, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.txtTotalQuantity, 1, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.txtTitle, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.txtIsbn, 1, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 7
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(465, 318)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'txtPublisher
        '
        Me.txtPublisher.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtPublisher, "Type name of the publisher. eg: Dorling Kindersley")
        Me.txtPublisher.Location = New System.Drawing.Point(174, 100)
        Me.txtPublisher.MaxLength = 75
        Me.txtPublisher.Name = "txtPublisher"
        Me.HelpProvider1.SetShowHelp(Me.txtPublisher, True)
        Me.txtPublisher.Size = New System.Drawing.Size(262, 25)
        Me.txtPublisher.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtPublisher, "Publisher")
        '
        'txtAuthor
        '
        Me.txtAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtAuthor, "Type name of the author. If muliple authors exist, type as eg: Ramez Elmasri, Sha" & _
        "mkant B. Navathe etc.")
        Me.txtAuthor.Location = New System.Drawing.Point(174, 145)
        Me.txtAuthor.MaxLength = 350
        Me.txtAuthor.Name = "txtAuthor"
        Me.HelpProvider1.SetShowHelp(Me.txtAuthor, True)
        Me.txtAuthor.Size = New System.Drawing.Size(262, 25)
        Me.txtAuthor.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtAuthor, "Author")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 149)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 17)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Author:"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 104)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 17)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Publisher:"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(5, 14)
        Me.Label22.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(43, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "ISBN:"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(5, 59)
        Me.Label24.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(41, 17)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Title:"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(5, 285)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(161, 17)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Total quantity in library:"
        '
        'cboCategory
        '
        Me.cboCategory.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboCategory.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboCategory, "Select a book category from the list if exists,otherwise type eg: Non-technical")
        Me.cboCategory.Location = New System.Drawing.Point(174, 237)
        Me.cboCategory.Name = "cboCategory"
        Me.HelpProvider1.SetShowHelp(Me.cboCategory, True)
        Me.cboCategory.Size = New System.Drawing.Size(262, 25)
        Me.cboCategory.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboCategory, "Category")
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(5, 239)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(68, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Category:"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(5, 194)
        Me.Label23.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(89, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Publish date:"
        '
        'dtpPublishDate
        '
        Me.dtpPublishDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.dtpPublishDate, "Select the published year from the list.")
        Me.dtpPublishDate.Location = New System.Drawing.Point(175, 190)
        Me.dtpPublishDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpPublishDate.Name = "dtpPublishDate"
        Me.HelpProvider1.SetShowHelp(Me.dtpPublishDate, True)
        Me.dtpPublishDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpPublishDate.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.dtpPublishDate, "Publish date")
        '
        'txtTotalQuantity
        '
        Me.txtTotalQuantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtTotalQuantity, "Type the total number of quantity of the book. eg: 10")
        Me.txtTotalQuantity.Location = New System.Drawing.Point(174, 281)
        Me.txtTotalQuantity.MaxLength = 5
        Me.txtTotalQuantity.Name = "txtTotalQuantity"
        Me.HelpProvider1.SetShowHelp(Me.txtTotalQuantity, True)
        Me.txtTotalQuantity.Size = New System.Drawing.Size(262, 25)
        Me.txtTotalQuantity.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtTotalQuantity, "Total Quantity")
        '
        'txtTitle
        '
        Me.txtTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtTitle, "Type the corresponding book title. eg: Fundamentals of Database Systems")
        Me.txtTitle.Location = New System.Drawing.Point(174, 55)
        Me.txtTitle.MaxLength = 255
        Me.txtTitle.Name = "txtTitle"
        Me.HelpProvider1.SetShowHelp(Me.txtTitle, True)
        Me.txtTitle.Size = New System.Drawing.Size(262, 25)
        Me.txtTitle.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtTitle, "Book Title")
        '
        'txtIsbn
        '
        Me.txtIsbn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.txtIsbn, "Type the Isbn no of the book. eg: 978-81-317-1625-0")
        Me.txtIsbn.Location = New System.Drawing.Point(174, 10)
        Me.txtIsbn.MaxLength = 17
        Me.txtIsbn.Name = "txtIsbn"
        Me.HelpProvider1.SetShowHelp(Me.txtIsbn, True)
        Me.txtIsbn.Size = New System.Drawing.Size(262, 25)
        Me.txtIsbn.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtIsbn, "Isbn")
        '
        'btnViewBooks
        '
        Me.btnViewBooks.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewBooks.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewBooks.Location = New System.Drawing.Point(493, 9)
        Me.btnViewBooks.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewBooks.Name = "btnViewBooks"
        Me.btnViewBooks.Size = New System.Drawing.Size(125, 35)
        Me.btnViewBooks.TabIndex = 21
        Me.btnViewBooks.TabStop = False
        Me.btnViewBooks.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewBooks, "View all of the library books available in the college.")
        Me.btnViewBooks.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Location = New System.Drawing.Point(432, -173)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(92, 17)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "List of books:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Location = New System.Drawing.Point(67, 350)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(397, 42)
        Me.Panel1.TabIndex = 15
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(262, 4)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(125, 4)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'grdBook
        '
        Me.grdBook.AllowUserToAddRows = False
        Me.grdBook.AllowUserToDeleteRows = False
        Me.grdBook.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdBook.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdBook.Location = New System.Drawing.Point(494, 51)
        Me.grdBook.MultiSelect = False
        Me.grdBook.Name = "grdBook"
        Me.grdBook.ReadOnly = True
        Me.grdBook.RowHeadersVisible = False
        Me.grdBook.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdBook.ShowCellToolTips = False
        Me.grdBook.Size = New System.Drawing.Size(297, 338)
        Me.grdBook.TabIndex = 23
        Me.grdBook.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grdBook, "Click header to sort the list of books")
        '
        'BookAddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grdBook)
        Me.Controls.Add(Me.btnViewBooks)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.GroupBox5)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "BookAddNew"
        Me.Size = New System.Drawing.Size(806, 407)
        Me.GroupBox5.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdBook, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents dtpPublishDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnViewBooks As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents grdBook As System.Windows.Forms.DataGridView
    Friend WithEvents txtTotalQuantity As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents txtIsbn As ControlLibrary_IMS.TextBoxNumericAndHyphon
    Friend WithEvents txtAuthor As ControlLibrary_IMS.TextBoxAuthorName
    Friend WithEvents txtPublisher As ControlLibrary_IMS.TextBoxCharacterPunctuation

End Class
