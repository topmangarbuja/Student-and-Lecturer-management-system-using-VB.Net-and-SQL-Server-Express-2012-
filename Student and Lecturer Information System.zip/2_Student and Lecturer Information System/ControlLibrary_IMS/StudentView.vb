﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class StudentView
    'Form-level variables
    Private dataAccess As New DataAccess
    Dim strStudentId As String
    Dim strStudentName As String
    Dim dtStudentList As DataTable
    Dim rowNumber As Int16
    Dim dtCountryUpdate As New DataTable
    Dim objCommand As SqlCommand


    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If
    End Sub

    'FORM LOAD EVENT
    Private Sub StudentView_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0

        'Select first item in the Status combobox in Filter View section
        cboFilterViewStatus.SelectedIndex = 0

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'METHOD: FILL THE DATAGRIDVIEW
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdStudent.DataSource = Nothing

            'Get the table data
            dtStudentList = dataAccess.objDataSet.Tables(0)
            GblAccessItem.DataTableStudentView = dataAccess.AutoNumberedTable(dtStudentList)

            'Get the datasource for datagridview
            grdStudent.DataSource = dtStudentList

            'Make DataGridView ReadOnly property to true
            grdStudent.ReadOnly = True

            If grdStudent.Rows.Count > 0 Then
                'Enable the Report button
                btnGetReport.Enabled = True
            Else
                'Disable the Report button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = dtStudentList.Rows.Count


            grdStudent.Columns(0).Frozen = True
        End If
    End Sub


    'METHOD: GET FILTERED STUDENT ID AND NAME AND SELECTED MODULE FOR THE DATAGRIDVIEW
    Private Sub GetFilterStudentList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        If intYear = 3 Then
            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
                                              "WHERE Status='" & cboFilterViewStatus.Text & "' " & _
                                              "AND StudentId In " & _
                                              "(SELECT Student.StudentId " & _
                "FROM Student " & _
                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                "WHERE Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "') " & _
            "ORDER BY FirstName;")
        ElseIf intYear = 2 Then
            'Get list of name and id and phone
            'dataAccess.RunQueryAndFillDataSet("SELECT DISTINCT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty, Status " & _
            '    "FROM Student " & _
            '    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
            '    "WHERE Year ='" & intYear & "' " & _
            '   "AND Faculty='" & cboFaculty.Text & "' " & _
            '"EXCEPT " & _
            '"SELECT DISTINCT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty, Status " & _
            '"FROM Student " & _
            '"JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
            '"WHERE Year ='" & intYear + 1 & "' " & _
            '"AND Faculty='" & cboFaculty.Text & "';")
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
                                              "WHERE Status='" & cboFilterViewStatus.Text & "' " & _
                                              "AND StudentId In " & _
                                              "(SELECT Student.StudentId " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE STudent.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "' " & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear + 1 & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "'))) " & _
            "ORDER BY FirstName;")
        ElseIf intYear = 1 Then
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
                                              "WHERE Status='" & cboFilterViewStatus.Text & "' " & _
                                              "AND StudentId In " & _
                                              "(SELECT Student.StudentId " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "' " & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear + 1 & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "')" & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear + 2 & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "'))) " & _
            "ORDER BY FirstName;")
        ElseIf intYear = 0 Then
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
                                              "WHERE Status='" & cboFilterViewStatus.Text & "' " & _
                                              "AND StudentId In " & _
                                              "(SELECT Student.StudentId " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear & "' " & _
                                            "AND Faculty='" & cboFaculty.Text & "' " & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear + 1 & "' " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA')" & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear + 2 & "' " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA')" & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear + 3 & "' " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA'))) " & _
            "ORDER BY FirstName;")

        End If


        'Fill the datagridview
        FillDataGridView()
    End Sub

    'CLICK EVENT OF VIEW BUTTON
    Private Sub btnFilterView_Click(sender As Object, e As EventArgs) Handles btnFilterView.Click
        'Call procedure
        GetFilterStudentList()

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub

    'CLEAR TEXT FIELD and SET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtStudentId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        dtpDateOfBirth.Value = Now
        cboGender.Text = ""
        txtDistrict.Clear()
        txtWardNo.Clear()
        txtPlace.Clear()
        cboEditCountry.Text = ""
        txtCitizenshipNo.Clear()
        txtPassportNo.Clear()
        cboStatus.Text = ""
    End Sub


    'CELL CLICK EVENT OF DATAGRIDVIEW CONTROL 
    Private Sub grdStudent_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdStudent.CellClick
        rowNumber = grdStudent.CurrentCell.RowIndex

        'First clear the text fields
        ClearFields()

        'Enable the controls of the datagridview sections
        EnableControls()

        'Get list of country
        GetCountryUpdate()

        For i As Integer = 0 To grdStudent.ColumnCount - 1
            Try
                Select Case i
                    Case 0
                        'Get id and name
                        strStudentId = grdStudent.Item(0, e.RowIndex).Value
                        'Get values for the textboxes and combobox
                        txtStudentId.Text = grdStudent.Item(0, e.RowIndex).Value

                    Case 1
                        strStudentName = grdStudent.Item(1, e.RowIndex).Value & " " & grdStudent.Item(2, e.RowIndex).Value
                        txtFirstName.Text = grdStudent.Item(1, e.RowIndex).Value

                    Case 2
                        txtLastName.Text = grdStudent.Item(2, e.RowIndex).Value

                    Case 3
                        dtpDateOfBirth.Value = grdStudent.Item(3, e.RowIndex).Value

                    Case 4

                        If grdStudent.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("female") Then
                            cboGender.SelectedIndex = 1
                        ElseIf grdStudent.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("male") Then
                            cboGender.SelectedIndex = 0
                        ElseIf grdStudent.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("other") Then
                            cboGender.SelectedIndex = 2
                        End If

                    Case 5
                        txtDistrict.Text = grdStudent.Item(5, e.RowIndex).Value

                    Case 6
                        txtWardNo.Text = grdStudent.Item(6, e.RowIndex).Value

                    Case 7
                        txtPlace.Text = grdStudent.Item(7, e.RowIndex).Value

                    Case 8
                        cboEditCountry.Text = grdStudent.Item(8, e.RowIndex).Value
                    Case 9
                        txtCitizenshipNo.Text = grdStudent.Item(9, e.RowIndex).Value

                    Case 10
                        txtPassportNo.Text = grdStudent.Item(10, e.RowIndex).Value
                    Case 11
                        If grdStudent.Item(11, e.RowIndex).Value.ToString.ToLower.StartsWith("active") Then
                            cboStatus.SelectedIndex = 0
                        ElseIf grdStudent.Item(11, e.RowIndex).Value.ToString.ToLower.StartsWith("inactive") Then
                            cboStatus.SelectedIndex = 1
                        End If
                End Select
            Catch ex As Exception

            End Try

        Next

        'Make sure that the Update button is disabled
        btnUpdate.Enabled = False
    End Sub

    'CLICK EVENT OF UDPATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Call procedure to check whether there is data or not
        If CheckFirstNameLastName() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update student: |" & strStudentId & "| (" & strStudentName & ") details?", "Student Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE STUDENT " & _
                                     "SET StudentId=@studentId, " & _
                                     "FirstName= @firstName, " & _
                                     "LastName=@lastName, " & _
                                     "DateOfBirth=@dob, " & _
                                     "Gender=@gender, " & _
                                     "District=@district, " & _
                                     "WardNo=@wardNo, " & _
                                     "Place=@place, " & _
                                     "Country=@country, " & _
                                     "CitizenshipNo=@citizenshipNo, " & _
                                     "PassportNo=@passportNo, " & _
                                     "Status=@status " & _
                                     "WHERE studentId=@studentIdOriginal;"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                objCommand.Parameters.AddWithValue("@studentId", txtStudentId.Text)
                objCommand.Parameters.AddWithValue("@firstName", txtFirstName.Text)
                objCommand.Parameters.AddWithValue("@lastName", txtLastName.Text)
                objCommand.Parameters.AddWithValue("@dob", dtpDateOfBirth.Value.Date)
                objCommand.Parameters.AddWithValue("@gender", cboGender.Text)
                objCommand.Parameters.AddWithValue("@district", txtDistrict.Text)
                objCommand.Parameters.AddWithValue("@wardNo", txtWardNo.Text)
                objCommand.Parameters.AddWithValue("@place", txtPlace.Text)
                objCommand.Parameters.AddWithValue("@country", cboEditCountry.Text)
                objCommand.Parameters.AddWithValue("@citizenshipNo", txtCitizenshipNo.Text)
                objCommand.Parameters.AddWithValue("@passportNo", txtPassportNo.Text)
                objCommand.Parameters.AddWithValue("@status", cboStatus.Text)
                objCommand.Parameters.AddWithValue("@studentIdOriginal", strStudentId)



                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Student Details")

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing

                    'Call ClearFields method to clear the text
                    ClearFields()

                    'Call DisableControl method to disable controls
                    DisabledControls()
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Student: |" & strStudentId & "| (" & strStudentName & ") details has been successfully updated.", MsgBoxStyle.Information, "Student Details")

                    'Call btnView_Click procedure
                    'btnFilterView_Click(Nothing, Nothing)

                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    'Get list of name and id and phone
                    dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
                        "FROM Student " & _
                        "WHERE StudentId ='" & txtStudentId.Text & "'; ")

                    'Fill the datagridview
                    FillDataGridView()
                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no student with details: |" & strStudentId & "| (" & strStudentName & ").", MsgBoxStyle.Exclamation, "Student Details")

                    'Call btnView_Click procedure
                    btnFilterView_Click(Nothing, Nothing)
                End If

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            End If
        End If

    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckFirstNameLastName() As Boolean
        If txtFirstName.Text.Trim.Length > 0 And txtLastName.Text.Trim.Length > 0 And txtStudentId.Text.Trim.Length = 12 Then
            Return True
        ElseIf txtFirstName.Text.Trim.Length <= 0 And txtLastName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter first name and last name.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtFirstName.Text.Trim.Length <= 0 And txtLastName.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter first name.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtFirstName.Text.Trim.Length > 0 And txtLastName.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter last name.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtStudentId.Text.Trim.Length < 12 Then
            MessageBox.Show("You have to enter 12 digit id.", "Student Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete student: |" & strStudentId & "| (" & strStudentName & ") details?", "Student Details", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM STUDENT " & _
                                 "WHERE StudentId= @studentId"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@studentId", strStudentId)

            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Student Details")

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("Student: |" & strStudentId & "| (" & strStudentName & ") details has been successfully deleted.", MsgBoxStyle.Information, "Student Details")

                'Call btnFilterView_Click procedure
                'btnFilterView_Click(Nothing, Nothing)

                'Remove row from the result box
                grdStudent.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdStudent.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no student with details: |" & strStudentId & "| (" & strStudentName & ").", MsgBoxStyle.Exclamation, "Student Details")

                'Call btnView_Click procedure
                btnFilterView_Click(Nothing, Nothing)
            End If

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub

    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtStudentId.Enabled = True
        txtFirstName.Enabled = True
        txtLastName.Enabled = True
        dtpDateOfBirth.Enabled = True
        cboGender.Enabled = True
        txtDistrict.Enabled = True
        txtWardNo.Enabled = True
        txtPlace.Enabled = True
        cboEditCountry.Enabled = True
        txtCitizenshipNo.Enabled = True
        txtPassportNo.Enabled = True
        cboStatus.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtStudentId.Enabled = False
        txtFirstName.Enabled = False
        txtLastName.Enabled = False
        dtpDateOfBirth.Enabled = False
        cboGender.Enabled = False
        txtDistrict.Enabled = False
        txtWardNo.Enabled = False
        txtPlace.Enabled = False
        cboEditCountry.Enabled = False
        txtCitizenshipNo.Enabled = False
        txtPassportNo.Enabled = False
        cboStatus.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtStudentId.TextChanged, txtFirstName.TextChanged, txtLastName.TextChanged, dtpDateOfBirth.ValueChanged, cboGender.SelectedIndexChanged, _
        txtDistrict.TextChanged, txtWardNo.TextChanged, txtPlace.TextChanged, cboEditCountry.TextChanged, cboEditCountry.SelectedIndexChanged, txtCitizenshipNo.TextChanged, txtPassportNo.TextChanged, cboStatus.SelectedIndexChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    'METHOD: GET ALL THE STUDENTS LIST
    Private Sub GetAllStudentList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of active or inactive or both students
        If rdbActive.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
                                              "WHERE Status='Active' " & _
            "ORDER BY FirstName;")
        ElseIf rdbInactive.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
                                              "WHERE Status='Inactive' " & _
            "ORDER BY FirstName;")
        ElseIf rdbBoth.Checked = True Then
            'Get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT * FROM STUDENT " & _
            "ORDER BY FirstName;")
        End If

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'CLICK EVENT OF VIEWALL BUTTON
    Private Sub btnViewAll_Click(sender As Object, e As EventArgs) Handles btnViewAll.Click
        'Call procedure to get all students
        GetAllStudentList()

        'Call ClearFields method to clear the text
        ClearFields()

        'Call DisableControl method to disable controls
        DisabledControls()
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "StudentView"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub




    Private Sub GetCountryUpdate()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Country FROM Student; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Country List | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtCountryUpdate = dataAccess.dtListForComboBox
            cboEditCountry.DataSource = dtCountryUpdate
            cboEditCountry.DisplayMember = "Country"

            'If cboEditCategory.Text = "" Then

            'End If
        End If
    End Sub
End Class
