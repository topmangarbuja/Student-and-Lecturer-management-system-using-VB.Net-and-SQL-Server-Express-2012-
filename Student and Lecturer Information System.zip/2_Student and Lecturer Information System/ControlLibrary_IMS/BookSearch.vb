﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class BookSearch
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtBookList As New DataTable

    Dim dtBookUpdateCategory As DataTable
    Dim intBookId As Integer
    Dim strBookIsbn As String
    Dim strBookTitle As String
    Dim rowNumber As Int16

    'FORM LOAD EVENT
    Private Sub StudentSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Call method to clear fields
        ClearSearchingFields()

        'Disable the controls of the textboxes and buttons
        DisabledControls()
    End Sub

    'METHOD:CLEAR SEARCHING FIELDS
    Private Sub ClearSearchingFields()
        'Clear other textboxes and combobox items
        txtIsbnNo.Clear()
        txtTitle.Clear()
        txtPublisher.Clear()
        txtCategory.Clear()
        txtAuthor.Clear()
    End Sub

    'METHOD: GET BOOK DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetBookList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
            "ORDER BY Title;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'METHOD: FILL THE DATA GRIDVIEW
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdBook.DataSource = Nothing

            'Get the table data
            dtBookList = dataAccess.objDataSet.Tables(0)
            'Get the datasource for datagridview
            grdBook.DataSource = dtBookList

            GblAccessItem.DataTableBookSearch = dataAccess.AutoNumberedTable(dtBookList)

            'Hide the first column
            grdBook.Columns(0).Visible = False

            dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand

            If grdBook.Rows.Count > 0 Then
                'Enable the GetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the GetReport button
                btnGetReport.Enabled = False
            End If

            'List the number of rows in the result
            lblResult.Text = grdBook.RowCount

            grdBook.Columns(1).Frozen = True
        End If
    End Sub

    Private Sub txtSearching_Enter(sender As Object, e As EventArgs) Handles txtIsbnNo.Enter, txtAuthor.Enter, txtCategory.Enter, txtPublisher.Enter, txtTitle.Enter
        'Call method to clear fields
        ClearSearchingFields()

        'Clear the datasource of the datagridview
        grdBook.DataSource = Nothing


        If grdBook.Rows.Count > 0 Then
            'Enable the GetReport button
            btnGetReport.Enabled = True
        Else
            'Disable the GetReport button
            btnGetReport.Enabled = False
        End If

        'List the number of rows in the result
        lblResult.Text = grdBook.RowCount
    End Sub

    'TEXTCHANGED EVENT OF ISBNNO TEXTBOX
    Private Sub txtIsbnNo_TextChanged(sender As Object, e As EventArgs) Handles txtIsbnNo.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
                                          "WHERE Isbn LIKE '%" & txtIsbnNo.Text & "%' " & _
            "ORDER BY Title;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF AUTHOR TEXTBOX
    Private Sub txtAuthor_TextChanged(sender As Object, e As EventArgs) Handles txtAuthor.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
            "WHERE Author LIKE '%" & txtAuthor.Text & "%' " & _
            "ORDER BY Title;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF TITLE TEXTBOX
    Private Sub txtTitle_TextChanged(sender As Object, e As EventArgs) Handles txtTitle.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
                                         "WHERE Title LIKE '%" & txtTitle.Text & "%' " & _
            "ORDER BY Title;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF PUBLISHER TEXTBOX
    Private Sub txtPublisher_TextChanged(sender As Object, e As EventArgs) Handles txtPublisher.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
                                           "WHERE Publisher LIKE '%" & txtPublisher.Text & "%' " & _
            "ORDER BY Title;")

        'Fill the datagridview
        FillDataGridView()
    End Sub

    'TEXTCHANGED EVENT OF CATEGORY TEXTBOX
    Private Sub txtCategory_TextChanged(sender As Object, e As EventArgs) Handles txtCategory.TextChanged
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
            "WHERE Category LIKE '%" & txtCategory.Text & "%' " & _
            "ORDER BY Title;")

        'Fill the datagridview
        FillDataGridView()
    End Sub







    'EVENTS AND METHODS FOR THE DATAGRIDVIEW SECTION
    Private Sub btnViewAllStudents_Click(sender As Object, e As EventArgs) Handles btnViewAllStudents.Click
        'Refresh the datagridview:Get all of the student details
        GetBookList()
    End Sub


    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "BookSearch"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub












    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtEditIsbn.Enabled = True
        txtEditTitle.Enabled = True
        txtEditPublisher.Enabled = True
        txtEditAuthor.Enabled = True
        dtpEditPublishDate.Enabled = True
        cboEditCategory.Enabled = True
        txtEditTotalQuantity.Enabled = True
        txtEditAvailableQuantity.Enabled = True
        btnDelete.Enabled = True
    End Sub

    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtEditIsbn.Enabled = False
        txtEditTitle.Enabled = False
        txtEditPublisher.Enabled = False
        txtEditAuthor.Enabled = False
        dtpEditPublishDate.Enabled = False
        cboEditCategory.Enabled = False
        txtEditTotalQuantity.Enabled = False
        txtEditAvailableQuantity.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub


    'CLEAR TEXT FIELDSSET THE DEFAULT OF OTHER CONTROLS
    Private Sub ClearFields()
        txtEditIsbn.Clear()
        txtEditTitle.Clear()
        txtEditPublisher.Clear()
        txtEditAuthor.Clear()
        dtpEditPublishDate.Value = Now
        cboEditCategory.Text = ""
        txtEditTotalQuantity.Clear()
        txtEditAvailableQuantity.Clear()
    End Sub


    Private Sub btnShowEditSection_Click(sender As Object, e As EventArgs) Handles btnShowEditSection.Click
        'Dim s As Point = pnlListOfStudent.Location
        If btnShowEditSection.Text = "Show Edit section" Then
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X - 235
            pnlListOfStudent.Location = p

            grpResult.Size = New Size(617, 422)


            Dim g As Point = grpResult.Location
            g.X = grpResult.Width + 20
            grpEdit.Location = g



            grpEdit.Visible = True
            lblDetails.Visible = True

            btnShowEditSection.Text = "Hide Edit section"
        Else
            Dim p As Point = pnlListOfStudent.Location
            p.X = p.X + 235
            pnlListOfStudent.Location = p


            grpResult.Size = New Size(1026, 422)


            grpEdit.Visible = False
            lblDetails.Visible = False

            btnShowEditSection.Text = "Show Edit section"

            'Disable the controls of the textboxes and buttons
            DisabledControls()
        End If

        'First clear the text fields
        ClearFields()
    End Sub


    'CELL CLICK EVENT OF DATAGRID
    Private Sub grdBook_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdBook.CellClick
        If grpEdit.Visible = True Then
            rowNumber = grdBook.CurrentCell.RowIndex

            'Call ClearFields method to clear the text
            ClearFields()

            'Enable the controls of the datagridview sections
            EnableControls()

            'Get list of category for book
            GetBookUpdateCategory()

            For i As Integer = 0 To grdBook.ColumnCount - 1
                Try
                    Select Case i
                        Case 0
                            intBookId = grdBook.Item(0, e.RowIndex).Value

                        Case 1
                            strBookIsbn = grdBook.Item(1, e.RowIndex).Value
                            txtEditIsbn.Text = grdBook.Item(1, e.RowIndex).Value

                        Case 2
                            strBookTitle = grdBook.Item(2, e.RowIndex).Value
                            txtEditTitle.Text = grdBook.Item(2, e.RowIndex).Value

                        Case 3
                            txtEditPublisher.Text = grdBook.Item(3, e.RowIndex).Value
                        Case 4

                            txtEditAuthor.Text = grdBook.Item(4, e.RowIndex).Value

                        Case 5
                            dtpEditPublishDate.Value = grdBook.Item(5, e.RowIndex).Value

                        Case 6
                            cboEditCategory.Text = grdBook.Item(6, e.RowIndex).Value

                        Case 7
                            txtEditTotalQuantity.Text = grdBook.Item(7, e.RowIndex).Value

                        Case 8
                            txtEditAvailableQuantity.Text = grdBook.Item(8, e.RowIndex).Value

                    End Select
                Catch ex As Exception

                End Try
            Next

            'Make sure that the Update button is disabled
            btnUpdate.Enabled = False
        End If
    End Sub

    Private Sub GetBookUpdateCategory()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Category FROM BOOK; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Book Category | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtBookUpdateCategory = dataAccess.dtListForComboBox
            cboEditCategory.DataSource = dtBookUpdateCategory
            cboEditCategory.DisplayMember = "Category"

            'If cboEditCategory.Text = "" Then

            'End If
        End If
    End Sub




    'EVENTS- TEXTCHANGED AND CHECKCHANGED EVENTS TO ENABLE BUTTON:UPDATE
    Private Sub TextAndCheckedChanged(sender As Object, e As EventArgs) Handles txtEditIsbn.TextChanged, txtEditTitle.TextChanged, txtEditPublisher.TextChanged, dtpEditPublishDate.ValueChanged, _
        txtEditAuthor.TextChanged, cboEditCategory.SelectedIndexChanged, cboEditCategory.TextChanged, txtEditTotalQuantity.TextChanged, txtEditAvailableQuantity.TextChanged
        'Enable update button
        btnUpdate.Enabled = True
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Are you sure to delete book: |" & strBookTitle & "| (" & strBookIsbn & ") details?", "Book Details", _
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM BOOK " & _
                                 "WHERE BookId= @bookId"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@bookId", intBookId)

            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully deleted message
                MsgBox("Book: |" & strBookTitle & "| (" & strBookIsbn & ") details has been successfully deleted.", MsgBoxStyle.Information, "Book Details")

                'Remove the row from the data gridview
                grdBook.Rows.RemoveAt(rowNumber)

                'List the number of rows in the result
                lblResult.Text = grdBook.RowCount

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no book with details: |" & strBookTitle & "| (" & strBookIsbn & ").", MsgBoxStyle.Exclamation, "Book Details")

            End If

            'Call ClearFields method to clear the text
            ClearFields()

            'Call DisableControl method to disable controls
            DisabledControls()
        End If
    End Sub

    'CLICK EVENT OF UPDATE BUTTON
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If CheckIsbnAndTitle() = True And CheckAvailableAndTotalQuantity() = True Then
            'Raise a YesNo question
            If MessageBox.Show("Do you really want to update book: |" & strBookTitle & "| (" & strBookIsbn & ") details?", "Book Details", _
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                'Create a sql query text
                Dim strCommand As String = "UPDATE BOOK " & _
                                     "SET Isbn= @isbn, " & _
                                     "Title=@title, " & _
                                     "Publisher=@publisher, " & _
                                     "Author=@author, " & _
                                     "PublishDate=@pubDate, " & _
                                     "Category=@category, " & _
                                     "TotalQuantity=@totalQuantity, " & _
                                     "AvailableQuantity=@availableQuantity " & _
                                     "WHERE BookId=@bookId;"

                'Create a new sql command
                Dim objCommand As New SqlCommand
                objCommand.CommandText = strCommand

                'Add parameters
                'objCommand.Parameters.AddWithValue("@bookId", txt)
                objCommand.Parameters.AddWithValue("@isbn", txtEditIsbn.Text)
                objCommand.Parameters.AddWithValue("@title", txtEditTitle.Text)
                objCommand.Parameters.AddWithValue("@publisher", txtEditPublisher.Text)
                objCommand.Parameters.AddWithValue("@author", txtEditAuthor.Text)
                objCommand.Parameters.AddWithValue("@pubDate", dtpEditPublishDate.Value.Date)
                objCommand.Parameters.AddWithValue("@category", cboEditCategory.Text)
                objCommand.Parameters.AddWithValue("@totalQuantity", txtEditTotalQuantity.Text)
                objCommand.Parameters.AddWithValue("@availableQuantity", txtEditAvailableQuantity.Text)
                objCommand.Parameters.AddWithValue("@bookId", intBookId)


                'Call RunQuery Method to update the selected user
                dataAccess.RunQuery(objCommand)

                'Check for errors
                If dataAccess.strExceptionRunQuery <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Book Details")

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQuery = Nothing
                ElseIf dataAccess.intCountRecord = 1 Then
                    'Show successfully update message
                    MsgBox("Book: |" & strBookTitle & "| (" & strBookIsbn & ") details has been successfully updated.", MsgBoxStyle.Information, "Book Details")

                    'Call btnView_Click procedure
                    'btnFilterView_Click(btnFilterView, Nothing)
                    'Clear existing records from the dataset
                    If dataAccess.objDataSet IsNot Nothing Then
                        dataAccess.objDataSet.Clear()
                    End If

                    dataAccess.RunQueryAndFillDataSet("SELECT * FROM Book " & _
                                                      "WHERE BookId =" & intBookId & ";")


                    'Fill the datagridview
                    FillDataGridView()

                ElseIf dataAccess.intCountRecord = 0 Then
                    'Show error message
                    MsgBox("There's no book with details: |" & strBookTitle & "| (" & strBookIsbn & ").", MsgBoxStyle.Exclamation, "Book Details")

                    'Call btnView_Click procedure
                    'btnFilterView_Click(btnFilterView, Nothing)
                End If

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            End If
        End If

    End Sub

    'CHECK WHETHER THERE IS TEXT OR NOT IN FIRSTNAME AND LASTNAME
    Private Function CheckIsbnAndTitle() As Boolean
        If txtEditIsbn.Text.Trim.Length > 0 And txtEditTitle.Text.Trim.Length > 0 Then
            Return True
        ElseIf txtEditIsbn.Text.Trim.Length <= 0 And txtEditTitle.Text.Trim.Length <= 0 Then
            MessageBox.Show("You have to enter book isbn and title.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        ElseIf txtEditIsbn.Text.Trim.Length <= 0 And txtEditTitle.Text.Trim.Length > 0 Then
            MessageBox.Show("You have to enter book isbn.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            MessageBox.Show("You have to enter book title.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
    End Function

    'CHECK WHETHER AVAILABLE IS GREATER THAN TOTAL QUANTITY
    Private Function CheckAvailableAndTotalQuantity() As Boolean
        Dim availableQuantity As String = txtEditAvailableQuantity.Text
        Dim totalQuantity As String = txtEditTotalQuantity.Text

        If availableQuantity = "" Then
            availableQuantity = "0"
        End If
        If totalQuantity = "" Then
            totalQuantity = "0"
        End If
        If CInt(availableQuantity) > CInt(totalQuantity) Then
            MessageBox.Show("The availabe quantity should not be greater than the total quantity of library books.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        Else
            Return True
        End If
    End Function


End Class
