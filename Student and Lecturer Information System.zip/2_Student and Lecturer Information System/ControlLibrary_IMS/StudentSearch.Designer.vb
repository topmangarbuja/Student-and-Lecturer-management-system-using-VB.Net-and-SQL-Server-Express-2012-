﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentSearch
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.grdStudent = New System.Windows.Forms.DataGridView()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtPassportNo = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtStudentId = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtCitizenshipNo = New ControlLibrary_IMS.TextBoxNumericPunctuation()
        Me.txtPlace = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtDistrict = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.txtFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.btnViewAllStudents = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.grpResult = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnShowEditSection = New System.Windows.Forms.Button()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cboEditGender = New System.Windows.Forms.ComboBox()
        Me.txtEditFirstName = New System.Windows.Forms.TextBox()
        Me.txtEditLastName = New System.Windows.Forms.TextBox()
        Me.dtpEditDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.txtEditDistrict = New System.Windows.Forms.TextBox()
        Me.txtEditWardNo = New System.Windows.Forms.TextBox()
        Me.txtEditPlace = New System.Windows.Forms.TextBox()
        Me.txtEditCitizenshipNo = New System.Windows.Forms.TextBox()
        Me.cboEditStatus = New System.Windows.Forms.ComboBox()
        Me.txtEditStudentId = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtEditPassportNo = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.cboEditCountry = New System.Windows.Forms.ComboBox()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.pnlListOfStudent = New System.Windows.Forms.Panel()
        CType(Me.grdStudent, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.grpResult.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.grpEdit.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.pnlListOfStudent.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(334, 11)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "First Name:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(651, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 17)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Last Name:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 50)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 17)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Gender:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(334, 93)
        Me.Label5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 17)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Passport no:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(334, 50)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 17)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "District:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(651, 50)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 17)
        Me.Label7.TabIndex = 38
        Me.Label7.Text = "Place:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 93)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 17)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "Citizenship no:"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(651, 93)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 17)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "Status:"
        '
        'grdStudent
        '
        Me.grdStudent.AllowUserToAddRows = False
        Me.grdStudent.AllowUserToDeleteRows = False
        Me.grdStudent.AllowUserToOrderColumns = True
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdStudent.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle2
        Me.grdStudent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdStudent.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdStudent.Location = New System.Drawing.Point(0, 18)
        Me.grdStudent.MultiSelect = False
        Me.grdStudent.Name = "grdStudent"
        Me.grdStudent.ReadOnly = True
        Me.grdStudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdStudent.ShowCellToolTips = False
        Me.grdStudent.Size = New System.Drawing.Size(1188, 426)
        Me.grdStudent.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.grdStudent, "Click 'Show Enable section' button to view the Edit section and select a record a" & _
        "nd get the data in the Details section.")
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 6
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.txtPassportNo, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtStudentId, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtCitizenshipNo, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtPlace, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtDistrict, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.cboGender, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.cboStatus, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtFirstName, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtLastName, 5, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(962, 125)
        Me.TableLayoutPanel1.TabIndex = 45
        '
        'txtPassportNo
        '
        Me.txtPassportNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPassportNo.Location = New System.Drawing.Point(428, 89)
        Me.txtPassportNo.MaxLength = 9
        Me.txtPassportNo.Name = "txtPassportNo"
        Me.txtPassportNo.Size = New System.Drawing.Size(215, 25)
        Me.txtPassportNo.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtPassportNo, "Citizenship no")
        '
        'txtStudentId
        '
        Me.txtStudentId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStudentId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtStudentId.Location = New System.Drawing.Point(113, 7)
        Me.txtStudentId.MaxLength = 12
        Me.txtStudentId.Name = "txtStudentId"
        Me.txtStudentId.Size = New System.Drawing.Size(213, 25)
        Me.txtStudentId.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtStudentId, "Student Id")
        '
        'txtCitizenshipNo
        '
        Me.txtCitizenshipNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtCitizenshipNo.Location = New System.Drawing.Point(113, 89)
        Me.txtCitizenshipNo.MaxLength = 15
        Me.txtCitizenshipNo.Name = "txtCitizenshipNo"
        Me.txtCitizenshipNo.Size = New System.Drawing.Size(213, 25)
        Me.txtCitizenshipNo.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtCitizenshipNo, "Citizenship no")
        '
        'txtPlace
        '
        Me.txtPlace.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPlace.Location = New System.Drawing.Point(736, 46)
        Me.txtPlace.MaxLength = 20
        Me.txtPlace.Name = "txtPlace"
        Me.txtPlace.Size = New System.Drawing.Size(213, 25)
        Me.txtPlace.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtPlace, "Place")
        '
        'txtDistrict
        '
        Me.txtDistrict.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtDistrict.Location = New System.Drawing.Point(428, 46)
        Me.txtDistrict.MaxLength = 20
        Me.txtDistrict.Name = "txtDistrict"
        Me.txtDistrict.Size = New System.Drawing.Size(215, 25)
        Me.txtDistrict.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtDistrict, "District")
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 11)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(76, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Student Id:"
        '
        'cboGender
        '
        Me.cboGender.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Location = New System.Drawing.Point(113, 48)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(213, 25)
        Me.cboGender.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboGender, "Gender")
        '
        'cboStatus
        '
        Me.cboStatus.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Location = New System.Drawing.Point(736, 91)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(213, 25)
        Me.cboStatus.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.cboStatus, "Status")
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtFirstName.Location = New System.Drawing.Point(428, 7)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(213, 25)
        Me.txtFirstName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtFirstName, "First Name")
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLastName.Location = New System.Drawing.Point(736, 7)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(213, 25)
        Me.txtLastName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtLastName, "Last Name")
        '
        'btnViewAllStudents
        '
        Me.btnViewAllStudents.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnViewAllStudents.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllStudents.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllStudents.Location = New System.Drawing.Point(394, 4)
        Me.btnViewAllStudents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllStudents.Name = "btnViewAllStudents"
        Me.btnViewAllStudents.Size = New System.Drawing.Size(134, 35)
        Me.btnViewAllStudents.TabIndex = 1
        Me.btnViewAllStudents.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllStudents, "View all of students in the college.")
        Me.btnViewAllStudents.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 3)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 17)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "List of students:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Location = New System.Drawing.Point(110, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(968, 153)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search By:"
        '
        'grpResult
        '
        Me.grpResult.BackColor = System.Drawing.Color.Transparent
        Me.grpResult.Controls.Add(Me.Panel1)
        Me.grpResult.Controls.Add(Me.grdStudent)
        Me.grpResult.Location = New System.Drawing.Point(9, 191)
        Me.grpResult.Name = "grpResult"
        Me.grpResult.Padding = New System.Windows.Forms.Padding(0)
        Me.grpResult.Size = New System.Drawing.Size(1188, 498)
        Me.grpResult.TabIndex = 0
        Me.grpResult.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel1.Controls.Add(Me.btnShowEditSection)
        Me.Panel1.Controls.Add(Me.btnViewAllStudents)
        Me.Panel1.Controls.Add(Me.btnGetReport)
        Me.Panel1.Location = New System.Drawing.Point(0, 455)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1188, 43)
        Me.Panel1.TabIndex = 20
        '
        'btnShowEditSection
        '
        Me.btnShowEditSection.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnShowEditSection.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShowEditSection.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnShowEditSection.Location = New System.Drawing.Point(536, 4)
        Me.btnShowEditSection.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShowEditSection.Name = "btnShowEditSection"
        Me.btnShowEditSection.Size = New System.Drawing.Size(132, 35)
        Me.btnShowEditSection.TabIndex = 20
        Me.btnShowEditSection.TabStop = False
        Me.btnShowEditSection.Text = "Show Edit section"
        Me.ToolTip1.SetToolTip(Me.btnShowEditSection, "Refresh the view list.")
        Me.btnShowEditSection.UseVisualStyleBackColor = True
        '
        'btnGetReport
        '
        Me.btnGetReport.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(675, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 52
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(127, 3)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 50
        Me.lblResult.Text = "0"
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(359, 43)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(120, 28)
        Me.btnDelete.TabIndex = 14
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(359, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(120, 28)
        Me.btnUpdate.TabIndex = 13
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cboEditGender
        '
        Me.cboEditGender.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEditGender.FormattingEnabled = True
        Me.cboEditGender.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.cboEditGender.Location = New System.Drawing.Point(114, 165)
        Me.cboEditGender.Name = "cboEditGender"
        Me.cboEditGender.Size = New System.Drawing.Size(237, 25)
        Me.cboEditGender.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cboEditGender, "Gender")
        '
        'txtEditFirstName
        '
        Me.txtEditFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditFirstName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtEditFirstName.Location = New System.Drawing.Point(115, 46)
        Me.txtEditFirstName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEditFirstName.MaxLength = 70
        Me.txtEditFirstName.Name = "txtEditFirstName"
        Me.txtEditFirstName.Size = New System.Drawing.Size(236, 25)
        Me.txtEditFirstName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtEditFirstName, "First Name")
        '
        'txtEditLastName
        '
        Me.txtEditLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditLastName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtEditLastName.Location = New System.Drawing.Point(115, 85)
        Me.txtEditLastName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEditLastName.MaxLength = 35
        Me.txtEditLastName.Name = "txtEditLastName"
        Me.txtEditLastName.Size = New System.Drawing.Size(236, 25)
        Me.txtEditLastName.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtEditLastName, "Last Name")
        '
        'dtpEditDateOfBirth
        '
        Me.dtpEditDateOfBirth.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpEditDateOfBirth.Location = New System.Drawing.Point(114, 124)
        Me.dtpEditDateOfBirth.Name = "dtpEditDateOfBirth"
        Me.dtpEditDateOfBirth.Size = New System.Drawing.Size(237, 25)
        Me.dtpEditDateOfBirth.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.dtpEditDateOfBirth, "Date of birth")
        Me.dtpEditDateOfBirth.Value = New Date(2015, 9, 9, 11, 36, 0, 0)
        '
        'txtEditDistrict
        '
        Me.txtEditDistrict.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditDistrict.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtEditDistrict.Location = New System.Drawing.Point(115, 202)
        Me.txtEditDistrict.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEditDistrict.MaxLength = 20
        Me.txtEditDistrict.Name = "txtEditDistrict"
        Me.txtEditDistrict.Size = New System.Drawing.Size(236, 25)
        Me.txtEditDistrict.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtEditDistrict, "District")
        '
        'txtEditWardNo
        '
        Me.txtEditWardNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditWardNo.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtEditWardNo.Location = New System.Drawing.Point(115, 241)
        Me.txtEditWardNo.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEditWardNo.MaxLength = 3
        Me.txtEditWardNo.Name = "txtEditWardNo"
        Me.txtEditWardNo.Size = New System.Drawing.Size(236, 25)
        Me.txtEditWardNo.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtEditWardNo, "Ward no")
        '
        'txtEditPlace
        '
        Me.txtEditPlace.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditPlace.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtEditPlace.Location = New System.Drawing.Point(115, 280)
        Me.txtEditPlace.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEditPlace.MaxLength = 20
        Me.txtEditPlace.Name = "txtEditPlace"
        Me.txtEditPlace.Size = New System.Drawing.Size(236, 25)
        Me.txtEditPlace.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtEditPlace, "Place")
        '
        'txtEditCitizenshipNo
        '
        Me.txtEditCitizenshipNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditCitizenshipNo.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtEditCitizenshipNo.Location = New System.Drawing.Point(115, 358)
        Me.txtEditCitizenshipNo.Margin = New System.Windows.Forms.Padding(4)
        Me.txtEditCitizenshipNo.MaxLength = 15
        Me.txtEditCitizenshipNo.Name = "txtEditCitizenshipNo"
        Me.txtEditCitizenshipNo.Size = New System.Drawing.Size(236, 25)
        Me.txtEditCitizenshipNo.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.txtEditCitizenshipNo, "Citizenship no")
        '
        'cboEditStatus
        '
        Me.cboEditStatus.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEditStatus.FormattingEnabled = True
        Me.cboEditStatus.Items.AddRange(New Object() {"Active", "Inactive"})
        Me.cboEditStatus.Location = New System.Drawing.Point(114, 440)
        Me.cboEditStatus.Name = "cboEditStatus"
        Me.cboEditStatus.Size = New System.Drawing.Size(237, 25)
        Me.cboEditStatus.TabIndex = 12
        Me.ToolTip1.SetToolTip(Me.cboEditStatus, "Status")
        '
        'txtEditStudentId
        '
        Me.txtEditStudentId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditStudentId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEditStudentId.Location = New System.Drawing.Point(114, 7)
        Me.txtEditStudentId.MaxLength = 12
        Me.txtEditStudentId.Name = "txtEditStudentId"
        Me.txtEditStudentId.Size = New System.Drawing.Size(237, 25)
        Me.txtEditStudentId.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtEditStudentId, "Student Id")
        '
        'txtEditPassportNo
        '
        Me.txtEditPassportNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditPassportNo.Location = New System.Drawing.Point(114, 397)
        Me.txtEditPassportNo.MaxLength = 9
        Me.txtEditPassportNo.Name = "txtEditPassportNo"
        Me.txtEditPassportNo.Size = New System.Drawing.Size(237, 25)
        Me.txtEditPassportNo.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.txtEditPassportNo, "Citizenship no")
        '
        'cboEditCountry
        '
        Me.cboEditCountry.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditCountry.FormattingEnabled = True
        Me.cboEditCountry.Location = New System.Drawing.Point(114, 319)
        Me.cboEditCountry.Name = "cboEditCountry"
        Me.cboEditCountry.Size = New System.Drawing.Size(237, 25)
        Me.cboEditCountry.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.cboEditCountry, "Book category")
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(917, 178)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(61, 17)
        Me.lblDetails.TabIndex = 59
        Me.lblDetails.Text = "Details:"
        Me.lblDetails.Visible = False
        '
        'grpEdit
        '
        Me.grpEdit.BackColor = System.Drawing.Color.Transparent
        Me.grpEdit.Controls.Add(Me.TableLayoutPanel2)
        Me.grpEdit.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.grpEdit.Location = New System.Drawing.Point(703, 191)
        Me.grpEdit.Margin = New System.Windows.Forms.Padding(4)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Padding = New System.Windows.Forms.Padding(4)
        Me.grpEdit.Size = New System.Drawing.Size(494, 498)
        Me.grpEdit.TabIndex = 0
        Me.grpEdit.TabStop = False
        Me.grpEdit.Visible = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 4
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.cboEditCountry, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditPassportNo, 1, 10)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditStudentId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnDelete, 3, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.btnUpdate, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.cboEditGender, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label11, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label15, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditFirstName, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditLastName, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpEditDateOfBirth, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditDistrict, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label17, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditWardNo, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label19, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditPlace, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label20, 0, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditCitizenshipNo, 1, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.Label21, 0, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.Label22, 0, 10)
        Me.TableLayoutPanel2.Controls.Add(Me.Label23, 0, 11)
        Me.TableLayoutPanel2.Controls.Add(Me.cboEditStatus, 1, 11)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(4, 22)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 12
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(486, 472)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Student Id:"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(4, 128)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(91, 17)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Date of birth:"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(4, 50)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(80, 17)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "First Name:"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 89)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 17)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Last Name:"
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(4, 167)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(57, 17)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Gender:"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(4, 206)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(59, 17)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "District:"
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 245)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(68, 17)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "Ward no.:"
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 284)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(46, 17)
        Me.Label19.TabIndex = 5
        Me.Label19.Text = "Place:"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(4, 323)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(63, 17)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "Country:"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(4, 362)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(103, 17)
        Me.Label21.TabIndex = 7
        Me.Label21.Text = "Citizenship no.:"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 401)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(89, 17)
        Me.Label22.TabIndex = 8
        Me.Label22.Text = "Passport no.:"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(4, 442)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(50, 17)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = "Status:"
        '
        'pnlListOfStudent
        '
        Me.pnlListOfStudent.BackColor = System.Drawing.Color.Transparent
        Me.pnlListOfStudent.Controls.Add(Me.Label10)
        Me.pnlListOfStudent.Controls.Add(Me.lblResult)
        Me.pnlListOfStudent.Location = New System.Drawing.Point(541, 175)
        Me.pnlListOfStudent.Name = "pnlListOfStudent"
        Me.pnlListOfStudent.Size = New System.Drawing.Size(155, 20)
        Me.pnlListOfStudent.TabIndex = 60
        '
        'StudentSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.pnlListOfStudent)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.grpResult)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "StudentSearch"
        Me.Size = New System.Drawing.Size(1208, 700)
        CType(Me.grdStudent, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.grpResult.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.grpEdit.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.pnlListOfStudent.ResumeLayout(False)
        Me.pnlListOfStudent.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents grdStudent As System.Windows.Forms.DataGridView
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnViewAllStudents As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents grpResult As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtDistrict As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtPlace As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtCitizenshipNo As ControlLibrary_IMS.TextBoxNumericPunctuation
    Friend WithEvents txtStudentId As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents grpEdit As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtEditStudentId As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents cboEditGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtEditFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtEditLastName As System.Windows.Forms.TextBox
    Friend WithEvents dtpEditDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtEditDistrict As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtEditWardNo As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtEditPlace As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtEditCitizenshipNo As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents cboEditStatus As System.Windows.Forms.ComboBox
    Friend WithEvents btnShowEditSection As System.Windows.Forms.Button
    Friend WithEvents pnlListOfStudent As System.Windows.Forms.Panel
    Friend WithEvents txtPassportNo As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents txtEditPassportNo As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents cboEditCountry As System.Windows.Forms.ComboBox

End Class
