﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Public Class StudentAddNew
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtStudentList As New DataTable
    Dim dtCountryLIst As New DataTable
    Dim strExceptionStudentId As String = "errStudentId"
    Dim strExceptionFirstName As String = "errFirstName"
    Dim strExceptionLastName As String = "errLastName"
    Dim strExceptionEmail As String = "errEmail"

    'FORM LOAD EVENT
    Private Sub StudentAddNew_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Select a item in the Gender combobox
        cboGender.SelectedIndex = 0

        'Select a item in the Status combobox
        cboStatus.SelectedIndex = 0

        'Get list of country
        GetCountry()

        'Check whether to enable save button or not
        EnabledSaveButton()

        'Set focus on the student id textbox
        'txtStudentId.Focus()
    End Sub

    'CLICK EVENT OF SAVE BUTTON TO ADD NEW STUDENT
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Create a succeed message string
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you want to add the information of the following student?")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Student-Info: " & txtStudentId.Text & " | " & txtFirstName.Text & " " & txtLastName.Text)

        'Show the message box
        If MessageBox.Show(objStringBuilder.ToString, "Add New Student | Process-Succeed", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
            = DialogResult.Yes Then
            'Call procedure to add lecturer details
            AddStudent()
        End If
    End Sub

    'METHOD: ADD NEW STUDENT
    Private Sub AddStudent()
        objCommand = New SqlCommand
        Dim strCommandText As String
        strCommandText = "INSERT INTO Student " & _
                                 "VALUES(@studentId,@firstName,@lastName,@dateOfBirth, @gender,@district,@wardNo,@place,@country,@citizenshipNo,@passportNo,@status); "

        If txtPhoneNumber.TextLength > 5 Then
            strCommandText = strCommandText & _
                 "INSERT INTO StudentPhoneNumber " & _
                                     "VALUES(@studentId,@phoneNo); "
        End If
        If txtEmailAddress.TextLength > 8 Then
            strCommandText = strCommandText & _
                                     "INSERT INTO StudentEmailId " & _
                                     "VALUES(@studentId,@emailId); "
        End If

        objCommand.CommandText = strCommandText

        'Add parameters for the placeholders in the SQL CommandText property..

        'Student Details
        objCommand.Parameters.AddWithValue("@studentId", txtStudentId.Text)
        objCommand.Parameters.AddWithValue("@firstName", txtFirstName.Text)
        objCommand.Parameters.AddWithValue("@lastName", txtLastName.Text)
        objCommand.Parameters.AddWithValue("@dateOfBirth", dtpDateOfBirth.Value.Date)
        objCommand.Parameters.AddWithValue("@gender", cboGender.Text)
        objCommand.Parameters.AddWithValue("@district", txtDistrict.Text)
        objCommand.Parameters.AddWithValue("@wardNo", txtWardNo.Text)
        objCommand.Parameters.AddWithValue("@place", txtPlace.Text)
        objCommand.Parameters.AddWithValue("@country", cboCountry.Text)
        objCommand.Parameters.AddWithValue("@citizenshipNo", txtCitizenshipNo.Text)
        objCommand.Parameters.AddWithValue("@passportNo", txtPassportNo.Text)
        objCommand.Parameters.AddWithValue("@status", cboStatus.Text)

        If txtPhoneNumber.TextLength > 5 Then
            'Student Phone Number Details
            objCommand.Parameters.AddWithValue("@phoneNo", txtPhoneNumber.Text)
        End If
        If txtEmailAddress.TextLength > 8 Then
            'Student Email Address Details
            objCommand.Parameters.AddWithValue("@emailId", txtEmailAddress.Text)
        End If

        'Call AddDetails method to add student
        dataAccess.AddDetails(objCommand)
        Dim objStringBuilder As New System.Text.StringBuilder

        'If no error occurs
        If dataAccess.strExceptionAddDetails = "" Then
            objStringBuilder.AppendLine("The following new information has been successfully added.")
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Student-Info: " & txtStudentId.Text & " | " & txtFirstName.Text & " " & txtLastName.Text)

            'Show message box
            MessageBox.Show(objStringBuilder.ToString, "Add New Student | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

            'Clear main fields
            ClearMainFields()

            'Focus on Student-Id Textbox
            txtStudentId.Focus()

            'Refresh Country combobox list
            GetCountry()
        End If

        If grdStudent.RowCount > 0 Then
            'Refresh ListBox
            GetStudentIdAndName()
        End If


        'Check for errors
        If dataAccess.strExceptionAddDetails <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionAddDetails, "Add New Student | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set variable to nothing
            dataAccess.strExceptionAddDetails = Nothing
        End If

        'Disable the save button
        btnSave.Enabled = False
    End Sub

    'METHOD:CLEARS TEXTBOXES OF STUDENT MAIN DETAILS GROUPBOX
    Private Sub ClearMainFields()
        'Clear the textboxes
        txtStudentId.Clear()
        txtFirstName.Clear()
        txtLastName.Clear()
        dtpDateOfBirth.Value = Now
        cboGender.SelectedIndex = 0
        txtPhoneNumber.Clear()
        txtEmailAddress.Clear()
        txtDistrict.Clear()
        txtWardNo.Clear()
        txtPlace.Clear()
        cboCountry.Text = ""
        cboCountry.SelectedText = "Nepal"
        txtCitizenshipNo.Clear()
        txtPassportNo.Clear()
        cboStatus.SelectedIndex = 0
        txtStudentId.Focus()
    End Sub



    'LISTVIEW EVENTS AND METHODS SECTIONS

    'METHOD: GET STUDENT ID AND NAME 
    Private Sub GetStudentIdAndName()
        'Call method to get list of name and id
        dataAccess.RunQueryAndFillDataSet("SELECT (FirstName + ' ' + LastName) As Name,StudentId  " & _
            "FROM Student " & _
            "ORDER BY Name;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Get the table data
            dtStudentList = dataAccess.AutoNumberedTable(dataAccess.objDataSet.Tables(0))

            'Fill the datagridview
            grdStudent.DataSource = dtStudentList


            'Change the header of the 1st column
            grdStudent.Columns(0).HeaderText = "S.n."
            grdStudent.Columns(0).Width = 30

            grdStudent.Columns(0).Frozen = True
        End If
    End Sub

    'METHOD: GET COUNTRY
    Private Sub GetCountry()
        objCommand = New SqlCommand

        objCommand.CommandText = "SELECT DISTINCT Country " & _
            "FROM Student"

        'Call method to get list of country
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Get list of students | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        ElseIf dataAccess.dtListForComboBox.Rows.Count > 0 Then
            'Get the table data
            dtCountryLIst = dataAccess.dtListForComboBox

            'Get the data in the combobox
            cboCountry.DataSource = dtCountryLIst
            cboCountry.DisplayMember = "Country"
        End If
    End Sub

    Private Sub btnViewStudents_Click(sender As Object, e As EventArgs) Handles btnViewStudents.Click
        'Get student list from database
        GetStudentIdAndName()
    End Sub

    Private Sub txtStudentId_Validating(sender As Object, e As EventArgs) Handles txtStudentId.Validating
        'Check if the student already exists
        If txtStudentId.TextLength = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSet IsNot Nothing Then
                dataAccess.objDataSet.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
                "FROM Student " & _
                "WHERE StudentId LIKE '%" & txtStudentId.Text & "%';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
                strExceptionStudentId = "This student already exists."
                ErrorProvider1.SetError(txtStudentId, strExceptionStudentId)

                'clear the textbox
                'txtStudentId.Clear()
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
                strExceptionStudentId = ""
                ErrorProvider1.SetError(txtStudentId, strExceptionStudentId)
            End If
        Else
            strExceptionStudentId = "Enter 12 character Student Id."
            ErrorProvider1.SetError(txtStudentId, strExceptionStudentId)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtFirstName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtFirstName.Validating
        If txtFirstName.Text.Trim.Length = 0 Then
            strExceptionFirstName = "Please enter first name."
            ErrorProvider1.SetError(txtFirstName, strExceptionFirstName)
        Else
            strExceptionFirstName = ""
            ErrorProvider1.SetError(txtFirstName, strExceptionFirstName)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtLastName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtLastName.Validating
        If txtLastName.Text.Trim.Length = 0 Then
            strExceptionLastName = "Please enter last name."
            ErrorProvider1.SetError(txtLastName, strExceptionLastName)
        Else
            strExceptionLastName = ""
            ErrorProvider1.SetError(txtLastName, strExceptionLastName)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub EnabledSaveButton()
        If strExceptionStudentId = "" And strExceptionFirstName = "" And strExceptionLastName = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub txtEmailAddress_Click(sender As Object, e As EventArgs) Handles txtEmailAddress.Click
        'Disable the save button
        btnSave.Enabled = False
    End Sub

    Private Sub txtEmailAddress_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEmailAddress.KeyPress
        Dim ac As String = "@"
        If e.KeyChar <> ChrW(Keys.Back) Then
            If Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then
                If Asc(e.KeyChar) <> 46 And Asc(e.KeyChar) <> 95 Then
                    If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                        If ac.IndexOf(e.KeyChar) = -1 Then
                            e.Handled = True

                        Else

                            If txtEmailAddress.Text.Contains("@") And e.KeyChar = "@" Then
                                e.Handled = True
                            End If

                        End If
                    End If
                End If
            End If

        End If
    End Sub

    Private Sub txtEmailAddress_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtEmailAddress.Validating
        If txtEmailAddress.TextLength > 0 Then
            Dim pattern As String = "^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$"
            Dim match As System.Text.RegularExpressions.Match = Regex.Match(txtEmailAddress.Text.Trim(), pattern, RegexOptions.IgnoreCase)
            If (match.Success) Then
                strExceptionEmail = ""
                ErrorProvider1.SetError(txtEmailAddress, strExceptionEmail)

                'Check whether to enable save button or not
                EnabledSaveButton()
            Else
                strExceptionEmail = "Please enter email in a valid format."
                ErrorProvider1.SetError(txtEmailAddress, strExceptionEmail)

                'Disable the save button
                btnSave.Enabled = False
            End If
        Else
            strExceptionEmail = ""
            ErrorProvider1.SetError(txtEmailAddress, strExceptionEmail)

            'Check whether to enable save button or not
            EnabledSaveButton()
        End If
    End Sub


    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear main fields
        ClearMainFields()
    End Sub

    Private Sub txtStudentId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtStudentId.Validating

    End Sub
End Class
