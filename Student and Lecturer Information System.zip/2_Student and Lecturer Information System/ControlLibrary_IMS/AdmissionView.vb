﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class AdmissionView
    Private dataAccess As New DataAccess
    Dim strId As String
    Dim dtAdmission As New DataTable
    Dim dtAdmissionDate As Date
    Dim intOriginalYear As Int16
    Dim rowNumber As Int16

    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If
    End Sub

    'FORM LOAD EVENT
    Private Sub StudentView_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0

        'Make sure that the view fields are cleared at first
        ClearFields()

        'Disable the controls in the View sections
        DisabledControls()
    End Sub


    'METHOD: GET STUDENT ID AND NAME AND SELECTED MODULE FOR THE DATAGRIDVIEW
    Private Sub GetStudentList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
            "FROM Student " & _
            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
            "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
            "And Year='" & intYear & "' " & _
           "AND Faculty='" & cboFaculty.Text & "' " & _
           "ORDER BY Name;")

        'If intYear = 3 Then
        '    'Get list of name and id and phone
        '    dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '        "FROM Student " & _
        '        "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '        "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '        "And Year='" & intYear & "' " & _
        '       "AND Faculty='" & cboFaculty.Text & "' " & _
        '       "ORDER BY Name;")
        'ElseIf intYear = 2 Then
        '    'Get list of name and id and phone
        '    'dataAccess.RunQueryAndFillDataSet("SELECT DISTINCT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty, Status " & _
        '    '    "FROM Student " & _
        '    '    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '    "WHERE Year ='" & intYear & "' " & _
        '    '   "AND Faculty='" & cboFaculty.Text & "' " & _
        '    '"EXCEPT " & _
        '    '"SELECT DISTINCT Student.StudentId As [Student Id], (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty, Status " & _
        '    '"FROM Student " & _
        '    '"JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '"WHERE Year ='" & intYear + 1 & "' " & _
        '    '"AND Faculty='" & cboFaculty.Text & "';")
        '    'dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '    '                                  "AND STudent.StudentId In " & _
        '    '                                  "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE Year = '" & intYear & "' " & _
        '    '                                  "AND Faculty='" & cboFaculty.Text & "' " & _
        '    '                                  "AND NOT Student.StudentId In " & _
        '    '                                  "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE Year = '" & intYear + 1 & "' " & _
        '    '                                  "AND Faculty='" & cboFaculty.Text & "')) " & _
        '    '   "ORDER BY Name;")

        '    'Get list of name and id and phone
        '    dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '        "FROM Student " & _
        '        "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '        "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '        "And Year='" & intYear & "' " & _
        '       "AND Faculty='" & cboFaculty.Text & "' " & _
        '       "ORDER BY Name;")
        'ElseIf intYear = 1 Then
        '    'Get list of name and id and phone
        '    dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '        "FROM Student " & _
        '        "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '        "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '        "And Year='" & intYear & "' " & _
        '       "AND Faculty='" & cboFaculty.Text & "' " & _
        '       "ORDER BY Name;")

        '    'dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '    '                                  "AND Student.StudentId In " & _
        '    '                                  "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE Year = '" & intYear & "' " & _
        '    '                                  "AND Faculty='" & cboFaculty.Text & "' " & _
        '    '                                  "AND NOT Student.StudentId In " & _
        '    '                                  "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE Year = '" & intYear + 1 & "' " & _
        '    '                                  "AND Faculty='" & cboFaculty.Text & "')" & _
        '    '                                  "AND NOT Student.StudentId In " & _
        '    '                                  "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                  "FROM Student " & _
        '    '                                  "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                  "WHERE Year = '" & intYear + 2 & "' " & _
        '    '                                  "AND Faculty='" & cboFaculty.Text & "')) " & _
        '    '   "ORDER BY Name;")
        'ElseIf intYear = 0 Then
        '    'Get list of name and id and phone
        '    dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '        "FROM Student " & _
        '        "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '        "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '        "And Year='" & intYear & "' " & _
        '       "AND Faculty='" & cboFaculty.Text & "' " & _
        '       "ORDER BY Name;")
        '    'dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
        '    '                                "FROM Student " & _
        '    '                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                "WHERE YEAR(AdmissionDate)=" & dtpYear.Value.Year & " " & _
        '    '                                "AND Student.StudentId In " & _
        '    '                                "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                "FROM Student " & _
        '    '                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                "WHERE Year = '" & intYear & "' " & _
        '    '                                "AND Faculty='" & cboFaculty.Text & "' " & _
        '    '                                "AND NOT Student.StudentId In " & _
        '    '                                "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                "FROM Student " & _
        '    '                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                "WHERE Year = '" & intYear + 1 & "' " & _
        '    '                                "AND Faculty='BSC.IT' OR Faculty ='BBA')" & _
        '    '                                "AND NOT Student.StudentId In " & _
        '    '                                "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                "FROM Student " & _
        '    '                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                "WHERE Year = '" & intYear + 2 & "' " & _
        '    '                                "AND Faculty='BSC.IT' OR Faculty ='BBA')" & _
        '    '                                "AND NOT Student.StudentId In " & _
        '    '                                "(SELECT Student.StudentId As [Student Id] " & _
        '    '                                "FROM Student " & _
        '    '                                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
        '    '                                "WHERE Year = '" & intYear + 3 & "' " & _
        '    '                                "AND Faculty='BSC.IT' OR Faculty ='BBA'))  " & _
        '    '   "ORDER BY Name;")

        'End If

        'Fill the datagridview 
        FillDataGridView()
    End Sub
    Private Sub FillDataGridView()
        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdStudent.DataSource = Nothing

            'Get the table data
            dtAdmission = dataAccess.objDataSet.Tables(0)
            'Get the datasource for datagridview
            grdStudent.DataSource = dtAdmission

            GblAccessItem.DataTableAdmissionView = dataAccess.AutoNumberedTable(dtAdmission)

            'Make DataGridView ReadOnly property to true
            grdStudent.ReadOnly = True

            If grdStudent.RowCount > 0 Then
                'Enable the btnGetReport button
                btnGetReport.Enabled = True
            Else
                'Disable the btnGetReport button
                btnGetReport.Enabled = False
            End If

            'Display the number of records in result text
            lblResult.Text = grdStudent.RowCount

            grdStudent.Columns(1).Frozen = True
        End If
    End Sub

    'CLICK EVENT OF VIEW BUTTON
    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        'Call procedure
        GetStudentList()

        'Make sure that the view fields are cleared at first
        ClearFields()

        'Disable the controls in the View sections
        DisabledControls()
    End Sub







    'METHODS AND EVENT FOR THE VIEW SECTION

    'SELECTEDINDEXCHANGED EVENT FOR VIEWYEAR COMBOBOX
    Private Sub cboViewYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboViewYear.SelectedIndexChanged
        If cboViewYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboViewFaculty.Items.Contains("FCHE") Then
                cboViewFaculty.Items.Add("FCHE")
            End If
            cboViewFaculty.SelectedIndex = cboViewFaculty.Items.Count - 1
            cboViewFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboViewFaculty.Enabled = True
            cboViewFaculty.Items.Remove("FCHE")
        End If
    End Sub


    'ENABLE THE CONTROLS
    Private Sub EnableControls()
        txtId.Enabled = True
        txtName.Enabled = True
        dtpAdmissionDate.Enabled = True
        cboViewYear.Enabled = True
        cboViewFaculty.Enabled = True
        btnDelete.Enabled = True
    End Sub


    'DISABLE THE CONTROLS
    Private Sub DisabledControls()
        txtId.Enabled = False
        txtName.Enabled = False
        dtpAdmissionDate.Enabled = False
        cboViewYear.Enabled = False
        cboViewFaculty.Enabled = False
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    'CLEAR THE FIELDS IN THE VIEW SECTIONS
    Private Sub ClearFields()
        txtId.Clear()
        txtName.Clear()
        dtpAdmissionDate.Value = Now
    End Sub

    Private Sub dtpAdmissionDate_ValueChanged(sender As Object, e As EventArgs) Handles dtpAdmissionDate.ValueChanged, cboViewFaculty.SelectedIndexChanged, cboViewYear.SelectedIndexChanged
        'Enable the Update button
        btnUpdate.Enabled = True
    End Sub

    Private Sub grdStudent_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdStudent.CellClick
        rowNumber = grdStudent.CurrentCell.RowIndex

        'Make sure that the view fields are cleared at first
        ClearFields()

        'Enable the controls in the View sections
        EnableControls()

        For i As Integer = 0 To grdStudent.ColumnCount - 1
            Try
                Select Case i
                    Case 0
                        strId = grdStudent.Item(0, e.RowIndex).Value.ToString
                        txtId.Text = grdStudent.Item(0, e.RowIndex).Value.ToString
                    Case 1
                        txtName.Text = grdStudent.Item(1, e.RowIndex).Value.ToString
                    Case 2
                        dtAdmissionDate = grdStudent.Item(2, e.RowIndex).Value
                        dtpAdmissionDate.Value = grdStudent.Item(2, e.RowIndex).Value
                    Case 3
                        intOriginalYear = grdStudent.Item(3, e.RowIndex).Value
                        Dim intViewYear As Integer = grdStudent.Item(3, e.RowIndex).Value

                        Select Case intViewYear
                            Case 0
                                cboViewYear.SelectedIndex = 0
                            Case 1
                                cboViewYear.SelectedIndex = 1
                            Case 2
                                cboViewYear.SelectedIndex = 2
                            Case 3
                                cboViewYear.SelectedIndex = 3
                        End Select
                    Case 4
                        If grdStudent.Item(3, e.RowIndex).Value <> 0 Then
                            If grdStudent.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("bba") Then
                                cboViewFaculty.SelectedIndex = 0
                            ElseIf grdStudent.Item(4, e.RowIndex).Value.ToString.ToLower.StartsWith("bsc") Then
                                cboViewFaculty.SelectedIndex = 1
                            Else
                                'Do nothing
                            End If
                        End If
                End Select
            Catch ex As Exception

            End Try
        Next

        'Make sure that the update button is disabled
        btnUpdate.Enabled = False
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Raise a YesNo question
        If MessageBox.Show("Do you really want to update admission details of " & txtName.Text & "| (" & strId & ")?", "Admission leDetails", _
                          MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            Dim intUpdateYear As Integer
            'Get year value for YEAR combobox
            Select Case cboViewYear.SelectedIndex
                Case 0
                    intUpdateYear = 0
                Case 1
                    intUpdateYear = 1
                Case 2
                    intUpdateYear = 2
                Case 3
                    intUpdateYear = 3
            End Select

            'Create a sql query text
            Dim strCommand As String = "UPDATE StudentAdmission " & _
                                 "SET AdmissionDate=@admissionDate, " & _
                                 "Year= @year, " & _
                                 "Faculty=@faculty " & _
                                 "WHERE StudentId=@studentId " & _
                                 "AND AdmissionDate=@originalAdmissionDate " & _
                                 "AND Year=@originalYear;"

            'Create a new sql command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add parameters
            'Module Details
            objCommand.Parameters.AddWithValue("@admissionDate", dtpAdmissionDate.Value.Date)
            objCommand.Parameters.AddWithValue("@year", intUpdateYear)
            objCommand.Parameters.AddWithValue("@faculty", cboViewFaculty.Text)
            objCommand.Parameters.AddWithValue("@studentId", strId)
            objCommand.Parameters.AddWithValue("@originalAdmissionDate", dtAdmissionDate)
            objCommand.Parameters.AddWithValue("@originalYear", intOriginalYear)

            'Call RunQuery Method to update the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Module Details")

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully update message
                MsgBox("Admission details of " & txtName.Text & "| (" & strId & ")?" & " has been successfully updated.", MsgBoxStyle.Information, "Admission Details")

                'Clear existing records from the dataset
                If dataAccess.objDataSet IsNot Nothing Then
                    dataAccess.objDataSet.Clear()
                End If

                Dim intSelectYear As Integer
                'Get year value for YEAR combobox
                Select Case cboViewYear.SelectedIndex
                    Case 0
                        intSelectYear = 0
                    Case 1
                        intSelectYear = 1
                    Case 2
                        intSelectYear = 2
                    Case 3
                        intSelectYear = 3
                End Select

                'Get list of name and id and phone
                dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name,AdmissionDate As [Admission Date],Year, Faculty " & _
                    "FROM Student " & _
                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                     "WHERE Student.StudentId='" & strId & "'" & _
                   "AND AdmissionDate='" & dtpAdmissionDate.Value.Date & "' " & _
                   "And Year=" & intSelectYear & ";")

                FillDataGridView()

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no such admission details of " & txtName.Text & "| (" & strId & ").", MsgBoxStyle.Exclamation, "Admission Details")

                'Call btnView_Click procedure
                btnView_Click(Nothing, Nothing)
            End If
        End If
    End Sub

    'CLICK EVENT OF DELETE BUTTON
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Raise a YesNo question
        If MessageBox.Show("Do you really want to delete admission details of " & txtName.Text & "| (" & strId & ")?", "Admission leDetails", _
                          MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            'Create a sql query text
            Dim strCommand As String = "DELETE FROM StudentAdmission " & _
                                "WHERE StudentId=@studentId " & _
                                 "AND AdmissionDate=@originalAdmissionDate " & _
                                 "AND Year=@originalYear;"

            'Create  a new command
            Dim objCommand As New SqlCommand
            objCommand.CommandText = strCommand

            'Add a parameter
            objCommand.Parameters.AddWithValue("@studentId", strId)
            objCommand.Parameters.AddWithValue("@originalAdmissionDate", dtAdmissionDate)
            objCommand.Parameters.AddWithValue("@originalYear", intOriginalYear)


            'Call RunQuery Method to delete the selected user
            dataAccess.RunQuery(objCommand)

            'Check for errors
            If dataAccess.strExceptionRunQuery <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQuery, MsgBoxStyle.Exclamation, "Admission Details")

                'Set the variable to nothing
                dataAccess.strExceptionRunQuery = Nothing
            ElseIf dataAccess.intCountRecord = 1 Then
                'Show successfully update message
                MsgBox("Admission details of " & txtName.Text & "| (" & strId & ")?" & " has been successfully deleted.", MsgBoxStyle.Information, "Admission Details")

                'Call btnView_Click procedure
                'btnView_Click(Nothing, Nothing)
                'ElseIf dataAccess.intCountRecord = 0 Then
                '    'Show successfully update message
                '    MsgBox("There's no module with details: |" & strModuleCode & "| (" & strModuleName & ").", MsgBoxStyle.Exclamation, "Module Details")

                '    'Call btnView_Click procedure
                '    btnFilterView_Click(Nothing, Nothing)

                'Remove a row from the GridView
                grdStudent.Rows.RemoveAt(rowNumber)

                'Get the number of rows
                lblResult.Text = grdStudent.RowCount

                'Call ClearFields method to clear the text
                ClearFields()

                'Call DisableControl method to disable controls
                DisabledControls()

                'Disable the GetReport button
                btnGetReport.Enabled = False
            ElseIf dataAccess.intCountRecord = 0 Then
                'Show successfully update message
                MsgBox("There's no such admission details of " & txtName.Text & "| (" & strId & ").", MsgBoxStyle.Exclamation, "Admission Details")

                'Call btnView_Click procedure
                btnView_Click(Nothing, Nothing)
            End If
        End If
    End Sub

    Private Sub btnGetReport_Click(sender As Object, e As EventArgs) Handles btnGetReport.Click
        Dim formReport As New FormReport
        formReport.strReport = "AdmissionView"
        formReport.WindowState = FormWindowState.Maximized
        formReport.ShowDialog()
    End Sub
End Class
