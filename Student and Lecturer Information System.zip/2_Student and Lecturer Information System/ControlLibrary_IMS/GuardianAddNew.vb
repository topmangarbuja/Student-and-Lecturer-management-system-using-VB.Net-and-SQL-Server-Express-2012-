﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class GuardianAddNew
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtStudentList As New DataTable
    Dim dtRelationship As New DataTable
    Dim dtGuardianList As New DataTable
    Dim strExceptionId As String = "errStudentId"
    Dim strExceptionFirstName As String = "errFirstName"
    Dim strExceptionLastName As String = "errLastName"
    Dim strExceptionGuardian As String = "errGuardian"
    'METHOD: GET STUDENT ID AND NAME BASED ON COMBOBOX SELECTION
    Private Sub GetStudentIdAndName()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Student;"

        'Call GetStudentName method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtStudentList = dataAccess.dtListForComboBox
            cboId.DataSource = dtStudentList
            cboId.DisplayMember = "StudentId"

            If cboId.Text = "" Then
                txtStudentName.Clear()
            End If
        End If
    End Sub

    'METHOD:GET LIST OF RELATIONSHIP 
    Private Sub GetRelationship()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT DISTINCT Relationship FROM Guardian; "

        'Call GetStudentName method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Relationship | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtRelationship = dataAccess.dtListForComboBox
            cboRelationship.DataSource = dtRelationship
            cboRelationship.DisplayMember = "Relationship"
        End If
    End Sub

    'FORM LOAD EVENT 
    Private Sub GuardianAddNew_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Get the list of student in the combobox
        GetStudentIdAndName()

        'Get list of relationship in the combobox
        GetRelationship()

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub


    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
    Private Sub cboId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
        'Clear any previous bindings..
        txtStudentName.DataBindings.Clear()

        'Binding process
        txtStudentName.DataBindings.Add("Text", dtStudentList, "Name")

        'Refresh datagridview
        'GetStudentIdAndNameAndGuardian()
    End Sub


    'CLICK EVENT TO SAVE STUDENT PHONE NUMBER
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you want to add the following guardian details?")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Student-Info: " & txtStudentName.Text & " | " & cboId.Text)
        objStringBuilder.AppendLine("Guardian-Info: " & txtGuardianFirstName.Text & " " & txtGuardianLastName.Text & " | " & cboRelationship.Text)

        'Show message box
        If MessageBox.Show(objStringBuilder.ToString, "Add Guardian Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            objCommand = New SqlCommand
            objCommand.CommandText = "INSERT INTO Guardian " & _
                                     "VALUES(@studentId,@guardianFirstName,@guardianLastName,@guardianPhoneNo,@relationship);"

            'Add parameters for the placeholder in the SQL CommandText property..
            objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
            objCommand.Parameters.AddWithValue("@guardianFirstName", txtGuardianFirstName.Text)
            objCommand.Parameters.AddWithValue("@guardianLastName", txtGuardianLastName.Text)
            objCommand.Parameters.AddWithValue("@guardianPhoneNo", txtGuardianPhoneNumber.Text)
            objCommand.Parameters.AddWithValue("@relationship", cboRelationship.Text)

            'Call AddDetails method to add phone number
            dataAccess.AddDetails(objCommand)

            'Check for errors
            If dataAccess.strExceptionAddDetails <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Guardian Details | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionAddDetails = Nothing
            Else
                'If there is no error, show succeed message

                Dim objStringBuilder1 As New System.Text.StringBuilder
                objStringBuilder1.AppendLine("The following guardian information has been successfully added.")
                objStringBuilder1.AppendLine(String.Empty)
                objStringBuilder1.AppendLine("Student-Info: " & txtStudentName.Text & " | " & cboId.Text)
                objStringBuilder1.AppendLine("Guardian-Info: " & txtGuardianFirstName.Text & " " & txtGuardianLastName.Text & " | " & cboRelationship.Text)

                'Show message box
                MessageBox.Show(objStringBuilder1.ToString, "Add Guardian Details | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)


                'Get list of relationship in the combobox
                GetRelationship()


                'Clear textboxes and focus on first name textbox
                txtGuardianFirstName.Clear()
                txtGuardianLastName.Clear()
                txtGuardianPhoneNumber.Clear()
                cboRelationship.SelectedIndex = 0
                txtGuardianFirstName.Focus()

                'Refresh datagridview
                GetGuardianAndStudentList()

               
            End If
        End If
    End Sub





    'LIST OF METHOD FOR THE DATAGRIDVIEW SECTION
    'METHOD: GET STUDENT ID AND NAME AND THEIR GUARDIAN DETAILS FOR THE DATAGRIDVIEW
    'Private Sub GetStudentIdAndNameAndGuardian()
    '    'Clear existing records from the dataset
    '    If dataAccess.objDataSet IsNot Nothing Then
    '        dataAccess.objDataSet.Clear()
    '    End If

    '    'Get list of name and id and phone
    '    dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId As [Student Id], (Student.FirstName + ' ' + Student.LastName) As [Student Name], (Guardian.FirstName + ' ' + Guardian.LastName) As [Guardian Name], PhoneNo As [Phone number], Relationship " & _
    '        "FROM Student " & _
    '        "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
    '        "WHERE Student.StudentId='" & cboId.Text & "';")

    '    'Check for errors
    '    If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
    '        'Show error message
    '        MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

    '        'Set the variable to nothing
    '        dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
    '    Else
    '        'Clear previous DataGridView DataSource
    '        grdGuardian.DataSource = Nothing

    '        'Get the datasource for datagridview
    '        grdGuardian.DataSource = dataAccess.objDataSet.Tables(0)

    '        'Make sure the following changes
    '        'Change the text
    '        btnEnableEdit.Text = "Enable Edit"

    '        'Make DataGridView ReadOnly property to true
    '        grdGuardian.ReadOnly = True

    '        'Enable or disable the Enable Edit button based on number of records retrieved
    '        If grdGuardian.RowCount > 0 Then
    '            btnEnableEdit.Enabled = True
    '        Else
    '            btnEnableEdit.Enabled = False
    '        End If
    '    End If
    'End Sub

    'METHOD: GET STUDENT GUARDIAN DETAILS FOR THE DATAGRIDVIEW FROM A SINGLE TABLE
    'Private Sub GetGuardian()
    '    'Clear existing records from the dataset
    '    If dataAccess.objDataSet IsNot Nothing Then
    '        dataAccess.objDataSet.Clear()
    '    End If

    '    'Get list of name and id and phone
    '    dataAccess.RunQueryAndFillDataSet("SELECT StudentId As [Student Id], FirstName As [First Name], LastName As [Last Name], PhoneNo As [Phone number], Relationship " & _
    '        "FROM Guardian " & _
    '        "WHERE StudentId='" & cboId.Text & "';")

    '    'Check for errors
    '    If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
    '        'Show error message
    '        MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

    '        'Set the variable to nothing
    '        dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
    '    Else
    '        'Clear previous DataGridView DataSource
    '        grdGuardian.DataSource = Nothing

    '        'Get the datasource for datagridview
    '        grdGuardian.DataSource = dataAccess.objDataSet.Tables(0)

    '        dataAccess.objDataAdapter.UpdateCommand = New SqlClient.SqlCommandBuilder(dataAccess.objDataAdapter).GetUpdateCommand
    '    End If
    'End Sub

    'ENABLE SAVE BUTTON BASED ON SOME STRING VALUES
    Private Sub EnabledSaveButton()
        If strExceptionId = "" And strExceptionFirstName = "" And strExceptionLastName = "" Then
            'Clear existing records from the dataset
            If dataAccess.objDataSet IsNot Nothing Then
                dataAccess.objDataSet.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
                "FROM Guardian " & _
                "WHERE StudentId LIKE '%" & cboId.Text & "%' " & _
                "AND FirstName ='" & txtGuardianFirstName.Text & "' " & _
                "AND LastName='" & txtGuardianLastName.Text & "'; ")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
                Dim strExceptionGuardian As String = "The guardian details: |" & txtGuardianFirstName.Text & " " & txtGuardianLastName.Text & "| of student: " & txtStudentName.Text & " (" & cboId.Text & ") already exist. For details click 'View' on view section or search & view in other tab."
                'ErrorProvider1.SetError(cboId, strExceptionId)

                MsgBox(strExceptionGuardian, MsgBoxStyle.Exclamation, "Guardian Details")

                'Clear guardian first and last name and focus on first name
                txtGuardianFirstName.Clear()
                txtGuardianLastName.Clear()
                txtGuardianFirstName.Focus()

                'Set error 
                ErrorProvider1.SetError(txtGuardianFirstName, "")
                ErrorProvider1.SetError(txtGuardianLastName, "")

                'Initialize error once more
                strExceptionFirstName = "errFirstName"
                strExceptionLastName = "errLastName"

                'Disable the save button
                btnSave.Enabled = False
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
                'Enable the save button
                btnSave.Enabled = True
            End If
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub cboId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboId.Validating
        'Check if the student already exists
        If cboId.Text.Trim.Length = 12 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSet IsNot Nothing Then
                dataAccess.objDataSet.Clear()
            End If

            'Get list of name and id and phone
            dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
                "FROM Student " & _
                "WHERE StudentId LIKE '%" & cboId.Text & "%';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
                'Show error message
                MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
                strExceptionId = ""
                ErrorProvider1.SetError(cboId, strExceptionId)

            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
                strExceptionId = "This student does not exist."
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtStudentName.Clear()
            End If
        Else
            strExceptionId = "Select or enter 12 character student Id."
            ErrorProvider1.SetError(cboId, strExceptionId)

            'Clear the name textbox
            txtStudentName.Clear()
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtGuardianFirstName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtGuardianFirstName.Validating
        If txtGuardianFirstName.Text.Trim.Length = 0 Then
            strExceptionFirstName = "Please enter first name."
            ErrorProvider1.SetError(txtGuardianFirstName, strExceptionFirstName)
        Else
            strExceptionFirstName = ""
            ErrorProvider1.SetError(txtGuardianFirstName, strExceptionFirstName)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtGuardianLastName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtGuardianLastName.Validating
        If txtGuardianLastName.Text.Trim.Length = 0 Then
            strExceptionLastName = "Please enter last name."
            ErrorProvider1.SetError(txtGuardianLastName, strExceptionLastName)
        Else
            strExceptionLastName = ""
            ErrorProvider1.SetError(txtGuardianLastName, strExceptionLastName)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub cboRelationship_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboRelationship.KeyPress
        If Not Char.IsLetter(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub





    'LIST OF METHODS FOR THE VIEW SECTIONS
    'METHOD: GET STUDENT ID AND NAME AND THEIR GUARDIAN DETAILS FOR THE DATAGRIDVIEW
    Private Sub GetGuardianAndStudentList()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Get list of name and id and phone
        dataAccess.RunQueryAndFillDataSet("SELECT (Guardian.FirstName + ' ' + Guardian.LastName) As [Guardian],(Student.FirstName + ' ' + Student.LastName) as [Student],Student.StudentId As [Student Id] " & _
            "FROM Student " & _
            "JOIN Guardian ON Student.StudentId=Guardian.StudentId " & _
            "ORDER BY Guardian;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear previous DataGridView DataSource
            grdGuardian.DataSource = Nothing
            'Get the table data
            dtGuardianList = dataAccess.AutoNumberedTable(dataAccess.objDataSet.Tables(0))

            'Get the datasource for datagridview
            grdGuardian.DataSource = dtGuardianList

            'Change the first column header text
            grdGuardian.Columns(0).HeaderText = "S.n."
            grdGuardian.Columns(0).Width = 30


            grdGuardian.Columns(0).Frozen = True
        End If
    End Sub

    Private Sub btnViewGuardians_Click(sender As Object, e As EventArgs) Handles btnViewGuardians.Click
        'Get list of guardians and students
        GetGuardianAndStudentList()
    End Sub

    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear textboxes and focus on first name textbox
        txtGuardianFirstName.Clear()
        txtGuardianLastName.Clear()
        txtGuardianPhoneNumber.Clear()
        cboRelationship.SelectedIndex = 0
        txtGuardianFirstName.Focus()

    End Sub
End Class
