﻿Imports ClassLibrary_IMS
Imports System.Data.SqlClient

Public Class IssueAddNew
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtStudentList As DataTable
    Dim dtLecturerList As DataTable
    Dim dtBookCategory As DataTable
    Dim dtBookTitleAndIsbn As DataTable
    Dim dtBookIssue As DataTable
    Dim objCurrencyManager As CurrencyManager
    Dim intBookId As Integer
    Dim strExceptionRadioBtn As String = "errRadioBtn"
    Dim strExceptionId As String = "errStudentId"
    Dim strExceptionIsbn As String = "errIsbn"


    'CHECKEDCHANGED EVENT TO ENABLE AND DISABLE YEAR AND FACULTY COMBOBOX
    Private Sub rdbStudent_CheckedChanged(sender As Object, e As EventArgs) Handles rdbStudent.CheckedChanged, rdbLecturer.CheckedChanged
        If rdbStudent.Checked = True Then
            'Enable 
            cboYear.Enabled = True
            cboYear.SelectedIndex = 0
            GetStudentIdAndName()
        ElseIf rdbLecturer.Checked = True Then
            GetLecturerIdAndName()
            'Disable
            cboYear.Enabled = False
            cboFaculty.Enabled = False
            
        End If

        'Set the string to blank
        strExceptionRadioBtn = ""

        cboId_Validating(Nothing, Nothing)
        txtIsbn_Validating(Nothing, Nothing)

        'Enable the view button
        btnViewAllIssueBook.Enabled = True

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If

        If rdbStudent.Checked = True Then
            'Call GetStudentName to get list in the combobox
            GetStudentIdAndName()
        End If


      
    End Sub

    'FORM LOAD EVENT
    Private Sub IssueAddNew_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0
        'GetStudentIdAndName()
        GetBookCategoryList()
        GetBookTitleAndIsbn()

        'Disable the view button
        btnViewAllIssueBook.Enabled = False

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    'METHOD: GET STUDENT ID AND NAME BASED ON COMBOBOX SELECTION
    Private Sub GetStudentIdAndName()
        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        objCommand = New SqlCommand
        If intYear = 3 Then
            'Get list of student id and name 
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                "FROM Student " & _
                "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                "WHERE Year='" & intYear & "' " & _
               "AND Faculty='" & cboFaculty.Text & "' " & _
               "AND Status='Active';"

        ElseIf intYear = 2 Then
            'Get list of student id and name 
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Status='Active' " & _
                                            "AND Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "' " & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear + 1 & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "'));"
        ElseIf intYear = 1 Then
            'Get list of student id and name 
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Status='Active' " & _
                                            "AND Student.StudentId In " &
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "' " & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear + 1 & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "')" & _
                                              "AND NOT Student.StudentId In " & _
                                              "(SELECT Student.StudentId As [Student Id] " & _
                                              "FROM Student " & _
                                              "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                              "WHERE Year = '" & intYear + 2 & "' " & _
                                              "AND Faculty='" & cboFaculty.Text & "'));"
        ElseIf intYear = 0 Then
            'Get list of student id and name 
            objCommand.CommandText = "SELECT DISTINCT Student.StudentId, (FirstName + ' ' + LastName) As Name " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Status='Active' " & _
                                            "AND Student.StudentId In " &
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear & "' " & _
                                            "AND Faculty='" & cboFaculty.Text & "' " & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear + 1 & "' " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA')" & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear + 2 & "' " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA')" & _
                                            "AND NOT Student.StudentId In " & _
                                            "(SELECT Student.StudentId As [Student Id] " & _
                                            "FROM Student " & _
                                            "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                            "WHERE Year = '" & intYear + 3 & "' " & _
                                            "AND Faculty='BSC.IT' OR Faculty ='BBA'));"

        End If
        

        'Call procedure to get list of student name and id
        dataAccess.GetListForComboBox(objCommand)


        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Student Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            'Clear previous datasource
            cboId.DataSource = Nothing

            dtStudentList = dataAccess.dtListForComboBox
            cboId.DataSource = dtStudentList
            cboId.DisplayMember = "StudentId"

            If cboId.Text = "" Then
                txtName.Clear()
                btnSave.Enabled = False
        End If
        End If

        cboId.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        cboId.AutoCompleteSource = AutoCompleteSource.ListItems
    End Sub

    'SELECTEDINDEXCHANGED EVENT TO GET STUDENTNAME FOR NAME TEXTBOX
    Private Sub cboId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboId.SelectedIndexChanged
        Try
            'Clear any previous bindings..
            txtName.DataBindings.Clear()

            If rdbStudent.Checked = True Then
                'Binding process
                txtName.DataBindings.Add("Text", dtStudentList, "Name")
            ElseIf rdbLecturer.Checked = True Then
                'Binding process
                txtName.DataBindings.Add("Text", dtLecturerList, "Name")
            End If
        Catch ex As Exception

        End Try
    End Sub


    'SELECTEDINDEXCHANGED EVEN TO GET LIST OF STUDENTS
    Private Sub cboFaculty_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFaculty.SelectedIndexChanged
        If rdbStudent.Checked = True Then
            'Call GetStudentName to get list in the combobox
            GetStudentIdAndName()
        End If
    End Sub

    'METHOD: GET BOOK CATEGORY
    Private Sub GetBookCategoryList()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Category " & _
            "FROM Book "

        'Call GetStudentName method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Book Category List | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtBookCategory = dataAccess.dtListForComboBox
            cboBookCategory.DataSource = dtBookCategory
            cboBookCategory.DisplayMember = "Category"
        End If
    End Sub

    'METHOD: GET BOOK TITLE AND ISBN BASED ON CATEGORY COMBOBOX SELECTION
    Private Sub GetBookTitleAndIsbn()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT BookId, Title, Isbn " & _
            "FROM Book " & _
            "WHERE Category=@category;"


        'Add parameters for the placeholders in the SQL CommandText property
        objCommand.Parameters.AddWithValue("@category", cboBookCategory.Text)

        'Call GetListForCombobox method to get list of book title and isbn
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Book Title and Isbn | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtBookTitleAndIsbn = dataAccess.dtListForComboBox
            'objCurrencyManager = CType(Me.BindingContext(dtBookTitleAndIsbn), CurrencyManager)
            cboBookTitle.DataSource = dtBookTitleAndIsbn
            cboBookTitle.DisplayMember = "Title"

            If cboBookTitle.Text = "" Then
                txtIsbn.Clear()
            End If
        End If
    End Sub

    'SELECTEDINDEXCHANGED EVENT TO GET BOOK ISBN FOR ISBN TEXTBOX
    Private Sub cboBookTitle_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboBookTitle.SelectedIndexChanged
        'Clear any previous bindings..
        txtIsbn.DataBindings.Clear()

        'Binding process
        txtIsbn.DataBindings.Add("Text", dtBookTitleAndIsbn, "Isbn")
    End Sub


    'SELECTEDINDEXCHANGED EVENT TO GET LIST OF BOOK FOR BOOKTITLE COMBOBOX
    Private Sub cboBookCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboBookCategory.SelectedIndexChanged
        GetBookTitleAndIsbn()
    End Sub

    'METHOD: GET LECTURER ID AND NAME
    Private Sub GetLecturerIdAndName()
        objCommand = New SqlCommand
        'objCommand.CommandText = "SELECT LecturerId, (FirstName + ' ' + LastName) As Name " & _
        '    "FROM Lecturer " & _
        '    "WHERE Status='Active';"
        objCommand.CommandText = "SELECT LecturerId, (FirstName + ' ' + LastName) As Name " & _
            "FROM Lecturer;"

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Lecturer Id and Name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtLecturerList = dataAccess.dtListForComboBox
            cboId.DataSource = dtLecturerList
            cboId.DisplayMember = "LecturerId"

            If cboId.Text = "" Then
                txtName.Clear()

                btnSave.Enabled = False
            End If
        End If
    End Sub

    'METHOD: SAVE BOOK ISSUED BY STUDENT
    Private Sub SaveStudentIssue()
        objCommand = New SqlCommand
        objCommand.CommandText = "INSERT INTO StudentBookIssue(StudentId,BookId,IssueDate,IssueTime,Remarks) " & _
            "VALUES(@studentId,@bookId,@issueDate,@issueTime,@remarks); "

        'Add parameters for the placeholders in the SQL CommandText property..
        objCommand.Parameters.AddWithValue("@studentId", cboId.Text)
        objCommand.Parameters.AddWithValue("@bookId", intBookId)
        objCommand.Parameters.AddWithValue("@issueDate", dtpIssueDate.Value.Date)
        objCommand.Parameters.AddWithValue("@issueTime", dtpIssueTime.Value.TimeOfDay)
        objCommand.Parameters.AddWithValue("@remarks", "Borrowed")

        'Call AddDetails procedure: Add book issue details by student
        dataAccess.AddDetails(objCommand)

        'Check for errors
        If dataAccess.strExceptionAddDetails <> "" Then
            If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                'Show error message
                MessageBox.Show("The person has issue the same book on same date.", "Add Book Issue | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                'Show error message
                MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Book Issue | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            'Set the variable to nothing
            dataAccess.strExceptionAddDetails = Nothing
        Else
            objCommand = New SqlCommand
            objCommand.CommandText = "UPDATE Book " & _
                "SET AvailableQuantity=(AvailableQuantity-1) " & _
                "WHERE BookId=@bookId; "

            'Add parameters for the placeholders in the SQL CommandText property..
            objCommand.Parameters.AddWithValue("@bookId", intBookId)

            'Call AddDetails procedure to update the available quantity of book
            dataAccess.AddDetails(objCommand)

            If dataAccess.strExceptionAddDetails <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Book Issue | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionAddDetails = Nothing
            Else
                'If there is no error, show succeed message

                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("The following book-issue information has been successfully added.")
                objStringBuilder.AppendLine(String.Empty)
                objStringBuilder.AppendLine("Book-Info: " & cboBookTitle.Text & " | " & txtIsbn.Text)
                objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)

                'Show message box
                MessageBox.Show(objStringBuilder.ToString, "Add Book Issue | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Disable save button
                btnSave.Enabled = False

                'Clear fields
                ClearFields()
            End If
        End If
    End Sub

    'METHOD:SAVE BOOK ISSUED BY LECTURER
    Private Sub SaveLecturerIssue()
        objCommand = New SqlCommand
        objCommand.CommandText = "INSERT INTO LecturerBookIssue(LecturerId,BookId,IssueDate,IssueTime,Remarks) " & _
            "VALUES(@lecturerId,@bookId,@issueDate,@issueTime,@remarks); "

        'Add parameters for the placeholders in the SQL CommandText property..
        objCommand.Parameters.AddWithValue("@lecturerId", cboId.Text)
        objCommand.Parameters.AddWithValue("@bookId", intBookId)
        objCommand.Parameters.AddWithValue("@issueDate", dtpIssueDate.Value.Date)
        objCommand.Parameters.AddWithValue("@issueTime", dtpIssueTime.Value.TimeOfDay)
        objCommand.Parameters.AddWithValue("@remarks", "Borrowed")

        'Call AddDetails procedure: Add book issue details by lecturer
        dataAccess.AddDetails(objCommand)

        'Check for errors
        If dataAccess.strExceptionAddDetails <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Book Issue | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionAddDetails = Nothing
        Else
            objCommand = New SqlCommand
            objCommand.CommandText = "UPDATE Book " & _
                "SET AvailableQuantity=(AvailableQuantity-1) " & _
                "WHERE BookId=@bookId; "

            'Add parameters for the placeholders in the SQL CommandText property..
            objCommand.Parameters.AddWithValue("@bookId", intBookId)

            'Call AddDetails procedure to update the available quantity of book
            dataAccess.AddDetails(objCommand)

            If dataAccess.strExceptionAddDetails <> "" Then
                If dataAccess.strExceptionAddDetails = "This data already exists!" Then
                    'Show error message
                    MessageBox.Show("The person has issue the same book on same date.", "Add Book Issue | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    'Show error message
                    MessageBox.Show(dataAccess.strExceptionAddDetails, "Add Book Issue | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

                'Set the variable to nothing
                dataAccess.strExceptionAddDetails = Nothing
            Else
                'If there is no error, show succeed message

                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("The following book-issue information has been successfully added.")
                objStringBuilder.AppendLine(String.Empty)
                objStringBuilder.AppendLine("Book-Info: " & cboBookTitle.Text & " | " & txtIsbn.Text)
                objStringBuilder.AppendLine("Lecturer-Info: " & txtName.Text & " | " & cboId.Text)

                'Show message box
                MessageBox.Show(objStringBuilder.ToString, "Add Book Issue | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Disable save button
                btnSave.Enabled = False

                'Clear fields
                ClearFields()
            End If
        End If
    End Sub

    'CLICK EVENT OF SAVE BUTTON
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Get BookId
        intBookId = BindingContext(dtBookTitleAndIsbn).Current("BookId")

        Dim objStringBuilder As New System.Text.StringBuilder
        objStringBuilder.AppendLine("Do you want to book-issue details?")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Book-Info: " & cboBookTitle.Text & " | " & txtIsbn.Text)
        If rdbStudent.Checked = True Then
            objStringBuilder.AppendLine("Student-Info: " & txtName.Text & " | " & cboId.Text)
        ElseIf rdbLecturer.Checked = True Then
            objStringBuilder.AppendLine("Lectuer-Info: " & txtName.Text & " | " & cboId.Text)
        End If
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Remember: The quantity i.e. 1 will also be subtracted from available quantity of the book in the library.")

        'Create a new command to check whether book is available or not.
        Dim objCommand As New SqlCommand
        objCommand.CommandText = "SELECT AvailableQuantity FROM BOOK " & _
            "WHERE BookId=@bookID;"
        objCommand.Parameters.AddWithValue("@bookId", intBookId)

        'Call AddDetails procedure to update the available quantity of book
        If dataAccess.GetAvailabilityOfBook(objCommand) = True Then
            'Show message box
            If MessageBox.Show(objStringBuilder.ToString, "Add Book Issue | Process-Succeed", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If rdbStudent.Checked = True Then
                    SaveStudentIssue()
                ElseIf rdbLecturer.Checked = True Then
                    SaveLecturerIssue()
                End If
            End If
        Else
            Dim objStringBuilder1 As New System.Text.StringBuilder
            objStringBuilder1.AppendLine("This book '" & cboBookTitle.Text & "' is not available.i.e. the available quantity of this book is zero. For its details, search or view about it.")
            objStringBuilder1.AppendLine(String.Empty)
            objStringBuilder1.AppendLine("Note: To issue book, the availbility of the book must be at least one.")
            'Show error message
            MsgBox(objStringBuilder1.ToString, MsgBoxStyle.Exclamation, "Book-Issue")

        End If


        

        'Call procedure to get list of book-issued details
        btnViewAllIssueBook_Click(Nothing, Nothing)
    End Sub

    'Private Sub rdbLecturer_CheckedChanged(sender As Object, e As EventArgs) Handles rdbLecturer.CheckedChanged
    '    If rdbLecturer.Checked = True Then
    '        GetLecturerIdAndName()
    '    End If
    'End Sub

    Private Sub cboId_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboId.Validating
        If rdbStudent.Checked = True Then
            'Check if the student already exists
            If cboId.Text.Trim.Length = 12 Then
                'Clear existing records from the dataset
                If dataAccess.objDataSetStudentCheck IsNot Nothing Then
                    dataAccess.objDataSetStudentCheck.Clear()
                End If

                Dim intYear As Integer
                'Get year value for YEAR combobox
                Select Case cboYear.SelectedIndex
                    Case 0
                        intYear = 0
                    Case 1
                        intYear = 1
                    Case 2
                        intYear = 2
                    Case 3
                        intYear = 3
                End Select
                ''Get list of name and id and phone
                'dataAccess.RunQueryAndFillDataSetIdCheck("SELECT *  " & _
                '    "FROM Student " & _
                '    "WHERE StudentId LIKE '%" & cboId.Text & "%';")

                If intYear = 3 Then
                    'Get list of name and id and phone
                    dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                    "FROM Student " & _
                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                     "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                    "AND Year= 3 " & _
                    "AND Faculty='" & cboFaculty.Text & "' " & _
                    "AND Status='Active';")
                ElseIf intYear = 2 Then
                    'Get list of name and id and phone
                    dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                     "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                                                      "AND Status='Active' " & _
                                                      "AND Student.StudentId In " & _
                                                      "(SELECT Student.StudentId As [Student Id] " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                      "WHERE Year = 2 " & _
                                                       "AND Faculty='" & cboFaculty.Text & "' " & _
                                                      "AND NOT Student.StudentId In " & _
                                                      "(SELECT Student.StudentId As [Student Id] " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                      "WHERE Year = 3 " & _
                                                       "AND Faculty='" & cboFaculty.Text & "')); ")
                    '"AND Faculty=@faculty ));"
                ElseIf intYear = 1 Then
                    dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                                                      "AND Status='Active' " & _
                                                      "AND Student.StudentId In " & _
                                                      "(SELECT Student.StudentId " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                      "WHERE STudent.StudentId In " & _
                                                      "(SELECT Student.StudentId As [Student Id] " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                      "WHERE Year =1 " & _
                                                       "AND Faculty='" & cboFaculty.Text & "' " & _
                                                      "AND NOT Student.StudentId In " & _
                                                      "(SELECT Student.StudentId As [Student Id] " & _
                                                      "FROM Student " & _
                                                      "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                      "WHERE Year = 2  " & _
                                                        "AND Faculty='" & cboFaculty.Text & "'))); ")
                    '"AND Faculty= @faculty )));"
                ElseIf intYear = 0 Then
                    dataAccess.RunQueryAndFillDataSetIdCheck("SELECT * " & _
                                                    "FROM Student " & _
                                                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                  "WHERE Student.StudentId ='" & cboId.Text & "' " & _
                                                     "AND Status='Active' " & _
                                                    "AND Student.StudentId In " & _
                                                    "(SELECT Student.StudentId As [Student Id] " & _
                                                    "FROM Student " & _
                                                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                    "WHERE Year = 0 " & _
                                                    "AND Faculty='" & cboFaculty.Text & "' " & _
                                                    "AND NOT Student.StudentId In " & _
                                                    "(SELECT Student.StudentId As [Student Id] " & _
                                                    "FROM Student " & _
                                                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                    "WHERE Year = 1 " & _
                                                    "AND Faculty='BSC.IT' OR Faculty ='BBA' " & _
                                                    "AND NOT Student.StudentId In " & _
                                                    "(SELECT Student.StudentId As [Student Id] " & _
                                                    "FROM Student " & _
                                                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                    "WHERE Year = 2 " & _
                                                    "AND Faculty='BSC.IT' OR Faculty ='BBA' " & _
                                                    "AND NOT Student.StudentId In " & _
                                                    "(SELECT Student.StudentId As [Student Id] " & _
                                                    "FROM Student " & _
                                                    "JOIN StudentAdmission ON Student.StudentId=StudentAdmission.StudentId " & _
                                                    "WHERE Year = 3 " & _
                                                    "AND Faculty='BSC.IT' OR Faculty ='BBA'))));")

                End If

                'Check for errors
                If dataAccess.strExceptionRunQueryAndFillDataSetIdCheck <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQueryAndFillDataSetIdCheck, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQueryAndFillDataSetIdCheck = Nothing
                ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 1 Then
                    strExceptionId = ""
                    ErrorProvider1.SetError(cboId, strExceptionId)

                ElseIf dataAccess.objDataSetStudentCheck.Tables(0).Rows.Count = 0 Then
                    If intYear = 0 Then
                        strExceptionId = "This student does not exist or now the student is not in 'FCHE' level."
                    Else
                        strExceptionId = "This student does not exist or now the student is not in " & cboYear.Text & " '" & cboFaculty.Text & "' level."
                    End If

                    ErrorProvider1.SetError(cboId, strExceptionId)

                    'Clear the name textbox
                    txtName.Clear()
                End If
            End If
        ElseIf rdbLecturer.Checked = True Then
            'Check if the student already exists
            If cboId.Text.Trim.Length = 12 Then
                'Clear existing records from the dataset
                If dataAccess.objDataSet IsNot Nothing Then
                    dataAccess.objDataSet.Clear()
                End If

                'Get list of name and id and phone
                dataAccess.RunQueryAndFillDataSet("SELECT *  " & _
                    "FROM Lecturer " & _
                    "WHERE LecturerId LIKE '%" & cboId.Text & "%';")

                'Check for errors
                If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
                    'Show error message
                    MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

                    'Set the variable to nothing
                    dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
                ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
                    strExceptionId = ""
                    ErrorProvider1.SetError(cboId, strExceptionId)

                    'clear the textbox
                    'txtStudentId.Clear()
                ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
                    strExceptionId = "This lecturer does not exist"
                    ErrorProvider1.SetError(cboId, strExceptionId)

                    'Clear the name textbox
                    txtName.Clear()
                End If
            Else
                strExceptionId = "Select or enter 12 character lecturer Id."
                ErrorProvider1.SetError(cboId, strExceptionId)

                'Clear the name textbox
                txtName.Clear()
            End If
        End If


        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub


    'ENABLE SAVE BUTTON BASED ON SOME STRING VALUES
    Private Sub EnabledSaveButton()
        If strExceptionRadioBtn = "" And strExceptionId = "" And strExceptionIsbn = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub txtIsbn_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtIsbn.Validating
        If txtIsbn.Text.Trim.Length = 0 Then
            strExceptionIsbn = "Please select category and then title to issue book."
            ErrorProvider1.SetError(txtIsbn, strExceptionIsbn)
        Else
            strExceptionIsbn = ""
            ErrorProvider1.SetError(txtIsbn, strExceptionIsbn)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub btnViewAllIssueBook_Click(sender As Object, e As EventArgs) Handles btnViewAllIssueBook.Click
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'If Student radiobutton is checked and 'Borrowed' is selected in the combobox
        If rdbStudent.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, FirstName+' ' + LastName As Name, Title, Isbn, Author, issuedate, issuetime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Borrowed' " & _
                                              "ORDER BY Name;")


            'If Lecturer radiobutton is checked and 'Borrowed' is selected in the combobox
        ElseIf rdbLecturer.Checked = True Then
            dataAccess.RunQueryAndFillDataSet("SELECT Lecturer.LecturerId, FirstName+' ' + LastName As Name,  Title, Isbn, Author, issuedate, issuetime, remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Borrowed' " & _
                                              "ORDER BY Name;")



            'If none of the radiobutton is checked
        Else
            dataAccess.RunQueryAndFillDataSet("SELECT Student.StudentId, FirstName+' ' + LastName As Name, Title, Isbn, Author, issuedate, issuetime, remarks  from book " & _
                                              "join StudentBookIssue on book.bookid= studentbookissue.bookid " & _
                                              "join Student on studentbookissue.studentid = student.studentid " & _
                                              "WHERE Remarks='Borrowed' " & _
                                              "UNION " & _
                                              "SELECT Book.BookId, Lecturer.LecturerId, FirstName+' ' + LastName As Name, Title, Isbn, Author, issuedate, issuetime,remarks  from book " & _
                                              "join LecturerBookIssue on book.bookid= LecturerBookIssue.bookid " & _
                                              "join Lecturer on LecturerBookIssue.Lecturerid = Lecturer.LecturerId " & _
                                             "WHERE Remarks='Borrowed' " & _
                                             "ORDER BY Name;")
        End If

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MsgBox(dataAccess.strExceptionRunQueryAndFillDataSet, MsgBoxStyle.Exclamation)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Get the table data 
            dtBookIssue = dataAccess.AutoNumberedTable(dataAccess.objDataSet.Tables(0))

            'Get the datasource for datagridview
            grdBookIssue.DataSource = dtBookIssue

            'Change the header text of firstcolumn
            grdBookIssue.Columns(0).HeaderText = "S.n."

            grdBookIssue.Columns(1).Frozen = True
        End If

    End Sub

    Private Sub ClearFields()
        dtpIssueDate.Value = Now
        dtpIssueTime.Value = Now
    End Sub

    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub
End Class