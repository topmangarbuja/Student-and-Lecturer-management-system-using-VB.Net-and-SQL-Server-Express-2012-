﻿Imports System.Data.SqlClient
Imports ClassLibrary_IMS

Public Class BookAddNew
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtBookList As DataTable
    Dim dtBookCategory As DataTable
    Dim intBookId As Integer
    Dim intAuthorId As Integer
    Dim strExceptionIsbn As String = "errIsbn"
    Dim strExceptionTitle As String = "errTitle"

    'CLICK EVENT OF SAVE BUTTON TO STORE DETAILS ABOUT BOOK AND AUTHOR
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtTotalQuantity.Text.Trim.Length > 0 Then
            If CType(txtTotalQuantity.Text, Integer) > 0 Then
                'Get book id
                GetBookId()

                Dim objStringBuilder As New System.Text.StringBuilder
                objStringBuilder.AppendLine("Do you want to add the following details?")
                objStringBuilder.AppendLine(String.Empty)
                objStringBuilder.AppendLine("Book-Info: " & txtTitle.Text & " | " & txtIsbn.Text)
                objStringBuilder.AppendLine("Publisher-Info: " & txtPublisher.Text)
                objStringBuilder.AppendLine("Author-Info: " & txtAuthor.Text)

                If MessageBox.Show(objStringBuilder.ToString, "Book Details", MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                    = DialogResult.Yes Then
                    'Call procedure to add book
                    AddBook()
                End If
            Else
                'Show error message
                MessageBox.Show("Please enter TotalQuantity at least 1.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Else
            'Show error message
            MessageBox.Show("Please enter TotalQuantity of book.", "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    'METHOD: TO GET HIGHEST BOOK ID
    Private Sub AddBook()
        objCommand = New SqlCommand
        objCommand.CommandText = "INSERT INTO Book " & _
            "VALUES(@bookId,@isbn,@title,@publisher,@author,@publishDate,@category,@totalQuantity,@availableQuantity); "


        'Add parameters for the placeholders in the SQL CommandText property

        'Book-details
        objCommand.Parameters.AddWithValue("@bookId", intBookId)
        objCommand.Parameters.AddWithValue("@isbn", txtIsbn.Text)
        objCommand.Parameters.AddWithValue("@title", txtTitle.Text)
        objCommand.Parameters.AddWithValue("@publisher", txtPublisher.Text)
        objCommand.Parameters.AddWithValue("@author", txtAuthor.Text)
        objCommand.Parameters.AddWithValue("@publishDate", dtpPublishDate.Value.Date)
        objCommand.Parameters.AddWithValue("@category", cboCategory.Text)
        objCommand.Parameters.AddWithValue("@totalQuantity", txtTotalQuantity.Text)
        objCommand.Parameters.AddWithValue("@availableQuantity", txtTotalQuantity.Text)

        'Call AddDetails procedure to add the details of book and author
        dataAccess.AddDetails(objCommand)
        Dim objStringBuilder As New System.Text.StringBuilder

        'Check for errors
        If dataAccess.strExceptionAddDetails <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionAddDetails, "Add New Book & Author | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionAddDetails = Nothing
        Else
            'Show succeed message
            objStringBuilder.AppendLine("The following new information has been successfully added.")
            objStringBuilder.AppendLine(String.Empty)
            objStringBuilder.AppendLine("Book-Info: " & txtTitle.Text & " | " & txtIsbn.Text)
            objStringBuilder.AppendLine("Publisher-Info: " & txtPublisher.Text)
            objStringBuilder.AppendLine("Author-Info: " & txtAuthor.Text)

            'Show message box
            MessageBox.Show(objStringBuilder.ToString, "Add New Book & Author | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

            'Call procedure to get all the category
            GetBookCategory()

            'Refresh DataGridView
            GetBookTitleAndIsbn()

            'Call procedure to clear fields
            ClearFields()
        End If
    End Sub

    'METHOD: TO GET HIGHEST BOOK ID
    Private Sub GetBookId()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Max(BookId) " & _
            "FROM Book "

        'Call GetAvailabeID procedure to get id
        intBookId = dataAccess.GetAvailabeID(objCommand)

        If dataAccess.strExceptionGetAvailableID <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetAvailableID, "Getting Book-Id | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetAvailableID = Nothing
        Else
            'Increase the BookId by 1
            intBookId += 1
        End If
    End Sub

    'FORM LOAD EVENT
    Private Sub BookAddNew_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Call procedure to get all the category
        GetBookCategory()

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub


    'MEHOTD: CLEAR FIELDS
    Private Sub ClearFields()
        txtIsbn.Clear()
        txtTitle.Clear()
        txtPublisher.Clear()
        txtAuthor.Clear()
        dtpPublishDate.Value = Now
        cboCategory.Text = ""
        txtTotalQuantity.Clear()
        txtIsbn.Focus()
    End Sub

    'METHOD: GET BOOK CATEGORY
    Private Sub GetBookCategory()
        objCommand = New SqlCommand
        objCommand.CommandText = "SELECT Distinct Category FROM BOOK; "

        'Call GetListorComboBox method to get list of name and id
        dataAccess.GetListForComboBox(objCommand)

        'Check for errors
        If dataAccess.strExceptionGetListForComboBox <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionGetListForComboBox, "Retrieving Book Category | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionGetListForComboBox = Nothing
        Else
            dtBookCategory = dataAccess.dtListForComboBox
            cboCategory.DataSource = dtBookCategory
            cboCategory.DisplayMember = "Category"

        End If
    End Sub




    'LISTVIEW EVENTS AND METHODS SECTIONS

    'METHOD: GET BOOK TITLE AND ISBN 
    Private Sub GetBookTitleAndIsbn()
        'Call method to get list of name and id
        dataAccess.RunQueryAndFillDataSet("SELECT BookId, Title, Isbn " & _
            "FROM Book " & _
            "ORDER BY Title;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Retrieving Book Details | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Clear the previous data source
            grdBook.DataSource = Nothing

            'Get the table data
            dtBookList = dataAccess.AutoNumberedTable(dataAccess.objDataSet.Tables(0))

            'Fill the data source  of the datagridview
            grdBook.DataSource = dtBookList

            'Change the header text of first column
            grdBook.Columns(0).HeaderText = "S.n."
            grdBook.Columns(0).Width = 35

            'Hide the second column
            grdBook.Columns(1).Visible = False

            grdBook.Columns(0).Frozen = True
        End If
    End Sub

    Private Sub btnViewStudents_Click(sender As Object, e As EventArgs) Handles btnViewBooks.Click
        'Get book list with few details
        GetBookTitleAndIsbn()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Call procedure to clear fields
        ClearFields()
    End Sub

    Private Sub txtIsbn_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtIsbn.Validating
        If txtIsbn.Text.Trim.Length >= 10 Then
            'Call method to get list of name and id
            dataAccess.RunQueryAndFillDataSet("SELECT BookId,Isbn FROM Book " & _
                          "WHERE Isbn= '" & txtIsbn.Text & "';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Book Details", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
                strExceptionIsbn = "This Book Isbn already exists."
                ErrorProvider1.SetError(txtIsbn, strExceptionIsbn)
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
                strExceptionIsbn = ""
                ErrorProvider1.SetError(txtIsbn, strExceptionIsbn)
            End If
        Else
            strExceptionIsbn = "Please enter 10 digits or 13 digits Isbn number. For more information, press F1."
            ErrorProvider1.SetError(txtIsbn, strExceptionIsbn)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub txtTitle_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtTitle.Validating
        If txtTitle.Text.Trim.Length = 0 Then
            strExceptionTitle = "Please enter book title.  For more information, press F1."
            ErrorProvider1.SetError(txtTitle, strExceptionTitle)
        Else
            strExceptionTitle = ""
            ErrorProvider1.SetError(txtTitle, strExceptionTitle)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub EnabledSaveButton()
        If strExceptionIsbn = "" And strExceptionTitle = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub
End Class
