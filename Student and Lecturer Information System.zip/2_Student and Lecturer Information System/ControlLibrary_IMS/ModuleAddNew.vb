﻿Imports System.Data.SqlClient
Imports ClassLibrary_IMS

Public Class ModuleAddNew
    'New instances
    Private dataAccess As New DataAccess
    Dim objCommand As SqlCommand
    Dim dtModuleList As New DataTable
    Dim strExceptionModuleCode As String = "errModuleCode"
    Dim strExceptionModuleName As String = "errModuleName"

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim objStringBuilder As New System.Text.StringBuilder

        objStringBuilder.AppendLine("Do you want to add the following module information?")
        objStringBuilder.AppendLine(String.Empty)
        objStringBuilder.AppendLine("Module-Code: " & txtModuleCode.Text)
        objStringBuilder.AppendLine("Module-Name: " & txtModuleName.Text)

        Dim intYear As Integer
        'Get year value for YEAR combobox
        Select Case cboYear.SelectedIndex
            Case 0
                intYear = 0
            Case 1
                intYear = 1
            Case 2
                intYear = 2
            Case 3
                intYear = 3
        End Select

        'Show message box
        If MessageBox.Show(objStringBuilder.ToString, "Add New Module | Process-Succeed", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = DialogResult.Yes Then

            objCommand = New SqlCommand
            objCommand.CommandText = "INSERT INTO Module " & _
                "VALUES(@moduleCode,@moduleName,@creditHours,@year,@faculty);"

            'Add parameters for the placeholders in the SQL CommandText property..

            'Module Details
            objCommand.Parameters.AddWithValue("@moduleCode", txtModuleCode.Text)
            objCommand.Parameters.AddWithValue("@moduleName", txtModuleName.Text)
            objCommand.Parameters.AddWithValue("@creditHours", txtCreditHours.Text)
            objCommand.Parameters.AddWithValue("@year", intYear)
            objCommand.Parameters.AddWithValue("@faculty", cboFaculty.Text)

            'Call AddDetails procedure to add Module Details
            dataAccess.AddDetails(objCommand)

            'Check for errors
            If dataAccess.strExceptionAddDetails <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionAddDetails, "Add New Module | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set variable to nothing
                dataAccess.strExceptionAddDetails = Nothing
            Else
                Dim objStringBuilder1 As New System.Text.StringBuilder

                objStringBuilder1.AppendLine("The following new information has been successfully added.")
                objStringBuilder1.AppendLine(String.Empty)
                objStringBuilder1.AppendLine("Module-Info: " & txtModuleCode.Text & " | " & txtModuleName.Text)

                'Show message box
                MessageBox.Show(objStringBuilder1.ToString, "Add New Module | Process-Succeed", MessageBoxButtons.OK, MessageBoxIcon.Information)

                'Call ClearMainFields procedure to clear textboxes
                ClearMainFields()

                'Select first item in the Year combobox
                'cboYear.SelectedIndex = 0

                'Focus on Module Code textbox
                txtModuleCode.Focus()

                If grdModule.RowCount > 0 Then
                    'Call method to get list of module code and name
                    GetModuleCodeAndName()
                End If
            End If
        End If

    End Sub

    'METHOD:CLEARS TEXTBOXES
    Private Sub ClearMainFields()
        'Clear the textboxes
        txtModuleCode.Clear()
        txtModuleName.Clear()
        txtCreditHours.Clear()
    End Sub

    'METHOD: GET MODULE CODE AND NAME
    Private Sub GetModuleCodeAndName()
        'Clear existing records from the dataset
        If dataAccess.objDataSet IsNot Nothing Then
            dataAccess.objDataSet.Clear()
        End If

        'Call method to get list of name and code
        dataAccess.RunQueryAndFillDataSet("SELECT  Name,ModuleCode,Faculty + ' ' + CAST(Year as varchar) As Faculty " & _
            "FROM Module " & _
            "ORDER BY Year, Faculty, Name;")

        'Check for errors
        If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
            'Show error message
            MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Retrieving Module code and name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Set the variable to nothing
            dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
        Else
            'Get the table data
            dtModuleList = dataAccess.AutoNumberedTable(dataAccess.objDataSet.Tables(0))

            'Fill the datagridview
            grdModule.DataSource = dtModuleList

            'Change the headertext of firstcolumn
            grdModule.Columns(0).HeaderText = "S.n."
            grdModule.Columns(0).Width = 30


            grdModule.Columns(0).Frozen = True
        End If
    End Sub

    'FORM LOAD EVENT
    Private Sub ModuleAddNew_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub


    'SELECTEDINDEXCHANGED EVENT FOR YEAR COMBOBOX
    Private Sub cboYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboYear.SelectedIndexChanged
        If cboYear.SelectedIndex = 0 Then
            'Insert and Select FCHE as facutly and disable the Faculty combobox
            If Not cboFaculty.Items.Contains("FCHE") Then
                cboFaculty.Items.Add("FCHE")
            End If
            cboFaculty.SelectedIndex = cboFaculty.Items.Count - 1
            cboFaculty.Enabled = False
        Else
            'Enable the Faculty combobox, remove FCHE and select 1st item in the combobox
            cboFaculty.Enabled = True
            cboFaculty.Items.Remove("FCHE")
        End If
    End Sub

    'CLICK EVENT OF CLEAR BUTTON
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Call ClearMainFields procedure to clear textboxes
        ClearMainFields()

        'Select first item in the Year combobox
        cboYear.SelectedIndex = 0

        'Focus on Module Code textbox
        txtModuleCode.Focus()
    End Sub

    'CLICK EVENT OF VIEW MODULES BUTTON
    Private Sub btnViewModules_Click(sender As Object, e As EventArgs) Handles btnViewModules.Click
        'Call method to get list of module code and name
        GetModuleCodeAndName()
    End Sub

    Private Sub txtModuleCode_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtModuleCode.Validating
        'Check if the modulde code is provided or not
        If Not txtModuleCode.Text.Trim.Length = 0 Then
            'Clear existing records from the dataset
            If dataAccess.objDataSet IsNot Nothing Then
                dataAccess.objDataSet.Clear()
            End If

            'Call method to get list of name and code
            dataAccess.RunQueryAndFillDataSet("SELECT * " & _
                "FROM Module " & _
                "WHERE ModuleCode='" & txtModuleCode.Text & "';")

            'Check for errors
            If dataAccess.strExceptionRunQueryAndFillDataSet <> "" Then
                'Show error message
                MessageBox.Show(dataAccess.strExceptionRunQueryAndFillDataSet, "Retrieving Module code and name | Process-Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)

                'Set the variable to nothing
                dataAccess.strExceptionRunQueryAndFillDataSet = Nothing
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 1 Then
                strExceptionModuleCode = "This module already exists."
                ErrorProvider1.SetError(txtModuleCode, strExceptionModuleCode)
            ElseIf dataAccess.objDataSet.Tables(0).Rows.Count = 0 Then
                strExceptionModuleCode = ""
                ErrorProvider1.SetError(txtModuleCode, strExceptionModuleCode)
            End If
        Else
            strExceptionModuleCode = "Please enter module code"
            ErrorProvider1.SetError(txtModuleCode, strExceptionModuleCode)
        End If


        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub

    Private Sub EnabledSaveButton()
        If strExceptionModuleCode = "" And strExceptionModuleName = "" Then
            'Enable the save button
            btnSave.Enabled = True
        Else
            'Disable the save button
            btnSave.Enabled = False
        End If
    End Sub

    Private Sub txtModuleName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtModuleName.Validating
        If txtModuleName.Text.Trim.Length = 0 Then
            strExceptionModuleName = "Please enter module name."
            ErrorProvider1.SetError(txtModuleName, strExceptionModuleName)
        Else
            strExceptionModuleName = ""
            ErrorProvider1.SetError(txtModuleName, strExceptionModuleName)
        End If

        'Check whether to enable save button or not
        EnabledSaveButton()
    End Sub
End Class
