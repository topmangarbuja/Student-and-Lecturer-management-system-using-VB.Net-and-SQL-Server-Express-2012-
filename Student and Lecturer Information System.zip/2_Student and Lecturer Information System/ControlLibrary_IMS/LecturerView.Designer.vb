﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LecturerView
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdbBoth = New System.Windows.Forms.RadioButton()
        Me.rdbInactive = New System.Windows.Forms.RadioButton()
        Me.rdbActive = New System.Windows.Forms.RadioButton()
        Me.btnViewAll = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.cboEditCountry = New System.Windows.Forms.ComboBox()
        Me.txtEditPassportNo = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtCitizenshipNo = New ControlLibrary_IMS.TextBoxNumericPunctuation()
        Me.txtPlace = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtWardNo = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtDistrict = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.txtLecturerId = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cboGender = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.grdLecturer = New System.Windows.Forms.DataGridView()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox4.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.grdLecturer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TableLayoutPanel3)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(296, 105)
        Me.GroupBox4.TabIndex = 60
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Select and view"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel3.Controls.Add(Me.Panel1, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.btnViewAll, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label17, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel3.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 2
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(290, 77)
        Me.TableLayoutPanel3.TabIndex = 45
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Panel1.Controls.Add(Me.rdbBoth)
        Me.Panel1.Controls.Add(Me.rdbInactive)
        Me.Panel1.Controls.Add(Me.rdbActive)
        Me.Panel1.Location = New System.Drawing.Point(59, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(228, 29)
        Me.Panel1.TabIndex = 57
        '
        'rdbBoth
        '
        Me.rdbBoth.AutoSize = True
        Me.rdbBoth.Location = New System.Drawing.Point(167, 3)
        Me.rdbBoth.Name = "rdbBoth"
        Me.rdbBoth.Size = New System.Drawing.Size(56, 21)
        Me.rdbBoth.TabIndex = 2
        Me.rdbBoth.Text = "Both"
        Me.ToolTip1.SetToolTip(Me.rdbBoth, "Both")
        Me.rdbBoth.UseVisualStyleBackColor = True
        '
        'rdbInactive
        '
        Me.rdbInactive.AutoSize = True
        Me.rdbInactive.Location = New System.Drawing.Point(77, 3)
        Me.rdbInactive.Name = "rdbInactive"
        Me.rdbInactive.Size = New System.Drawing.Size(77, 21)
        Me.rdbInactive.TabIndex = 1
        Me.rdbInactive.Text = "Inactive"
        Me.ToolTip1.SetToolTip(Me.rdbInactive, "Inactive")
        Me.rdbInactive.UseVisualStyleBackColor = True
        '
        'rdbActive
        '
        Me.rdbActive.AutoSize = True
        Me.rdbActive.Checked = True
        Me.rdbActive.Location = New System.Drawing.Point(3, 3)
        Me.rdbActive.Name = "rdbActive"
        Me.rdbActive.Size = New System.Drawing.Size(66, 21)
        Me.rdbActive.TabIndex = 0
        Me.rdbActive.TabStop = True
        Me.rdbActive.Text = "Active"
        Me.ToolTip1.SetToolTip(Me.rdbActive, "Active")
        Me.rdbActive.UseVisualStyleBackColor = True
        '
        'btnViewAll
        '
        Me.btnViewAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAll.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAll.Location = New System.Drawing.Point(60, 45)
        Me.btnViewAll.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAll.Name = "btnViewAll"
        Me.btnViewAll.Size = New System.Drawing.Size(126, 28)
        Me.btnViewAll.TabIndex = 53
        Me.btnViewAll.TabStop = False
        Me.btnViewAll.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAll, "View all of students based on the selection of this section.")
        Me.btnViewAll.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(5, 12)
        Me.Label17.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(46, 17)
        Me.Label17.TabIndex = 55
        Me.Label17.Text = "Status"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TableLayoutPanel2)
        Me.GroupBox3.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(592, 140)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(494, 458)
        Me.GroupBox3.TabIndex = 59
        Me.GroupBox3.TabStop = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 4
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.cboEditCountry, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.txtEditPassportNo, 1, 10)
        Me.TableLayoutPanel2.Controls.Add(Me.txtCitizenshipNo, 1, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.txtPlace, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.txtWardNo, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.txtDistrict, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.txtLastName, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtFirstName, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtLecturerId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnDelete, 3, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.btnUpdate, 3, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.cboGender, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpDateOfBirth, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label15, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label14, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.Label11, 0, 10)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 11)
        Me.TableLayoutPanel2.Controls.Add(Me.cboStatus, 1, 11)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 12
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(486, 435)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'cboEditCountry
        '
        Me.cboEditCountry.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditCountry.FormattingEnabled = True
        Me.cboEditCountry.Location = New System.Drawing.Point(114, 301)
        Me.cboEditCountry.Name = "cboEditCountry"
        Me.cboEditCountry.Size = New System.Drawing.Size(237, 25)
        Me.cboEditCountry.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.cboEditCountry, "Book category")
        '
        'txtEditPassportNo
        '
        Me.txtEditPassportNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditPassportNo.Location = New System.Drawing.Point(114, 370)
        Me.txtEditPassportNo.MaxLength = 9
        Me.txtEditPassportNo.Name = "txtEditPassportNo"
        Me.txtEditPassportNo.Size = New System.Drawing.Size(235, 25)
        Me.txtEditPassportNo.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.txtEditPassportNo, "Citizenship no")
        '
        'txtCitizenshipNo
        '
        Me.txtCitizenshipNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtCitizenshipNo.Location = New System.Drawing.Point(114, 336)
        Me.txtCitizenshipNo.MaxLength = 15
        Me.txtCitizenshipNo.Name = "txtCitizenshipNo"
        Me.txtCitizenshipNo.Size = New System.Drawing.Size(237, 25)
        Me.txtCitizenshipNo.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.txtCitizenshipNo, "Citizenship no")
        '
        'txtPlace
        '
        Me.txtPlace.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPlace.Location = New System.Drawing.Point(114, 265)
        Me.txtPlace.MaxLength = 20
        Me.txtPlace.Name = "txtPlace"
        Me.txtPlace.Size = New System.Drawing.Size(237, 25)
        Me.txtPlace.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtPlace, "Place")
        '
        'txtWardNo
        '
        Me.txtWardNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtWardNo.Location = New System.Drawing.Point(114, 233)
        Me.txtWardNo.MaxLength = 3
        Me.txtWardNo.Name = "txtWardNo"
        Me.txtWardNo.Size = New System.Drawing.Size(237, 25)
        Me.txtWardNo.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.txtWardNo, "Ward no")
        '
        'txtDistrict
        '
        Me.txtDistrict.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtDistrict.Location = New System.Drawing.Point(114, 200)
        Me.txtDistrict.MaxLength = 20
        Me.txtDistrict.Name = "txtDistrict"
        Me.txtDistrict.Size = New System.Drawing.Size(237, 25)
        Me.txtDistrict.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtDistrict, "District")
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLastName.Location = New System.Drawing.Point(114, 85)
        Me.txtLastName.MaxLength = 35
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(237, 25)
        Me.txtLastName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtLastName, "Last Name")
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtFirstName.Location = New System.Drawing.Point(114, 46)
        Me.txtFirstName.MaxLength = 70
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(237, 25)
        Me.txtFirstName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtFirstName, "First Name")
        '
        'txtLecturerId
        '
        Me.txtLecturerId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLecturerId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtLecturerId.Location = New System.Drawing.Point(114, 7)
        Me.txtLecturerId.MaxLength = 12
        Me.txtLecturerId.Name = "txtLecturerId"
        Me.txtLecturerId.Size = New System.Drawing.Size(237, 25)
        Me.txtLecturerId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtLecturerId, "Lecturer Id")
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(358, 43)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(120, 28)
        Me.btnDelete.TabIndex = 13
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(358, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(120, 28)
        Me.btnUpdate.TabIndex = 12
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cboGender
        '
        Me.cboGender.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.cboGender.Location = New System.Drawing.Point(114, 165)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(237, 25)
        Me.cboGender.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboGender, "Gender")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Lecturer Id:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 128)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 17)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Date of birth:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 50)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "First Name:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 89)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 17)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Last Name:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 167)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 17)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Gender:"
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(114, 124)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(237, 25)
        Me.dtpDateOfBirth.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dtpDateOfBirth, "Date of birth")
        Me.dtpDateOfBirth.Value = New Date(2015, 9, 9, 11, 36, 0, 0)
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(4, 204)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(59, 17)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "District:"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 237)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(68, 17)
        Me.Label14.TabIndex = 4
        Me.Label14.Text = "Ward no.:"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 269)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(46, 17)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Place:"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(4, 303)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 17)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Country:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 340)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(103, 17)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Citizenship no.:"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(4, 374)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 17)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Passport no.:"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(4, 408)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(50, 17)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Status:"
        '
        'cboStatus
        '
        Me.cboStatus.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Items.AddRange(New Object() {"Active", "Inactive"})
        Me.cboStatus.Location = New System.Drawing.Point(114, 406)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(237, 25)
        Me.cboStatus.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.cboStatus, "Status")
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(184, 122)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(120, 17)
        Me.Label10.TabIndex = 57
        Me.Label10.Text = "List of lecturers:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.grdLecturer)
        Me.GroupBox2.Controls.Add(Me.btnGetReport)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 138)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(0)
        Me.GroupBox2.Size = New System.Drawing.Size(572, 460)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        '
        'grdLecturer
        '
        Me.grdLecturer.AllowUserToAddRows = False
        Me.grdLecturer.AllowUserToDeleteRows = False
        Me.grdLecturer.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdLecturer.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdLecturer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdLecturer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdLecturer.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdLecturer.Location = New System.Drawing.Point(0, 18)
        Me.grdLecturer.MultiSelect = False
        Me.grdLecturer.Name = "grdLecturer"
        Me.grdLecturer.ReadOnly = True
        Me.grdLecturer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdLecturer.Size = New System.Drawing.Size(572, 395)
        Me.grdLecturer.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdLecturer, "Select a record and get the data in the Details section.")
        '
        'btnGetReport
        '
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(203, 419)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 62
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(312, 122)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 61
        Me.lblResult.Text = "0"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(769, 122)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 17)
        Me.Label18.TabIndex = 71
        Me.Label18.Text = "Details:"
        '
        'LecturerView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "LecturerView"
        Me.Size = New System.Drawing.Size(1100, 614)
        Me.GroupBox4.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.grdLecturer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents rdbBoth As System.Windows.Forms.RadioButton
    Friend WithEvents rdbInactive As System.Windows.Forms.RadioButton
    Friend WithEvents rdbActive As System.Windows.Forms.RadioButton
    Friend WithEvents btnViewAll As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents grdLecturer As System.Windows.Forms.DataGridView
    Friend WithEvents txtLecturerId As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents txtFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtDistrict As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtWardNo As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtPlace As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtCitizenshipNo As ControlLibrary_IMS.TextBoxNumericPunctuation
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtEditPassportNo As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents cboEditCountry As System.Windows.Forms.ComboBox

End Class
