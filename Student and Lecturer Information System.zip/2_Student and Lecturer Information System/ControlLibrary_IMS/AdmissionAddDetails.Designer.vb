﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdmissionAddDetails
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grpAdmission = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.dtpAdmissionDate = New System.Windows.Forms.DateTimePicker()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboFaculty = New System.Windows.Forms.ComboBox()
        Me.cboId = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.grdAdmission = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.btnGrdSave = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnEnableEdit = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.grpAdmission.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.grdAdmission, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpAdmission
        '
        Me.grpAdmission.Controls.Add(Me.TableLayoutPanel2)
        Me.grpAdmission.Font = New System.Drawing.Font("Stencil", 9.25!)
        Me.grpAdmission.Location = New System.Drawing.Point(8, 9)
        Me.grpAdmission.Margin = New System.Windows.Forms.Padding(4)
        Me.grpAdmission.Name = "grpAdmission"
        Me.grpAdmission.Padding = New System.Windows.Forms.Padding(4)
        Me.grpAdmission.Size = New System.Drawing.Size(440, 226)
        Me.grpAdmission.TabIndex = 3
        Me.grpAdmission.TabStop = False
        Me.grpAdmission.Text = "Admission"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666!))
        Me.TableLayoutPanel2.Controls.Add(Me.txtName, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.cboYear, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpAdmissionDate, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.cboFaculty, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.cboId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 5
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(432, 203)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'txtName
        '
        Me.txtName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.HelpProvider1.SetHelpString(Me.txtName, "Here, you get the corresponding name of the selected student id.")
        Me.txtName.Location = New System.Drawing.Point(148, 46)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtName.Name = "txtName"
        Me.txtName.ReadOnly = True
        Me.HelpProvider1.SetShowHelp(Me.txtName, True)
        Me.txtName.Size = New System.Drawing.Size(261, 25)
        Me.txtName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtName, "Name")
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 128)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 17)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Year:"
        '
        'cboYear
        '
        Me.cboYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYear.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboYear, "Select a year for the student admission.")
        Me.cboYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboYear.Location = New System.Drawing.Point(147, 126)
        Me.cboYear.Name = "cboYear"
        Me.HelpProvider1.SetShowHelp(Me.cboYear, True)
        Me.cboYear.Size = New System.Drawing.Size(262, 25)
        Me.cboYear.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.cboYear, "Year")
        '
        'dtpAdmissionDate
        '
        Me.dtpAdmissionDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.HelpProvider1.SetHelpString(Me.dtpAdmissionDate, "Select admission date.")
        Me.dtpAdmissionDate.Location = New System.Drawing.Point(147, 85)
        Me.dtpAdmissionDate.Name = "dtpAdmissionDate"
        Me.HelpProvider1.SetShowHelp(Me.dtpAdmissionDate, True)
        Me.dtpAdmissionDate.Size = New System.Drawing.Size(262, 25)
        Me.dtpAdmissionDate.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.dtpAdmissionDate, "Admission date")
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 89)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(107, 17)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Admission date:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 50)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 17)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Name:"
        '
        'cboFaculty
        '
        Me.cboFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFaculty.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboFaculty, "Select a faculty for the student admission.")
        Me.cboFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboFaculty.Location = New System.Drawing.Point(147, 169)
        Me.cboFaculty.Name = "cboFaculty"
        Me.HelpProvider1.SetShowHelp(Me.cboFaculty, True)
        Me.cboFaculty.Size = New System.Drawing.Size(262, 25)
        Me.cboFaculty.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboFaculty, "Faculty")
        '
        'cboId
        '
        Me.cboId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboId.FormattingEnabled = True
        Me.HelpProvider1.SetHelpString(Me.cboId, "Select from the list or type 12 character student Id.")
        Me.cboId.Location = New System.Drawing.Point(147, 9)
        Me.cboId.Name = "cboId"
        Me.HelpProvider1.SetShowHelp(Me.cboId, True)
        Me.cboId.Size = New System.Drawing.Size(262, 25)
        Me.cboId.Sorted = True
        Me.cboId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.cboId, "Student Id")
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 171)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Faculty:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 17)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Student Id:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Panel3)
        Me.GroupBox2.Controls.Add(Me.Panel1)
        Me.GroupBox2.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(8, 291)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(516, 209)
        Me.GroupBox2.TabIndex = 20
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "View and Modify"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.grdAdmission)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Font = New System.Drawing.Font("Cambria", 10.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.Location = New System.Drawing.Point(4, 19)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(508, 136)
        Me.Panel3.TabIndex = 20
        '
        'grdAdmission
        '
        Me.grdAdmission.AllowUserToAddRows = False
        Me.grdAdmission.AllowUserToDeleteRows = False
        Me.grdAdmission.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdAdmission.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdAdmission.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdAdmission.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdAdmission.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdAdmission.Location = New System.Drawing.Point(0, 0)
        Me.grdAdmission.MultiSelect = False
        Me.grdAdmission.Name = "grdAdmission"
        Me.grdAdmission.ReadOnly = True
        Me.grdAdmission.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdAdmission.Size = New System.Drawing.Size(508, 136)
        Me.grdAdmission.TabIndex = 20
        Me.grdAdmission.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnGetReport)
        Me.Panel1.Controls.Add(Me.btnGrdSave)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.btnEnableEdit)
        Me.Panel1.Location = New System.Drawing.Point(0, 158)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(512, 43)
        Me.Panel1.TabIndex = 19
        '
        'btnGetReport
        '
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(374, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 53
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'btnGrdSave
        '
        Me.btnGrdSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGrdSave.Enabled = False
        Me.btnGrdSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGrdSave.Location = New System.Drawing.Point(127, 4)
        Me.btnGrdSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGrdSave.Name = "btnGrdSave"
        Me.btnGrdSave.Size = New System.Drawing.Size(120, 35)
        Me.btnGrdSave.TabIndex = 20
        Me.btnGrdSave.TabStop = False
        Me.btnGrdSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnGrdSave, "Save the changed data.")
        Me.btnGrdSave.UseVisualStyleBackColor = True
        '
        'btnRefresh
        '
        Me.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRefresh.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnRefresh.Location = New System.Drawing.Point(252, 4)
        Me.btnRefresh.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(120, 35)
        Me.btnRefresh.TabIndex = 19
        Me.btnRefresh.TabStop = False
        Me.btnRefresh.Text = "Refresh"
        Me.ToolTip1.SetToolTip(Me.btnRefresh, "Refresh the view list.")
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'btnEnableEdit
        '
        Me.btnEnableEdit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEnableEdit.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnEnableEdit.Location = New System.Drawing.Point(4, 4)
        Me.btnEnableEdit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEnableEdit.Name = "btnEnableEdit"
        Me.btnEnableEdit.Size = New System.Drawing.Size(120, 35)
        Me.btnEnableEdit.TabIndex = 17
        Me.btnEnableEdit.TabStop = False
        Me.btnEnableEdit.Text = "Enable Edit"
        Me.ToolTip1.SetToolTip(Me.btnEnableEdit, "Click to edit the above viewed data.")
        Me.btnEnableEdit.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnClear)
        Me.Panel2.Controls.Add(Me.btnSave)
        Me.Panel2.Location = New System.Drawing.Point(151, 240)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(270, 43)
        Me.Panel2.TabIndex = 21
        '
        'btnClear
        '
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnClear.Location = New System.Drawing.Point(141, 4)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 35)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Clear the above fields.")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnSave.Location = New System.Drawing.Point(5, 4)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btnSave, "Saved the entered data.")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'AdmissionAddDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.grpAdmission)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox2)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "AdmissionAddDetails"
        Me.Size = New System.Drawing.Size(534, 514)
        Me.grpAdmission.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.grdAdmission, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpAdmission As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dtpAdmissionDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents cboYear As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboId As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnEnableEdit As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents grdAdmission As System.Windows.Forms.DataGridView
    Friend WithEvents btnGrdSave As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents btnGetReport As System.Windows.Forms.Button

End Class
