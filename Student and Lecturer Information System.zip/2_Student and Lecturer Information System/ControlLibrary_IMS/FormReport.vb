﻿Imports Microsoft.Reporting.WinForms

Public Class FormReport
    Public strReport As String

    Private Sub FormReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim rptDataSource As ReportDataSource

        Try
            'ReportViewer1.Reset()
            'ReportViewer1.ProcessingMode = ProcessingMode.Local

            With Me.ReportViewer1.LocalReport
                .ReportPath = "Reports\" & strReport & ".rdlc"
                .DataSources.Clear()
            End With

            Select Case strReport
                Case "StudentSearch"
                    Dim ds As New DataSetStudentSearch

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)
                Case "StudentView"
                    Dim ds As New DataSetStudentView

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "LecturerSearch"
                    Dim ds As New DataSetLecturerSearch

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "LecturerView"
                    Dim ds As New DataSetLecturerView

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

             
                Case "ModuleSearch"
                    Dim ds As New DataSetModuleSearch

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "ModuleView"
                    Dim ds As New DataSetModuleView

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "GuardianSearchView"
                    Dim ds As New DataSetGuardianSearchView

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "BookSearch"
                    Dim ds As New DataSetBookSearch
                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "BookView"
                    Dim ds As New DataSetBookView
                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "IssueSearch"
                    Dim ds As New DataSetIssueSearch

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "IssueView"
                    Dim ds As New DataSetIssueView

                    ' Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "StudentModule"
                    Dim ds As New DataSetStudentModule

                    'Use the same name as defined in the report Data Source Definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "LecturerModule"
                    Dim ds As New DataSetLecturerModule

                    'Use the same name as defined in the rerpot Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)


                Case "AdmissionAdd"
                    Dim ds As New DataSetAdmissionAdd

                    'Use the same name as defined in the report Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "AdmissionView"
                    Dim ds As New DataSetAdmissionView

                    'Use the same name as defined in the report Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)


                Case "StudentAdditionalViewPhone"
                    Dim ds As New DataSetStudentAdditionalView

                    'Use the same name as defined in the report Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "StudentAdditionalViewEmail"
                    Dim ds As New DataSetStudentAdditionalView

                    'Use the same name as defined in the report Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "LecturerAdditionalViewPhone"
                    Dim ds As New DataSetLecturerAdditionalView

                    'Use the same name as defined in the report Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)

                Case "LecturerAdditionalViewEmail"
                    Dim ds As New DataSetLecturerAdditionalView

                    'Use the same name as defined in the report Data Source definition
                    rptDataSource = New ReportDataSource("DataSet1", ds.dt)
            End Select
            With Me.ReportViewer1
                .LocalReport.DataSources.Add(rptDataSource)
                .SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)

                If strReport = "ModuleSearch" Or strReport = "ModuleView" Or strReport = "GuardianSearchView" _
                    Or strReport = "AdmissionAdd" Or strReport = "AdmissionView" _
                    Or strReport = "StudentAdditionalViewPhone" Or strReport = "StudentAdditionalViewEmail" _
                    Or strReport = "LecturerAdditionalViewPhone" Or strReport = "LecturerAdditionalViewEmail" Then
                    .ZoomMode = ZoomMode.Percent
                    .ZoomPercent = 100%
                End If
            End With


            
        Catch ex As Exception
            MessageBox.Show(ex.Message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Me.ReportViewer1.RefreshReport()
    End Sub
End Class