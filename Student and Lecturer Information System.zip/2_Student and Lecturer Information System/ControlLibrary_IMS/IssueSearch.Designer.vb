﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IssueSearch
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtAuthor = New ControlLibrary_IMS.TextBoxAuthorName()
        Me.txtIsbnNo = New ControlLibrary_IMS.TextBoxNumericAndHyphon()
        Me.txtId = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.txtLastName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtFirstName = New ControlLibrary_IMS.TextBoxCharacters()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdbLecturer = New System.Windows.Forms.RadioButton()
        Me.rdbStudent = New System.Windows.Forms.RadioButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpIssueDate = New System.Windows.Forms.DateTimePicker()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.grpResult = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.btnShowEditSection = New System.Windows.Forms.Button()
        Me.btnViewAllIssueBook = New System.Windows.Forms.Button()
        Me.grdBookIssue = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtViewIsbn = New ControlLibrary_IMS.TextBoxNumericAndHyphon()
        Me.dtpViewIssueTime = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtViewName = New System.Windows.Forms.TextBox()
        Me.txtViewId = New System.Windows.Forms.TextBox()
        Me.dtpViewReturnTime = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.dtpViewReturnDate = New System.Windows.Forms.DateTimePicker()
        Me.dtpViewIssueDate = New System.Windows.Forms.DateTimePicker()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtViewAuthor = New System.Windows.Forms.TextBox()
        Me.txtViewTitle = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cboViewRemarks = New System.Windows.Forms.ComboBox()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pnlListOfStudent = New System.Windows.Forms.Panel()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.grpResult.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.grdBookIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpEdit.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.pnlListOfStudent.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Location = New System.Drawing.Point(219, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(658, 179)
        Me.GroupBox1.TabIndex = 49
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select and search:"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.txtAuthor, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtIsbnNo, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtId, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txtTitle, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtLastName, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtFirstName, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.dtpIssueDate, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 2, 3)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(652, 155)
        Me.TableLayoutPanel1.TabIndex = 45
        '
        'txtAuthor
        '
        Me.txtAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtAuthor.Location = New System.Drawing.Point(93, 123)
        Me.txtAuthor.MaxLength = 350
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(227, 25)
        Me.txtAuthor.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtAuthor, "Author")
        '
        'txtIsbnNo
        '
        Me.txtIsbnNo.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtIsbnNo.Location = New System.Drawing.Point(93, 85)
        Me.txtIsbnNo.MaxLength = 17
        Me.txtIsbnNo.Name = "txtIsbnNo"
        Me.txtIsbnNo.Size = New System.Drawing.Size(227, 25)
        Me.txtIsbnNo.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtIsbnNo, "Isbn no")
        '
        'txtId
        '
        Me.txtId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtId.Location = New System.Drawing.Point(413, 7)
        Me.txtId.MaxLength = 12
        Me.txtId.Name = "txtId"
        Me.txtId.Size = New System.Drawing.Size(227, 25)
        Me.txtId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtId, "Id")
        '
        'txtTitle
        '
        Me.txtTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtTitle.Location = New System.Drawing.Point(413, 85)
        Me.txtTitle.MaxLength = 255
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(227, 25)
        Me.txtTitle.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtTitle, "Book title")
        '
        'txtLastName
        '
        Me.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtLastName.Location = New System.Drawing.Point(413, 46)
        Me.txtLastName.MaxLength = 35
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(227, 25)
        Me.txtLastName.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtLastName, "Last Name")
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(328, 11)
        Me.Label17.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(25, 17)
        Me.Label17.TabIndex = 68
        Me.Label17.Text = "Id:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 127)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 17)
        Me.Label5.TabIndex = 57
        Me.Label5.Text = "Author:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtFirstName.Location = New System.Drawing.Point(93, 46)
        Me.txtFirstName.MaxLength = 70
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(227, 25)
        Me.txtFirstName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtFirstName, "First Name")
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(328, 89)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(41, 17)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "Title:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 17)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Select:"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(4, 89)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(58, 17)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Isbn no:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rdbLecturer)
        Me.Panel1.Controls.Add(Me.rdbStudent)
        Me.Panel1.Location = New System.Drawing.Point(93, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(198, 32)
        Me.Panel1.TabIndex = 46
        '
        'rdbLecturer
        '
        Me.rdbLecturer.AutoSize = True
        Me.rdbLecturer.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbLecturer.Location = New System.Drawing.Point(83, 6)
        Me.rdbLecturer.Name = "rdbLecturer"
        Me.rdbLecturer.Size = New System.Drawing.Size(80, 21)
        Me.rdbLecturer.TabIndex = 23
        Me.rdbLecturer.Text = "Lecturer"
        Me.ToolTip1.SetToolTip(Me.rdbLecturer, "Lecturer")
        Me.rdbLecturer.UseVisualStyleBackColor = True
        '
        'rdbStudent
        '
        Me.rdbStudent.AutoSize = True
        Me.rdbStudent.Checked = True
        Me.rdbStudent.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.rdbStudent.Location = New System.Drawing.Point(3, 6)
        Me.rdbStudent.Name = "rdbStudent"
        Me.rdbStudent.Size = New System.Drawing.Size(74, 21)
        Me.rdbStudent.TabIndex = 22
        Me.rdbStudent.TabStop = True
        Me.rdbStudent.Text = "Student"
        Me.ToolTip1.SetToolTip(Me.rdbStudent, "Student")
        Me.rdbStudent.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(5, 50)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "First Name:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(328, 50)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 17)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Last Name:"
        '
        'dtpIssueDate
        '
        Me.dtpIssueDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpIssueDate.Location = New System.Drawing.Point(413, 123)
        Me.dtpIssueDate.Name = "dtpIssueDate"
        Me.dtpIssueDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.dtpIssueDate.Size = New System.Drawing.Size(227, 25)
        Me.dtpIssueDate.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.dtpIssueDate, "Issue date")
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(327, 127)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(74, 17)
        Me.Label21.TabIndex = 50
        Me.Label21.Text = "Issue date:"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 10)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(25, 17)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Id:"
        '
        'grpResult
        '
        Me.grpResult.BackColor = System.Drawing.Color.Transparent
        Me.grpResult.Controls.Add(Me.Panel2)
        Me.grpResult.Controls.Add(Me.grdBookIssue)
        Me.grpResult.Location = New System.Drawing.Point(11, 207)
        Me.grpResult.Name = "grpResult"
        Me.grpResult.Padding = New System.Windows.Forms.Padding(0)
        Me.grpResult.Size = New System.Drawing.Size(1154, 418)
        Me.grpResult.TabIndex = 0
        Me.grpResult.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnGetReport)
        Me.Panel2.Controls.Add(Me.btnShowEditSection)
        Me.Panel2.Controls.Add(Me.btnViewAllIssueBook)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 375)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1154, 43)
        Me.Panel2.TabIndex = 22
        '
        'btnGetReport
        '
        Me.btnGetReport.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(682, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 70
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'btnShowEditSection
        '
        Me.btnShowEditSection.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnShowEditSection.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShowEditSection.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnShowEditSection.Location = New System.Drawing.Point(542, 4)
        Me.btnShowEditSection.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShowEditSection.Name = "btnShowEditSection"
        Me.btnShowEditSection.Size = New System.Drawing.Size(132, 35)
        Me.btnShowEditSection.TabIndex = 74
        Me.btnShowEditSection.TabStop = False
        Me.btnShowEditSection.Text = "Show Edit section"
        Me.ToolTip1.SetToolTip(Me.btnShowEditSection, "Refresh the view list.")
        Me.btnShowEditSection.UseVisualStyleBackColor = True
        '
        'btnViewAllIssueBook
        '
        Me.btnViewAllIssueBook.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnViewAllIssueBook.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllIssueBook.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllIssueBook.Location = New System.Drawing.Point(409, 4)
        Me.btnViewAllIssueBook.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllIssueBook.Name = "btnViewAllIssueBook"
        Me.btnViewAllIssueBook.Size = New System.Drawing.Size(125, 35)
        Me.btnViewAllIssueBook.TabIndex = 0
        Me.btnViewAllIssueBook.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllIssueBook, "View all of the issued details based on student or lecturer selection.")
        Me.btnViewAllIssueBook.UseVisualStyleBackColor = True
        '
        'grdBookIssue
        '
        Me.grdBookIssue.AllowUserToAddRows = False
        Me.grdBookIssue.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdBookIssue.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdBookIssue.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdBookIssue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdBookIssue.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdBookIssue.Location = New System.Drawing.Point(0, 18)
        Me.grdBookIssue.MultiSelect = False
        Me.grdBookIssue.Name = "grdBookIssue"
        Me.grdBookIssue.ReadOnly = True
        Me.grdBookIssue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdBookIssue.Size = New System.Drawing.Size(1154, 352)
        Me.grdBookIssue.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdBookIssue, "Click 'Show Enable section' button to view the Edit section and select a record a" & _
        "nd get the data in the Details section.")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 17)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "List of issued books:"
        '
        'grpEdit
        '
        Me.grpEdit.Controls.Add(Me.TableLayoutPanel2)
        Me.grpEdit.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpEdit.Location = New System.Drawing.Point(781, 209)
        Me.grpEdit.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Padding = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.grpEdit.Size = New System.Drawing.Size(384, 416)
        Me.grpEdit.TabIndex = 67
        Me.grpEdit.TabStop = False
        Me.grpEdit.Visible = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewIsbn, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewIssueTime, 1, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 9)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewName, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewId, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label14, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewReturnTime, 1, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label12, 0, 8)
        Me.TableLayoutPanel2.Controls.Add(Me.Label13, 0, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.Label26, 0, 6)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewReturnDate, 1, 7)
        Me.TableLayoutPanel2.Controls.Add(Me.dtpViewIssueDate, 1, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label15, 0, 5)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label7, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewAuthor, 1, 4)
        Me.TableLayoutPanel2.Controls.Add(Me.txtViewTitle, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 1, 10)
        Me.TableLayoutPanel2.Controls.Add(Me.cboViewRemarks, 1, 9)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(5, 21)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 11
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(374, 389)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'txtViewIsbn
        '
        Me.txtViewIsbn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewIsbn.Location = New System.Drawing.Point(99, 77)
        Me.txtViewIsbn.MaxLength = 17
        Me.txtViewIsbn.Name = "txtViewIsbn"
        Me.txtViewIsbn.ReadOnly = True
        Me.txtViewIsbn.Size = New System.Drawing.Size(262, 25)
        Me.txtViewIsbn.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtViewIsbn, "Isbn no")
        '
        'dtpViewIssueTime
        '
        Me.dtpViewIssueTime.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewIssueTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpViewIssueTime.Location = New System.Drawing.Point(100, 216)
        Me.dtpViewIssueTime.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewIssueTime.Name = "dtpViewIssueTime"
        Me.dtpViewIssueTime.ShowUpDown = True
        Me.dtpViewIssueTime.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewIssueTime.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.dtpViewIssueTime, "Issue time")
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 318)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 17)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "Remarks:"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(5, 47)
        Me.Label16.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(48, 17)
        Me.Label16.TabIndex = 68
        Me.Label16.Text = "Name:"
        '
        'txtViewName
        '
        Me.txtViewName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewName.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewName.Location = New System.Drawing.Point(101, 43)
        Me.txtViewName.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewName.Name = "txtViewName"
        Me.txtViewName.ReadOnly = True
        Me.txtViewName.Size = New System.Drawing.Size(260, 25)
        Me.txtViewName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtViewName, "Name")
        '
        'txtViewId
        '
        Me.txtViewId.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewId.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewId.Location = New System.Drawing.Point(101, 6)
        Me.txtViewId.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewId.Name = "txtViewId"
        Me.txtViewId.ReadOnly = True
        Me.txtViewId.Size = New System.Drawing.Size(260, 25)
        Me.txtViewId.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtViewId, "Id")
        '
        'dtpViewReturnTime
        '
        Me.dtpViewReturnTime.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewReturnTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpViewReturnTime.Location = New System.Drawing.Point(100, 282)
        Me.dtpViewReturnTime.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewReturnTime.Name = "dtpViewReturnTime"
        Me.dtpViewReturnTime.ShowUpDown = True
        Me.dtpViewReturnTime.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewReturnTime.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.dtpViewReturnTime, "Return time")
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(5, 286)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 17)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Return time:"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(5, 253)
        Me.Label13.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 17)
        Me.Label13.TabIndex = 69
        Me.Label13.Text = "Return date:"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(5, 220)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(75, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Issue time:"
        '
        'dtpViewReturnDate
        '
        Me.dtpViewReturnDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewReturnDate.Location = New System.Drawing.Point(100, 249)
        Me.dtpViewReturnDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewReturnDate.Name = "dtpViewReturnDate"
        Me.dtpViewReturnDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewReturnDate.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.dtpViewReturnDate, "Return date")
        '
        'dtpViewIssueDate
        '
        Me.dtpViewIssueDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dtpViewIssueDate.Location = New System.Drawing.Point(100, 183)
        Me.dtpViewIssueDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpViewIssueDate.Name = "dtpViewIssueDate"
        Me.dtpViewIssueDate.Size = New System.Drawing.Size(261, 25)
        Me.dtpViewIssueDate.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.dtpViewIssueDate, "Issue date")
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(5, 187)
        Me.Label15.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(74, 17)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Issue date:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 152)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "Author:"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(5, 115)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 17)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Title:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 81)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(43, 17)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "ISBN:"
        '
        'txtViewAuthor
        '
        Me.txtViewAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewAuthor.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewAuthor.Location = New System.Drawing.Point(101, 148)
        Me.txtViewAuthor.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewAuthor.Name = "txtViewAuthor"
        Me.txtViewAuthor.ReadOnly = True
        Me.txtViewAuthor.Size = New System.Drawing.Size(260, 25)
        Me.txtViewAuthor.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtViewAuthor, "Book author")
        '
        'txtViewTitle
        '
        Me.txtViewTitle.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtViewTitle.Font = New System.Drawing.Font("Cambria", 11.5!)
        Me.txtViewTitle.Location = New System.Drawing.Point(101, 111)
        Me.txtViewTitle.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.txtViewTitle.Name = "txtViewTitle"
        Me.txtViewTitle.ReadOnly = True
        Me.txtViewTitle.Size = New System.Drawing.Size(260, 25)
        Me.txtViewTitle.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtViewTitle, "Book title")
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnDelete)
        Me.Panel3.Controls.Add(Me.btnUpdate)
        Me.Panel3.Location = New System.Drawing.Point(99, 345)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(261, 38)
        Me.Panel3.TabIndex = 60
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(132, 3)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(2, 4)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cboViewRemarks
        '
        Me.cboViewRemarks.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboViewRemarks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboViewRemarks.FormattingEnabled = True
        Me.cboViewRemarks.Items.AddRange(New Object() {"Borrowed", "Returned", "Lost"})
        Me.cboViewRemarks.Location = New System.Drawing.Point(99, 314)
        Me.cboViewRemarks.Name = "cboViewRemarks"
        Me.cboViewRemarks.Size = New System.Drawing.Size(262, 25)
        Me.cboViewRemarks.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.cboViewRemarks, "Remarks")
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(951, 192)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(61, 17)
        Me.lblDetails.TabIndex = 66
        Me.lblDetails.Text = "Details:"
        Me.lblDetails.Visible = False
        '
        'pnlListOfStudent
        '
        Me.pnlListOfStudent.BackColor = System.Drawing.Color.Transparent
        Me.pnlListOfStudent.Controls.Add(Me.lblResult)
        Me.pnlListOfStudent.Controls.Add(Me.Label3)
        Me.pnlListOfStudent.Location = New System.Drawing.Point(539, 192)
        Me.pnlListOfStudent.Name = "pnlListOfStudent"
        Me.pnlListOfStudent.Size = New System.Drawing.Size(187, 20)
        Me.pnlListOfStudent.TabIndex = 68
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(157, 0)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 50
        Me.lblResult.Text = "0"
        '
        'IssueSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.pnlListOfStudent)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.grpResult)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "IssueSearch"
        Me.Size = New System.Drawing.Size(1178, 640)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.grpResult.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.grdBookIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpEdit.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.pnlListOfStudent.ResumeLayout(False)
        Me.pnlListOfStudent.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents rdbLecturer As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStudent As System.Windows.Forms.RadioButton
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents dtpIssueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents grpResult As System.Windows.Forms.GroupBox
    Friend WithEvents grdBookIssue As System.Windows.Forms.DataGridView
    Friend WithEvents btnViewAllIssueBook As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents grpEdit As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtViewTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtViewAuthor As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtViewId As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents dtpViewIssueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents dtpViewReturnTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dtpViewReturnDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtViewName As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cboViewRemarks As System.Windows.Forms.ComboBox
    Friend WithEvents dtpViewIssueTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtLastName As ControlLibrary_IMS.TextBoxCharacters
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtId As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnShowEditSection As System.Windows.Forms.Button
    Friend WithEvents pnlListOfStudent As System.Windows.Forms.Panel
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents txtIsbnNo As ControlLibrary_IMS.TextBoxNumericAndHyphon
    Friend WithEvents txtViewIsbn As ControlLibrary_IMS.TextBoxNumericAndHyphon
    Friend WithEvents txtAuthor As ControlLibrary_IMS.TextBoxAuthorName

End Class
