﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModuleSearch
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtModuleName = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.txtCreditHours = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtModuleCode = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.cboYear = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.cboFaculty = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.btnViewAllModules = New System.Windows.Forms.Button()
        Me.grpResult = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnShowEditSection = New System.Windows.Forms.Button()
        Me.btnGetReport = New System.Windows.Forms.Button()
        Me.grdModule = New System.Windows.Forms.DataGridView()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.cboEditFaculty = New System.Windows.Forms.ComboBox()
        Me.cboEditYear = New System.Windows.Forms.ComboBox()
        Me.txtEditCreditHours = New ControlLibrary_IMS.TextBoxNumeric()
        Me.txtEditModuleCode = New ControlLibrary_IMS.TextBoxNumericCharacters()
        Me.txtEditModuleName = New ControlLibrary_IMS.TextBoxCharacterPunctuation()
        Me.lblDetails = New System.Windows.Forms.Label()
        Me.grpEdit = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pnlListOfStudent = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.GroupBox5.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.grpResult.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grdModule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpEdit.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnlListOfStudent.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox5.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(13, 5)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(720, 141)
        Me.GroupBox5.TabIndex = 11
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Search by:"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 4
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel4.Controls.Add(Me.txtModuleName, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.txtCreditHours, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.txtModuleCode, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label22, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label25, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label24, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.cboYear, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label23, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.cboFaculty, 3, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label26, 2, 1)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(4, 22)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 3
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(712, 115)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'txtModuleName
        '
        Me.txtModuleName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtModuleName.Location = New System.Drawing.Point(107, 46)
        Me.txtModuleName.MaxLength = 70
        Me.txtModuleName.Name = "txtModuleName"
        Me.txtModuleName.Size = New System.Drawing.Size(261, 25)
        Me.txtModuleName.TabIndex = 63
        Me.ToolTip1.SetToolTip(Me.txtModuleName, "Module name")
        '
        'txtCreditHours
        '
        Me.txtCreditHours.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtCreditHours.Location = New System.Drawing.Point(107, 85)
        Me.txtCreditHours.MaxLength = 3
        Me.txtCreditHours.Name = "txtCreditHours"
        Me.txtCreditHours.Size = New System.Drawing.Size(261, 25)
        Me.txtCreditHours.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtCreditHours, "Credit hours")
        '
        'txtModuleCode
        '
        Me.txtModuleCode.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtModuleCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtModuleCode.Location = New System.Drawing.Point(107, 7)
        Me.txtModuleCode.MaxLength = 10
        Me.txtModuleCode.Name = "txtModuleCode"
        Me.txtModuleCode.Size = New System.Drawing.Size(261, 25)
        Me.txtModuleCode.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtModuleCode, "Module code")
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 11)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(92, 17)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Module code:"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(4, 89)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(89, 17)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Credit hours:"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(4, 50)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(96, 17)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Module name:"
        '
        'cboYear
        '
        Me.cboYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYear.FormattingEnabled = True
        Me.cboYear.Location = New System.Drawing.Point(440, 9)
        Me.cboYear.Name = "cboYear"
        Me.cboYear.Size = New System.Drawing.Size(261, 25)
        Me.cboYear.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.cboYear, "Year")
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(375, 11)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(36, 17)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Year"
        '
        'cboFaculty
        '
        Me.cboFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFaculty.FormattingEnabled = True
        Me.cboFaculty.Location = New System.Drawing.Point(440, 48)
        Me.cboFaculty.Name = "cboFaculty"
        Me.cboFaculty.Size = New System.Drawing.Size(261, 25)
        Me.cboFaculty.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboFaculty, "Faculty")
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(375, 50)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(58, 17)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Faculty:"
        '
        'btnViewAllModules
        '
        Me.btnViewAllModules.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnViewAllModules.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewAllModules.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnViewAllModules.Location = New System.Drawing.Point(250, 4)
        Me.btnViewAllModules.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAllModules.Name = "btnViewAllModules"
        Me.btnViewAllModules.Size = New System.Drawing.Size(134, 35)
        Me.btnViewAllModules.TabIndex = 0
        Me.btnViewAllModules.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnViewAllModules, "View all of modules available in the college.")
        Me.btnViewAllModules.UseVisualStyleBackColor = True
        '
        'grpResult
        '
        Me.grpResult.BackColor = System.Drawing.Color.Transparent
        Me.grpResult.Controls.Add(Me.Panel1)
        Me.grpResult.Controls.Add(Me.grdModule)
        Me.grpResult.Location = New System.Drawing.Point(13, 184)
        Me.grpResult.Name = "grpResult"
        Me.grpResult.Padding = New System.Windows.Forms.Padding(0)
        Me.grpResult.Size = New System.Drawing.Size(880, 330)
        Me.grpResult.TabIndex = 0
        Me.grpResult.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnShowEditSection)
        Me.Panel1.Controls.Add(Me.btnViewAllModules)
        Me.Panel1.Controls.Add(Me.btnGetReport)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 287)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(880, 43)
        Me.Panel1.TabIndex = 20
        '
        'btnShowEditSection
        '
        Me.btnShowEditSection.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnShowEditSection.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnShowEditSection.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnShowEditSection.Location = New System.Drawing.Point(392, 4)
        Me.btnShowEditSection.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShowEditSection.Name = "btnShowEditSection"
        Me.btnShowEditSection.Size = New System.Drawing.Size(132, 35)
        Me.btnShowEditSection.TabIndex = 53
        Me.btnShowEditSection.TabStop = False
        Me.btnShowEditSection.Text = "Show Edit section"
        Me.ToolTip1.SetToolTip(Me.btnShowEditSection, "Refresh the view list.")
        Me.btnShowEditSection.UseVisualStyleBackColor = True
        '
        'btnGetReport
        '
        Me.btnGetReport.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGetReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGetReport.Enabled = False
        Me.btnGetReport.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnGetReport.Location = New System.Drawing.Point(532, 4)
        Me.btnGetReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetReport.Name = "btnGetReport"
        Me.btnGetReport.Size = New System.Drawing.Size(134, 35)
        Me.btnGetReport.TabIndex = 51
        Me.btnGetReport.TabStop = False
        Me.btnGetReport.Text = "Get Report"
        Me.ToolTip1.SetToolTip(Me.btnGetReport, "Get a report. The report format is similar to what you see in the list of student" & _
        "s result box.")
        Me.btnGetReport.UseVisualStyleBackColor = True
        '
        'grdModule
        '
        Me.grdModule.AllowUserToAddRows = False
        Me.grdModule.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grdModule.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.grdModule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grdModule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdModule.Dock = System.Windows.Forms.DockStyle.Top
        Me.grdModule.Location = New System.Drawing.Point(0, 18)
        Me.grdModule.MultiSelect = False
        Me.grdModule.Name = "grdModule"
        Me.grdModule.ReadOnly = True
        Me.grdModule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdModule.Size = New System.Drawing.Size(880, 266)
        Me.grdModule.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.grdModule, "Click 'Show Enable section' button to view the Edit section and select a record a" & _
        "nd get the data in the Details section.")
        '
        'btnDelete
        '
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnDelete.Location = New System.Drawing.Point(136, 2)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(125, 32)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.btnDelete, "Delete the current selected information.")
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.btnUpdate.Location = New System.Drawing.Point(0, 2)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(125, 31)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.btnUpdate, "Update the changed data.")
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'cboEditFaculty
        '
        Me.cboEditFaculty.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditFaculty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEditFaculty.FormattingEnabled = True
        Me.cboEditFaculty.Items.AddRange(New Object() {"BBA", "BSC.IT", "FCHE"})
        Me.cboEditFaculty.Location = New System.Drawing.Point(109, 165)
        Me.cboEditFaculty.Name = "cboEditFaculty"
        Me.cboEditFaculty.Size = New System.Drawing.Size(261, 25)
        Me.cboEditFaculty.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.cboEditFaculty, "Faculty")
        '
        'cboEditYear
        '
        Me.cboEditYear.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboEditYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEditYear.FormattingEnabled = True
        Me.cboEditYear.Items.AddRange(New Object() {"0 | FCHE", "1 | 1st year", "2 | 2nd year", "3 | 3rd year"})
        Me.cboEditYear.Location = New System.Drawing.Point(109, 126)
        Me.cboEditYear.Name = "cboEditYear"
        Me.cboEditYear.Size = New System.Drawing.Size(261, 25)
        Me.cboEditYear.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.cboEditYear, "Year")
        '
        'txtEditCreditHours
        '
        Me.txtEditCreditHours.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditCreditHours.Location = New System.Drawing.Point(109, 85)
        Me.txtEditCreditHours.MaxLength = 3
        Me.txtEditCreditHours.Name = "txtEditCreditHours"
        Me.txtEditCreditHours.Size = New System.Drawing.Size(261, 25)
        Me.txtEditCreditHours.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtEditCreditHours, "Credti hours")
        '
        'txtEditModuleCode
        '
        Me.txtEditModuleCode.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditModuleCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEditModuleCode.Location = New System.Drawing.Point(109, 7)
        Me.txtEditModuleCode.MaxLength = 10
        Me.txtEditModuleCode.Name = "txtEditModuleCode"
        Me.txtEditModuleCode.Size = New System.Drawing.Size(261, 25)
        Me.txtEditModuleCode.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtEditModuleCode, "Module code")
        '
        'txtEditModuleName
        '
        Me.txtEditModuleName.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEditModuleName.Location = New System.Drawing.Point(109, 46)
        Me.txtEditModuleName.MaxLength = 70
        Me.txtEditModuleName.Name = "txtEditModuleName"
        Me.txtEditModuleName.Size = New System.Drawing.Size(261, 25)
        Me.txtEditModuleName.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtEditModuleName, "Module name")
        '
        'lblDetails
        '
        Me.lblDetails.AutoSize = True
        Me.lblDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblDetails.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDetails.Location = New System.Drawing.Point(656, 165)
        Me.lblDetails.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetails.Name = "lblDetails"
        Me.lblDetails.Size = New System.Drawing.Size(57, 17)
        Me.lblDetails.TabIndex = 61
        Me.lblDetails.Text = "Details"
        Me.lblDetails.Visible = False
        '
        'grpEdit
        '
        Me.grpEdit.Controls.Add(Me.TableLayoutPanel1)
        Me.grpEdit.Font = New System.Drawing.Font("Stencil", 9.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpEdit.Location = New System.Drawing.Point(503, 187)
        Me.grpEdit.Margin = New System.Windows.Forms.Padding(4)
        Me.grpEdit.Name = "grpEdit"
        Me.grpEdit.Padding = New System.Windows.Forms.Padding(4)
        Me.grpEdit.Size = New System.Drawing.Size(390, 262)
        Me.grpEdit.TabIndex = 60
        Me.grpEdit.TabStop = False
        Me.grpEdit.Visible = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.txtEditModuleName, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtEditCreditHours, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtEditModuleCode, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.cboEditFaculty, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.cboEditYear, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 4)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Font = New System.Drawing.Font("Cambria", 11.25!)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 19)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 6
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(382, 239)
        Me.TableLayoutPanel1.TabIndex = 60
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnDelete)
        Me.Panel2.Controls.Add(Me.btnUpdate)
        Me.Panel2.Location = New System.Drawing.Point(109, 198)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(261, 38)
        Me.Panel2.TabIndex = 60
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Module code:"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 128)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 17)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Year"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 50)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Module Name:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 89)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 17)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Credit hours:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 167)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Faculty:"
        '
        'pnlListOfStudent
        '
        Me.pnlListOfStudent.BackColor = System.Drawing.Color.Transparent
        Me.pnlListOfStudent.Controls.Add(Me.Label10)
        Me.pnlListOfStudent.Controls.Add(Me.lblResult)
        Me.pnlListOfStudent.Location = New System.Drawing.Point(290, 161)
        Me.pnlListOfStudent.Name = "pnlListOfStudent"
        Me.pnlListOfStudent.Size = New System.Drawing.Size(155, 20)
        Me.pnlListOfStudent.TabIndex = 62
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 3)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 17)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "List of modules:"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.BackColor = System.Drawing.Color.Transparent
        Me.lblResult.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(127, 3)
        Me.lblResult.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(17, 17)
        Me.lblResult.TabIndex = 50
        Me.lblResult.Text = "0"
        '
        'ModuleSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BackgroundImage = Global.ControlLibrary_IMS.My.Resources.Resources.background
        Me.Controls.Add(Me.pnlListOfStudent)
        Me.Controls.Add(Me.lblDetails)
        Me.Controls.Add(Me.grpEdit)
        Me.Controls.Add(Me.grpResult)
        Me.Controls.Add(Me.GroupBox5)
        Me.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(9, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "ModuleSearch"
        Me.Size = New System.Drawing.Size(913, 555)
        Me.GroupBox5.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.grpResult.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.grdModule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpEdit.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.pnlListOfStudent.ResumeLayout(False)
        Me.pnlListOfStudent.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cboFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents cboYear As System.Windows.Forms.ComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents btnViewAllModules As System.Windows.Forms.Button
    Friend WithEvents grpResult As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents grdModule As System.Windows.Forms.DataGridView
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtModuleCode As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents txtCreditHours As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents btnGetReport As System.Windows.Forms.Button
    Friend WithEvents btnShowEditSection As System.Windows.Forms.Button
    Friend WithEvents lblDetails As System.Windows.Forms.Label
    Friend WithEvents grpEdit As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtEditCreditHours As ControlLibrary_IMS.TextBoxNumeric
    Friend WithEvents txtEditModuleCode As ControlLibrary_IMS.TextBoxNumericCharacters
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents cboEditFaculty As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboEditYear As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents pnlListOfStudent As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents txtModuleName As ControlLibrary_IMS.TextBoxCharacterPunctuation
    Friend WithEvents txtEditModuleName As ControlLibrary_IMS.TextBoxCharacterPunctuation

End Class
