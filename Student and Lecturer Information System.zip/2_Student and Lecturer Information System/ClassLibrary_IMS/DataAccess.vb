﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class DataAccess
    Private dataSource As String = Configuration.ConfigurationSettings.AppSettings("DataSource")
    Private networkLibary As String = ConfigurationSettings.AppSettings("NetworkLibrary")
    Private username As String = ConfigurationSettings.AppSettings("Username")
    Private password As String = ConfigurationSettings.AppSettings("Password")


    Public objConnection As New SqlConnection With {.ConnectionString = "Data Source=" & dataSource & "; Network Library=" & networkLibary & _
        "; Initial Catalog=IcpInfo; user id=" & username & "; password=" & password & ";"}

    'Public objConnection As New SqlConnection With {.ConnectionString = "Data Source=GARBUJA_DBA\SQLEXPRESS; Initial Catalog=IcpInfo; user id=sa; password=winattitude;"}

    Public dtListForComboBox As DataTable

    Private objCommand As SqlCommand
    Public objDataAdapter As SqlDataAdapter
    Public objDataSet As DataSet
    Public objDataSetStudentCheck As DataSet

    'ERROR CAPTURING VARIABLES
    Public strExceptionAddDetails As String
    Public strExceptionGetAvailableID As String
    Public strExceptionGetListForComboBox As String
    Public strExceptionRunQueryAndFillDataSet As String
    Public strExceptionRunQueryAndFillDataSetIdCheck As String
    Public strExceptionDeleteDetails As String
    Public strExceptionRunQuery As String
    Public intCountRecord As Integer
    Public availableQuantity As Integer

    'INSERT A NEW AUTOINCREMENT COLUMN TABLE AND MERGE THE SOURCE TABLE TO IT
    Public Function AutoNumberedTable(ByVal sourceTable As DataTable)
        Dim resultTable As DataTable = New DataTable

        Dim autoNumberColumn As New DataColumn
        autoNumberColumn.DataType = GetType(Integer)
        autoNumberColumn.AutoIncrement = True
        autoNumberColumn.AutoIncrementSeed = 1
        autoNumberColumn.AutoIncrementStep = 1
        resultTable.Columns.Add(autoNumberColumn)
        resultTable.Merge(sourceTable)
        Return resultTable
    End Function

    'ADD DETAILS
    Public Sub AddDetails(command As SqlCommand)
        Try
            'Open the connection
            objConnection.Open()

            'Get the connection string
            command.Connection = objConnection

            'Execute the query
            command.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex1 As SqlClient.SqlException
            If ex1.Number = 2627 Then
                'Capture errors
                strExceptionAddDetails = "This data already exists!"
            Else
                strExceptionAddDetails = ex1.Message
            End If

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        Catch ex As Exception
            'Capture error
            strExceptionAddDetails = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    'GET THE HIGHEST ID
    Public Function GetAvailabeID(command As SqlCommand) As Integer
        Try
            'Open the connection
            objConnection.Open()

            'Get the connection string
            command.Connection = objConnection

            'Execute the query
            Dim intAvailableId As Integer = command.ExecuteScalar()

            'Close the connection
            objConnection.Close()

            Return intAvailableId
        Catch ex As Exception
            'Capture error
            strExceptionGetAvailableID = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()

            Return Nothing
        End Try
    End Function

    'GET THE AVAILABLE QUANTITY OF A BOOK
    Public Function GetAvailabilityOfBook(command As SqlCommand) As Boolean
        Try
            'Open the connection
            objConnection.Open()

            'Get the connection string
            command.Connection = objConnection

            'Execute the query
            Dim intAvailableQuantity As Integer = command.ExecuteScalar()

            'Close the connection
            objConnection.Close()

            If intAvailableQuantity > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            'Capture error
            strExceptionGetAvailableID = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()

            Return Nothing
        End Try
    End Function

    'GET THE LIST FOR THE COMBOBOX
    Public Sub GetListForComboBox(command As SqlCommand)
        Try
            dtListForComboBox = New DataTable

            'Open the connection
            objConnection.Open()

            'Get the connection string
            command.Connection = objConnection

            'Execute the query
            dtListForComboBox.Load(command.ExecuteReader)

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture error
            strExceptionGetListForComboBox = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    'METHOD TO EXECUTE GENERAL QUERY AND SET TABLE TO DATASET
    Public Sub RunQueryAndFillDataSetIdCheck(query As String)
        Try
            'Open the connection
            objConnection.Open()

            'Create a command
            objCommand = New SqlCommand(query, objConnection)

            'Fill dataset
            objDataAdapter = New SqlDataAdapter(objCommand)
            objDataSetStudentCheck = New DataSet
            objDataAdapter.Fill(objDataSetStudentCheck)

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionRunQueryAndFillDataSetIdCheck = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub


    'METHOD TO EXECUTE GENERAL QUERY AND SET TABLE TO DATASET
    Public Sub RunQueryAndFillDataSet(query As String)
        Try
            'Open the connection
            objConnection.Open()

            'Create a command
            objCommand = New SqlCommand(query, objConnection)

            'Fill dataset
            objDataAdapter = New SqlDataAdapter(objCommand)
            objDataSet = New DataSet
            objDataAdapter.Fill(objDataSet)

            'Execute the query
            'objCommand.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionRunQueryAndFillDataSet = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    'METHOD TO EXECUTE GENERAL QUERY-THAT DONOT RETURN VALUE
    Public Sub RunQuery(command As SqlCommand)
        Try
            'Open the connection
            objConnection.Open()

            'Get the connection 
            command.Connection = objConnection

            intCountRecord = New Integer

            'Execute the query
            intCountRecord = command.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex1 As SqlClient.SqlException
            If ex1.Number = 2627 Then
                'Capture errors
                strExceptionRunQuery = "This data already exists!"
            ElseIf ex1.Number = 547 Then
                'Capture errors
                strExceptionRunQuery = "This data doesnot exist!"
            Else
                strExceptionAddDetails = ex1.Message
            End If
            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        Catch ex As Exception
            If strExceptionRunQuery = "" Then
                'Capture errors
                strExceptionRunQuery = ex.Message
            End If

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub
End Class
