﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class BackupRestore
    Private dataSource As String = Configuration.ConfigurationSettings.AppSettings("DataSource")
    Private networkLibary As String = ConfigurationSettings.AppSettings("NetworkLibrary")
    Private username As String = ConfigurationSettings.AppSettings("Username")
    Private password As String = ConfigurationSettings.AppSettings("Password")

    Public objConnection As New SqlConnection With {.ConnectionString = "Data Source=" & dataSource & "; Network Library=" & networkLibary & _
        "; Initial Catalog=master; user id=" & username & "; password=" & password & ";"}

    'Public objConnection As New SqlConnection With {.ConnectionString = "Data Source=GARBUJA_DBA\SQLEXPRESS; Initial Catalog=Master; user id=sa; password=winattitude;"}
    Private intCountRecord As Integer
    Private objCommand As SqlCommand
    Public strExceptionRunQuery As String

    'CHECK WHETHER THE CONNECTION TO SQL SERVER IS OK OR NOT
    Public Function HasConnection() As Boolean
        Try
            'Open the connection
            objConnection.Open()

            'Close the connection
            objConnection.Close()

            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Connection to SQL SERVER")

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()

            Return False
        End Try
    End Function
    'METHOD TO EXECUTE GENERAL QUERY-THAT DONOT RETURN VALUE
    Public Sub RunQuery(query As String)
        Try
            'Open the connection
            objConnection.Open()

            objCommand = New SqlCommand
            'Get the connection 
            objCommand.Connection = objConnection
            objCommand.CommandText = query


            intCountRecord = New Integer

            'Execute the query
            intCountRecord = objCommand.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex1 As SqlClient.SqlException
            If ex1.Number = 3201 Then
                'Capture errors
                strExceptionRunQuery = "The selected backup file doesn't exists!"
            Else
                'Capture errors
                strExceptionRunQuery = ex1.Message
                'ElseIf ex1.Number = 547 Then
                '    'Capture errors
                '    strExceptionRunQuery = "This data doesnot exist!"
            End If
            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        Catch ex As Exception
            If strExceptionRunQuery <> "" Then
                'Capture errors
                strExceptionRunQuery = ex.Message
            End If

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub
End Class
