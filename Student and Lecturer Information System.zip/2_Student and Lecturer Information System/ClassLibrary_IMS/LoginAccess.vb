﻿Imports System.Data.SqlClient
Imports System.Configuration


Public Class LoginAccess
    Private dataSource As String = ConfigurationSettings.AppSettings("DataSource")
    Private networkLibary As String = ConfigurationSettings.AppSettings("NetworkLibrary")
    Private username As String = ConfigurationSettings.AppSettings("Username")
    Private password As String = ConfigurationSettings.AppSettings("Password")

    Private objConnection As New SqlConnection With {.ConnectionString = "Data Source=" & dataSource & "; Network Library=" & networkLibary & _
        ";Initial Catalog=IcpAdmin; user id=" & username & "; password=" & password & ";"}

    'Private objConnection As New SqlConnection With {.ConnectionString = "Data Source=GARBUJA_DBA\SQLEXPRESS; Initial Catalog=IcpAdmin; user id=sa; password=winattitude;"}

    Public objCommand As SqlCommand
    Private objDataAdapter As SqlDataAdapter
    Public objDataSet As DataSet
    Public objDataSetLogin As DataSet


    Public intCountRecord As Integer

    'ERROR CAPUTRING VARIABLES
    Public strExceptionRunQueryToLogin As String
    Public strExceptionRunQuery As String
    Public strExceptionRunQueryAndFillDataSet As String
    Public strExceptionSetPassword As String


    'VARIABLES FOR FORM-MANAGEUSER
    Public strExceptionCreateUser As String

    'CHECK WHETHER THE CONNECTION TO SQL SERVER IS OK OR NOT
    Public Function HasConnection() As Boolean
        Try
            'Open the connection
            objConnection.Open()

            'Close the connection
            objConnection.Close()

            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Connection to SQL SERVER")

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()

            Return False
        End Try
    End Function

    'CHECK WHETHER THE USER ACCOUNT IS VALID ACCOUNT OR NOT
    Public Sub RunQueryToLogin(ByVal userName As String, ByVal passWord As String)
        Try
            'Open the connection
            objConnection.Open()

            'Create a command
            objCommand = New SqlCommand("SELECT Count(Username) As UserCount " & _
                             "FROM ADMIN " & _
                             "WHERE Username= " & "@userName" & " COLLATE SQL_Latin1_General_CP1_CS_AS " & _
                             "AND Password= " & "@passWord" & " COLLATE SQL_Latin1_General_CP1_CS_AS;", objConnection)
            'MsgBox(userName & passWord)
            objCommand.Parameters.AddWithValue("@userName", userName)
            objCommand.Parameters.AddWithValue("@passWord", passWord)

            'Fill dataset
            objDataAdapter = New SqlDataAdapter(objCommand)
            objDataSetLogin = New DataSet
            objDataAdapter.Fill(objDataSetLogin)

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionRunQueryToLogin = ex.Message

            'MsgBox(ex.Message, MsgBoxStyle.Critical, "Query Execution")

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    'CHANGE THE PASSWORD OF THE USER
    Public Sub SetPassword(ByVal userName As String, ByVal passWord As String)
        Try
            'Open the connection
            objConnection.Open()

            'Create a command
            objCommand = New SqlCommand("UPDATE ADMIN  " & _
                             "SET Password = @passWord " & _
                             "WHERE Username= @userName ", objConnection)
            objCommand.Parameters.AddWithValue("@userName", userName)
            objCommand.Parameters.AddWithValue("@passWord", passWord)

            'Execute the query
            intCountRecord = objCommand.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionSetPassword = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    'METHOD TO EXECUTE GENERAL QUERY-THAT DONOT RETURN VALUE
    Public Sub RunQuery(command As SqlCommand)
        Try
            'Open the connection
            objConnection.Open()

            'Get the connection 
            command.Connection = objConnection

            'Execute the query
            intCountRecord = command.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionRunQuery = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub

    'METHOD TO EXECUTE GENERAL QUERY AND SET TABLE TO DATASET
    Public Sub RunQueryAndFillDataSet(query As String)
        Try
            'Open the connection
            objConnection.Open()

            'Create a command
            objCommand = New SqlCommand(query, objConnection)

            'Fill dataset
            objDataAdapter = New SqlDataAdapter(objCommand)
            objDataSet = New DataSet
            objDataAdapter.Fill(objDataSet)

            'Execute the query
            objCommand.ExecuteNonQuery()

            'Close the connection
            objConnection.Close()
        Catch ex As Exception
            'Capture errors
            strExceptionRunQueryAndFillDataSet = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub


    'FORM MANAGER USER METHODS
    Public Sub CreateUser(Command As SqlCommand)
        Try
            'Open the connection
            objConnection.Open()

            'Get the connection
            Command.Connection = objConnection

            'Execute the query
            intCountRecord = Command.ExecuteNonQuery()

            'Close the connection

            objConnection.Close()
        Catch ex1 As SqlClient.SqlException
            If ex1.Number = 2627 Then
                'Capture errors
                strExceptionCreateUser = "The account with the same username already exists. Please provide unique username."
            Else
                strExceptionCreateUser = ex1.Message
            End If

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        Catch ex As Exception
            'Capture error message
            strExceptionCreateUser = ex.Message

            'Make sure that the connection is closed
            If objConnection.State <> ConnectionState.Closed Then objConnection.Close()
        End Try
    End Sub
End Class
