﻿Public Class GblAccessItem
    Private Shared strUsername As String
    Private Shared strType As String
    Private Shared dtmLastLoginDate As DateTime

    'Variable for Student Additional View--to check if email address or phone radio button is selected
    Public Shared blnStudentPhone As Boolean
    'Variable for Lecturer Additional View
    Public Shared blnLecturerPhone As Boolean

    'Datatable
    Private Shared dtStudentSearch As DataTable
    Private Shared dtStudentView As DataTable


    Private Shared dtLecturerSearch As DataTable
    Private Shared dtLecturerView As DataTable

    Private Shared dtModuleSearch As DataTable
    Private Shared dtModuleView As DataTable

    Private Shared dtGuardianSearchView As DataTable

    Private Shared dtBookSearch As DataTable
    Private Shared dtBookView As DataTable

    Private Shared dtIssueSearch As DataTable
    Private Shared dtIssueView As DataTable

    Private Shared dtStudentModule As DataTable
    Private Shared dtLecturerModule As DataTable

    Private Shared dtAdmissionAdd As DataTable
    Private Shared dtAdmissionView As DataTable

    Private Shared dtStudentAdditionalView As DataTable
    Private Shared dtLecturerAdditionalView As DataTable

    Public Shared Property gstrUsername As String
        Get
            Return strUsername
        End Get
        Set(value As String)
            strUsername = value
        End Set
    End Property

    Public Shared Property gstrType As String
        Get
            Return strType
        End Get
        Set(value As String)
            strType = value
        End Set
    End Property
    Public Shared Property gdtmLastLoginDate As DateTime
        Get
            Return dtmLastLoginDate
        End Get
        Set(value As DateTime)
            dtmLastLoginDate = value
        End Set
    End Property


    


    'LIST OF SHARED PROPERTY FOR DATATABLE
    Public Shared Property DataTableStudentSearch As DataTable
        Get
            Return dtStudentSearch
        End Get
        Set(value As DataTable)
            dtStudentSearch = value
        End Set
    End Property

    Public Shared Property DataTableStudentView As DataTable
        Get
            Return dtStudentView
        End Get
        Set(value As DataTable)
            dtStudentView = value
        End Set
    End Property

    Public Shared Property DataTableLecturerSearch As DataTable
        Get
            Return dtLecturerSearch
        End Get
        Set(value As DataTable)
            dtLecturerSearch = value
        End Set
    End Property

    Public Shared Property DataTableLecturerView As DataTable
        Get
            Return dtLecturerView
        End Get
        Set(value As DataTable)
            dtLecturerView = value
        End Set
    End Property

    Public Shared Property DataTableModuleSearch As DataTable
        Get
            Return dtModuleSearch
        End Get
        Set(value As DataTable)
            dtModuleSearch = value
        End Set
    End Property

    Public Shared Property DataTableModuleView As DataTable
        Get
            Return dtModuleView
        End Get
        Set(value As DataTable)
            'dtModuleView = AutoNumberedTable(value)
            dtModuleView = value
        End Set
    End Property

    Public Shared Property DataTableGuardianSearchView As DataTable
        Get
            Return dtGuardianSearchView
        End Get
        Set(value As DataTable)
            dtGuardianSearchView = value
        End Set
    End Property

    Public Shared Property DataTableBookSearch As DataTable
        Get
            Return dtBookSearch
        End Get
        Set(value As DataTable)
            dtBookSearch = value
        End Set
    End Property

    Public Shared Property DataTableBookView As DataTable
        Get
            Return dtBookView
        End Get
        Set(value As DataTable)
            dtBookView = value
        End Set
    End Property

    Public Shared Property DataTableIssueSearch As DataTable
        Get
            Return dtIssueSearch
        End Get
        Set(value As DataTable)
            dtIssueSearch = value
        End Set
    End Property

    Public Shared Property DataTableIssueView As DataTable
        Get
            Return dtIssueView
        End Get
        Set(value As DataTable)
            dtIssueView = value
        End Set
    End Property

    Public Shared Property DataTableStudentModule As DataTable
        Get
            Return dtStudentModule
        End Get
        Set(value As DataTable)
            dtStudentModule = value
        End Set
    End Property

    Public Shared Property DataTableLecturerModule As DataTable
        Get
            Return dtLecturerModule
        End Get
        Set(value As DataTable)
            dtLecturerModule = value
        End Set
    End Property

    Public Shared Property DataTableAdmissionAdd As DataTable
        Get
            Return dtAdmissionAdd
        End Get
        Set(value As DataTable)
            dtAdmissionAdd = value
        End Set
    End Property

    Public Shared Property DataTableAdmissionView As DataTable
        Get
            Return dtAdmissionView
        End Get
        Set(value As DataTable)
            dtAdmissionView = value
        End Set
    End Property

    Public Shared Property DataTableStudentAdditionalView As DataTable
        Get
            Return dtStudentAdditionalView
        End Get
        Set(value As DataTable)
            dtStudentAdditionalView = value
        End Set
    End Property

    Public Shared Property DataTableLecturerAdditionalView As DataTable
        Get
            Return dtLecturerAdditionalView
        End Get
        Set(value As DataTable)
            dtLecturerAdditionalView = value
        End Set
    End Property
End Class
